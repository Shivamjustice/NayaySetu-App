package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NyaySetu", appName)
  }

  @Test
  fun `firestore database id is configured and non-empty`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dbId = context.getString(R.string.firestore_database_id)
    org.junit.Assert.assertTrue(dbId.isNotBlank())
    org.junit.Assert.assertTrue(dbId.contains("nyaysetu"))
  }

  @Test
  fun `session persistence restores active user`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    com.example.data.NyaySetuRepository.init(context)
    val testUser = com.example.model.AppUser(
      id = "test_usr_123",
      username = "test_villager",
      passwordHash = "pass123",
      name = "राजू सहरिया",
      phone = "9826000000",
      district = "श्योपुर",
      block = "विजयपुर",
      village = "पीपलखेड़ा",
      role = com.example.model.UserRole.COMMUNITY_MEMBER
    )
    com.example.data.NyaySetuRepository.addGoogleUser(testUser)
    com.example.data.NyaySetuRepository.switchUser(testUser)
    assertEquals("test_usr_123", com.example.data.NyaySetuRepository.currentUser.value?.id)

    // Re-init should restore saved user session without needing to log in again
    com.example.data.NyaySetuRepository.restorePersistedSession()
    assertEquals("test_usr_123", com.example.data.NyaySetuRepository.currentUser.value?.id)
  }
}
