package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.components.BottomNavBar
import com.example.ui.components.MoreModulesSheet
import com.example.ui.components.NotificationDialog
import com.example.ui.components.TopBar
import com.example.ui.screens.*
import com.example.ui.theme.JhsTeal
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.NyaySetuViewModel
import com.example.viewmodel.ScreenTab

class MainActivity : ComponentActivity() {

  private val viewModel: NyaySetuViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    com.example.data.NyaySetuRepository.init(this)
    com.example.data.FirestoreSyncManager.init(this)

    // Attempt silent auto-sign-in so users don't have to re-enter credentials
    val credentialManager = androidx.credentials.CredentialManager.create(this)
    com.example.data.FirestoreSyncManager.attemptAutoSignIn(
      context = this,
      credentialManager = credentialManager,
      onAuthSuccess = { firebaseUser ->
        viewModel.onGoogleSignInSuccess(firebaseUser)
      },
      onUnauthenticated = {
        // App will display AuthScreen
      },
      scope = lifecycleScope
    )

    setContent {
      val highContrast by viewModel.highContrastMode.collectAsState()
      MyApplicationTheme(highContrast = highContrast) {
        NyaySetuApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun NyaySetuApp(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val activeTab by viewModel.activeTab.collectAsState()
  val isWizardOpen by viewModel.isWizardOpen.collectAsState()
  val isNotificationOpen by viewModel.isNotificationDrawerOpen.collectAsState()
  var showMoreSheet by remember { mutableStateOf(false) }

  // 1. Mandatory Login Gate: When currentUser is null, display secure Login Page
  if (currentUser == null) {
    AuthScreen(viewModel = viewModel)
    return
  }

  // 2. Main Authenticated Platform Scaffold
  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    topBar = {
      TopBar(viewModel = viewModel)
    },
    bottomBar = {
      BottomNavBar(
        viewModel = viewModel,
        onOpenMoreMenu = { showMoreSheet = true }
      )
    },
    floatingActionButton = {
      if (activeTab != ScreenTab.ASSISTANT) {
        ExtendedFloatingActionButton(
          onClick = { viewModel.setTab(ScreenTab.ASSISTANT) },
          containerColor = JhsTeal,
          contentColor = Color.White,
          icon = { Icon(Icons.Default.Mic, contentDescription = "AI Voice Assistant") },
          text = { Text(viewModel.tr("AI बोलकर पूछें", "Ask AI Voice", "AI Bolkar Poochein"), fontWeight = FontWeight.Bold, fontSize = 12.sp) },
          modifier = Modifier.testTag("floating_ai_assistant_button")
        )
      }
    }
  ) { innerPadding ->
    // Android back navigation: Return to Home if on sub-screens
    BackHandler(enabled = activeTab != ScreenTab.HOME) {
      viewModel.setTab(ScreenTab.HOME)
    }

    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (activeTab) {
        ScreenTab.HOME -> HomeScreen(viewModel = viewModel)
        ScreenTab.SCHEMES -> SchemesScreen(viewModel = viewModel)
        ScreenTab.TRACK -> CaseTrackerScreen(viewModel = viewModel)
        ScreenTab.BUILDER -> ApplicationBuilderScreen(viewModel = viewModel)
        ScreenTab.RIGHTS -> KnowledgeBankScreen(viewModel = viewModel)
        ScreenTab.RTI -> RtiCentreScreen(viewModel = viewModel)
        ScreenTab.VILLAGE_PROFILE -> VillageDigitalProfileScreen(viewModel = viewModel)
        ScreenTab.GRAM_SABHA -> GramSabhaScreen(viewModel = viewModel)
        ScreenTab.LIVELIHOOD -> LivelihoodHubScreen(viewModel = viewModel)
        ScreenTab.WOMEN_CHILD -> WomenChildSupportScreen(viewModel = viewModel)
        ScreenTab.STORIES -> StorytellingScreen(viewModel = viewModel)
        ScreenTab.LEARNING -> LearningCentreScreen(viewModel = viewModel)
        ScreenTab.ABOUT_JHS -> AboutJhsScreen(viewModel = viewModel)
        ScreenTab.PROFILE -> ProfileScreen(viewModel = viewModel)
        ScreenTab.DIRECTORY -> ExpertDirectoryScreen(viewModel = viewModel)
        ScreenTab.HELPLINE -> HelplineScreen(viewModel = viewModel)
        ScreenTab.VOLUNTEER -> VolunteerWorkspaceScreen(viewModel = viewModel)
        ScreenTab.ADMIN -> AdminDashboardScreen(viewModel = viewModel)
        ScreenTab.ASSISTANT -> SupportAssistantScreen(viewModel = viewModel)
        ScreenTab.PRIORITIES -> VillagePrioritiesScreen(viewModel = viewModel)
      }

      // Full Support Request Wizard Modal (accessible from any screen)
      if (isWizardOpen) {
        SupportRequestWizardScreen(viewModel = viewModel)
      }

      // More Services & Modules Bottom Sheet
      if (showMoreSheet) {
        MoreModulesSheet(
          viewModel = viewModel,
          onDismiss = { showMoreSheet = false }
        )
      }

      // Notification & Urgent Alerts Dialog
      if (isNotificationOpen) {
        NotificationDialog(
          viewModel = viewModel,
          onDismiss = { viewModel.isNotificationDrawerOpen.value = false }
        )
      }
    }
  }
}
