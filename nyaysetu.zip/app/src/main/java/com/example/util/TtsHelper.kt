package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsHelper(context: Context) : TextToSpeech.OnInitListener {

  private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
  private var isInitialized = false
  private var lastSpokenText: String = ""
  private var lastIsHindi: Boolean = true

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  override fun onInit(status: Int) {
    if (status == TextToSpeech.SUCCESS) {
      isInitialized = true
      tts?.language = Locale("hi", "IN")
      tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
          _isSpeaking.value = true
        }

        override fun onDone(utteranceId: String?) {
          _isSpeaking.value = false
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
          _isSpeaking.value = false
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
          _isSpeaking.value = false
        }
      })
    }
  }

  fun speak(text: String, isHindi: Boolean = true, rate: Float = 0.95f) {
    if (!isInitialized || tts == null) return
    stop()
    lastSpokenText = text
    lastIsHindi = isHindi
    val locale = if (isHindi) Locale("hi", "IN") else Locale("en", "IN")
    tts?.language = locale
    tts?.setSpeechRate(rate)
    _isSpeaking.value = true
    val utteranceId = "NyaySetuTTS_${System.currentTimeMillis()}"
    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
  }

  fun repeatLast() {
    if (lastSpokenText.isNotBlank()) {
      speak(lastSpokenText, lastIsHindi)
    }
  }

  fun stop() {
    tts?.stop()
    _isSpeaking.value = false
  }

  fun shutdown() {
    tts?.stop()
    tts?.shutdown()
    tts = null
  }
}
