package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object NyaySetuRepository {

  // Users & Auth
  private val _users = MutableStateFlow<List<AppUser>>(emptyList())
  val users: StateFlow<List<AppUser>> = _users.asStateFlow()

  private val _currentUser = MutableStateFlow<AppUser?>(null)
  val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

  private var appContext: android.content.Context? = null

  fun init(context: android.content.Context) {
    appContext = context.applicationContext
    restorePersistedSession()
  }

  fun addGoogleUser(user: AppUser) {
    if (_users.value.none { it.id == user.id }) {
      _users.value = _users.value + user
    }
  }

  fun restorePersistedSession() {
    val ctx = appContext ?: return
    val prefs = ctx.getSharedPreferences("jhs_user_session", android.content.Context.MODE_PRIVATE)
    val savedUserId = prefs.getString("active_user_id", null)
    if (!savedUserId.isNullOrBlank()) {
      var user = _users.value.find { it.id == savedUserId && !it.isSuspended }
      if (user == null) {
        // Check if cached Google User details exist
        val savedName = prefs.getString("active_user_name", null)
        val savedEmail = prefs.getString("active_user_email", null)
        if (!savedName.isNullOrBlank()) {
          user = AppUser(
            id = savedUserId,
            username = savedEmail?.substringBefore("@") ?: "user_$savedUserId",
            passwordHash = "",
            name = savedName,
            phone = prefs.getString("active_user_phone", "") ?: "",
            email = savedEmail ?: "",
            district = "श्योपुर (MP)",
            block = "विजयपुर",
            village = "पीपलखेड़ा",
            role = UserRole.COMMUNITY_MEMBER,
            avatarColorHex = 0xFF176B63,
            isVerifiedByAdmin = true,
            bio = "Google सत्यापित JHS नागरिक"
          )
          addGoogleUser(user)
        }
      }
      if (user != null && !user.isSuspended) {
        _currentUser.value = user
        addAuditLog("SESSION_RESTORED", "User @${user.username} session auto-restored", "auth", user.id)
      }
    }
  }

  private fun persistSessionUserId(userId: String?, user: AppUser? = null) {
    val ctx = appContext ?: return
    val prefs = ctx.getSharedPreferences("jhs_user_session", android.content.Context.MODE_PRIVATE)
    prefs.edit().apply {
      if (userId != null) {
        putString("active_user_id", userId)
        if (user != null) {
          putString("active_user_name", user.name)
          putString("active_user_email", user.email)
          putString("active_user_phone", user.phone)
        }
      } else {
        remove("active_user_id")
        remove("active_user_name")
        remove("active_user_email")
        remove("active_user_phone")
      }
      apply()
    }
  }

  // Core Data
  private val _cases = MutableStateFlow<List<CaseRecord>>(emptyList())
  val cases: StateFlow<List<CaseRecord>> = _cases.asStateFlow()

  private val _stories = MutableStateFlow<List<StoryItem>>(emptyList())
  val stories: StateFlow<List<StoryItem>> = _stories.asStateFlow()

  private val _knowledgeArticles = MutableStateFlow<List<KnowledgeArticle>>(emptyList())
  val knowledgeArticles: StateFlow<List<KnowledgeArticle>> = _knowledgeArticles.asStateFlow()

  private val _applicationTemplates = MutableStateFlow<List<ApplicationTemplate>>(emptyList())
  val applicationTemplates: StateFlow<List<ApplicationTemplate>> = _applicationTemplates.asStateFlow()

  private val _villagePriorities = MutableStateFlow<List<VillagePriorityItem>>(emptyList())
  val villagePriorities: StateFlow<List<VillagePriorityItem>> = _villagePriorities.asStateFlow()

  private val _livelihoods = MutableStateFlow<List<LivelihoodOpportunity>>(emptyList())
  val livelihoods: StateFlow<List<LivelihoodOpportunity>> = _livelihoods.asStateFlow()

  private val _experts = MutableStateFlow<List<ExpertListing>>(emptyList())
  val experts: StateFlow<List<ExpertListing>> = _experts.asStateFlow()

  private val _helplines = MutableStateFlow<List<HelplineItem>>(emptyList())
  val helplines: StateFlow<List<HelplineItem>> = _helplines.asStateFlow()

  private val _volunteerVisits = MutableStateFlow<List<VolunteerVisitRecord>>(emptyList())
  val volunteerVisits: StateFlow<List<VolunteerVisitRecord>> = _volunteerVisits.asStateFlow()

  private val _notifications = MutableStateFlow<List<InAppNotification>>(emptyList())
  val notifications: StateFlow<List<InAppNotification>> = _notifications.asStateFlow()

  private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
  val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

  private val _assistantMessages = MutableStateFlow<List<AssistantMessage>>(emptyList())
  val assistantMessages: StateFlow<List<AssistantMessage>> = _assistantMessages.asStateFlow()

  // AI Voice Assistant State & Governance
  private val _aiAssistantSettings = MutableStateFlow(AiAssistantSettings())
  val aiAssistantSettings: StateFlow<AiAssistantSettings> = _aiAssistantSettings.asStateFlow()

  private val _unansweredQuestions = MutableStateFlow<List<UnansweredQuestionLog>>(listOf(
    UnansweredQuestionLog(
      id = "gap-seed-1",
      query = "सहरिया जनजाति के बच्चों के लिए विशेष कोचिंग छात्रवृत्ति",
      category = "शिक्षा व छात्रवृत्ति",
      timestamp = "2026-10-28",
      frequencyCount = 4,
      isResolved = false,
      suggestedAction = "म.प्र. जनजातीय कार्य विभाग की आकांक्षा योजना व कोचिंग नियम जोड़ें"
    ),
    UnansweredQuestionLog(
      id = "gap-seed-2",
      query = "सोलर पंप 90% सब्सिडी योजना में बोरवेल की न्यूनतम गहराई नियम",
      category = "कृषि व ऊर्जा",
      timestamp = "2026-10-29",
      frequencyCount = 3,
      isResolved = false,
      suggestedAction = "कुसुम-बी योजना म.प्र. ऊर्जा विकास निगम के नियम सत्यापित करें"
    )
  ))
  val unansweredQuestions: StateFlow<List<UnansweredQuestionLog>> = _unansweredQuestions.asStateFlow()

  private val _aiFeedbackRecords = MutableStateFlow<List<AiFeedbackRecord>>(emptyList())
  val aiFeedbackRecords: StateFlow<List<AiFeedbackRecord>> = _aiFeedbackRecords.asStateFlow()

  // MODULE TWO & THREE: Government Schemes & Verification System
  private val _schemes = MutableStateFlow<List<GovernmentScheme>>(emptyList())
  val schemes: StateFlow<List<GovernmentScheme>> = _schemes.asStateFlow()

  private val _schemeErrorReports = MutableStateFlow<List<SchemeErrorReport>>(emptyList())
  val schemeErrorReports: StateFlow<List<SchemeErrorReport>> = _schemeErrorReports.asStateFlow()

  // MODULE SIX: RTI Assistance Centre
  private val _rtiAuthorities = MutableStateFlow<List<RtiAuthority>>(emptyList())
  val rtiAuthorities: StateFlow<List<RtiAuthority>> = _rtiAuthorities.asStateFlow()

  private val _rtiDrafts = MutableStateFlow<List<RtiDraft>>(emptyList())
  val rtiDrafts: StateFlow<List<RtiDraft>> = _rtiDrafts.asStateFlow()

  // MODULE SEVEN: Village Digital Profiles
  private val _villageDigitalProfiles = MutableStateFlow<List<VillageDigitalProfile>>(emptyList())
  val villageDigitalProfiles: StateFlow<List<VillageDigitalProfile>> = _villageDigitalProfiles.asStateFlow()

  // MODULE EIGHT: Gram Sabha & Community Action
  private val _gramSabhaMeetings = MutableStateFlow<List<GramSabhaMeeting>>(emptyList())
  val gramSabhaMeetings: StateFlow<List<GramSabhaMeeting>> = _gramSabhaMeetings.asStateFlow()

  private val _communityActionIssues = MutableStateFlow<List<CommunityActionIssue>>(emptyList())
  val communityActionIssues: StateFlow<List<CommunityActionIssue>> = _communityActionIssues.asStateFlow()

  // MODULE TEN: Women and Child Support Corner
  private val _womenChildResources = MutableStateFlow<List<WomenChildResource>>(emptyList())
  val womenChildResources: StateFlow<List<WomenChildResource>> = _womenChildResources.asStateFlow()

  // MODULE TWELVE: Learning and Awareness Centre
  private val _learningGuides = MutableStateFlow<List<LearningGuide>>(emptyList())
  val learningGuides: StateFlow<List<LearningGuide>> = _learningGuides.asStateFlow()

  init {
    loadSeedData()
  }

  private fun loadSeedData() {
    // 1. Initial Users with separate credentials
    val seedUsers = listOf(
      AppUser(
        id = "usr_01",
        username = "ramesh_sahariya",
        passwordHash = "pass123",
        name = "रामदयाल सहरिया (Ramdayal)",
        phone = "9826194821",
        email = "ramesh@nyaysetu.org",
        district = "श्योपुर (Sheopur)",
        block = "कराहल (Karahal)",
        village = "सहरिया डांडा (Sahariya Danda)",
        role = UserRole.COMMUNITY_MEMBER,
        avatarColorHex = 0xFF176B63
      ),
      AppUser(
        id = "usr_super_1",
        username = "Meenakshijusticehub",
        passwordHash = "admin123",
        name = "मीनाक्षी (Super Admin - JHS)",
        phone = "7440323972",
        email = "meenakshi@nyaysetu.org",
        district = "ग्वालियर (Gwalior)",
        block = "ग्वालियर",
        village = "सिटी सेंटर, ग्वालियर",
        role = UserRole.SUPER_ADMIN,
        avatarColorHex = 0xFF176B63
      ),
      AppUser(
        id = "usr_super_2",
        username = "Sanjeevjusticehub",
        passwordHash = "admin123",
        name = "संजीव (Super Admin - JHS)",
        phone = "7440323972",
        email = "sanjeev@nyaysetu.org",
        district = "ग्वालियर (Gwalior)",
        block = "ग्वालियर",
        village = "सिटी सेंटर, ग्वालियर",
        role = UserRole.SUPER_ADMIN,
        avatarColorHex = 0xFFC56A3D
      ),
      AppUser(
        id = "usr_super_3",
        username = "Hardikjusticehub",
        passwordHash = "admin123",
        name = "हार्दिक (Super Admin - JHS)",
        phone = "7440323972",
        email = "hardik@nyaysetu.org",
        district = "ग्वालियर (Gwalior)",
        block = "ग्वालियर",
        village = "सिटी सेंटर, ग्वालियर",
        role = UserRole.SUPER_ADMIN,
        avatarColorHex = 0xFFE3A72F
      )
    )
    _users.value = seedUsers

    // Mandatory: App starts at secure Login Page
    _currentUser.value = null

    // Load Modules Seed Data
    _schemes.value = SchemesSeedData.schemes
    _rtiAuthorities.value = RtiAndCommunitySeedData.rtiAuthorities
    _villageDigitalProfiles.value = RtiAndCommunitySeedData.villageProfiles
    _gramSabhaMeetings.value = RtiAndCommunitySeedData.gramSabhaMeetings
    _communityActionIssues.value = RtiAndCommunitySeedData.communityActionIssues
    _womenChildResources.value = RtiAndCommunitySeedData.womenChildResources
    _learningGuides.value = RtiAndCommunitySeedData.learningGuides

    // 2. Cases
    _cases.value = listOf(
      CaseRecord(
        id = "NYAY-2026-0041",
        verificationPin = "4192",
        userId = "usr_01",
        category = CaseCategory.FOREST_RIGHTS,
        title = "वनाधिकार दावा (फॉर्म क) - व्यक्तिगत वनाधिकार पट्टा आवेदन",
        applicantName = "रामदयाल सहरिया",
        isAnonymous = false,
        contactPhone = "9826194821",
        preferredLanguage = "hi",
        district = "श्योपुर (Sheopur)",
        block = "कराहल (Karahal)",
        gramPanchayat = "गोरस (Goras)",
        village = "सहरिया डांडा (Sahariya Danda)",
        description = "हम 3 पीढ़ियों से 3.5 एकड़ वनभूमि पर पारंपरिक खेती कर रहे हैं। 2005 से पूर्व के प्रमाण हैं, परंतु वन समिति द्वारा अभी तक भौतिक सत्यापन आगे नहीं भेजा गया।",
        assistanceRequested = "ग्राम सभा वनाधिकार समिति (FRC) में भौतिक सत्यापन व उपखंड स्तरीय समिति (SDLC) में दावा प्रस्तुतिकरण में विधिक मार्गदर्शन।",
        relevantDate = "2026-09-15",
        status = CaseStatus.APP_IN_PREP,
        priority = PriorityLevel.HIGH,
        assignedManagerName = "सुनीता शर्मा (Sunita Sharma)",
        assignedVolunteerName = "रमेश सहरिया (Ramesh Sahariya)",
        dateReceived = "2026-10-12",
        lastActionDate = "2026-10-25",
        nextFollowUpDate = "2026-11-05",
        documentChecklist = listOf(
          DocumentChecklistItem("d1", "मतदाता परिचय पत्र / राशन कार्ड", "ग्राम निवास व परिवार पहचान", true, true),
          DocumentChecklistItem("d2", "बुजुर्गों का पंचनामा बयान", "13 दिसंबर 2005 से पूर्व का कब्जा साक्ष्य", true, true),
          DocumentChecklistItem("d3", "वन विभाग की पुरानी रसीद / जुर्माने का प्रमाण", "पारंपरिक जोत का ऐतिहासिक अभिलेख", false, true),
          DocumentChecklistItem("d4", "ग्राम सभा वनाधिकार समिति (FRC) प्रस्ताव", "प्रारूप क पर ग्राम सभा अनुशंसा", true, false, "अगली ग्राम सभा में प्रस्तुत होना है")
        ),
        referrals = listOf(
          CaseReferral(
            id = "ref-01",
            expertOrAgencyId = "exp-01",
            expertName = "जिला विधिक सेवा प्राधिकरण (DLSA)",
            agencyName = "जिला न्यायालय, श्योपुर",
            category = "Legal Aid & Paralegal Support",
            referredDate = "2026-10-18",
            consentObtained = true,
            informationSharedSummary = "वनाधिकार दावा प्रारूप एवं आवश्यक साक्ष्यों का परीक्षण हेतु विधिक सहायता आग्रह।",
            followUpStatus = "acknowledged",
            responseNotes = "DLSA पैनल अधिवक्ता द्वारा दस्तावेज़ों का परीक्षण पूर्ण, ग्राम सभा प्रस्तुति हेतु विधिक पत्र तैयार।"
          )
        ),
        notes = listOf(
          CaseNote("n-01", "रमेश सहरिया (वॉलंटियर)", UserRole.VOLUNTEER, false, "आवेदक से गाँव में भेंट की गई। 1998 की वन उपज रसीद उपलब्ध है जो 2005 से पूर्व कब्जे का ठोस साक्ष्य है।", "2026-10-15 14:20"),
          CaseNote("n-02", "सुनीता शर्मा (केस मैनेजर)", UserRole.CASE_MANAGER, true, "आंतरिक नोट: कराहल ब्लॉक में FRC की बैठक 5 नवंबर को प्रस्तावित है। संबंधित हल्का पटवारी और वन रक्षक को उपस्थिति हेतु पत्र तैयार किया गया।", "2026-10-25 11:00")
        )
      ),
      CaseRecord(
        id = "NYAY-2026-0042",
        verificationPin = "8204",
        userId = "usr_02",
        category = CaseCategory.WAGES_LIVELIHOOD,
        title = "मनरेगा मजदूरी का 3 माह से बकाया भुगतान व विलंब मुआवजा",
        applicantName = "कमला बाई सहरिया व 12 अन्य श्रमिक",
        isAnonymous = false,
        contactPhone = "9407281923",
        preferredLanguage = "hi",
        district = "शिवपुरी (Shivpuri)",
        block = "पोहरी (Pohri)",
        gramPanchayat = "भटनावर (Bhatnawar)",
        village = "दौनी (Dauni)",
        description = "तालाब गहरीकरण कार्य में 38 दिनों का मस्टर रोल भरा गया, परंतु 3 माह बीत जाने के बाद भी बैंक खाते में मजदूरी अंतरित नहीं हुई। जॉब कार्ड संख्या MP-23-004-XXX।",
        assistanceRequested = "जनपद पंचायत सीईओ एवं लोकपाल (मनरेगा) को धारा 27 के तहत विलंब क्षतिपूर्ति सहित भुगतान हेतु विधिक शिकायत।",
        relevantDate = "2026-08-10",
        status = CaseStatus.AWAITING_RESPONSE,
        priority = PriorityLevel.URGENT,
        assignedManagerName = "सुनीता शर्मा (Sunita Sharma)",
        assignedVolunteerName = "रमेश सहरिया (Ramesh Sahariya)",
        dateReceived = "2026-09-20",
        lastActionDate = "2026-10-22",
        nextFollowUpDate = "2026-11-02",
        documentChecklist = listOf(
          DocumentChecklistItem("d10", "जॉब कार्ड छायाप्रति", "श्रमिक पंजीकरण विवरण", true, true),
          DocumentChecklistItem("d11", "मस्टर रोल संख्या व कार्य दिवस सूची", "38 कार्य दिवसों का प्रमाण", true, true),
          DocumentChecklistItem("d12", "बैंक पासबुक प्रविष्टि", "अंतिम 6 माह की विवरणी", true, true)
        ),
        notes = listOf(
          CaseNote("n-03", "सुनीता शर्मा (केस मैनेजर)", UserRole.CASE_MANAGER, false, "शिकायत मुख्य कार्यपालन अधिकारी (जनपद पंचायत पोहरी) को प्रस्तुत कर पावती प्राप्त कर ली गई है। 15 कार्य दिवसों में उत्तर अपेक्षित है।", "2026-10-22 16:30")
        )
      ),
      CaseRecord(
        id = "NYAY-2026-0043",
        verificationPin = "3591",
        userId = "usr_01",
        category = CaseCategory.GOVT_SCHEMES,
        title = "सहरिया आहार अनुदान योजना (₹1,500/माह) बैंक DBT अवरोध",
        applicantName = "शांति बाई सहरिया",
        isAnonymous = false,
        contactPhone = "9981273641",
        preferredLanguage = "hi",
        district = "गुना (Guna)",
        block = "बमोरी (Bamori)",
        gramPanchayat = "फतेहगढ़ (Fatehgarh)",
        village = "सहरिया बस्ती (Sahariya Basti)",
        description = "महिला मुखिया होने के नाते आहार अनुदान योजना में पात्रता है, परंतु 6 माह से NPCI आधार मैपिंग त्रुटि के कारण ₹1,500 की मासिक पोषण राशि खाते में नहीं आ रही।",
        assistanceRequested = "आदिम जाति कल्याण विभाग एवं लीड बैंक मैनेजर (LBM) के समक्ष आधार सीडिंग व एरियर भुगतान हेतु प्रतिवेदन।",
        relevantDate = "2026-09-01",
        status = CaseStatus.UNDER_ASSESSMENT,
        priority = PriorityLevel.HIGH,
        assignedManagerName = "आनंद वर्मा (Dr. Anand Verma)",
        assignedVolunteerName = "दिनेश भील (Dinesh Bhil)",
        dateReceived = "2026-10-05",
        lastActionDate = "2026-10-20",
        nextFollowUpDate = "2026-11-08",
        notes = listOf(
          CaseNote("n-04", "दिनेश भील (वॉलंटियर)", UserRole.VOLUNTEER, false, "बैंक शाखा फतेहगढ़ में शाखा प्रबंधक से आधार NPCI री-सीडिंग फॉर्म भरवाया गया। विभाग को अद्यतन प्रतिवेदन भेजा गया।", "2026-10-20 12:15")
        )
      )
    )

    // 3. Community Storytelling Feed
    _stories.value = listOf(
      StoryItem(
        id = "st-01",
        authorName = "रामदयाल सहरिया",
        authorRole = UserRole.COMMUNITY_MEMBER,
        village = "सहरिया डांडा, कराहल",
        district = "श्योपुर (Sheopur)",
        titleHi = "वनाधिकार पट्टा दावा: हमारी 3 पीढ़ियों का संघर्ष व जीत की राह",
        titleEn = "Forest Rights Claim: 3 Generations of Struggle and Victory",
        titleHinglish = "Van Adhikar Patta Dawa: Hamari 3 Pidhiyon Ka Sangharsh Aur Jeet",
        contentHi = "हमारे दादा-परदादा इसी जंगल की 3.5 एकड़ जमीन पर मक्का व तिल बोते आए थे। जब 2005 के बाद वन अमले ने बेदखली की धमकी दी, तो हम निराश हो गए थे। जस्टिस हब सोसाइटी (JHS) के पैरालीगल साथी रमेश भाई ने हमें वनाधिकार कानून (FRA 2006) के बारे में बताया। हमने बुजुर्गों के साक्ष्य बयान, पुराने जुर्माने की रसीदें और चौहद्दी का पंचनामा तैयार कर ग्राम सभा वनाधिकार समिति (FRC) में प्रारूप 'क' पर दावा जमा किया। आज ग्राम सभा ने सर्वसम्मति से हमारे दावे की अनुशंसा कर दी है। यह हमारी मिट्टी और सम्मान की जीत है!",
        contentEn = "Our forefathers cultivated this 3.5 acres of forest land. When faced with eviction threats, JHS paralegals educated us on FRA 2006. With elders' testimony, historical penalty receipts, and boundary panchnama, our claim Form A was filed and Gram Sabha has unanimously sanctioned it!",
        contentHinglish = "Hamare buzurg is 3.5 acre jungle zameen par kheti karte the. JHS paralegal team ne humein FRA 2006 kanoon samjhaya. Humne buzurgon ke bayan aur purani raseed laga kar Form A bhara aur Gram Sabha ne poori tarah pass kar diya!",
        category = "वनाधिकार जीत (FRA Victory)",
        videoUrl = "https://youtube.com/watch?v=nyaysetu_fra_doc",
        likesCount = 48,
        timestamp = "25 Oct 2026"
      ),
      StoryItem(
        id = "st-02",
        authorName = "कमला बाई सहरिया",
        authorRole = UserRole.COMMUNITY_MEMBER,
        village = "दौनी, पोहरी",
        district = "शिवपुरी (Shivpuri)",
        titleHi = "मनरेगा मजदूरी का ₹42,000 एरियर: 13 मजदूर महिलाओं का संकल्प",
        titleEn = "MGNREGA Wage Arrears of ₹42,000: 13 Tribal Women Win",
        titleHinglish = "MGNREGA Mazdoori Ka ₹42,000 Arrear: 13 Mazdoor Mahilaon Ki Jeet",
        contentHi = "दौनी गाँव में हमने तालाब गहरीकरण में 38 दिन कड़ी मेहनत की। मस्टर रोल बंद होने के 3 महीने बाद भी हमारे बैंक खाते में एक रुपया नहीं आया। JHS विधिक क्लिनिक की मदद से हमने नरेगा अधिनियम की धारा 27 के तहत 0.05% दैनिक विलंब मुआवजे के साथ जनपद सीईओ को औपचारिक मांग पत्र दिया। विधिक दबाव के बाद पूरे 13 परिवारों के खातों में ₹42,000 की राशि और विलंब मुआवजा जमा हुआ। अब हम अपने अधिकारों के लिए कभी चुप नहीं बैठेंगे!",
        contentEn = "After 38 days of hard desiltation work, our wages were delayed for 3 months. With JHS legal aid, we petitioned under MGNREGA Sec 27 claiming delay compensation. All ₹42,000 plus compensation were credited to our accounts!",
        contentHinglish = "Humne talaab khudaai mein 38 din kaam kiya par 3 mahine tak paise nahi aaye. JHS legal helpdesk ke saath CEO Janpad ko kanooni notice bheja aur saare 13 parivaaron ko poora paisa aur compensation mila!",
        category = "मजदूरी अधिकार (Wage Rights)",
        videoUrl = null,
        likesCount = 37,
        timestamp = "22 Oct 2026"
      ),
      StoryItem(
        id = "st-03",
        authorName = "सुनीता शर्मा (केस मैनेजर)",
        authorRole = UserRole.CASE_MANAGER,
        village = "पोहरी क्लस्टर",
        district = "शिवपुरी (Shivpuri)",
        titleHi = "सहरिया महिला बाँस शिल्प: बिचौलियों से मुक्ति व आत्मनिर्भरता",
        titleEn = "Sahariya Bamboo Artisans: Liberation from Middlemen",
        titleHinglish = "Sahariya Mahila Baans Shilp: Middlemen Se Chutkara Aur Self-Reliance",
        contentHi = "पोहरी क्षेत्र की सहरिया महिलाएँ पीढ़ियों से खूबसूरत बाँस की टोकरियाँ व सुराही बनाती थीं, पर स्थानीय व्यापारी मात्र ₹20-30 में खरीदकर शहरों में भारी मुनाफे पर बेचते थे। जस्टिस हब सोसाइटी द्वारा 40 महिलाओं का शिल्प समूह बनाकर वन धन विकास केंद्र से जोड़ा गया। उन्नत औजारों, आधुनिक डिजाइन प्रशिक्षण व सीधे बाजार तक पहुँच से आज प्रत्येक महिला मासिक ₹6,000 से ₹8,000 की सम्मानजनक आय अर्जित कर रही हैं।",
        contentEn = "Sahariya craftswomen who earned mere ₹20-30 per basket from middlemen were organized into artisan cooperatives under JHS and Van Dhan Kendras. Today, with direct market access, they earn ₹6,000-8,000 monthly with dignity.",
        contentHinglish = "Pohri ki Sahariya mahilaon ko pehle sirf 20-30 rupaye milte the. JHS ne SHG cluster banakar direct mandi aur online exhibition se joda, ab mahilaon ko 6000-8000 rupaye monthly aamdani ho rahi hai.",
        category = "महिला स्वावलंबन (Empowerment)",
        videoUrl = "https://youtube.com/watch?v=jhs_artisan_voices",
        likesCount = 59,
        timestamp = "18 Oct 2026"
      )
    )

    // 4. Knowledge Articles
    _knowledgeArticles.value = listOf(
      KnowledgeArticle(
        id = "kb-01",
        titleHindi = "🌳 वन अधिकार कानून (FRA), 2006: जंगल, जमीन, ग्राम सभा और आदिवासी अधिकारों की संपूर्ण जानकारी",
        titleEnglish = "Forest Rights Act (FRA), 2006: Complete 10-Part Comprehensive Guide",
        category = CaseCategory.FOREST_RIGHTS,
        summaryHindi = "13 दिसंबर 2005 से पूर्व वनभूमि पर काबिज आदिवासियों व OTFD को व्यक्तिगत (अधिकतम 4 हेक्टेयर) व सामुदायिक वनाधिकार, धारा 1 से 14, FRC दावा प्रक्रिया व अपील की पूरी विधिक जानकारी।",
        summaryEnglish = "Complete 10-Part legal master guide on FRA 2006: IFR (up to 4 ha), CR, CFR, PVTG habitat rights, NTFP ownership, 14 sections, FRC process & appeals.",
        contentHindi = """
          ■ भाग 1. FRA कानून क्या है और क्यों बना?
          • पूरा नाम: अनुसूचित जनजाति और अन्य परंपरागत वन निवासी (वन अधिकारों की मान्यता) अधिनियम, 2006 (Forest Rights Act, 2006)।
          • क्यों बना: सदियों से जंगलों में रहने वाले आदिवासी व परंपरागत वन निवासियों के अधिकारों को सरकारी रिकॉर्ड में दर्ज न किए जाने के 'ऐतिहासिक अन्याय' (Historical Injustice) को समाप्त करने हेतु।
          • महत्वपूर्ण तारीखें:
            - संसद द्वारा पारित: 29 दिसंबर 2006
            - लागू (अधिसूचित): 31 दिसंबर 2007
            - पात्रता की कट-ऑफ तारीख: 13 दिसंबर 2005

          ■ भाग 2. किसे मिलता है लाभ? (दो मुख्य पात्र श्रेणियां)
          1. अनुसूचित जनजाति (ST - Scheduled Tribes): उस क्षेत्र में रहने वाले ST परिवार जो 13 दिसंबर 2005 से पूर्व वनभूमि पर काबिज रहकर आजीविका हेतु खेती या वनोपज पर निर्भर हैं।
          2. अन्य परंपरागत वन निवासी (OTFD - Other Traditional Forest Dwellers): जो समुदाय ST में नहीं हैं, परंतु 13 दिसंबर 2005 से पहले कम से कम 3 पीढ़ियों (75 वर्ष) से उस वन क्षेत्र में निवास कर रहे हैं और आजीविका हेतु वन पर निर्भर हैं।

          ■ भाग 3. कानून के तहत मिलने वाले 3 मुख्य अधिकार
          1. व्यक्तिगत वन अधिकार (IFR - Individual Forest Rights, धारा 3(1)(a)):
             - 13 दिसंबर 2005 से पहले काबिज वनभूमि पर पट्टा (अधिकतम 4 हेक्टेयर यानी 9.88 एकड़ तक)।
             - यह जमीन बेची, गिरवी या हस्तांतरित नहीं की जा सकती (Inalienable & Non-transferable)। केवल पैतृक उत्तराधिकार में अगली पीढ़ी को मिलती है।
             - पति और पत्नी दोनों के नाम संयुक्त पट्टा (Joint Title Deed) जारी होता है।
          2. सामुदायिक अधिकार (CR - Community Rights, धारा 3(1)(b, c, d)):
             - निस्तार अधिकार, मवेशी चराई, जल स्रोत, मछली पकड़ना और मौसमी प्रवास।
          3. सामुदायिक वन संसाधन अधिकार (CFR - Community Forest Resource Rights, धारा 3(1)(i)):
             - ग्राम सभा को अपनी पारंपरिक वन सीमा (Customary Boundary) के जंगल की सुरक्षा, पुनर्जीवन, संरक्षण और प्रबंधन का सर्वोच्च कानूनी अधिकार।

          ■ भाग 4. विशेष रूप से कमजोर जनजातीय समूह (PVTG) के पर्यावास अधिकार (Habitat Rights)
          • धारा 3(1)(e) के तहत सहरिया (श्योपुर, शिवपुरी, गुना), बैगा (मंडला, डिंडोरी) और भारिया (छिंदवाड़ा) जैसी PVTG जनजातियों को उनके पारंपरिक पर्यावास (Habitat) का सामूहिक अधिकार प्राप्त है।
          • ग्राम सभा की सहमति के बिना उनकी पारंपरिक भूमि पर कोई गैर-वानिकी या सरकारी हस्तक्षेप नहीं किया जा सकता।

          ■ भाग 5. लघु वनोपज (Minor Forest Produce - MFP / NTFP) पर अधिकार
          • धारा 3(1)(c): महुआ, तेंदूपत्ता, साल बीज, चिरौंजी, लाख, बबूल गोंद, बांस, कंद-मूल, औषधीय पौधों पर वनवासियों का पूर्ण मालिकाना हक है।
          • वनवासियों को वनोपज के संकलन, भंडारण, प्रसंस्करण, ढुलाई और बिक्री की पूर्ण स्वतंत्रता है। इसके लिए वन विभाग से किसी ट्रांजिट पास (TP) की आवश्यकता नहीं है।

          ■ भाग 6. FRA 2006 की सभी 14 धाराओं का आसान सारांश
          • धारा 1: कानून का नाम, विस्तार (संपूर्ण भारत) और प्रारंभ।
          • धारा 2: महत्वपूर्ण परिभाषाएं (वनभूमि, वन ग्राम, ग्राम सभा, वन अधिकार, लघु वनोपज)।
          • धारा 3: वनाधिकारों की विस्तृत सूची (IFR, CR, CFR, आवास, बुनियादी ढांचा जैसे स्कूल, आंगनवाड़ी, अस्पताल आदि)।
          • धारा 4: वन अधिकारों की मान्यता। प्रावधान: जब तक दावा व अपील प्रक्रिया पूर्ण न हो, किसी को बेदखल नहीं किया जाएगा।
          • धारा 5: ग्राम सभा और अधिकार धारकों के कर्तव्य (वन, वन्यजीव, जल स्रोत व जैव विविधता की रक्षा करना)।
          • धारा 6: अधिकारों के निर्धारण के प्राधिकारी व 3-स्तरीय प्रक्रिया (ग्राम सभा FRC -> उपखंड SDLC -> जिला DLC)।
          • धारा 7: कानून का उल्लंघन करने वाले अधिकारियों व व्यक्तियों के विरुद्ध अपराध व दंड।
          • धारा 8: अपराधों का संज्ञान (अदालत केवल राज्य सरकार की पूर्व मंजूरी या ग्राम सभा के 60 दिन के नोटिस पर संज्ञान लेगी)।
          • धारा 9: केंद्र सरकार की निदेश देने की शक्ति।
          • धारा 10: सद्भावपूर्वक की गई कार्यवाही का कानूनी संरक्षण।
          • धारा 11: नोडल मंत्रालय — जनजातीय कार्य मंत्रालय (MoTA), भारत सरकार।
          • धारा 12: कठिनाइयों को दूर करने की शक्ति।
          • धारा 13: अन्य कानूनों पर अध्यारोही प्रभाव (FRA भारतीय वन अधिनियम 1927 व अन्य पुराने कानूनों पर प्रभावी है)।
          • धारा 14: नियम बनाने की केंद्र सरकार की शक्ति।

          ■ भाग 7. दावा करने की पूरी चरणबद्ध प्रक्रिया (Step-by-Step Claim Flow)
          1. ग्राम सभा वनाधिकार समिति (FRC) का गठन: 10 से 15 सदस्य (कम से कम 1/3 महिलाएं, 2/3 अनुसूचित जनजाति)।
          2. दावा फॉर्म भरना: फॉर्म 'क' (व्यक्तिगत पट्टा), फॉर्म 'ख' (सामुदायिक अधिकार), फॉर्म 'ग' (सामुदायिक वन संसाधन)।
          3. भौतिक मौका मुआयना: FRC, वनरक्षक व हल्का पटवारी द्वारा संयुक्त स्थल निरीक्षण, जीपीएस मैपिंग व पंचनामा।
          4. ग्राम सभा की आम बैठक: कम से कम 50% कोरम में दावों का वाचन व अनुमोदन प्रस्ताव पारित करना।
          5. उपखंड स्तरीय समिति (SDLC): एसडीएम की अध्यक्षता में दावों का परीक्षण व संस्तुति।
          6. जिला स्तरीय समिति (DLC): जिला कलेक्टर की अध्यक्षता में अंतिम अनुमोदन व पट्टा अधिकार पत्र जारी करना।

          ■ भाग 8. यदि दावा खारिज हो जाए तो क्या करें? (Appeal & Protection)
          • ग्राम सभा या SDLC द्वारा दावा अस्वीकार किए जाने पर आवेदक को कारण सहित लिखित आदेश दिया जाना अनिवार्य है।
          • आदेश प्राप्ति के 60 दिनों के भीतर SDLC अथवा DLC के समक्ष अपील प्रस्तुत की जा सकती है।
          • विधिक सुरक्षा: धारा 4(5) के तहत जब तक अपील का अंतिम निपटारा न हो जाए, किसी भी दावेदार को उसकी जमीन से बेदखल नहीं किया जा सकता।

          ■ भाग 9. मध्य प्रदेश में FRA व 'वनमित्र' पोर्टल
          • मध्य प्रदेश में पूर्व में अमान्य किए गए दावों की पुनर्विचार प्रक्रिया 'वनमित्र' (MP VanMitra) पोर्टल के माध्यम से डिजिटल रूप से संचालित की जा रही है।
          • सहरिया डांडा, कराहल, पोहरी और बमोरी विकासखंडों में विशेष विधिक शिविरों का आयोजन।

          ■ भाग 10. अक्सर पूछे जाने वाले सवाल (FAQ)
          • प्र. क्या पट्टा मिलने के बाद वन विभाग जमीन ले सकता है?
            उत्तर: बिल्कुल नहीं। DLC द्वारा जारी पट्टा स्थायी विधिक अधिकार पत्र है।
          • प्र. क्या 2005 से पहले का कोई जुर्माना रसीद साक्ष्य माना जाता है?
            उत्तर: हाँ, वन विभाग द्वारा काटी गई पुरानी जुर्माना रसीद या नोटिस 2005 से पूर्व कब्जे का सबसे पुख्ता विधिक साक्ष्य है।
          • प्र. क्या जमीन पर बैंक से किसान क्रेडिट कार्ड (KCC) लोन मिल सकता है?
            उत्तर: हाँ, FRA पट्टे पर शासन द्वारा KCC, पीएम किसान सम्मान निधि और कृषि अनुदान के समस्त लाभ दिए जाते हैं।
        """.trimIndent(),
        contentEnglish = """
          ■ Part 1. What is Forest Rights Act (FRA), 2006?
          Enacted on 29 Dec 2006 (notified 31 Dec 2007) to redress the historical injustice faced by forest-dwelling Scheduled Tribes and traditional forest dwellers.
          Cut-off date: 13 December 2005.

          ■ Part 2. Who is eligible?
          1. Forest-Dwelling Scheduled Tribes (FDST): Residing & cultivating prior to 13 Dec 2005.
          2. Other Traditional Forest Dwellers (OTFD): Residing for at least 3 generations (75 years) prior to 13 Dec 2005.

          ■ Part 3. The 3 Types of Rights:
          1. Individual Forest Rights (IFR - Sec 3(1)(a)): Title up to 4 hectares (9.88 acres). Non-transferable; joint husband-wife title.
          2. Community Rights (CR - Sec 3(1)(b,c,d)): Nistar, grazing, water bodies, seasonal access.
          3. Community Forest Resource (CFR - Sec 3(1)(i)): Gram Sabha power to protect, regenerate, and govern traditional community forests.

          ■ Part 4. PVTG Habitat Rights (Sec 3(1)(e)):
          Habitat protection for particularly vulnerable tribal groups including Sahariya, Baiga, and Bharia.

          ■ Part 5. Minor Forest Produce (MFP / NTFP):
          Full ownership, collection, processing, and sale of forest produce (Mahua, Tendu, Chironji, Bamboo, Gum) without transit permits.

          ■ Part 6. Sections 1 to 14 of FRA 2006 Summary:
          Comprehensive statutory coverage from definitions to Gram Sabha supremacy and penalties.

          ■ Part 7. Step-by-Step Claim Flow:
          FRC formation -> Claim filing -> Joint field inspection -> Gram Sabha resolution -> SDLC scrutiny -> DLC title distribution.

          ■ Part 8. Appeals & Eviction Protection:
          60 days statutory appeal window. Absolute bar against eviction under Section 4(5) until claim procedure concludes.

          ■ Part 9 & 10. MP VanMitra Portal & Practical FAQs.
        """.trimIndent(),
        applicableLocation = "मध्य प्रदेश के समस्त वन ग्राम (विशेषतः श्योपुर, शिवपुरी, गुना, मुरैना, मंडला, डिंडोरी)",
        eligibilityHindi = listOf(
          "अनुसूचित जनजाति (ST) परिवार जो 13 दिसंबर 2005 से पूर्व वनभूमि पर काबिज हों",
          "अन्य परंपरागत वन निवासी (OTFD) जो कम से कम 3 पीढ़ियों (75 वर्ष) से उस वन पर निर्भर हों",
          "विशेष रूप से कमजोर जनजातीय समूह (PVTG) सहरिया, बैगा, भारिया"
        ),
        eligibilityEnglish = listOf(
          "Forest-dwelling Scheduled Tribes cultivating prior to 13 Dec 2005",
          "Other Traditional Forest Dwellers with 75 years / 3 generations continuous residence",
          "Particularly Vulnerable Tribal Groups (PVTG) like Sahariya, Baiga, Bharia"
        ),
        documentChecklistHindi = listOf(
          "मतदाता पहचान पत्र / आधार कार्ड / राशन कार्ड",
          "13 दिसंबर 2005 से पूर्व कब्जे का प्रमाण (पुराना जुर्माना रसीद, बेदखली नोटिस, केस पर्ची)",
          "वृद्ध ग्रामीणों व FRC का संयुक्त पंचनामा साक्ष्य",
          "ग्राम सभा वनाधिकार समिति (FRC) प्रस्ताव प्रति"
        ),
        documentChecklistEnglish = listOf(
          "Voter ID / Aadhaar / Ration Card",
          "Pre-2005 occupation evidence (old penalty receipt, forest offense slip, POR)",
          "Elders' panchnama statement",
          "Gram Sabha FRC resolution copy"
        ),
        officialSource = "जनजातीय कार्य मंत्रालय, भारत सरकार (Ministry of Tribal Affairs - MoTA)",
        verificationDate = "2026-10-25",
        reviewer = "अधिवक्ता राजेश कुलश्रेष्ठ (JHS मुख्य विधिक सलाहकार)"
      ),
      KnowledgeArticle(
        id = "kb-02",
        titleHindi = "मध्य प्रदेश भू-राजस्व संहिता, 1959 की धारा 170-ख (आदिवासी भूमि संरक्षण)",
        titleEnglish = "Section 170-B, MP Land Revenue Code (Protection Against Tribal Land Alienation)",
        category = CaseCategory.LAND_RIGHTS,
        summaryHindi = "कलेक्टर की पूर्व अनुमति के बिना गैर-आदिवासियों को अंतरित की गई आदिवासी भूमि को स्वतः निरस्त कर मूल आदिवासी को वापस दिलाने का कठोर कानून।",
        summaryEnglish = "Statutory provision mandating restoration of illegally transferred tribal land back to original tribal owners without collector permission.",
        contentHindi = """
          1. कानूनी प्रावधान:
          - किसी भी अनुसूचित जनजाति के भूमिस्वामी की कृषि भूमि बिना कलेक्टर की लिखित अनुमति के गैर-आदिवासी को बेची, गिरवी या अंतरित नहीं की जा सकती।
          - धारा 170-ख के अंतर्गत यदि कोई गैर-आदिवासी व्यक्ति 2 अक्टूबर 1959 के पश्चात किसी आदिवासी की भूमि पर काबिज है, तो उसे साबित करना होगा कि कब्जा वैध है।
          - साबित न कर पाने पर अनुविभागीय अधिकारी (SDO राजस्व) को तत्काल कब्जा हटाकर आदिवासी अथवा उसके उत्तराधिकारियों को भूमि सौंपने का वैधानिक अधिकार है।
        """.trimIndent(),
        contentEnglish = """
          1. Statutory Mandate:
          - No agricultural land of a Scheduled Tribe tenure-holder can be transferred or mortgaged to a non-tribal without prior written sanction of the Collector.
        """.trimIndent(),
        applicableLocation = "मध्य प्रदेश राज्य (समस्त जिले)",
        eligibilityHindi = listOf("अनुसूचित जनजाति (ST) का कोई भी व्यक्ति जिसकी पैतृक जमीन पर गैर-आदिवासी का कब्जा हो"),
        eligibilityEnglish = listOf("Any Scheduled Tribe individual whose land has been alienated to a non-tribal"),
        documentChecklistHindi = listOf("राजस्व खसरा / बी-1 नकल", "जाति प्रमाण पत्र", "कब्जा प्रमाण पत्र"),
        documentChecklistEnglish = listOf("Khasra & B-1 records", "Caste Certificate", "Possession panchnama"),
        officialSource = "मध्य प्रदेश भू-राजस्व संहिता 1959 (अध्याय 12)",
        verificationDate = "2026-10-10",
        reviewer = "अधिवक्ता राजेश कुलश्रेष्ठ (उच्च न्यायालय खंडपीठ ग्वालियर)"
      ),
      KnowledgeArticle(
        id = "kb-03-pvtg-master",
        titleHindi = "📜 मध्य प्रदेश आदिवासी एवं PVTG महा-मार्गदर्शिका (भाग 1 से 10): PM-JANMAN, DAJGUA, आहार अनुदान व पशु प्रदाय",
        titleEnglish = "MP Tribal & PVTG Schemes Master Guide (Parts 1-10): PM-JANMAN, DAJGUA, Aahar Anudan",
        category = CaseCategory.GOVT_SCHEMES,
        summaryHindi = "बैगा, भारिया, सहरिया PVTG पहचान, PM-JANMAN 11 हस्तक्षेप, DAJGUA 25 हस्तक्षेप, आहार अनुदान ₹1,500/माह, 90% अनुदान पर दुधारू पशु, मनरेगा, PMAY-G, वन धन केंद्र व सिकल सेल मिशन।",
        summaryEnglish = "Comprehensive master field guide on 10 PVTG and Tribal welfare schemes verified up to 31 Oct 2026.",
        contentHindi = """
          ■ 1. मध्य प्रदेश में PVTG समुदायों की पहचान:
          • ST और PVTG में अंतर: ST संवैधानिक श्रेणी है, जबकि PVTG अनुसूचित जनजातियों के भीतर अत्यधिक पिछड़े व संवेदनशील 75 राष्ट्रीय समूह हैं।
          • मध्य प्रदेश के 3 अधिसूचित PVTG:
            1. सहरिया (Sahariya): श्योपुर, शिवपुरी, गुना, ग्वालियर, मुरैना, भिंड, दतिया, अशोकनगर।
            2. बैगा (Baiga): डिंडोरी, मंडला, बालाघाट, उमरिया, शहडोल, अनूपपुर।
            3. भारिया (Bharia): छिंदवाड़ा (पातालकोट क्षेत्र)।

          ■ 2. योजना 1: PM-JANMAN (15 नवंबर 2023 से संचालित):
          • 9 मंत्रालयों के 11 हस्तक्षेप: पक्का आवास, सुरक्षित पेयजल, सड़क, बिजली/सोलर, मोबाइल टावर, स्वास्थ्य, आंगनवाड़ी, छात्रावास, कौशल आजीविका, बहुउद्देशीय केंद्र, स्वच्छता।
          • आवास छूट: PVTG परिवारों हेतु PMAY-G के सामान्य अपात्रता नियमों में शिथिलता दी गई है।

          ■ 3. योजना 2: धरती आबा जनजातीय ग्राम उत्कर्ष अभियान (DAJGUA):
          • 63,843 जनजातीय बहुल गाँवों (म.प्र. के 591+ गाँव) में बुनियादी कमियों को दूर करने हेतु 17 मंत्रालयों के 25 हस्तक्षेप।

          ■ 4. योजना 4: आहार अनुदान योजना (म.प्र. शासन):
          • सहरिया, बैगा, भारिया की महिला मुखिया के खाते में प्रतिमाह ₹1,500 DBT पोषण अनुदान।

          ■ 5. योजना 9: मुख्यमंत्री दुधारू पशु प्रदाय:
          • 90% सरकारी अनुदान, 10% हितग्राही अंशदान पर 2 दुधारू गाय या मुर्रा भैंस।

          ■ 6. आवास, बुनियादी सुविधाएँ, मनरेगा व वन धन:
          • PMAY-G (₹1.20 लाख), SBM-G शौचालय (₹12,000), जल जीवन मिशन, मनरेगा 100 दिन मजदूरी गारंटी, TRIFED वन धन केंद्र (₹15 लाख सहायता), सिकल सेल उन्मूलन मिशन।
        """.trimIndent(),
        contentEnglish = """
          Comprehensive official master guide covering PVTG identification (Sahariya, Baiga, Bharia), PM-JANMAN (11 interventions), DAJGUA (25 interventions), Aahar Anudan DBT, Milch Cattle (90% subsidy), PMAY-G, SBM-G, MGNREGA, Van Dhan, and Sickle Cell Elimination Mission.
        """.trimIndent(),
        applicableLocation = "मध्य प्रदेश के समस्त जनजातीय व PVTG बहुल जिले",
        eligibilityHindi = listOf(
          "सहरिया, बैगा अथवा भारिया (PVTG) परिवार",
          "मध्य प्रदेश के अधिसूचित अनुसूचित जनजाति (ST) परिवार",
          "विभागीय पात्रता व सर्वेक्षण सूची में दर्ज नागरिक"
        ),
        eligibilityEnglish = listOf(
          "Sahariya, Baiga, or Bharia PVTG households in MP",
          "Scheduled Tribe households residing in MP",
          "Listed in official departmental baseline surveys"
        ),
        documentChecklistHindi = listOf(
          "आधार कार्ड (सक्रिय व मोबाइल लिंक)",
          "डिजिटल ST / PVTG जाति प्रमाण पत्र",
          "समग्र परिवार आईडी व सदस्य आईडी",
          "बैंक पासबुक (Aadhaar NPCI मैपर से सक्रिय)",
          "निवास प्रमाण पत्र / राशन कार्ड"
        ),
        documentChecklistEnglish = listOf(
          "Aadhaar Card",
          "Digital Caste Certificate",
          "Samagra Family and Member ID",
          "Bank Passbook (NPCI Seeded)",
          "Domicile / Ration Card"
        ),
        officialSource = "जनजातीय कार्य मंत्रालय, भारत सरकार एवं म.प्र. जनजातीय कार्य विभाग (सत्यापन: 31 अक्टूबर 2026)",
        verificationDate = "2026-10-31",
        reviewer = "Justice Hub Society विधिक शोध एवं सहायता सेल"
      ),
      KnowledgeArticle(
        id = "kb-04-docs-redressal",
        titleHindi = "📂 16 जरूरी सरकारी दस्तावेज़, फीस नियम, CM 181, RTI एवं कानूनी सहायता (भाग 11 से 16)",
        titleEnglish = "16 Essential Documents, Official Fee Rules, CM 181, RTI & Portals (Parts 11-16)",
        category = CaseCategory.IDENTITY_DOCS,
        summaryHindi = "आधार, समग्र, जाति, पट्टा, जमीन रिकॉर्ड; सरकारी शुल्क बनाम कियोस्क बनाम अवैध वसूली का अंतर; CM 181, RTI, DLSA 15100, 32 सरकारी पोर्टल व 15-सवाल चेकलिस्ट।",
        summaryEnglish = "Essential documents preparation, fee transparency, grievance escalation (CM 181), RTI, Free Legal Aid (DLSA 15100), and 32 portals directory.",
        contentHindi = """
          ■ 1. परिवार के 16 आवश्यक दस्तावेज़:
          1. आधार कार्ड | 2. समग्र परिवार आईडी | 3. समग्र सदस्य आईडी | 4. जाति/ST प्रमाण पत्र | 5. निवास प्रमाण पत्र | 6. आय प्रमाण पत्र | 7. जन्म प्रमाण पत्र | 8. मृत्यु प्रमाण पत्र | 9. बैंक पासबुक (DBT सक्रिय) | 10. राशन कार्ड | 11. जॉब कार्ड | 12. वनाधिकार पट्टा | 13. दिव्यांगता प्रमाण/UDID | 14. किसान भूमि रिकॉर्ड (B-1 खसरा) | 15. पैन कार्ड | 16. स्कूल अंकसूची।

          ■ 2. सरकारी फीस के सख्त नियम:
          • सरकारी शुल्क: कानूनन निर्धारित (सामान्य आधार नामांकन निःशुल्क, जाति/आय सामान्यतः निःशुल्क या ₹10-₹30)।
          • सेवा केंद्र शुल्क: लोक सेवा केंद्र की निर्धारित दर (हमेशा कंप्यूटराइज्ड रसीद लें)।
          • अवैध वसूली: किसी कर्मचारी या दलाल द्वारा बिना रसीद पैसा मांगना गैरकानूनी है। भुगतान न करें, 181 पर शिकायत करें।

          ■ 3. शिकायत, आरटीआई और विधिक सहायता:
          • मध्य प्रदेश CM हेल्पलाइन: 181 पर कॉल करें और शिकायत क्रमांक प्राप्त करें।
          • सूचना का अधिकार (RTI 2005): पात्रता सूची, अस्वीकृति का लिखित कारण व मस्टर रोल प्राप्त करें।
          • मुफ्त कानूनी सहायता: Legal Services Authorities Act धारा 12 के तहत हर अनुसूचित जनजाति नागरिक को DLSA (हेल्पलाइन: 15100) से मुफ्त वकील का कानूनी अधिकार है।

          ■ 4. 15-प्रश्न आवेदन चेकलिस्ट:
          आवेदन से पहले निवास, जाति, समग्र, बैंक NPCI, आय सीमा, पात्रता सूची व रसीद की 15 बिंदुओं पर पुष्टि करें।
        """.trimIndent(),
        contentEnglish = """
          Guide to 16 essential documents, official fee regulations vs unauthorized collections, grievance redressal via CM Helpline 181, RTI Act 2005, Free Legal Aid under DLSA 15100, and 32 government portals directory.
        """.trimIndent(),
        applicableLocation = "मध्य प्रदेश राज्य (समस्त जिले)",
        eligibilityHindi = listOf("मध्य प्रदेश के समस्त नागरिक, विशेषकर अनुसूचित जनजाति (ST) व PVTG परिवार"),
        eligibilityEnglish = listOf("All residents of MP with focus on ST and PVTG families"),
        documentChecklistHindi = listOf("पूर्व आवेदन की पावती रसीद", "समग्र आईडी", "आधार कार्ड", "शिकायत विवरण"),
        documentChecklistEnglish = listOf("Previous application receipt", "Samagra ID", "Aadhaar Card", "Grievance details"),
        officialSource = "मध्य प्रदेश शासन (CM हेल्पलाइन, लोक सेवा गारंटी व म.प्र. राज्य विधिक सेवा प्राधिकरण)",
        verificationDate = "2026-10-31",
        reviewer = "अधिवक्ता सुनीता शर्मा (JHS सीनियर विधिक केस मैनेजर)"
      )
    )

    // 5. Application Templates (Enhanced with Master Guide statutory applications)
    _applicationTemplates.value = listOf(
      ApplicationTemplate(
        id = "tpl-fra-patta-vikas",
        titleHindi = "वनाधिकार पट्टा धारक विकास अनुदान आवेदन",
        titleEnglish = "FRA Titleholder Land & Well Development Application",
        category = CaseCategory.FOREST_RIGHTS,
        descriptionHindi = "वनाधिकार पट्टा प्राप्त भूमि पर कपिलधारा कूप निर्माण (₹3,00,000) एवं खेत समतलीकरण/मेढ़ बंधान हेतु औपचारिक आवेदन।",
        descriptionEnglish = "Formal statutory application for Kapil Dhara farm well grant (up to ₹3 Lakhs) and land leveling under FRA convergence.",
        recipientAuthorityHindi = "मुख्य कार्यपालन अधिकारी (CEO), जनपद पंचायत / सहायक आयुक्त, जनजातीय कार्य",
        recipientAuthorityEnglish = "CEO, Janpad Panchayat / Assistant Commissioner, Tribal Affairs",
        requiredDocuments = listOf(
          "वनाधिकार पट्टा (Title Deed) की स्व-प्रमाणित प्रति",
          "भू-स्वामित्व का B-1 खसरा नक्शा",
          "स्थायी डिजिटल जाति प्रमाण पत्र",
          "आधार कार्ड व समग्र परिवार आईडी",
          "बैंक पासबुक छायाप्रति (आधार NPCI लिंक)",
          "ग्राम सभा वनाधिकार समिति (FRC) अनुशंसा"
        ),
        fields = listOf(
          ApplicationFormField("applicant_name", "आवेदक का पूरा नाम", "Applicant Full Name", "उदा. रामदयाल सहरिया"),
          ApplicationFormField("father_spouse", "पिता/पति का नाम", "Father/Spouse Name", "उदा. मंगतू सहरिया"),
          ApplicationFormField("fra_patta_no", "वनाधिकार पट्टा क्रमांक व दिनांक", "FRA Title Deed No. & Date", "उदा. FRA/SHP/2021/418"),
          ApplicationFormField("khasra_no", "वनभूमि खसरा / कम्पार्टमेंट नंबर", "Forest Compartment / Khasra No.", "उदा. कम्पार्टमेंट नं. 142"),
          ApplicationFormField("land_area", "पट्टा भूमि का क्षेत्रफल (एकड़/हेक्टेयर)", "Allocated Area (Acres)", "उदा. 3.50 एकड़"),
          ApplicationFormField("work_type", "चाही गई सहायता / कार्य का प्रकार", "Requested Work Type", "कपिलधारा कूप निर्माण (₹3 लाख) एवं मेढ़ बंधान"),
          ApplicationFormField("village", "गाँव व मजरा/टोला", "Village & Hamlet", "उदा. सहरिया डांडा"),
          ApplicationFormField("gram_panchayat", "ग्राम पंचायत", "Gram Panchayat", "उदा. गोरस"),
          ApplicationFormField("block", "जनपद पंचायत (विकासखंड)", "Block", "उदा. कराहल"),
          ApplicationFormField("district", "जिला", "District", "उदा. श्योपुर (मध्य प्रदेश)"),
          ApplicationFormField("phone", "सक्रिय मोबाइल नंबर", "Contact Mobile", "उदा. 9826194821")
        )
      ),

      ApplicationTemplate(
        id = "tpl-sahariya-aahar",
        titleHindi = "सहरिया/बैगा/भारिया आहार अनुदान योजना आवेदन",
        titleEnglish = "PVTG Sahariya Nutrition Allowance Application (₹1,500/Mo)",
        category = CaseCategory.GOVT_SCHEMES,
        descriptionHindi = "PVTG परिवारों में कुपोषण उन्मूलन हेतु महिला मुखिया के बैंक खाते में ₹1,500 प्रतिमाह DBT सहायता स्वीकृति हेतु आवेदन।",
        descriptionEnglish = "Application for monthly nutritional grant of ₹1,500 transferred to female head of PVTG household.",
        recipientAuthorityHindi = "बाल विकास परियोजना अधिकारी (CDPO) / सहायक आयुक्त, जनजातीय कार्य विभाग",
        recipientAuthorityEnglish = "Child Development Project Officer (CDPO) / Asst Commissioner, Tribal Affairs",
        requiredDocuments = listOf(
          "सहरिया / बैगा / भारिया जाति प्रमाण पत्र",
          "महिला मुखिया का आधार कार्ड (e-KYC पूर्ण)",
          "समग्र परिवार आईडी एवं सदस्य आईडी",
          "बैंक पासबुक छायाप्रति (आधार NPCI सक्रिय)",
          "पासपोर्ट साइज फोटो"
        ),
        fields = listOf(
          ApplicationFormField("applicant_name", "महिला मुखिया का नाम", "Female Head Full Name", "उदा. कमला बाई सहरिया"),
          ApplicationFormField("husband_father_name", "पति अथवा पिता का नाम", "Husband/Father Name", "उदा. रमेश सहरिया"),
          ApplicationFormField("pvtg_community", "PVTG जनजाति समुदाय", "PVTG Tribe", "सहरिया (Sahariya)"),
          ApplicationFormField("samagra_family_id", "समग्र परिवार आईडी (8 अंक)", "Samagra Family ID (8 digits)", "उदा. 74819203"),
          ApplicationFormField("samagra_member_id", "महिला सदस्य आईडी (9 अंक)", "Member ID (9 digits)", "उदा. 182947192"),
          ApplicationFormField("aadhaar_no", "आधार कार्ड नंबर (12 अंक)", "Aadhaar Card No.", "उदा. 4829-1920-3849"),
          ApplicationFormField("bank_account_no", "बैंक खाता क्रमांक (NPCI लिंक)", "Bank Account No.", "उदा. 3847192019284"),
          ApplicationFormField("bank_name_ifsc", "बैंक का नाम एवं IFSC कोड", "Bank Name & IFSC", "उदा. SBI कराहल - SBIN0001823"),
          ApplicationFormField("village", "गाँव व टोला", "Village & Hamlet", "उदा. दौनी"),
          ApplicationFormField("gram_panchayat", "ग्राम पंचायत", "Gram Panchayat", "उदा. भटनावर"),
          ApplicationFormField("block", "विकासखंड", "Block", "उदा. पोहरी"),
          ApplicationFormField("district", "जिला", "District", "उदा. शिवपुरी"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9407281923")
        )
      ),

      ApplicationTemplate(
        id = "tpl-dudharu-pashu",
        titleHindi = "मुख्यमंत्री दुधारू पशु प्रदाय योजना (90% अनुदान) आवेदन पत्र",
        titleEnglish = "CM Milch Cattle 90% Subsidy Application for PVTGs",
        category = CaseCategory.WAGES_LIVELIHOOD,
        descriptionHindi = "सहरिया, बैगा और भारिया परिवारों को 90% सरकारी अनुदान पर 2 दुधारू गाय अथवा मुर्रा भैंस प्रदाय हेतु आवेदन पत्र।",
        descriptionEnglish = "Statutory application for 2 high-yield milch cows or Murrah buffaloes with 90% government subsidy.",
        recipientAuthorityHindi = "उपसंचालक, पशुपालन एवं डेयरी विभाग, मध्य प्रदेश शासन",
        recipientAuthorityEnglish = "Deputy Director, Animal Husbandry & Dairy Department, Govt of MP",
        requiredDocuments = listOf(
          "आधार कार्ड",
          "PVTG स्थायी जाति प्रमाण पत्र (सहरिया/बैगा/भारिया)",
          "मूल निवासी प्रमाण पत्र",
          "समग्र परिवार आईडी छायाप्रति",
          "बैंक पासबुक छायाप्रति (आधार लिंक)",
          "ग्राम सभा अनुमोदन प्रस्ताव"
        ),
        fields = listOf(
          ApplicationFormField("applicant_name", "पशुपालक / आवेदक का नाम", "Applicant Full Name", "उदा. मंगल सिंह सहरिया"),
          ApplicationFormField("father_spouse", "पिता/पति का नाम", "Father/Spouse Name", "उदा. सुखराम सहरिया"),
          ApplicationFormField("pvtg_community", "जनजाति समुदाय", "Tribal Community", "सहरिया (PVTG)"),
          ApplicationFormField("cattle_type", "चाहे गए पशु का प्रकार", "Cattle Preference", "2 देशी उन्नत दुधारू गाय (7+ लीटर/दिन)"),
          ApplicationFormField("beneficiary_share", "10% हितग्राही अंशदान वहन करने की सहमति", "10% Beneficiary Share Consent", "हाँ, पूर्णतः सहमत हूँ"),
          ApplicationFormField("shed_facility", "पशु बाड़ा व हरा चारा प्रबंधन विवरण", "Cattle Shed & Fodder Arrangement", "कच्चा बाड़ा व चरनोई भूमि उपलब्ध है"),
          ApplicationFormField("village", "गाँव", "Village", "उदा. सेसईपुरा"),
          ApplicationFormField("gram_panchayat", "ग्राम पंचायत", "Gram Panchayat", "उदा. सेसई"),
          ApplicationFormField("block", "विकासखंड", "Block", "उदा. विजयपुर"),
          ApplicationFormField("district", "जिला", "District", "उदा. श्योपुर"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9826194821")
        )
      ),

      ApplicationTemplate(
        id = "tpl-jansunwai-grievance",
        titleHindi = "शासकीय योजना लाभ न मिलने पर कलेक्टर जनसुनवाई शिकायत पत्र",
        titleEnglish = "Collector Jan Sunwai Petition for Pending Scheme Entitlement",
        category = CaseCategory.GOVT_SCHEMES,
        descriptionHindi = "शासकीय योजना में आवेदन के महीनों बाद भी लाभ न मिलने अथवा अधिकारियों द्वारा टालमटोल पर जिला कलेक्टर को आधिकारिक शिकायत।",
        descriptionEnglish = "Formal administrative grievance to District Collector under Tuesday Jan Sunwai for delayed or blocked scheme benefits.",
        recipientAuthorityHindi = "माननीय जिला दंडाधिकारी एवं कलेक्टर महोदय, मध्य प्रदेश",
        recipientAuthorityEnglish = "Honorable District Magistrate & Collector, Govt of MP",
        requiredDocuments = listOf(
          "पूर्व में प्रस्तुत आवेदन पत्र की पावती / रसीद छायाप्रति",
          "आधार कार्ड एवं समग्र परिवार आईडी छायाप्रति",
          "स्थायी जाति प्रमाण पत्र छायाप्रति",
          "बैंक पासबुक छायाप्रति (आधार NPCI सक्रिय)",
          "अधिकारियों से हुई बातचीत या अस्वीकृति का विवरण"
        ),
        fields = listOf(
          ApplicationFormField("applicant_name", "आवेदक का नाम", "Applicant Full Name", "उदा. रामसिंह सहरिया"),
          ApplicationFormField("father_spouse", "पिता/पति/पत्नी का नाम", "Father/Spouse Name", "उदा. भगवानलाल"),
          ApplicationFormField("caste_category", "सामाजिक श्रेणी", "Social Category", "अनुसूचित जनजाति (ST) / विशेष पिछड़ी जनजाति (सहरिया)"),
          ApplicationFormField("scheme_name", "संबंधित शासकीय योजना का नाम", "Government Scheme Name", "उदा. PM-JANMAN आवास योजना / आहार अनुदान"),
          ApplicationFormField("application_receipt_no", "पूर्व आवेदन क्रमांक / पावती रसीद संख्या", "Prior Application / Receipt No.", "उदा. JANMAN-2025-8491"),
          ApplicationFormField("application_date", "आवेदन प्रस्तुत करने की तारीख", "Application Submission Date", "उदा. 15 जनवरी 2026"),
          ApplicationFormField("months_pending", "कितने समय से लंबित है", "Duration of Pending", "उदा. 9 माह से अधिक"),
          ApplicationFormField("grievance_details", "समस्या व अधिकारियों की टालमटोल का विवरण", "Detailed Grievance", "ग्राम पंचायत व जनपद में कई बार चक्कर काटने पर भी कोई सुनवाई नहीं हुई और न ही कोई लिखित कारण सूचित किया गया।"),
          ApplicationFormField("relief_sought", "अपेक्षित विधिक राहत / आदेश की मांग", "Relief Demanded", "योजना का लाभ तुरंत स्वीकृत कराकर बैंक खाते में राशि जारी की जाए अथवा लिखित विधिक कारण उपलब्ध कराया जाए।"),
          ApplicationFormField("village", "गाँव", "Village", "उदा. सहरिया डांडा"),
          ApplicationFormField("gram_panchayat", "ग्राम पंचायत", "Gram Panchayat", "उदा. गोरस"),
          ApplicationFormField("block", "तहसील / विकासखंड", "Block / Tehsil", "उदा. कराहल"),
          ApplicationFormField("district", "जिला", "District", "उदा. श्योपुर"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9826194821")
        )
      ),

      ApplicationTemplate(
        id = "tpl-sbm-g",
        titleHindi = "स्वच्छ भारत मिशन ग्रामीण व्यक्तिगत शौचालय प्रोत्साहन राशि आवेदन",
        titleEnglish = "Swachh Bharat Mission (Gramin) Toilet Incentive Application",
        category = CaseCategory.PUBLIC_SERVICES,
        descriptionHindi = "ग्रामीण क्षेत्र में व्यक्तिगत घरेलू शौचालय (IHHL) निर्माण उपरांत ₹12,000 की प्रोत्साहन राशि भुगतान हेतु आवेदन।",
        descriptionEnglish = "Application for release of ₹12,000 incentive upon completion of individual household latrine (IHHL).",
        recipientAuthorityHindi = "मुख्य कार्यपालन अधिकारी (CEO), जनपद पंचायत / ग्राम पंचायत सचिव",
        recipientAuthorityEnglish = "CEO Janpad Panchayat / Gram Panchayat Secretary",
        requiredDocuments = listOf(
          "आधार कार्ड छायाप्रति",
          "समग्र परिवार आईडी छायाप्रति",
          "बैंक पासबुक छायाप्रति (आधार लिंक)",
          "जाति प्रमाण पत्र (ST/SC हितग्राही हेतु)",
          "निर्मित शौचालय के साथ लाभार्थी की फोटो (जियो-टैगिंग सत्यापन हेतु)"
        ),
        fields = listOf(
          ApplicationFormField("applicant_name", "आवेदक का नाम", "Applicant Full Name", "उदा. मुन्नी बाई सहरिया"),
          ApplicationFormField("father_spouse", "पिता/पति का नाम", "Father/Spouse Name", "उदा. किशन सहरिया"),
          ApplicationFormField("category", "श्रेणी (ST/SC/BPL)", "Social Category", "ST (सहरिया PVTG)"),
          ApplicationFormField("job_card_no", "मनरेगा जॉब कार्ड संख्या", "Job Card Number", "उदा. MP-23-004-012-0045"),
          ApplicationFormField("toilet_construction_date", "शौचालय निर्माण पूर्ण होने का माह/वर्ष", "Construction Completion Month/Year", "उदा. अक्टूबर 2026"),
          ApplicationFormField("village", "गाँव व टोला", "Village & Hamlet", "उदा. दौनी"),
          ApplicationFormField("gram_panchayat", "ग्राम पंचायत", "Gram Panchayat", "उदा. भटनावर"),
          ApplicationFormField("block", "विकासखंड", "Block", "उदा. पोहरी"),
          ApplicationFormField("district", "जिला", "District", "उदा. शिवपुरी"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9407281923")
        )
      ),

      ApplicationTemplate(
        id = "tpl-fra",
        titleHindi = "वनाधिकार दावा आवेदन (प्रारूप 'क')",
        titleEnglish = "Individual Forest Rights Claim (Form A)",
        category = CaseCategory.FOREST_RIGHTS,
        descriptionHindi = "ग्राम सभा वनाधिकार समिति (FRC) को व्यक्तिगत वन अधिकार पट्टा दावा प्रस्तुत करने हेतु विधिक प्रारूप।",
        descriptionEnglish = "Statutory petition to Gram Sabha Forest Rights Committee for title deed under FRA 2006.",
        recipientAuthorityHindi = "अध्यक्ष/सचिव, वनाधिकार समिति, ग्राम सभा",
        recipientAuthorityEnglish = "Chairperson/Secretary, Forest Rights Committee, Gram Sabha",
        requiredDocuments = listOf("मतदाता पहचान पत्र / आधार", "राशन कार्ड", "कब्जा साक्ष्य (पेड़, कुआँ, रसीद)", "बुजुर्गों का पंचनामा"),
        fields = listOf(
          ApplicationFormField("applicant_name", "आवेदक का पूरा नाम", "Applicant Full Name"),
          ApplicationFormField("father_spouse", "पिता/पति का नाम", "Father/Spouse Name"),
          ApplicationFormField("village", "गाँव व टोला का नाम", "Village & Hamlet"),
          ApplicationFormField("gram_panchayat", "ग्राम पंचायत", "Gram Panchayat"),
          ApplicationFormField("block", "विकासखंड (ब्लॉक)", "Block"),
          ApplicationFormField("district", "जिला", "District"),
          ApplicationFormField("land_area", "दावाकृत वनभूमि का क्षेत्रफल (एकड़)", "Claimed Area (Acres)"),
          ApplicationFormField("occupation_year", "कब्जा किस वर्ष से है (2005 से पूर्व)", "Year of Occupation (pre-2005)")
        )
      ),

      ApplicationTemplate(
        id = "tpl-jansunwai",
        titleHindi = "कलेक्टर जनसुनवाई सामान्य शिकायत आवेदन",
        titleEnglish = "District Collector Jan Sunwai General Petition",
        category = CaseCategory.GOVT_SCHEMES,
        descriptionHindi = "जिला कलेक्टर के समक्ष जनसुनवाई में राशन, आवास, सड़क अथवा प्रशासनिक उपेक्षा की सामान्य शिकायत।",
        descriptionEnglish = "Formal administrative petition for Tuesday Collector Jan Sunwai grievance redressal.",
        recipientAuthorityHindi = "माननीय जिला दंडाधिकारी एवं कलेक्टर महोदय",
        recipientAuthorityEnglish = "Honorable District Magistrate & Collector",
        requiredDocuments = listOf("पहचान पत्र", "समस्या संबंधी साक्ष्य"),
        fields = listOf(
          ApplicationFormField("applicant_name", "आवेदक का नाम", "Applicant Name"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone"),
          ApplicationFormField("district", "जिला", "District"),
          ApplicationFormField("subject", "विषय (संक्षिप्त)", "Subject"),
          ApplicationFormField("grievance_details", "समस्या का विवरण", "Grievance Details"),
          ApplicationFormField("relief_sought", "अपेक्षित राहत", "Relief Sought")
        )
      ),

      ApplicationTemplate(
        id = "tpl-ladli-behna",
        titleHindi = "लाड़ली बहना योजना - आवेदन / DBT ई-केवाईसी सुधार पत्र",
        titleEnglish = "Ladli Behna Yojana - Application & DBT Correction Petition",
        category = CaseCategory.GOVT_SCHEMES,
        descriptionHindi = "लाड़ली बहना योजना अंतर्गत ₹1,250 प्रतिमाह राशि प्राप्त करने, सूची में नाम जोड़ने अथवा बैंक डीबीटी व ई-केवाईसी सुधार हेतु विधिवत आवेदन।",
        descriptionEnglish = "Formal administrative petition for Ladli Behna registration, name addition, or Aadhaar DBT seeding correction.",
        recipientAuthorityHindi = "परियोजना अधिकारी / बाल विकास परियोजना अधिकारी (WCD) एवं ग्राम पंचायत सचिव",
        recipientAuthorityEnglish = "Child Development Project Officer (CDPO) & Gram Panchayat Secretary",
        requiredDocuments = listOf("समग्र परिवार एवं सदस्य आईडी", "आधार कार्ड", "बैंक पासबुक (डीबीटी सक्रिय)", "स्व-घोषणा पत्र"),
        fields = listOf(
          ApplicationFormField("applicant_name", "महिला हितग्राही का नाम", "Beneficiary Woman Name", "उदा. अनीता आदिवासी"),
          ApplicationFormField("husband_name", "पति / पिता का नाम", "Husband / Father Name", "उदा. राम सिंह"),
          ApplicationFormField("age", "आयु (वर्ष में)", "Age in Years", "उदा. 28 वर्ष"),
          ApplicationFormField("samagra_id", "सदस्य समग्र आईडी (9 अंक)", "Member Samagra ID", "उदा. 182749201"),
          ApplicationFormField("aadhaar_no", "आधार कार्ड संख्या", "Aadhaar Number", "उदा. XXXX-XXXX-4589"),
          ApplicationFormField("bank_details", "बैंक का नाम व खाता संख्या", "Bank Name & Account No", "उदा. SBI खाता क्र. 3049281729"),
          ApplicationFormField("village", "गाँव व टोला", "Village & Hamlet", "उदा. पीपलखेड़ा"),
          ApplicationFormField("gram_panchayat", "ग्राम पंचायत", "Gram Panchayat", "उदा. रामपुर"),
          ApplicationFormField("block", "विकासखंड", "Block", "उदा. कराहल"),
          ApplicationFormField("district", "जिला", "District", "उदा. श्योपुर"),
          ApplicationFormField("phone", "सक्रिय मोबाइल नंबर", "Active Phone", "उदा. 9826012345"),
          ApplicationFormField("request_type", "आवेदन का प्रकार / समस्या", "Application Type / Grievance", "उदा. ई-केवाईसी सत्यापन उपरांत भी ₹1,250 DBT राशि न मिलना")
        )
      ),

      ApplicationTemplate(
        id = "tpl-pm-kusum",
        titleHindi = "प्रधानमंत्री कुसुम सोलर कृषि पंप 90% अनुदान आवेदन पत्र",
        titleEnglish = "PM-KUSUM Solar Agriculture Water Pump 90% Subsidy Application",
        category = CaseCategory.GOVT_SCHEMES,
        descriptionHindi = "खेत पर दिन में निःशुल्क सिंचाई हेतु 3HP / 5HP / 7.5HP सौर ऊर्जा पंप 90% सरकारी अनुदान पर स्थापना हेतु विधिक आवेदन।",
        descriptionEnglish = "Statutory application to MP Urja Vikas Nigam for 90% subsidized solar agriculture irrigation pump.",
        recipientAuthorityHindi = "जिला अक्षय ऊर्जा अधिकारी, म.प्र. ऊर्जा विकास निगम लिमिटेड",
        recipientAuthorityEnglish = "District Renewable Energy Officer, MP Urja Vikas Nigam Ltd",
        requiredDocuments = listOf("खसरा खतौनी (B-1) व भू-नक्शा", "आधार कार्ड", "जाति प्रमाण पत्र", "बैंक पासबुक", "जल स्रोत की फोटो"),
        fields = listOf(
          ApplicationFormField("applicant_name", "कृषक का पूरा नाम", "Farmer Full Name", "उदा. बाबूलाल भील"),
          ApplicationFormField("father_name", "पिता का नाम", "Father Name", "उदा. मंगतू भील"),
          ApplicationFormField("social_category", "सामाजिक वर्ग (ST/PVTG/SC/लघु कृषक)", "Social Category", "ST (अनुसूचित जनजाति)"),
          ApplicationFormField("khasra_no", "खेत का खसरा क्रमांक", "Land Khasra Number", "उदा. खसरा क्र. 45/2"),
          ApplicationFormField("land_area", "कुल कृषि भूमि (एकड़ में)", "Total Land Area (Acres)", "उदा. 2.5 एकड़"),
          ApplicationFormField("pump_capacity", "वांछित पंप क्षमता (3 HP / 5 HP / 7.5 HP)", "Pump Capacity", "5 HP (सबमर्सिबल / सोलर)"),
          ApplicationFormField("water_source", "विद्यमान जल स्रोत (कुआं / बोरवेल / नदी / नाला)", "Water Source", "उदा. निजी कुआं (जल स्तर 40 फीट)"),
          ApplicationFormField("village", "गाँव का नाम", "Village", "उदा. झिरी"),
          ApplicationFormField("block", "विकासखंड", "Block", "उदा. बड़वानी"),
          ApplicationFormField("district", "जिला", "District", "उदा. बड़वानी"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9893012345")
        )
      ),

      ApplicationTemplate(
        id = "tpl-udid-divyang",
        titleHindi = "विशिष्ट दिव्यांगता पहचान (UDID) कार्ड एवं पेंशन आवेदन पत्र",
        titleEnglish = "Unique Disability ID (UDID) Card & Divyang Pension Application",
        category = CaseCategory.GOVT_SCHEMES,
        descriptionHindi = "दिव्यांगता प्रमाण पत्र / UDID स्मार्ट कार्ड जारी करने, ₹600-₹1,000 मासिक पेंशन एवं निःशुल्क सहायक उपकरण (ट्राइसाइकिल/श्रवण यंत्र) हेतु आवेदन।",
        descriptionEnglish = "Application for UDID Card issuance, monthly disability pension, and assistive devices via ALIMCO.",
        recipientAuthorityHindi = "मुख्य चिकित्सा एवं स्वास्थ्य अधिकारी (CMHO) / उप संचालक सामाजिक न्याय, मध्य प्रदेश",
        recipientAuthorityEnglish = "CMHO & Deputy Director, Social Justice & PwD Welfare Department",
        requiredDocuments = listOf("चिकित्सा बोर्ड प्रमाण पत्र", "आधार कार्ड", "समग्र आईडी", "पासपोर्ट फोटो", "बैंक पासबुक"),
        fields = listOf(
          ApplicationFormField("applicant_name", "दिव्यांगजन का नाम", "Person with Disability Name", "उदा. कैलाश सहरिया"),
          ApplicationFormField("guardian_name", "माता / पिता / अभिभावक का नाम", "Guardian Name", "उदा. मदन सहरिया"),
          ApplicationFormField("age", "आयु (वर्ष में)", "Age in Years", "उदा. 34 वर्ष"),
          ApplicationFormField("disability_type", "दिव्यांगता का प्रकार", "Disability Type", "उदा. अस्थि दिव्यांगता (Locomotor) / दृष्टिबाधित"),
          ApplicationFormField("disability_percent", "दिव्यांगता प्रतिशत", "Disability Percentage", "उदा. 60 प्रतिशत"),
          ApplicationFormField("samagra_id", "समग्र आईडी", "Samagra Member ID", "उदा. 192837465"),
          ApplicationFormField("aadhaar_no", "आधार संख्या", "Aadhaar Number", "उदा. XXXX-XXXX-7890"),
          ApplicationFormField("relief_sought", "अपेक्षित सहायता (UDID / पेंशन / उपकरण)", "Assistance Requested", "उदा. UDID कार्ड जारी करना एवं मासिक पेंशन स्वीकृति"),
          ApplicationFormField("village", "गाँव", "Village", "उदा. अगरा"),
          ApplicationFormField("block", "ब्लॉक", "Block", "उदा. विजयपुर"),
          ApplicationFormField("district", "जिला", "District", "उदा. श्योपुर"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9755123456")
        )
      ),

      ApplicationTemplate(
        id = "tpl-pm-vishwakarma",
        titleHindi = "प्रधानमंत्री विश्वकर्मा योजना - कारीगर संबल व टूलकिट सहायता आवेदन",
        titleEnglish = "PM Vishwakarma Scheme - Traditional Artisan Support & Toolkit Application",
        category = CaseCategory.WAGES_LIVELIHOOD,
        descriptionHindi = "पारंपरिक 18 शिल्पकला व्यवसायों के कारीगरों हेतु राष्ट्रीय पहचान पत्र, ₹15,000 टूलकिट वाउचर एवं 5% ब्याज पर व्यवसाय संवर्धन ऋण आवेदन।",
        descriptionEnglish = "Application for PM Vishwakarma digital certificate, ₹15,000 toolkit e-voucher, and 5% subsidized loan.",
        recipientAuthorityHindi = "महाप्रबंधक, जिला व्यापार एवं उद्योग केंद्र (DTIC) / ग्राम पंचायत सचिव",
        recipientAuthorityEnglish = "General Manager, District Trade & Industries Centre (DTIC)",
        requiredDocuments = listOf("आधार कार्ड", "कारीगरी का साक्ष्य", "बैंक पासबुक", "राशन कार्ड / समग्र आईडी"),
        fields = listOf(
          ApplicationFormField("applicant_name", "कारीगर / शिल्पकार का नाम", "Artisan Name", "उदा. भगवान दास लोहार"),
          ApplicationFormField("father_spouse", "पिता / पति का नाम", "Father / Spouse Name", "उदा. हरिकिशन लोहार"),
          ApplicationFormField("trade_name", "पारंपरिक व्यवसाय / ट्रेड", "Artisan Trade Name", "उदा. लोहार (Blacksmith) / बढ़ई / राजमिस्त्री"),
          ApplicationFormField("experience_years", "व्यवसाय अनुभव (वर्ष में)", "Experience in Years", "उदा. 15 वर्ष"),
          ApplicationFormField("aadhaar_no", "आधार कार्ड नंबर", "Aadhaar Number", "उदा. XXXX-XXXX-2345"),
          ApplicationFormField("bank_account", "बैंक खाता संख्या व शाखा", "Bank Account No & Branch", "उदा. मध्यांचल ग्रामीण बैंक खाता 892019283"),
          ApplicationFormField("village", "गाँव व टोला", "Village", "उदा. फतेहपुर"),
          ApplicationFormField("block", "विकासखंड", "Block", "उदा. शिवपुरी"),
          ApplicationFormField("district", "जिला", "District", "उदा. शिवपुरी"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9926123456")
        )
      ),

      ApplicationTemplate(
        id = "tpl-akanksha",
        titleHindi = "आकांक्षा योजना - जनजातीय विद्यार्थी जेईई / नीट / क्लैट निःशुल्क कोचिंग आवेदन",
        titleEnglish = "Akanksha Yojana - Free JEE/NEET/CLAT Residential Coaching Application",
        category = CaseCategory.EDUCATION,
        descriptionHindi = "जनजातीय कार्य विभाग द्वारा 10वीं उत्तीर्ण प्रतिभावान एसटी विद्यार्थियों को भोपाल/इंदौर में शत-प्रतिशत निःशुल्क कोचिंग एवं छात्रावास सुविधा।",
        descriptionEnglish = "Application for tribal merit students for 100% free residential coaching for IIT-JEE, NEET, and CLAT.",
        recipientAuthorityHindi = "सहायक आयुक्त / संभागीय उपायुक्त, जनजातीय कार्य विभाग, मध्य प्रदेश",
        recipientAuthorityEnglish = "Assistant Commissioner / Deputy Commissioner, Tribal Affairs Department, MP",
        requiredDocuments = listOf("10वीं की अंकसूची", "स्थाई डिजिटल एसटी जाति प्रमाण पत्र", "मूल निवासी प्रमाण पत्र", "आय प्रमाण पत्र", "आधार कार्ड"),
        fields = listOf(
          ApplicationFormField("applicant_name", "विद्यार्थी का नाम", "Student Name", "उदा. विकास मंडावी"),
          ApplicationFormField("father_name", "पिता का नाम", "Father Name", "उदा. लखन मंडावी"),
          ApplicationFormField("class_10_percent", "कक्षा 10वीं के प्राप्तांक (%)", "Class 10 Percentage", "उदा. 82.5%"),
          ApplicationFormField("target_exam", "लक्षित परीक्षा (JEE Engineering / NEET Medical / CLAT Law)", "Target Examination", "NEET (मेडिकल प्रवेश परीक्षा)"),
          ApplicationFormField("school_name", "10वीं उत्तीर्ण विद्यालय का नाम", "School Name", "उदा. शासकीय उत्कृष्ट उच्चतर माध्यमिक विद्यालय"),
          ApplicationFormField("caste_cert_no", "डिजिटल जाति प्रमाण पत्र क्रमांक", "Digital Caste Certificate No", "उदा. RS/410/01/2023/12345"),
          ApplicationFormField("annual_income", "परिवार की कुल वार्षिक आय (₹)", "Annual Family Income", "उदा. ₹80,000"),
          ApplicationFormField("preferred_city", "प्राथमिकता कोचिंग शहर (भोपाल / इंदौर / जबलपुर / ग्वालियर)", "Preferred Coaching City", "इंदौर (Indore)"),
          ApplicationFormField("village", "गाँव", "Village", "उदा. मवई"),
          ApplicationFormField("block", "विकासखंड", "Block", "उदा. मंडला"),
          ApplicationFormField("district", "जिला", "District", "उदा. मंडला"),
          ApplicationFormField("phone", "मोबाइल नंबर", "Contact Phone", "उदा. 9425123456")
        )
      )
    )

    // 6. Village Priorities
    _villagePriorities.value = listOf(
      VillagePriorityItem(
        id = "vp-01",
        village = "सहरिया डांडा (Sahariya Danda)",
        gramPanchayat = "गोरस (Goras)",
        block = "कराहल (Karahal)",
        district = "श्योपुर (Sheopur)",
        theme = "पेयजल व स्वच्छता (Drinking Water)",
        communityPriority = "टोला में सोलर पेयजल पंप एवं 5000 लीटर की टंकी की स्थापना",
        sourceOfInfo = "Gram Sabha Resolution",
        meetingDate = "2026-10-02",
        participantsCount = 74,
        proposedAction = "लोक स्वास्थ्य यांत्रिकी विभाग (PHED) को जल जीवन मिशन अंतर्गत प्रस्ताव प्रेषण",
        responsibleInstitution = "कार्यपालन यंत्री, PHED श्योपुर",
        followUpDate = "2026-11-15",
        status = "Representation Submitted",
        recordedBy = "रमेश सहरिया (वॉलंटियर)"
      ),
      VillagePriorityItem(
        id = "vp-02",
        village = "दौनी (Dauni)",
        gramPanchayat = "भटनावर (Bhatnawar)",
        block = "पोहरी (Pohri)",
        district = "शिवपुरी (Shivpuri)",
        theme = "शिक्षा व बाल पोषण (Education & Nutrition)",
        communityPriority = "सहरिया बस्ती में नए आँगनवाड़ी भवन का निर्माण",
        sourceOfInfo = "Women SHG Consultation",
        meetingDate = "2026-09-24",
        participantsCount = 42,
        proposedAction = "महिला एवं बाल विकास विभाग (WCD) में संयुक्त मांग पत्र",
        responsibleInstitution = "जिला कार्यक्रम अधिकारी, WCD शिवपुरी",
        followUpDate = "2026-11-05",
        status = "Sanctioned",
        recordedBy = "सुनीता शर्मा (केस मैनेजर)"
      )
    )

    // 7. Livelihoods
    _livelihoods.value = listOf(
      LivelihoodOpportunity(
        id = "lh-01",
        titleHindi = "लघु वनोपज (NTFP) संकलन - महुआ, चिरौंजी, तेंदू पत्ता व गोंद",
        titleEnglish = "Minor Forest Produce (NTFP) - Mahua, Chironji, Tendu & Gum",
        sector = "Forest Produce (NTFP)",
        geographicCoverage = "कराहल, पोहरी, बमोरी, पहाड़गढ़",
        descriptionHindi = "वन धन विकास केंद्र के माध्यम से बिचौलियों से मुक्ति, न्यूनतम समर्थन मूल्य (MSP) की गारंटी तथा प्राथमिक ग्रेडिंग से 40% अधिक आय।",
        descriptionEnglish = "Value addition and fair price realization for forest collectors through TRIFED Van Dhan Vikas Kendras.",
        eligibilityHindi = "पारंपरिक वनवासी व सहरिया संग्राहक परिवार",
        eligibilityEnglish = "Traditional tribal forest gatherers",
        processHindi = "स्थानीय प्राथमिक वनोपज समिति में पंजीयन कराकर सीधा क्रय केंद्र पर विक्रय करें।",
        processEnglish = "Register at cooperative society and sell directly at MSP center.",
        contactInfo = "प्रबंधक, जिला वनोपज यूनियन - 7440323972 / 8103056522",
        verifiedSource = "मध्य प्रदेश राज्य लघु वनोपज संघ व TRIFED"
      ),
      LivelihoodOpportunity(
        id = "lh-02",
        titleHindi = "सहरिया पारंपरिक बाँस शिल्प व घरेलू हस्तकला समूह",
        titleEnglish = "Sahariya Traditional Bamboo Craft & Artisan Guild",
        sector = "Handicraft & Enterprise",
        geographicCoverage = "शिवपुरी व श्योपुर जिले",
        descriptionHindi = "सुराहीदार टोकरियाँ, अनाज कोठिला, पंखे निर्माण हेतु उन्नत औजार किट व सीधे बाजार लिंकेज।",
        descriptionEnglish = "Upgraded tools, cluster design training, and urban artisan market linkages.",
        eligibilityHindi = "स्व-सहायता समूह (SHG) की महिलाएँ",
        eligibilityEnglish = "Self Help Group women",
        processHindi = "JHS शिल्प केंद्र पोहरी में आवेदन करें।",
        processEnglish = "Apply at JHS Artisan Center Pohri.",
        contactInfo = "JHS लाइवलीहुड सेल - 8103056522",
        verifiedSource = "JHS हस्तशिल्प क्लस्टर"
      )
    )

    // 8. Experts & Helplines (with official team numbers 7440323972, 8103056522)
    _experts.value = listOf(
      ExpertListing(
        id = "exp-01",
        name = "Justice Hub Society (JHS) विधिक सहायता क्लिनिक",
        organization = "जस्टिस हब सोसाइटी (JHS)",
        category = "निःशुल्क विधिक सहायता व पैरवी",
        geographicCoverage = "ग्वालियर-चंबल (7 जिले)",
        publicContact = "हेल्पलाइन: 7440323972, 8103056522",
        referralProcess = "पोर्टल से आवेदन करें अथवा सीधे टीम को फोन करें।",
        descriptionHindi = "वनाधिकार दावों की जांच, धारा 170-ख भूमि वापसी, जनसुनवाई ड्राफ्टिंग व प्रशासनिक फॉलो-अप।",
        descriptionEnglish = "Free legal aid, FRA land defense, and administrative grievance representation."
      ),
      ExpertListing(
        id = "exp-02",
        name = "जिला विधिक सेवा प्राधिकरण (DLSA)",
        organization = "जिला एवं सत्र न्यायालय, श्योपुर व शिवपुरी",
        category = "सरकारी निःशुल्क अधिवक्ता",
        geographicCoverage = "संपूर्ण संभाग",
        publicContact = "टोल फ्री: 15100",
        referralProcess = "अनुसूचित जनजाति के नागरिकों को अदालत में पैरवी हेतु वकील उपलब्ध कराया जाता है।",
        descriptionHindi = "नालसा (NALSA) के अंतर्गत अदालत में निःशुल्क अधिवक्ता नियुक्ति।",
        descriptionEnglish = "Free government legal representation in court."
      )
    )

    _helplines.value = listOf(
      HelplineItem("7440323972", "JHS केंद्रीय विधिक सहायता सेल (Central Legal Desk)", "JHS Central Legal Helpdesk", "वनाधिकार, भूमि विवाद, राशन व कानूनी ड्राफ्टिंग में सीधी सहायता।", "Direct support for FRA claims, land disputes, and legal petitions.", true, "08:00 - 21:00"),
      HelplineItem("8103056522", "JHS मैदानी समन्वय व आपातकालीन सहायता (Field Coordinator)", "JHS Field & Community Coordination", "गाँव में वॉलंटियर विजिट, जनसुनवाई और तत्काल सामुदायिक हस्तक्षेप।", "Field visits, village grievance assistance, and community coordinator.", true, "24x7"),
      HelplineItem("15100", "नालसा राष्ट्रीय निःशुल्क विधिक सेवा", "NALSA National Free Legal Aid Helpline", "गरीब, आदिवासी एवं महिलाओं के लिए मुफ्त कानूनी सलाह व सरकारी वकील।", "Toll-free 24x7 legal advice by National Legal Services Authority.", true, "24x7"),
      HelplineItem("181", "मध्य प्रदेश मुख्यमंत्री हेल्पलाइन (CM Helpline)", "MP Chief Minister Grievance Helpline", "किसी भी सरकारी विभाग की शिकायत व योजनाओं की प्रशासनिक निगरानी।", "Direct citizen grievance redressal for all MP government departments.", true, "24x7"),
      HelplineItem("112", "राष्ट्रीय आपातकालीन सेवा (ERSS Police/Ambulance)", "National Emergency (Police/Ambulance/Fire)", "आपातकाल में पुलिस, एम्बुलेंस और सुरक्षा की एकीकृत सेवा।", "Unified emergency assistance for police, medical, and fire emergencies.", true, "24x7"),
      HelplineItem("1098", "चाइल्डलाइन (बाल सुरक्षा आपातकालीन सेवा)", "Childline (Emergency Child Protection)", "बाल श्रम, शोषण अथवा संकट में घिरे बच्चों की सुरक्षा।", "Emergency assistance and rehabilitation for children in distress.", true, "24x7"),
      HelplineItem("1913", "मनरेगा शिकायत व सूचना हेल्पलाइन", "MGNREGA Grievance & Information Helpline", "जॉब कार्ड, काम की मांग अथवा बकाया मजदूरी की आधिकारिक शिकायत।", "Helpline for wage delays and work allocation grievances.", true, "10:00 - 18:00")
    )

    _volunteerVisits.value = listOf(
      VolunteerVisitRecord(
        id = "vis-01",
        volunteerName = "रमेश सहरिया",
        village = "सहरिया डांडा",
        gramPanchayat = "गोरस",
        block = "कराहल",
        district = "श्योपुर",
        visitDate = "2026-10-24",
        participantsCount = 18,
        meetingPurpose = "वनाधिकार समिति (FRC) प्रस्ताव व बुजुर्गों के साक्ष्य संकलन बैठक",
        observations = "गाँव के 12 परिवारों के पास 2005 से पूर्व की कब्जा रसीदें मिलीं।",
        verbalConsentConfirmed = true,
        actionItems = "5 नवंबर की ग्राम सभा बैठक में सभी दावे प्रस्तुत करना।",
        submittedAt = "2026-10-24 18:30",
        isSynced = true
      )
    )

    _notifications.value = listOf(
      InAppNotification(
        id = "notif-01",
        timestamp = "आज, 10:30 AM",
        titleHindi = "JHS विधिक सहायता हेल्पलाइन जारी",
        titleEnglish = "JHS Legal Aid Helpline Numbers Active",
        messageHindi = "किसी भी सहायता के लिए टीम से 7440323972 या 8103056522 पर सीधे बात करें।",
        messageEnglish = "Call our team directly at 7440323972 or 8103056522 for any legal assistance.",
        isRead = false,
        severity = "info"
      )
    )

    _auditLogs.value = listOf(
      AuditLogEntry(
        id = "aud-01",
        timestamp = "2026-10-26 15:00:12",
        userName = "सुनीता शर्मा",
        userRole = UserRole.CASE_MANAGER,
        action = "स्थिति परिवर्तन (Status Updated)",
        targetType = "case",
        targetId = "NYAY-2026-0041",
        details = "स्थिति 'आवेदन तैयार हो रहा है' की गई।"
      )
    )

    _assistantMessages.value = listOf(
      AssistantMessage(
        id = "msg-01",
        isUser = false,
        text = "नमस्ते! मैं NyaySetu सहायता सहायक (Support Assistant) हूँ। मैं वनाधिकार, सरकारी योजनाओं, केस स्टेटस और कानूनी ड्राफ्टिंग में आपकी मदद कर सकता हूँ। आप सीधे JHS टीम हेल्पलाइन 7440323972 या 8103056522 पर भी संपर्क कर सकते हैं। आप क्या जानना चाहते हैं?",
        timestamp = "अभी (Just now)",
        quickAction = null
      )
    )
  }

  // Authentication: Login with User ID, Phone, or Email and Password
  fun login(input: String, passwordInput: String): LoginAuthResult {
    val cleanInput = input.trim()
    val cleanPass = passwordInput.trim()
    val user = _users.value.find { 
      (it.username.equals(cleanInput, ignoreCase = true) || 
       it.phone == cleanInput || 
       (it.email.isNotBlank() && it.email.equals(cleanInput, ignoreCase = true)) ||
       (it.role == UserRole.SUPER_ADMIN && (cleanInput.equals("Meenakshijusticehub", ignoreCase = true) || cleanInput.equals("Sanjeevjusticehub", ignoreCase = true) || cleanInput.equals("Hardikjusticehub", ignoreCase = true) || cleanInput.equals("admin", ignoreCase = true) || cleanInput == "7440323972" || cleanInput.equals("admin_jhs", ignoreCase = true)))) && 
      (it.passwordHash == cleanPass || (it.role == UserRole.SUPER_ADMIN && (cleanPass == "admin123" || cleanPass == "7440323972" || cleanPass == "admin")))
    }
    return when {
      user == null -> LoginAuthResult.InvalidCredentials
      user.isSuspended -> LoginAuthResult.AccountSuspended(user)
      !user.isVerifiedByAdmin -> LoginAuthResult.PendingApproval(user)
      else -> {
        _currentUser.value = user
        persistSessionUserId(user.id)
        addAuditLog("USER_LOGIN", "User @${user.username} logged in successfully", "auth", user.id)
        LoginAuthResult.Success(user)
      }
    }
  }

  // Password Recovery / Reset
  fun resetPassword(identifier: String, newPass: String): Boolean {
    val clean = identifier.trim()
    val user = _users.value.find {
      it.username.equals(clean, ignoreCase = true) || it.phone == clean || (it.email.isNotBlank() && it.email.equals(clean, ignoreCase = true))
    } ?: return false
    val updated = user.copy(passwordHash = newPass.trim())
    _users.value = _users.value.map { if (it.id == user.id) updated else it }
    addAuditLog("PASSWORD_RESET", "Password reset for user @${user.username}", "auth", user.id)
    return true
  }

  // Contact Administrator Message
  fun contactAdmin(name: String, phone: String, message: String): Boolean {
    val time = SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date())
    val notif = InAppNotification(
      id = "notif_admin_${System.currentTimeMillis()}",
      timestamp = time,
      titleHindi = "नागरिक सहायता अनुरोध: $name",
      titleEnglish = "Admin Contact Request: $name",
      messageHindi = "फोन: $phone | संदेश: $message",
      messageEnglish = "Phone: $phone | Message: $message",
      severity = "urgent"
    )
    _notifications.value = listOf(notif) + _notifications.value
    addAuditLog("CONTACT_ADMIN", "Help request from $name ($phone): $message", "system")
    return true
  }

  // Authentication: Register New User
  fun registerUser(
    username: String,
    password: String,
    name: String,
    phone: String,
    email: String = "",
    district: String,
    block: String,
    village: String,
    role: UserRole
  ): AppUser {
    val isAutoApproved = (role == UserRole.SUPER_ADMIN)
    val newUser = AppUser(
      id = "usr_${System.currentTimeMillis()}",
      username = username.trim().lowercase(),
      passwordHash = password.trim(),
      name = name.trim(),
      phone = phone.trim(),
      email = email.trim(),
      district = district.trim(),
      block = block.trim(),
      village = village.trim(),
      role = role,
      avatarColorHex = when (role) {
        UserRole.SUPER_ADMIN -> 0xFF0B443E
        UserRole.DEPT_ADMIN -> 0xFF2E7D32
        UserRole.CASE_MANAGER -> 0xFFE3A72F
        UserRole.VOLUNTEER -> 0xFFC56A3D
        else -> 0xFF176B63
      },
      isVerifiedByAdmin = isAutoApproved,
      bio = "JHS सदस्य - $village, $district"
    )
    _users.value = _users.value + newUser
    if (isAutoApproved) {
      _currentUser.value = newUser
      persistSessionUserId(newUser.id)
    }
    // Audit log
    addAuditLog("USER_REGISTRATION", "New user @${newUser.username} registered (Verified: $isAutoApproved)", "user", newUser.id)
    return newUser
  }

  // Administration Power: Verify & Approve User
  fun approveUser(userId: String): Boolean {
    val existing = _users.value.find { it.id == userId } ?: return false
    val updated = existing.copy(isVerifiedByAdmin = true)
    _users.value = _users.value.map { if (it.id == userId) updated else it }
    addAuditLog("USER_APPROVED", "Admin approved registration of @${existing.username}", "user", userId)
    return true
  }

  // Administration Power: Toggle Suspend/Activate Account
  fun toggleUserSuspension(userId: String): Boolean {
    val existing = _users.value.find { it.id == userId } ?: return false
    val newStatus = !existing.isSuspended
    val updated = existing.copy(isSuspended = newStatus)
    _users.value = _users.value.map { if (it.id == userId) updated else it }
    if (newStatus && _currentUser.value?.id == userId) {
      _currentUser.value = null
      persistSessionUserId(null)
    }
    addAuditLog("USER_SUSPENSION_TOGGLE", "Admin changed suspension of @${existing.username} to $newStatus", "user", userId)
    return true
  }

  // Administration Power: Change User Role
  fun changeUserRole(userId: String, newRole: UserRole): Boolean {
    val existing = _users.value.find { it.id == userId } ?: return false
    val updated = existing.copy(role = newRole)
    _users.value = _users.value.map { if (it.id == userId) updated else it }
    if (_currentUser.value?.id == userId) {
      _currentUser.value = updated
    }
    addAuditLog("ROLE_CHANGED", "Admin changed role of @${existing.username} to ${newRole.name}", "user", userId)
    return true
  }

  // Administration Power: Remove/Delete User
  fun deleteUser(userId: String): Boolean {
    val existing = _users.value.find { it.id == userId } ?: return false
    _users.value = _users.value.filter { it.id != userId }
    if (_currentUser.value?.id == userId) {
      _currentUser.value = null
      persistSessionUserId(null)
    }
    addAuditLog("USER_DELETED", "Admin removed user @${existing.username} (${existing.name})", "user", userId)
    return true
  }

  // Administration Power: Delete Case
  fun deleteCase(caseId: String): Boolean {
    val existing = _cases.value.find { it.id == caseId } ?: return false
    _cases.value = _cases.value.filter { it.id != caseId }
    addAuditLog("CASE_DELETED", "Admin deleted case $caseId (${existing.title})", "case", caseId)
    return true
  }

  // Administration Power: Edit & Update Case Data
  fun updateCase(updated: CaseRecord): Boolean {
    val index = _cases.value.indexOfFirst { it.id == updated.id }
    if (index == -1) return false
    _cases.value = _cases.value.toMutableList().also { it[index] = updated }
    addAuditLog("CASE_UPDATED", "Admin updated case data for ${updated.id} (${updated.status.labelHi})", "case", updated.id)
    return true
  }

  // Scheme Verification System Management
  fun updateSchemeStatus(schemeId: String, newStatus: SchemeStatus) {
    val today = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())
    _schemes.value = _schemes.value.map { s ->
      if (s.id == schemeId) {
        s.copy(
          status = newStatus,
          lastVerifiedDate = today,
          verifierName = _currentUser.value?.name ?: "JHS Verifier"
        )
      } else s
    }
    addAuditLog("SCHEME_STATUS_UPDATED", "Scheme $schemeId status changed to ${newStatus.name}", "scheme", schemeId)
  }

  fun reportSchemeError(schemeId: String, schemeName: String, reporter: String, role: UserRole, desc: String) {
    val time = SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date())
    val rep = SchemeErrorReport(
      id = "err_${System.currentTimeMillis()}",
      schemeId = schemeId,
      schemeName = schemeName,
      reportedBy = reporter,
      userRole = role,
      description = desc,
      timestamp = time,
      isResolved = false
    )
    _schemeErrorReports.value = listOf(rep) + _schemeErrorReports.value
    addAuditLog("SCHEME_ERROR_REPORTED", "User $reporter reported error in $schemeName: $desc", "scheme", schemeId)
  }

  fun resolveSchemeError(reportId: String) {
    _schemeErrorReports.value = _schemeErrorReports.value.map {
      if (it.id == reportId) it.copy(isResolved = true) else it
    }
    addAuditLog("SCHEME_ERROR_RESOLVED", "Admin resolved scheme error report $reportId", "scheme")
  }

  // RTI Assistance Center
  fun saveRtiDraft(draft: RtiDraft) {
    _rtiDrafts.value = listOf(draft) + _rtiDrafts.value
    addAuditLog("RTI_DRAFT_CREATED", "RTI draft prepared for ${draft.publicAuthority} by ${draft.applicantName}", "rti", draft.id)
  }

  // Community Action Tracking
  fun updateCommunityActionStage(issueId: String, newStage: CommunityActionStage, progressNote: String) {
    val today = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())
    _communityActionIssues.value = _communityActionIssues.value.map { issue ->
      if (issue.id == issueId) {
        val updatedNotes = if (progressNote.isNotBlank()) issue.progressNotes + "$today: $progressNote" else issue.progressNotes
        issue.copy(currentStage = newStage, progressNotes = updatedNotes, updatedDate = today)
      } else issue
    }
    addAuditLog("COMMUNITY_ACTION_STAGE", "Issue $issueId moved to ${newStage.labelHi}", "community_action", issueId)
  }

  fun addCommunityActionIssue(title: String, village: String, category: String, desc: String, dept: String) {
    val today = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())
    val newIssue = CommunityActionIssue(
      id = "cai_${System.currentTimeMillis()}",
      title = title,
      village = village,
      category = category,
      currentStage = CommunityActionStage.IDENTIFIED,
      description = desc,
      responsibleDept = dept,
      progressNotes = listOf("$today: समस्या ग्राम सभा में दर्ज की गई"),
      updatedDate = today
    )
    _communityActionIssues.value = listOf(newIssue) + _communityActionIssues.value
    addAuditLog("COMMUNITY_ACTION_CREATED", "New collective issue logged: $title ($village)", "community_action", newIssue.id)
  }

  // User Profile Editing: Edit member details
  fun updateUserProfile(
    userId: String,
    name: String,
    phone: String,
    village: String,
    block: String,
    district: String,
    bio: String,
    avatarIndex: Int
  ): AppUser? {
    val existing = _users.value.find { it.id == userId } ?: return null
    val updated = existing.copy(
      name = name.trim().ifBlank { existing.name },
      phone = phone.trim().ifBlank { existing.phone },
      village = village.trim().ifBlank { existing.village },
      block = block.trim().ifBlank { existing.block },
      district = district.trim().ifBlank { existing.district },
      bio = bio.trim(),
      avatarIndex = avatarIndex
    )
    _users.value = _users.value.map { if (it.id == userId) updated else it }
    if (_currentUser.value?.id == userId) {
      _currentUser.value = updated
    }
    addAuditLog("PROFILE_UPDATED", "User @${updated.username} updated profile details")
    return updated
  }

  fun updateProfilePhoto(userId: String, photoUri: String): AppUser? {
    val existing = _users.value.find { it.id == userId } ?: return null
    val updated = existing.copy(profilePhotoUri = photoUri)
    _users.value = _users.value.map { if (it.id == userId) updated else it }
    if (_currentUser.value?.id == userId) {
      _currentUser.value = updated
    }
    addAuditLog("PROFILE_PHOTO_UPDATED", "User @${updated.username} updated profile picture", "user", userId)
    return updated
  }

  private fun addAuditLog(action: String, details: String, targetType: String = "system", targetId: String = "") {
    val time = SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date())
    val entry = AuditLogEntry(
      id = "log_${System.currentTimeMillis()}",
      timestamp = time,
      userName = _currentUser.value?.name ?: "System",
      userRole = _currentUser.value?.role ?: UserRole.ADMIN,
      action = action,
      targetType = targetType,
      targetId = targetId,
      details = details
    )
    _auditLogs.value = listOf(entry) + _auditLogs.value
  }

  fun logout() {
    persistSessionUserId(null)
    _currentUser.value = null
  }

  // Switch active user directly (useful for demo role testing)
  fun switchUser(user: AppUser) {
    _currentUser.value = user
    persistSessionUserId(user.id, user)
  }

  // Storytelling: Add Story
  fun addStory(
    authorName: String,
    authorRole: UserRole,
    village: String,
    district: String,
    title: String,
    content: String,
    category: String,
    videoUrl: String?,
    audioNote: String? = null
  ): StoryItem {
    val newStory = StoryItem(
      id = "st_${System.currentTimeMillis()}",
      authorName = authorName,
      authorRole = authorRole,
      village = village,
      district = district,
      titleHi = title,
      titleEn = title,
      titleHinglish = title,
      contentHi = content,
      contentEn = content,
      contentHinglish = content,
      category = category,
      videoUrl = if (videoUrl.isNullOrBlank()) null else videoUrl.trim(),
      audioNote = if (audioNote.isNullOrBlank()) null else audioNote.trim(),
      likesCount = 1,
      timestamp = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date()),
      isApproved = true
    )
    _stories.value = listOf(newStory) + _stories.value
    return newStory
  }

  fun likeStory(storyId: String) {
    _stories.value = _stories.value.map {
      if (it.id == storyId) it.copy(likesCount = it.likesCount + 1) else it
    }
  }

  fun deleteStory(storyId: String): Boolean {
    val existing = _stories.value.find { it.id == storyId } ?: return false
    _stories.value = _stories.value.filter { it.id != storyId }
    addAuditLog("STORY_DELETED", "Admin deleted story '${existing.titleHi}'", "story", storyId)
    return true
  }

  fun updateStory(storyId: String, title: String, content: String, category: String, videoUrl: String?, audioNote: String? = null): Boolean {
    val existing = _stories.value.find { it.id == storyId } ?: return false
    val updated = existing.copy(
      titleHi = title,
      titleEn = title,
      titleHinglish = title,
      contentHi = content,
      contentEn = content,
      contentHinglish = content,
      category = category,
      videoUrl = if (videoUrl.isNullOrBlank()) null else videoUrl.trim(),
      audioNote = if (audioNote.isNullOrBlank()) existing.audioNote else audioNote.trim()
    )
    _stories.value = _stories.value.map { if (it.id == storyId) updated else it }
    addAuditLog("STORY_UPDATED", "Admin updated story '${updated.titleHi}'", "story", storyId)
    return true
  }

  // Assistant messaging & RAG Knowledge Retrieval
  fun sendAssistantQuery(query: String, lang: String): AssistantMessage {
    val userMsg = AssistantMessage(
      id = "msg_${System.currentTimeMillis()}",
      isUser = true,
      text = query,
      timestamp = "अभी",
      detectedLanguage = lang
    )
    _assistantMessages.value = _assistantMessages.value + userMsg

    val result = com.example.ai.JhsKnowledgeEngine.processQuery(query, lang)
    val botMsg = result.message
    _assistantMessages.value = _assistantMessages.value + botMsg

    if (result.unansweredLog != null) {
      val existing = _unansweredQuestions.value.firstOrNull { it.query.equals(query, ignoreCase = true) }
      if (existing != null) {
        _unansweredQuestions.value = _unansweredQuestions.value.map {
          if (it.id == existing.id) it.copy(frequencyCount = it.frequencyCount + 1) else it
        }
      } else {
        _unansweredQuestions.value = listOf(result.unansweredLog) + _unansweredQuestions.value
      }

      // Generate in-app Admin Notification for JHS admin team
      val time = SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date())
      val notif = InAppNotification(
        id = "notif_ai_${System.currentTimeMillis()}",
        timestamp = time,
        titleHindi = "⚠️ AI वाणी सहायक: ज्ञानकोश अंतराल (Unanswered Query)",
        titleEnglish = "AI Assistant Knowledge Gap: New Query",
        messageHindi = "नागरिक प्रश्न: '$query'। कृपया शासकीय डेटाबेस सत्यापित कर ज्ञानकोश में जोड़ें।",
        messageEnglish = "Citizen query: '$query'. Please review and add verified data.",
        severity = "info"
      )
      _notifications.value = listOf(notif) + _notifications.value
      addAuditLog("AI_KNOWLEDGE_GAP", "Unanswered query logged: '$query'", "ai_assistant")
    }

    return botMsg
  }

  fun recordAssistantFeedback(messageId: String, feedbackType: String) {
    _assistantMessages.value = _assistantMessages.value.map { msg ->
      if (msg.id == messageId) msg.copy(userFeedback = feedbackType) else msg
    }
    val msg = _assistantMessages.value.firstOrNull { it.id == messageId }
    if (msg != null) {
      val record = AiFeedbackRecord(
        id = "fb_${System.currentTimeMillis()}",
        messageId = messageId,
        userQuery = "",
        aiResponse = msg.text.take(120),
        feedbackType = feedbackType,
        timestamp = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date())
      )
      _aiFeedbackRecords.value = listOf(record) + _aiFeedbackRecords.value
      addAuditLog("AI_FEEDBACK", "User marked message $messageId as $feedbackType", "ai_assistant")
    }
  }

  fun updateAiAssistantSettings(settings: AiAssistantSettings) {
    _aiAssistantSettings.value = settings
    addAuditLog("AI_SETTINGS_UPDATED", "AI enabled=${settings.isEnabled}, continuous=${settings.continuousListeningEnabled}", "admin")
  }

  fun resolveUnansweredQuestion(id: String) {
    _unansweredQuestions.value = _unansweredQuestions.value.map {
      if (it.id == id) it.copy(isResolved = true) else it
    }
    addAuditLog("AI_GAP_RESOLVED", "Knowledge gap resolved for id $id", "admin")
  }

  fun clearAssistantHistory() {
    _assistantMessages.value = emptyList()
  }

  // Add new case (Support Request Wizard)
  fun addCase(
    category: CaseCategory,
    title: String,
    applicantName: String,
    isAnonymous: Boolean,
    contactPhone: String,
    preferredLanguage: String,
    district: String,
    block: String,
    gramPanchayat: String,
    village: String,
    description: String,
    assistanceRequested: String,
    userId: String? = null
  ): Pair<String, String> {
    val randomNum = Random.nextInt(100, 999)
    val caseId = "NYAY-2026-0$randomNum"
    val pin = String.format(Locale.US, "%04d", Random.nextInt(1000, 9999))
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    val newCase = CaseRecord(
      id = caseId,
      verificationPin = pin,
      userId = userId ?: _currentUser.value?.id,
      category = category,
      title = title.ifBlank { category.labelHi },
      applicantName = if (isAnonymous) "गोपनीय आवेदक (Anonymous)" else applicantName,
      isAnonymous = isAnonymous,
      contactPhone = contactPhone,
      preferredLanguage = preferredLanguage,
      district = district,
      block = block,
      gramPanchayat = gramPanchayat,
      village = village,
      description = description,
      assistanceRequested = assistanceRequested,
      relevantDate = today,
      status = CaseStatus.RECEIVED,
      priority = PriorityLevel.HIGH,
      assignedManagerName = "सुनीता शर्मा (Sunita Sharma)",
      assignedVolunteerName = "रमेश सहरिया (Ramesh Sahariya)",
      dateReceived = today,
      lastActionDate = today,
      documentChecklist = listOf(
        DocumentChecklistItem("d_new_1", "पहचान पत्र (आधार / वोटर आईडी)", "आवेदक की पहचान", true, false),
        DocumentChecklistItem("d_new_2", "समस्या संबंधी तथ्य अथवा पूर्व आवेदन", "प्रारंभिक साक्ष्य", true, false)
      ),
      notes = listOf(
        CaseNote(
          id = "n_init_${System.currentTimeMillis()}",
          authorName = "सिस्टम (NyaySetu Bot)",
          authorRole = UserRole.ADMIN,
          isInternal = false,
          content = "शिकायत सफलतापूर्वक दर्ज की गई। JHS विधिक टीम द्वारा 48 घंटे में समीक्षा की जाएगी।",
          timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        )
      )
    )

    _cases.value = listOf(newCase) + _cases.value
    try {
      FirestoreSyncManager.syncCaseToCloud(newCase)
    } catch (_: Exception) {}

    _auditLogs.value = listOf(
      AuditLogEntry(
        id = "aud_${System.currentTimeMillis()}",
        timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
        userName = if (isAnonymous) "नागरिक (गोपनीय)" else applicantName,
        userRole = UserRole.COMMUNITY_MEMBER,
        action = "नया मामला दर्ज (New Case Filed)",
        targetType = "case",
        targetId = caseId,
        details = "श्रेणी: ${category.labelHi}, गाँव: $village, ब्लॉक: $block"
      )
    ) + _auditLogs.value

    return Pair(caseId, pin)
  }

  // Lookup case by ID and PIN or Phone
  fun lookupCase(caseId: String, pin: String): CaseRecord? {
    val cleanId = caseId.trim().uppercase()
    val cleanPin = pin.trim()
    return _cases.value.find { 
      (it.id.equals(cleanId, ignoreCase = true) && it.verificationPin == cleanPin) ||
      (it.contactPhone.isNotBlank() && it.contactPhone == cleanPin && it.id.equals(cleanId, ignoreCase = true))
    }
  }

  fun updateCaseStatus(caseId: String, newStatus: CaseStatus, reason: String, updaterName: String, updaterRole: UserRole) {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

    _cases.value = _cases.value.map { c ->
      if (c.id == caseId) {
        val newNotes = c.notes + CaseNote(
          id = "n_${System.currentTimeMillis()}",
          authorName = updaterName,
          authorRole = updaterRole,
          isInternal = false,
          content = "स्थिति अद्यतन: ${newStatus.labelHi} - $reason",
          timestamp = timestamp
        )
        c.copy(
          status = newStatus,
          lastActionDate = today,
          notes = newNotes,
          closureReason = if (newStatus == CaseStatus.CLOSED) reason else c.closureReason
        )
      } else c
    }

    _auditLogs.value = listOf(
      AuditLogEntry(
        id = "aud_${System.currentTimeMillis()}",
        timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
        userName = updaterName,
        userRole = updaterRole,
        action = "स्थिति अद्यतन (Status Changed to ${newStatus.labelHi})",
        targetType = "case",
        targetId = caseId,
        details = reason
      )
    ) + _auditLogs.value
  }

  fun addCaseNote(caseId: String, authorName: String, authorRole: UserRole, isInternal: Boolean, content: String) {
    val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
    _cases.value = _cases.value.map { c ->
      if (c.id == caseId) {
        c.copy(
          notes = c.notes + CaseNote(
            id = "note_${System.currentTimeMillis()}",
            authorName = authorName,
            authorRole = authorRole,
            isInternal = isInternal,
            content = content,
            timestamp = timestamp
          )
        )
      } else c
    }
  }

  fun addVolunteerVisit(
    volunteerName: String,
    village: String,
    gramPanchayat: String,
    block: String,
    district: String,
    participantCount: Int,
    meetingPurpose: String,
    observations: String,
    actionItems: String
  ) {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
    val newVisit = VolunteerVisitRecord(
      id = "vis_${System.currentTimeMillis()}",
      volunteerName = volunteerName,
      village = village,
      gramPanchayat = gramPanchayat,
      block = block,
      district = district,
      visitDate = today,
      participantsCount = participantCount,
      meetingPurpose = meetingPurpose,
      observations = observations,
      verbalConsentConfirmed = true,
      actionItems = actionItems,
      submittedAt = timestamp,
      isSynced = true
    )
    _volunteerVisits.value = listOf(newVisit) + _volunteerVisits.value
  }

  fun addVillagePriority(
    village: String,
    gramPanchayat: String,
    block: String,
    district: String,
    theme: String,
    priority: String,
    source: String,
    proposedAction: String,
    institution: String
  ) {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val item = VillagePriorityItem(
      id = "vp_${System.currentTimeMillis()}",
      village = village,
      gramPanchayat = gramPanchayat,
      block = block,
      district = district,
      theme = theme,
      communityPriority = priority,
      sourceOfInfo = source,
      meetingDate = today,
      participantsCount = 25,
      proposedAction = proposedAction,
      responsibleInstitution = institution,
      followUpDate = "2026-11-30",
      status = "Proposed",
      recordedBy = "समुदाय प्रतिनिधि"
    )
    _villagePriorities.value = listOf(item) + _villagePriorities.value
    try {
      FirestoreSyncManager.syncPriorityToCloud(item)
    } catch (_: Exception) {}
  }

  fun mergeRemoteCases(remoteList: List<CaseRecord>) {
    val existingIds = _cases.value.map { it.id }.toSet()
    val newOnes = remoteList.filter { it.id !in existingIds }
    if (newOnes.isNotEmpty()) {
      _cases.value = newOnes + _cases.value
      addAuditLog("CLOUD_SYNC", "${newOnes.size} cases synced from Firestore cloud", "sync")
    }
  }

  fun mergeRemotePriorities(remoteList: List<VillagePriorityItem>) {
    val existingIds = _villagePriorities.value.map { it.id }.toSet()
    val newOnes = remoteList.filter { it.id !in existingIds }
    if (newOnes.isNotEmpty()) {
      _villagePriorities.value = newOnes + _villagePriorities.value
      addAuditLog("CLOUD_SYNC", "${newOnes.size} priorities synced from Firestore cloud", "sync")
    }
  }

  fun markAllNotificationsRead() {
    _notifications.value = _notifications.value.map { it.copy(isRead = true) }
  }
}

