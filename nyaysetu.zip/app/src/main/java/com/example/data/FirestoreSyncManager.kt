package com.example.data

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.model.*
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Manages Firebase Firestore real-time cloud data synchronization and
 * Google Sign-In authentication via Jetpack CredentialManager.
 */
object FirestoreSyncManager {

  private const val TAG = "FirestoreSyncManager"

  private var firestoreDb: FirebaseFirestore? = null
  private var isInitialized = false

  private val _isCloudConnected = MutableStateFlow(false)
  val isCloudConnected: StateFlow<Boolean> = _isCloudConnected.asStateFlow()

  private val _syncStatusMessage = MutableStateFlow("क्लाउड सिंक तैयार")
  val syncStatusMessage: StateFlow<String> = _syncStatusMessage.asStateFlow()

  private var casesListener: ListenerRegistration? = null
  private var prioritiesListener: ListenerRegistration? = null

  fun init(context: Context) {
    if (isInitialized) return
    try {
      val databaseId = context.getString(R.string.firestore_database_id)
      firestoreDb = FirebaseFirestore.getInstance(databaseId)
      isInitialized = true
      _isCloudConnected.value = true
      _syncStatusMessage.value = "🟢 ऑनलाइन क्लाउड सिंक सक्रिय"
      Log.d(TAG, "Firestore successfully initialized with database: $databaseId")

      // If user is already authenticated with Firebase, start listeners
      Firebase.auth.currentUser?.let { user ->
        startCloudListeners(user.uid)
      }
    } catch (e: Exception) {
      Log.e(TAG, "Failed to initialize Firestore", e)
      _isCloudConnected.value = false
      _syncStatusMessage.value = "ऑफलाइन मोड"
    }
  }

  fun getDb(context: Context): FirebaseFirestore {
    if (firestoreDb == null) {
      init(context)
    }
    return firestoreDb ?: FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
  }

  // --------------------------------------------------------------------------
  // Real-time Cloud Listeners
  // --------------------------------------------------------------------------
  fun startCloudListeners(userId: String) {
    val db = firestoreDb ?: return
    stopCloudListeners()

    try {
      // 1. Observe Cases in Firestore
      casesListener = db.collection("cases")
        .addSnapshotListener { snapshot, error ->
          if (error != null) {
            Log.w(TAG, "Cases sync error: ${error.message}")
            return@addSnapshotListener
          }
          if (snapshot != null) {
            val remoteCases = snapshot.documents.mapNotNull { doc ->
              val data = doc.data ?: return@mapNotNull null
              val catStr = data["category"] as? String ?: "GOVT_SCHEMES"
              val cat = try { CaseCategory.valueOf(catStr) } catch (_: Exception) { CaseCategory.GOVT_SCHEMES }
              val statStr = data["status"] as? String ?: "RECEIVED"
              val stat = try { CaseStatus.valueOf(statStr) } catch (_: Exception) { CaseStatus.RECEIVED }
              val prioStr = data["priority"] as? String ?: "MEDIUM"
              val prio = try { PriorityLevel.valueOf(prioStr) } catch (_: Exception) { PriorityLevel.MEDIUM }

              CaseRecord(
                id = doc.id,
                verificationPin = data["verificationPin"] as? String ?: "1234",
                category = cat,
                title = data["title"] as? String ?: "शिकायत",
                applicantName = data["applicantName"] as? String ?: "नागरिक",
                isAnonymous = data["isAnonymous"] as? Boolean ?: false,
                contactPhone = data["contactPhone"] as? String ?: "",
                preferredLanguage = data["preferredLanguage"] as? String ?: "hi",
                district = data["district"] as? String ?: "श्योपुर",
                block = data["block"] as? String ?: "",
                gramPanchayat = data["gramPanchayat"] as? String ?: "",
                village = data["village"] as? String ?: "",
                description = data["description"] as? String ?: "",
                assistanceRequested = data["assistanceRequested"] as? String ?: "",
                status = stat,
                priority = prio,
                assignedVolunteerName = data["assignedVolunteerName"] as? String ?: "JHS सार्थी",
                assignedManagerName = data["assignedManagerName"] as? String ?: "JHS विधिक दल",
                dateReceived = data["dateReceived"] as? String ?: "2026-10-31",
                lastActionDate = data["lastActionDate"] as? String ?: "2026-10-31",
                notes = listOf(
                  CaseNote(
                    id = "cn_${doc.id}",
                    authorName = "Firebase Cloud",
                    authorRole = UserRole.SUPER_ADMIN,
                    isInternal = false,
                    content = "क्लाउड से समन्वयित रिकॉर्ड",
                    timestamp = "अभी"
                  )
                ),
                userId = data["userId"] as? String ?: userId
              )
            }
            if (remoteCases.isNotEmpty()) {
              NyaySetuRepository.mergeRemoteCases(remoteCases)
            }
          }
        }

      // 2. Observe Village Priorities in Firestore
      prioritiesListener = db.collection("village_priorities")
        .addSnapshotListener { snapshot, error ->
          if (error != null) {
            Log.w(TAG, "Priorities sync error: ${error.message}")
            return@addSnapshotListener
          }
          if (snapshot != null) {
            val remotePriorities = snapshot.documents.mapNotNull { doc ->
              val data = doc.data ?: return@mapNotNull null
              VillagePriorityItem(
                id = doc.id,
                village = data["village"] as? String ?: "",
                gramPanchayat = data["gramPanchayat"] as? String ?: "",
                block = data["block"] as? String ?: "",
                district = data["district"] as? String ?: "",
                theme = data["theme"] as? String ?: "सामुदायिक विकास",
                communityPriority = data["communityPriority"] as? String ?: (data["title"] as? String ?: "प्राथमिकता"),
                sourceOfInfo = data["sourceOfInfo"] as? String ?: "ग्राम सभा",
                meetingDate = data["meetingDate"] as? String ?: "2026-10-31",
                participantsCount = (data["participantsCount"] as? Long)?.toInt() ?: 20,
                proposedAction = data["proposedAction"] as? String ?: "विकास कार्य",
                responsibleInstitution = data["responsibleInstitution"] as? String ?: "ग्राम पंचायत",
                followUpDate = data["followUpDate"] as? String ?: "2026-11-30",
                status = data["status"] as? String ?: "Proposed",
                recordedBy = data["recordedBy"] as? String ?: "समुदाय प्रतिनिधि"
              )
            }
            if (remotePriorities.isNotEmpty()) {
              NyaySetuRepository.mergeRemotePriorities(remotePriorities)
            }
          }
        }
    } catch (e: Exception) {
      Log.e(TAG, "Failed to start cloud listeners", e)
    }
  }

  fun stopCloudListeners() {
    casesListener?.remove()
    casesListener = null
    prioritiesListener?.remove()
    prioritiesListener = null
  }

  // --------------------------------------------------------------------------
  // Cloud Mutation Operations
  // --------------------------------------------------------------------------
  fun syncCaseToCloud(caseRecord: CaseRecord) {
    val db = firestoreDb ?: return
    val user = Firebase.auth.currentUser ?: return
    try {
      val data = hashMapOf(
        "id" to caseRecord.id,
        "verificationPin" to caseRecord.verificationPin,
        "title" to caseRecord.title,
        "citizenName" to caseRecord.applicantName,
        "applicantName" to caseRecord.applicantName,
        "category" to caseRecord.category.name,
        "status" to caseRecord.status.name,
        "priority" to caseRecord.priority.name,
        "description" to caseRecord.description,
        "village" to caseRecord.village,
        "gramPanchayat" to caseRecord.gramPanchayat,
        "block" to caseRecord.block,
        "district" to caseRecord.district,
        "contactPhone" to caseRecord.contactPhone,
        "isAnonymous" to caseRecord.isAnonymous,
        "submittedBy" to user.uid,
        "userId" to user.uid,
        "dateReceived" to caseRecord.dateReceived,
        "lastActionDate" to caseRecord.lastActionDate,
        "lastUpdatedAt" to System.currentTimeMillis()
      )
      db.collection("cases").document(caseRecord.id)
        .set(data, SetOptions.merge())
        .addOnSuccessListener {
          Log.d(TAG, "Case ${caseRecord.id} synced to Firestore successfully")
        }
        .addOnFailureListener { e ->
          Log.w(TAG, "Failed to sync case to Firestore: ${e.message}")
        }
    } catch (e: Exception) {
      Log.w(TAG, "Exception syncing case to cloud", e)
    }
  }

  fun syncPriorityToCloud(priority: VillagePriorityItem) {
    val db = firestoreDb ?: return
    val user = Firebase.auth.currentUser ?: return
    try {
      val data = hashMapOf(
        "id" to priority.id,
        "village" to priority.village,
        "gramPanchayat" to priority.gramPanchayat,
        "block" to priority.block,
        "district" to priority.district,
        "theme" to priority.theme,
        "communityPriority" to priority.communityPriority,
        "sourceOfInfo" to priority.sourceOfInfo,
        "meetingDate" to priority.meetingDate,
        "participantsCount" to priority.participantsCount.toLong(),
        "proposedAction" to priority.proposedAction,
        "responsibleInstitution" to priority.responsibleInstitution,
        "followUpDate" to priority.followUpDate,
        "status" to priority.status,
        "recordedBy" to priority.recordedBy,
        "submittedBy" to user.uid,
        "createdAt" to System.currentTimeMillis()
      )
      db.collection("village_priorities").document(priority.id)
        .set(data, SetOptions.merge())
        .addOnSuccessListener {
          Log.d(TAG, "Priority ${priority.id} synced to Firestore successfully")
        }
        .addOnFailureListener { e ->
          Log.w(TAG, "Failed to sync priority: ${e.message}")
        }
    } catch (e: Exception) {
      Log.w(TAG, "Exception syncing priority", e)
    }
  }

  fun syncUserProfileToCloud(user: AppUser) {
    val db = firestoreDb ?: return
    val authUser = Firebase.auth.currentUser ?: return
    try {
      val data = hashMapOf(
        "uid" to authUser.uid,
        "name" to user.name,
        "username" to user.username,
        "email" to (authUser.email ?: user.email),
        "phone" to user.phone,
        "role" to user.role.name,
        "village" to user.village,
        "block" to user.block,
        "district" to user.district,
        "state" to "Madhya Pradesh",
        "preferredLanguage" to "hi",
        "lastActiveAt" to System.currentTimeMillis()
      )
      db.collection("users").document(authUser.uid)
        .set(data, SetOptions.merge())
    } catch (e: Exception) {
      Log.w(TAG, "Exception syncing user profile", e)
    }
  }

  // --------------------------------------------------------------------------
  // Google Sign-In with Jetpack CredentialManager
  // --------------------------------------------------------------------------
  fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: (com.google.firebase.auth.FirebaseUser) -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
  ) {
    val currentAuthUser = Firebase.auth.currentUser
    if (currentAuthUser != null) {
      startCloudListeners(currentAuthUser.uid)
      onAuthSuccess(currentAuthUser)
      return
    }

    val clientId = try {
      context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
      onUnauthenticated()
      return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
      .setFilterByAuthorizedAccounts(true)
      .setServerClientId(clientId)
      .setAutoSelectEnabled(true)
      .build()

    val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()

    scope.launch {
      try {
        val result = credentialManager.getCredential(context, request)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
          val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
          val authResult = Firebase.auth.signInWithCredential(authCredential).await()
          val user = authResult.user
          if (user != null) {
            startCloudListeners(user.uid)
            onAuthSuccess(user)
          } else {
            onUnauthenticated()
          }
        } else {
          onUnauthenticated()
        }
      } catch (e: Exception) {
        onUnauthenticated()
      }
    }
  }

  fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: (com.google.firebase.auth.FirebaseUser) -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
  ) {
    val clientId = try {
      context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
      onAuthError("Google Sign-In configuration missing: default_web_client_id not found")
      return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    scope.launch {
      try {
        val activity = context as? Activity
        if (activity == null) {
          onAuthError("Activity context required for Google Sign-In")
          return@launch
        }
        val result = credentialManager.getCredential(activity, request)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
          val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
          val authResult = Firebase.auth.signInWithCredential(authCredential).await()
          val user = authResult.user
          if (user != null) {
            startCloudListeners(user.uid)
            onAuthSuccess(user)
          } else {
            onAuthError("Firebase authentication returned empty user")
          }
        } else {
          onAuthError("Unexpected credential type")
        }
      } catch (e: GetCredentialCancellationException) {
        Log.w(TAG, "Google Sign-In flow cancelled: ${e.message}", e)
        onAuthCancelled()
      } catch (e: Exception) {
        Log.e(TAG, "Google Sign-In failed", e)
        onAuthError(e.localizedMessage ?: "Sign in failed")
      }
    }
  }

  fun signOut(
    credentialManager: CredentialManager,
    onSignOutComplete: () -> Unit,
    scope: CoroutineScope
  ) {
    stopCloudListeners()
    Firebase.auth.signOut()
    scope.launch {
      try {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
      } catch (e: Exception) {
        Log.e(TAG, "Failed to clear credential state", e)
      } finally {
        onSignOutComplete()
      }
    }
  }
}
