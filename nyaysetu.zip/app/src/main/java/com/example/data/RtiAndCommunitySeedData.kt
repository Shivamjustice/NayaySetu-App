package com.example.data

import com.example.model.*

object RtiAndCommunitySeedData {

  // ----------------------------------------------------
  // MODULE SIX: RTI Authorities & Templates
  // ----------------------------------------------------
  val rtiAuthorities: List<RtiAuthority> = listOf(
    RtiAuthority(
      id = "rti-janpad",
      departmentNameHindi = "पंचायत एवं ग्रामीण विकास विभाग (जनपद पंचायत)",
      departmentNameEnglish = "Panchayat & Rural Development (Janpad Panchayat)",
      designationHindi = "लोक सूचना अधिकारी (PIO) सह मुख्य कार्यपालन अधिकारी",
      designationEnglish = "Public Information Officer & CEO Janpad",
      district = "श्योपुर / शिवपुरी / गुना",
      addressHindi = "कार्यालय जनपद पंचायत, मुख्यालय",
      feeDetails = "₹10 का गैर-न्यायिक स्टाम्प / आईपीओ अथवा बीपीएल कार्ड पर निःशुल्क",
      onlinePortalUrl = "https://rtionline.mp.gov.in"
    ),
    RtiAuthority(
      id = "rti-collector",
      departmentNameHindi = "राजस्व विभाग / जिला कलेक्ट्रेट कार्यालय",
      departmentNameEnglish = "Revenue Dept / District Collectorate Office",
      designationHindi = "लोक सूचना अधिकारी (PIO) सह डिप्टी कलेक्टर",
      designationEnglish = "Public Information Officer & Deputy Collector",
      district = "समस्त जिले (श्योपुर, शिवपुरी, गुना, ग्वालियर)",
      addressHindi = "जिला कलेक्ट्रेट परिसर",
      feeDetails = "₹10 का गैर-न्यायिक स्टाम्प / आईपीओ (बीपीएल हेतु पूर्णतः निःशुल्क)",
      onlinePortalUrl = "https://rtionline.mp.gov.in"
    ),
    RtiAuthority(
      id = "rti-forest",
      departmentNameHindi = "वन विभाग (Forest Department)",
      departmentNameEnglish = "Forest Department (Territorial & Protected)",
      designationHindi = "लोक सूचना अधिकारी सह उप वन संरक्षक (DFO)",
      designationEnglish = "Public Information Officer & DFO",
      district = "श्योपुर / शिवपुरी सामान्य वन मंडल",
      addressHindi = "कार्यालय संभागीय/जिला वन अधिकारी",
      feeDetails = "₹10 (बीपीएल हेतु निःशुल्क)",
      onlinePortalUrl = "https://rtionline.mp.gov.in"
    ),
    RtiAuthority(
      id = "rti-tribal",
      departmentNameHindi = "जनजातीय कार्य विभाग (Tribal Affairs)",
      departmentNameEnglish = "Tribal Affairs Department",
      designationHindi = "लोक सूचना अधिकारी सह सहायक आयुक्त",
      designationEnglish = "Public Information Officer & Assistant Commissioner",
      district = "श्योपुर / शिवपुरी / गुना",
      addressHindi = "जिला जनजातीय कार्य विभाग कार्यालय",
      feeDetails = "₹10 (बीपीएल कार्डधारक को निःशुल्क)",
      onlinePortalUrl = "https://rtionline.mp.gov.in"
    )
  )

  // ----------------------------------------------------
  // MODULE SEVEN: Village Digital Profiles
  // ----------------------------------------------------
  val villageProfiles: List<VillageDigitalProfile> = listOf(
    VillageDigitalProfile(
      id = "vp-sahariya-danda",
      villageName = "सहरिया डांडा (Sahariya Danda)",
      gramPanchayat = "गोरस (Goras)",
      block = "कराहल (Karahal)",
      district = "श्योपुर (Sheopur)",
      population = 680,
      schoolsCount = 1,
      anganwadiCount = 1,
      healthFacility = "उप स्वास्थ्य केंद्र गोरस (3 किमी)",
      drinkingWaterStatus = "2 हैंडपंप चालू, सौर नल-जल टंकी पाइपलाइन प्रगति पर",
      roadsStatus = "मुख्य मार्ग से 1.2 किमी कच्चा रास्ता (गिट्टीकरण स्वीकृत)",
      electricityStatus = "घरेलू विद्युतीकृत, कृषि फीडर पृथक",
      primaryLivelihood = "महुआ, तेन्दूपत्ता व वनोपज संग्रहण, मनरेगा मजदूरी, बाजरा व सरसों",
      developmentPriorities = listOf(
        "सामुदायिक वन अधिकार (CFR) 450 एकड़ का सीमांकन",
        "सहरिया डांडा हेतु 1 अतिरिक्त प्राथमिक शाला भवन",
        "पेयजल पाइपलाइन का संपूर्ण मोहल्ले तक विस्तार"
      ),
      ongoingWorks = listOf(
        "कपिलधारा कूप निर्माण (4 हितग्राही)",
        "जल जीवन मिशन अंतर्गत 25,000 लीटर पानी की टंकी"
      ),
      verifiedDate = "24 Oct 2026"
    ),
    VillageDigitalProfile(
      id = "vp-dauni",
      villageName = "दौनी (Dauni)",
      gramPanchayat = "भटनावर (Bhatnawar)",
      block = "पोहरी (Pohri)",
      district = "शिवपुरी (Shivpuri)",
      population = 840,
      schoolsCount = 2,
      anganwadiCount = 2,
      healthFacility = "प्राथमिक स्वास्थ्य केंद्र भटनावर (4 किमी)",
      drinkingWaterStatus = "नल-जल योजना क्रियाशील, 3 हैंडपंप",
      roadsStatus = "प्रधानमंत्री ग्राम सड़क योजना पक्की डामर सड़क उपलब्ध",
      electricityStatus = "पूर्ण विद्युतीकृत (24 घंटे घरेलू, 10 घंटे कृषि)",
      primaryLivelihood = "बांस हस्तशिल्प, कृषि (सोयाबीन, चना, गेहूं), मजदूरी",
      developmentPriorities = listOf(
        "सहरिया महिला बांस हस्तशिल्प साझा सुविधा केंद्र (CFC)",
        "उद्यानिकी पौधशाला व ड्रिप इरिगेशन क्लस्टर",
        "माध्यमिक विद्यालय का उन्नयन"
      ),
      ongoingWorks = listOf(
        "स्टॉप डैम सह चेक डैम निर्माण (नाले पर)",
        "आंगनवाड़ी भवन सुदृढ़ीकरण"
      ),
      verifiedDate = "20 Oct 2026"
    ),
    VillageDigitalProfile(
      id = "vp-fatehgarh",
      villageName = "फतेहगढ़ (Fatehgarh)",
      gramPanchayat = "फतेहगढ़ (Fatehgarh)",
      block = "बमोरी (Bamori)",
      district = "गुना (Guna)",
      population = 1120,
      schoolsCount = 3,
      anganwadiCount = 2,
      healthFacility = "सामुदायिक स्वास्थ्य केंद्र फतेहगढ़",
      drinkingWaterStatus = "जॉब कार्ड धारक क्लस्टर में हैंडपंप व बोरवेल",
      roadsStatus = "पक्की सड़क युक्त",
      electricityStatus = "उपलब्ध",
      primaryLivelihood = "कृषि, दुग्ध उत्पादन, वनोपज व मनरेगा",
      developmentPriorities = listOf(
        "वनाधिकार पट्टों का ऑनलाइन दुरुस्तीकरण",
        "कृषि उपज मंडी उप-केंद्र की स्थापना",
        "डिजिटल पंचायत सेवा केंद्र"
      ),
      ongoingWorks = listOf(
        "तालाब गहरीकरण व मेढ़ बंधान",
        "आवास प्लस के 32 मकान निर्माण"
      ),
      verifiedDate = "18 Oct 2026"
    )
  )

  // ----------------------------------------------------
  // MODULE EIGHT: Gram Sabha & Community Action Issues
  // ----------------------------------------------------
  val gramSabhaMeetings: List<GramSabhaMeeting> = listOf(
    GramSabhaMeeting(
      id = "gsm-01",
      village = "सहरिया डांडा (Sahariya Danda)",
      gramPanchayat = "गोरस",
      meetingDate = "02 Oct 2026",
      agenda = "सामुदायिक वनाधिकार (CFR) दावा सत्यापन, मनरेगा वार्षिक कार्ययोजना व जल संरक्षण प्राथमिकता।",
      keyProposals = listOf(
        "वनाधिकार समिति (FRC) द्वारा तैयार 18 व्यक्तिगत पट्टा दावों का सर्वसम्मति से अनुमोदन।",
        "गांव के पारंपरिक नाले पर 2 नए चेकडैम निर्माण की माँग।",
        "सहरिया आहार अनुदान योजना में छूटी 14 महिलाओं के नाम जोड़ने का प्रस्ताव।"
      ),
      resolutionsPassed = listOf(
        "संकल्प क्र. 01: वनाधिकार दावे फॉर्म A अनुविभागीय स्तरीय समिति (SDLC) को प्रेषित।",
        "संकल्प क्र. 02: ग्राम पंचायत फंड से हैंडपंप मरम्मत प्राथमिकता।"
      ),
      attendeesCount = 74
    ),
    GramSabhaMeeting(
      id = "gsm-02",
      village = "दौनी (Dauni)",
      gramPanchayat = "भटनावर",
      meetingDate = "15 Aug 2026",
      agenda = "बांस शिल्प क्लस्टर गठन, जल जीवन मिशन पाइपलाइन कवरेज व शिक्षा गुणवत्ता।",
      keyProposals = listOf(
        "सहरिया शिल्पकार महिलाओं के लिए वन धन विकास केंद्र से आधुनिक टूलकिट आवंटन।",
        "प्राथमिक शाला में शिक्षक की नियमित उपस्थिति सुनिश्चित करने हेतु निगरानी समिति गठन।"
      ),
      resolutionsPassed = listOf(
        "संकल्प क्र. 04: वन धन विकास केंद्र हेतु शासकीय भूमि प्रस्ताव पारित।"
      ),
      attendeesCount = 62
    )
  )

  val communityActionIssues: List<CommunityActionIssue> = listOf(
    CommunityActionIssue(
      id = "cai-01",
      title = "सहरिया डांडा मोहल्ले में शुद्ध पेयजल पाइपलाइन व सोलर पंप",
      village = "सहरिया डांडा, कराहल",
      category = "पेयजल व स्वच्छता",
      currentStage = CommunityActionStage.DEPT_CONTACT,
      description = "गर्मी के दिनों में 2 हैंडपंप सूखने से 65 परिवारों को 1.5 किमी दूर से पानी लाना पड़ता था। ग्राम सभा ने सामूहिक आवेदन देकर पीएचई विभाग से संपर्क किया।",
      responsibleDept = "लोक स्वास्थ्य यांत्रिकी विभाग (PHED), श्योपुर",
      progressNotes = listOf(
        "02 Oct: ग्राम सभा में प्रस्ताव पारित",
        "12 Oct: 54 ग्रामीणों के हस्ताक्षर युक्त सामूहिक ज्ञापन कार्यपालन यंत्री पीएचई को सौंपा",
        "22 Oct: पीएचई उप-यंत्री द्वारा स्थल निरीक्षण व ₹4.8 लाख का प्राक्कलन तैयार"
      ),
      updatedDate = "26 Oct 2026"
    ),
    CommunityActionIssue(
      id = "cai-02",
      title = "मनरेगा मजदूरी का 3 माह का लंबित भुगतान व विलंब मुआवजा",
      village = "दौनी, पोहरी",
      category = "मजदूरी व रोजगार अधिकार",
      currentStage = CommunityActionStage.COMMUNITY_CONFIRMATION,
      description = "तालाब गहरीकरण में काम करने वाले 38 मजदूरों की ₹1.82 लाख मजदूरी 90 दिनों से अटकी थी। JHS के साथ विधिक नोटिस के बाद समस्त भुगतान व मुआवजा स्वीकृत हुआ।",
      responsibleDept = "जनपद पंचायत पोहरी / जिला पंचायत शिवपुरी",
      progressNotes = listOf(
        "10 Aug: मजदूरों की सामूहिक बैठक",
        "25 Aug: सीईओ जनपद को मनरेगा धारा 27 के तहत कानूनी नोटिस",
        "28 Sep: FTO जारी होकर शत-प्रतिशत राशि मजदूरों के खाते में अंतरित"
      ),
      updatedDate = "22 Oct 2026"
    )
  )

  // ----------------------------------------------------
  // MODULE TEN: Women & Child Support Resources
  // ----------------------------------------------------
  val womenChildResources: List<WomenChildResource> = listOf(
    WomenChildResource(
      id = "wcr-dv",
      titleHindi = "घरेलू हिंसा से महिलाओं का संरक्षण अधिनियम, 2005",
      titleEnglish = "Protection of Women from Domestic Violence Act, 2005",
      category = "Domestic Violence Legal Relief",
      descriptionHindi = "शारीरिक, मानसिक, मौखिक, भावनात्मक अथवा आर्थिक प्रताड़ना के विरुद्ध महिलाओं को त्वरित संरक्षण, साझी गृहस्थी में रहने का अधिकार व अंतरिम भरण-पोषण।",
      descriptionEnglish = "Civil law remedy providing protection orders, residence rights, monetary relief, and custody orders for aggrieved women.",
      legalProvisions = "धारा 12 (आवेदन), धारा 18 (संरक्षण आदेश), धारा 19 (निवास आदेश), धारा 20 (आर्थिक राहत), धारा 22 (मुआवजा)",
      emergencyContacts = listOf("181 (महिला हेल्पलाइन)", "112 (राष्ट्रीय आपातकालीन)", "One Stop Centre (सखी केंद्र)"),
      procedureHindi = "संरक्षण अधिकारी (Protection Officer) अथवा निकटतम प्रथम श्रेणी न्यायिक मजिस्ट्रेट के न्यायालय में विधिक सहायता से आवेदन। DLSA से निःशुल्क अधिवक्ता उपलब्ध।"
    ),
    WomenChildResource(
      id = "wcr-child",
      titleHindi = "बाल विवाह प्रतिषेध अधिनियम एवं पोक्सो (POCSO) संरक्षण",
      titleEnglish = "Child Marriage Prohibition and POCSO Child Safety",
      category = "POCSO & Child Safety",
      descriptionHindi = "लड़की के 18 वर्ष व लड़के के 21 वर्ष से पूर्व विवाह कानूनन संज्ञेय व गैर-जमानती अपराध है। बाल शोषण के विरुद्ध कठोर दंड का प्रावधान।",
      descriptionEnglish = "Strict legal protection prohibiting child marriage and zero-tolerance statutory safeguards under POCSO Act.",
      legalProvisions = "बाल विवाह प्रतिषेध अधिनियम 2006 (धारा 9, 10, 11) एवं POCSO Act, 2012",
      emergencyContacts = listOf("1098 (चाइल्डलाइन 24x7)", "112 (आपातकालीन पुलिस)", "जिला बाल संरक्षण इकाई (DCPU)"),
      procedureHindi = "बाल विवाह या खतरे की सूचना तुरंत 1098 या बाल कल्याण समिति (CWC) को दें। सूचना देने वाले की पहचान पूर्णतः गोपनीय रखी जाती है।"
    ),
    WomenChildResource(
      id = "wcr-maternal",
      titleHindi = "मातृत्व वंदना (PMMVY) एवं लाडली बहना योजना",
      titleEnglish = "Pradhan Mantri Matru Vandana & State Women Welfare",
      category = "Nutrition & Maternal",
      descriptionHindi = "गर्भवती व धात्री माताओं को प्रथम व द्वितीय संतान पर नकद पोषण सहायता तथा ₹1,250 प्रतिमाह लाडली बहना आर्थिक संबल।",
      descriptionEnglish = "Maternal nutrition financial grant and monthly cash support to empower rural and tribal women.",
      legalProvisions = "राष्ट्रीय खाद्य सुरक्षा अधिनियम (NFSA), 2013 की धारा 4(b)",
      emergencyContacts = listOf("104 (स्वास्थ्य परामर्श)", "आशा / आँगनवाड़ी कार्यकर्ता"),
      procedureHindi = "आँगनवाड़ी केंद्र में MCP कार्ड पंजीयन कराएं। आधार-लिंक बैंक खाते में 3 किस्तों में DBT हस्तांतरण।"
    )
  )

  // ----------------------------------------------------
  // MODULE TWELVE: Learning and Awareness Guides
  // ----------------------------------------------------
  val learningGuides: List<LearningGuide> = listOf(
    LearningGuide(
      id = "lg-fra",
      titleHindi = "वनाधिकार कानून, 2006: 10 बुनियादी बातें जो हर वन निवासी को जानना जरूरी हैं",
      titleEnglish = "Forest Rights Act 2006: 10 Core Facts for Forest Dwellers",
      category = "वनाधिकार व जल-जंगल-जमीन",
      summaryHindi = "13 दिसंबर 2005 की कट-ऑफ तिथि, 4 हेक्टेयर तक का पट्टा, पति-पत्नी का संयुक्त नाम और ग्राम सभा की सर्वोच्च शक्ति।",
      fullContentHindi = """
        1. वनाधिकार कानून क्या है?
        यह कानून सदियों से जंगलों में रह रहे आदिवासियों और पारंपरिक वन निवासियों के साथ हुए 'ऐतिहासिक अन्याय' को दूर करने के लिए बनाया गया।
        
        2. कौन पात्र है?
        - अनुसूचित जनजाति (ST): जो 13 दिसंबर 2005 से पहले से काबिज हैं।
        - अन्य पारंपरिक वन निवासी (OTFD): जो कम से कम 3 पीढ़ियों (75 वर्षों) से उस वन क्षेत्र में निवास कर रहे हैं।
        
        3. क्या अधिकार मिलते हैं?
        - व्यक्तिगत अधिकार (IFR): अधिकतम 4 हेक्टेयर (लगभग 10 एकड़) तक खेती की जमीन का स्थायी मालिकाना हक। पट्टा पति और पत्नी दोनों के नाम संयुक्त होता है।
        - सामुदायिक अधिकार (CR): निस्तार, पशु चराई, मछली पालन, जल स्रोतों का उपयोग।
        - सामुदायिक वन संसाधन (CFR): जंगल की सुरक्षा, संरक्षण और ग्राम सभा द्वारा प्रबंधन का विधिक अधिकार।
        - लघु वनोपज (MFP): महुआ, तेन्दूपत्ता, चिरौंजी, हर्रा, बहेड़ा आदि का संग्रह, प्रसंस्करण और बिना किसी ट्रांजिट पास के बेचने का पूरा अधिकार।
        
        4. ग्राम सभा की सर्वोच्चता:
        दावा स्वीकार या खारिज करने की पहली और सबसे बड़ी शक्ति ग्राम सभा की वनाधिकार समिति (FRC) के पास है। वन विभाग सीधे किसी को बेदखल नहीं कर सकता। धारा 4(5) के तहत जब तक दावा प्रक्रिया पूरी न हो, बेदखली पूरी तरह प्रतिबंधित है।
      """.trimIndent(),
      keyTakeaways = listOf(
        "कट-ऑफ तिथि: 13 दिसंबर 2005",
        "पट्टा पति और पत्नी दोनों के संयुक्त नाम पर जारी होता है",
        "पट्टा अहस्तांतरणीय है—इसे कोई खरीद या छीन नहीं सकता",
        "धारा 4(5): दावा लंबित रहने तक बेदखली गैरकानूनी है"
      ),
      simplifiedGlossary = mapOf(
        "FRC" to "वनाधिकार समिति (Forest Rights Committee): ग्राम सभा द्वारा चुनी गई 10-15 ग्रामीणों की समिति",
        "SDLC" to "अनुविभागीय स्तरीय समिति: एसडीएम की अध्यक्षता वाली उप-खंड स्तरीय जांच समिति",
        "DLC" to "जिला स्तरीय समिति: कलेक्टर की अध्यक्षता वाली समिति जो अंतिम पट्टा मंजूर करती है",
        "POR" to "प्रारंभिक अपराध रिपोर्ट (विभागीय चालान जो 2005 से पहले कब्जे का सबसे बड़ा कानूनी सबूत बनता है)",
        "Transit Permit" to "परिवहन अनुमति (लघु वनोपज हेतु अब इसकी आवश्यकता समाप्त कर दी गई है)"
      )
    ),
    LearningGuide(
      id = "lg-land",
      titleHindi = "धारा 170-ख (म.प्र. भू-राजस्व संहिता): आदिवासी जमीन की गैरकानूनी खरीद-फरोख्त से सुरक्षा",
      titleEnglish = "Section 170-B MPLRC: Tribal Land Restoration Law",
      category = "भूमि अधिकार",
      summaryHindi = "कलेक्टर की पूर्व अनुमति के बिना गैर-आदिवासी को बेची या बंधक रखी गई आदिवासी जमीन स्वतः मूल मालिक को वापस होती है।",
      fullContentHindi = """
        मध्य प्रदेश भू-राजस्व संहिता, 1959 की धारा 165(6) और 170-ख आदिवासियों की जमीन की सुरक्षा का सबसे मजबूत ढाल है।
        
        1. मूल नियम:
        कोई भी गैर-आदिवासी व्यक्ति कलेक्टर की लिखित अनुमति के बिना किसी अनुसूचित जनजाति के व्यक्ति की जमीन नहीं खरीद सकता, न ही बंधक रख सकता है।
        
        2. धारा 170-ख के तहत स्वतः संज्ञान:
        अनुविभागीय अधिकारी (एसडीओ / एसडीएम) को यह अधिकार है कि वह बिना किसी आवेदन के भी ऐसी किसी भी संदिग्ध रजिस्ट्री या कब्जे की जांच शुरू कर सकता है।
        
        3. सिद्ध करने का भार (Burden of Proof):
        यह साबित करने की जिम्मेदारी गैर-आदिवासी खरीदार की होती है कि उसने जमीन कानूनन और वैध अनुमति से ली है। यदि वह साबित नहीं कर पाता, तो जमीन मूल आदिवासी खातेदार या उसके वारिसों को तुरंत वापस दिलाई जाती है।
      """.trimIndent(),
      keyTakeaways = listOf(
        "कलेक्टर की पूर्व अनुमति के बिना हुई रजिस्ट्री कानूनी रूप से शून्य (Void) है",
        "आदिवासी द्वारा जमीन वापस मांगने पर कोई समय-सीमा (Limitation) बाधक नहीं बनती",
        "अवैध कब्जेदारों को बेदखल कर कब्जा मूल आदिवासी परिवार को सौंपा जाता है"
      ),
      simplifiedGlossary = mapOf(
        "खसरा (Khasra)" to "जमीन का कानूनी ब्यौरा जिसमें रकबा, फसल और मालिक का नाम होता है",
        "खतौनी (B-1)" to "खातेदार के समस्त खेतों की संयुक्त जोत पुस्तिका",
        "पंचनामा (Panchnama)" to "मौके पर 5 स्वतंत्र गवाहों द्वारा तैयार किया गया दस्तावेजी बयान",
        "SDO (राजस्व)" to "अनुविभागीय अधिकारी (प्रायः एसडीएम) जिन्हें जमीन बहाली का फैसला करने का अधिकार है"
      )
    )
  ) + PvtgAndTribalMasterGuideData.masterLearningGuides
}
