package com.example.data

import com.example.model.CaseCategory
import com.example.model.GovernmentScheme
import com.example.model.KnowledgeArticle
import com.example.model.LearningGuide
import com.example.model.SchemeCategory
import com.example.model.SchemeStatus

/**
 * मध्य प्रदेश के आदिवासी एवं विशेष रूप से कमजोर जनजातीय समूह (PVTG)
 * के लिए सरकारी योजनाएँ, विधिक अधिकार व आवश्यक दस्तावेज़ महा-मार्गदर्शिका (भाग 1 से 16)
 * स्थिति सत्यापन: 31 अक्टूबर 2026 तक के आधिकारिक आदेशों एवं पोर्टल्स के आधार पर।
 */
object PvtgAndTribalMasterGuideData {

  data class PortalEntry(
    val subject: String,
    val name: String,
    val url: String
  )

  data class CaseStudyExample(
    val id: String,
    val title: String,
    val situation: String,
    val applicableSchemes: String,
    val recommendedAction: String
  )

  val officialPortalsList: List<PortalEntry> = listOf(
    PortalEntry("मध्य प्रदेश की योजनाएँ और शिकायत", "CM Helpline 181", "https://cmhelpline.mp.gov.in"),
    PortalEntry("जनजातीय कार्य विभाग, मध्य प्रदेश", "MP Tribal Department (MPTAAS)", "https://www.tribal.mp.gov.in"),
    PortalEntry("केंद्र का जनजातीय कार्य मंत्रालय", "Ministry of Tribal Affairs (MoTA)", "https://tribal.nic.in"),
    PortalEntry("PM-JANMAN मिशन पोर्टल", "PM-JANMAN Official Portal", "https://pmjanman.gov.in"),
    PortalEntry("वन अधिकार अधिनियम पोर्टल", "FRA Portal / MP VanMitra", "https://tribal.mp.gov.in/MPVanMitra"),
    PortalEntry("राष्ट्रीय छात्रवृत्ति पोर्टल", "National Scholarship Portal (NSP)", "https://scholarships.gov.in"),
    PortalEntry("मध्य प्रदेश जनजातीय छात्रवृत्ति", "MPTAAS Portal", "https://www.tribal.mp.gov.in/mptaas"),
    PortalEntry("समग्र परिवार एवं सदस्य आईडी", "Samagra Portal MP", "https://samagra.gov.in"),
    PortalEntry("आधार कार्ड सेवाएँ", "UIDAI Official Portal", "https://uidai.gov.in"),
    PortalEntry("मध्य प्रदेश ई-सर्विस", "MP e-Service", "https://eservices.mp.gov.in"),
    PortalEntry("लोक सेवा गारंटी केंद्र", "MP e-District", "https://mpedistrict.gov.in"),
    PortalEntry("प्रधानमंत्री ग्रामीण आवास योजना", "PMAY-G Portal", "https://pmayg.nic.in"),
    PortalEntry("महात्मा गांधी नरेगा", "MGNREGA Portal", "https://nrega.nic.in"),
    PortalEntry("जल जीवन मिशन", "Jal Jeevan Mission Har Ghar Jal", "https://jaljeevanmission.gov.in"),
    PortalEntry("स्वच्छ भारत मिशन ग्रामीण", "SBM-G Portal", "https://swachhbharatmission.ddws.gov.in"),
    PortalEntry("पीएम किसान सम्मान निधि", "PM-KISAN Portal", "https://pmkisan.gov.in"),
    PortalEntry("प्रधानमंत्री फसल बीमा योजना", "PMFBY Portal", "https://pmfby.gov.in"),
    PortalEntry("प्रधानमंत्री जन धन योजना", "PMJDY Portal", "https://pmjdy.gov.in"),
    PortalEntry("प्रधानमंत्री जीवन ज्योति बीमा योजना", "PMJJBY Portal", "https://financialservices.gov.in"),
    PortalEntry("प्रधानमंत्री सुरक्षा बीमा योजना", "PMSBY Portal", "https://financialservices.gov.in"),
    PortalEntry("सामाजिक न्याय एवं दिव्यांगजन कल्याण, म.प्र.", "Social Justice MP", "https://socialjustice.mp.gov.in"),
    PortalEntry("आयुष्मान भारत जन आरोग्य योजना", "Ayushman Beneficiary Portal", "https://beneficiary.nha.gov.in"),
    PortalEntry("विशिष्ट दिव्यांगता पहचान (UDID)", "UDID Portal", "https://swavlambancard.gov.in"),
    PortalEntry("बाल संरक्षण एवं वात्सल्य", "MP Child Protection / WCD", "https://mpwcdmis.gov.in"),
    PortalEntry("महिला एवं बाल विकास मंत्रालय", "Ministry of Women and Child Development", "https://wcd.nic.in"),
    PortalEntry("स्किल इंडिया डिजिटल", "Skill India Digital Portal", "https://skillindiadigital.gov.in"),
    PortalEntry("राष्ट्रीय अप्रेंटिसशिप संवर्धन योजना", "Apprenticeship India", "https://apprenticeshipindia.gov.in"),
    PortalEntry("मुख्यमंत्री सीखो-कमाओ योजना", "Seekho Kamao MP Portal", "https://mmsky.mp.gov.in"),
    PortalEntry("प्रधानमंत्री रोजगार सृजन कार्यक्रम", "PMEGP Portal (KVIC)", "https://kviconline.gov.in/pmegp"),
    PortalEntry("प्रधानमंत्री मुद्रा योजना", "MUDRA Scheme Portal", "https://mudra.org.in"),
    PortalEntry("वन धन एवं जनजातीय उत्पाद", "TRIFED Portal", "https://trifed.tribal.gov.in"),
    PortalEntry("सूचना का अधिकार ऑनलाइन", "MP RTI Portal", "https://rtionline.mp.gov.in"),
    PortalEntry("मुफ्त कानूनी सहायता", "MP State Legal Services Authority (MPSLSA) / NALSA 15100", "https://mpslsa.gov.in")
  )

  val caseStudies: List<CaseStudyExample> = listOf(
    CaseStudyExample(
      id = "cs-1",
      title = "उदाहरण 1: परिवार कच्चे मकान में रहता है",
      situation = "परिवार के पास पक्का मकान नहीं है, मिट्टी-घास-फूस के कच्चे मकान में निवास है।",
      applicableSchemes = "1. PM-JANMAN आवास (यदि सहरिया, बैगा, भारिया PVTG परिवार है)\n2. PMAY-G (यदि सामान्य ग्रामीण आवास पात्रता सूची में नाम है)",
      recommendedAction = "ग्राम पंचायत में आवास सर्वेक्षण सूची जाँचें। सूची में नाम न होने पर ग्राम सभा व जनपद में लिखित आवेदन दें। किसी बिचौलिए को भुगतान न करें।"
    ),
    CaseStudyExample(
      id = "cs-2",
      title = "उदाहरण 2: परिवार के पास शौचालय नहीं है",
      situation = "खुले में शौच जाने की मजबूरी है, स्वच्छता परिसर उपलब्ध नहीं है।",
      applicableSchemes = "स्वच्छ भारत मिशन – ग्रामीण (SBM-G) व्यक्तिगत घरेलू शौचालय (IHHL) प्रोत्साहन राशि ₹12,000.",
      recommendedAction = "ग्राम पंचायत सचिव/रोजगार सहायक से पात्रता सूची में नाम जुड़वाएं, मानक निर्माण उपरांत जिओ-टैग कर राशि बैंक खाते में प्राप्त करें।"
    ),
    CaseStudyExample(
      id = "cs-3",
      title = "उदाहरण 3: घर में नल कनेक्शन नहीं है",
      situation = "दूर हैंडपंप या नाले से पानी ढोना पड़ता है, पेयजल संकट बना रहता है।",
      applicableSchemes = "जल जीवन मिशन (हर घर जल)।",
      recommendedAction = "ग्राम जल एवं स्वच्छता समिति (VWSC) तथा PHE विभाग को आवेदन दें। पानी की नियमितता व गुणवत्ता दोनों बिंदुओं पर लिखित शिकायत दर्ज करें।"
    ),
    CaseStudyExample(
      id = "cs-4",
      title = "उदाहरण 4: परिवार के पास जमीन है और खेती करता है",
      situation = "खातेदार आदिवासी किसान, उन्नत खाद-बीज और मौसमी जोखिमों से ग्रस्त है।",
      applicableSchemes = "1. PM-KISAN (₹6,000 वार्षिक)\n2. किसान क्रेडिट कार्ड (KCC)\n3. PM फसल बीमा योजना (खरीफ 2%, रबी 1.5% प्रीमियम)",
      recommendedAction = "खसरा-खतौनी, आधार व बैंक पासबुक लेकर e-KYC पूरा करें। बुवाई के तुरंत बाद बैंक में फसल बीमा प्रीमियम प्रविष्टि जाँचें।"
    ),
    CaseStudyExample(
      id = "cs-5",
      title = "उदाहरण 5: परिवार वन भूमि पर परंपरागत खेती करता है",
      situation = "सदियों या 13 दिसंबर 2005 से पहले से वनभूमि पर काबिज है, वन विभाग की बेदखली का भय है।",
      applicableSchemes = "वन अधिकार अधिनियम (FRA), 2006 (व्यक्तिगत वनाधिकार पट्टा Form-A अधिकतम 4 हेक्टेयर)।",
      recommendedAction = "ग्राम सभा की FRC में दावा प्रस्तुत करें। 2005 पूर्व के साक्ष्य (पुरानी रसीद, पंचनामा, बुजुर्गों के बयान) संलग्न करें। दावा प्रक्रियाधीन रहने तक धारा 4(5) बेदखली से पूर्ण संरक्षण देती है।"
    ),
    CaseStudyExample(
      id = "cs-6",
      title = "उदाहरण 6: महिला महुआ और अन्य वनोपज एकत्र करती है",
      situation = "स्थानीय बिचौलिये महुआ, चिरौंजी, तेन्दूपत्ता औने-पौने दामों में खरीदते हैं।",
      applicableSchemes = "1. PMJVM (प्रधानमंत्री जनजातीय विकास मिशन)\n2. वन धन विकास केंद्र योजना (TRIFED)\n3. DAY-NRLM स्वयं सहायता समूह",
      recommendedAction = "महिलाएं स्वयं सहायता समूह बनाकर वन धन विकास केंद्र (VDSHG) से जुड़ें। प्रसंस्करण, छंटाई और पैकेजिंग द्वारा उत्पाद का उचित मूल्य प्राप्त करें।"
    ),
    CaseStudyExample(
      id = "cs-7",
      title = "उदाहरण 7: परिवार में वृद्ध व्यक्ति है",
      situation = "60 वर्ष से अधिक आयु, कोई नियमित आय या सहारा नहीं है।",
      applicableSchemes = "मध्य प्रदेश सामाजिक सुरक्षा वृद्धावस्था पेंशन योजना (न्यूनतम ₹600/माह राज्यांश)।",
      recommendedAction = "आयु प्रमाण, समग्र सदस्य आईडी, आधार व सक्रिय बैंक पासबुक के साथ ग्राम पंचायत या लोक सेवा केंद्र से आवेदन करें।"
    ),
    CaseStudyExample(
      id = "cs-8",
      title = "उदाहरण 8: परिवार की महिला विधवा / कल्याणी है",
      situation = "पति की मृत्यु के बाद बच्चों के भरण-पोषण की गंभीर समस्या।",
      applicableSchemes = "1. कल्याणी पेंशन योजना (सामाजिक न्याय विभाग)\n2. राशन पात्रता (प्राथमिकता परिवार)\n3. बच्चों की छात्रवृत्ति\n4. सहरिया/बैगा/भारिया होने पर आहार अनुदान (₹1,500/माह)",
      recommendedAction = "मृत्यु प्रमाण पत्र बनवाएं, समग्र में महिला को मुखिया के रूप में दर्ज कराएं और पेंशन व आहार अनुदान का आवेदन करें।"
    ),
    CaseStudyExample(
      id = "cs-9",
      title = "उदाहरण 9: बच्चे के माता-पिता दोनों नहीं हैं (अनाथ)",
      situation = "संरक्षण का अभाव, पढ़ाई और भोजन का संकट।",
      applicableSchemes = "1. मुख्यमंत्री बाल आशीर्वाद योजना\n2. मिशन वात्सल्य (स्पॉन्सरशिप सहायता)\n3. बाल कल्याण समिति (CWC) देखभाल",
      recommendedAction = "तुरंत बाल हेल्पलाइन 1098 या जिला बाल संरक्षण इकाई (DCPU) को सूचित करें। सहायता सीधे बच्चे के बैंक खाते में स्वीकृत कराई जाती है।"
    ),
    CaseStudyExample(
      id = "cs-10",
      title = "उदाहरण 10: परिवार में दिव्यांग सदस्य है",
      situation = "शारीरिक, दृष्टि या मानसिक दिव्यांगता, आवागमन और आजीविका में परेशानी।",
      applicableSchemes = "1. UDID विशिष्ट दिव्यांगता कार्ड\n2. दिव्यांग पेंशन योजना\n3. कृत्रिम अंग व सहायक उपकरण योजना\n4. दिव्यांग शिक्षा छात्रवृत्ति",
      recommendedAction = "जिला अस्पताल के मेडिकल बोर्ड से दिव्यांगता प्रमाण पत्र बनवाएं, UDID पोर्टल पर पंजीकृत कर पेंशन व उपकरण का लाभ लें।"
    ),
    CaseStudyExample(
      id = "cs-11",
      title = "उदाहरण 11: आदिवासी युवा रोजगार व हुनर चाहता है",
      situation = "8वीं, 10वीं या 12वीं पास युवा, आजीविका के साधन की तलाश।",
      applicableSchemes = "1. ITI / CTS तकनीकी प्रशिक्षण\n2. मुख्यमंत्री सीखो-कमाओ योजना (MMSKY - स्टाइपेंड सहित)\n3. राष्ट्रीय अप्रेंटिसशिप (NAPS)\n4. NSTFDC / मुद्रा स्वरोजगार ऋण",
      recommendedAction = "Skill India Digital या MMSKY पोर्टल पर पंजीयन करें। ट्रेड अनुसार प्रशिक्षण चुनें और ऑन-द-जॉब अनुभव व स्टाइपेंड प्राप्त करें।"
    ),
    CaseStudyExample(
      id = "cs-12",
      title = "उदाहरण 12: पात्र परिवार का आवेदन बार-बार लंबित या अस्वीकृत है",
      situation = "सरकारी दफ्तरों के चक्कर, अधिकारी टालमटोल कर रहे हैं।",
      applicableSchemes = "1. मध्य प्रदेश CM हेल्पलाइन 181\n2. सूचना का अधिकार (RTI Act 2005)\n3. जिला विधिक सेवा प्राधिकरण (DLSA 15100 - मुफ्त विधिक सहायता)",
      recommendedAction = "आवेदन की रसीद के साथ CM हेल्पलाइन 181 पर शिकायत दर्ज करें। RTI लगाकर अस्वीकृति का लिखित कारण मांगें। जरूरत पड़ने पर DLSA से मुफ्त वकील की सहायता लें।"
    )
  )

  val preApplication15Questions: List<String> = listOf(
    "1. क्या परिवार मध्य प्रदेश का मूल निवासी है?",
    "2. क्या परिवार अनुसूचित जनजाति (ST) श्रेणी में आता है?",
    "3. क्या संबंधित योजना केवल PVTG (सहरिया, बैगा, भारिया) के लिए है या सभी ST परिवारों के लिए?",
    "4. क्या परिवार के जाति प्रमाण पत्र में सही जनजाति का स्पष्ट उल्लेख है?",
    "5. क्या परिवार की समग्र परिवार आईडी एवं सदस्य आईडी पूर्णतः अद्यतन है?",
    "6. क्या आधार कार्ड और बैंक पासबुक में नाम, पिता/पति का नाम और जन्मतिथि एक समान है?",
    "7. क्या बैंक खाता सक्रिय है और आधार NPCI DBT मैपर से लिंक है?",
    "8. क्या परिवार का नाम संबंधित सरकारी सर्वेक्षण या पात्रता सूची में दर्ज है?",
    "9. क्या योजना में कोई विशिष्ट आय सीमा (Income Ceiling) लागू है?",
    "10. क्या आवेदन की कोई निर्धारित अंतिम तारीख (Deadline) है?",
    "11. क्या आवेदन ऑनलाइन पोर्टल से होगा या पंचायत/कार्यालय में ऑफलाइन जमा होगा?",
    "12. क्या कोई निर्धारित आधिकारिक सरकारी शुल्क है? (निजी बिचौलिए को कोई भुगतान न करें)",
    "13. क्या आवेदन जमा करने के बाद विधिवत पावती/रसीद (Acknowledgement Receipt) प्राप्त हुई है?",
    "14. आवेदन की प्रगति व स्थिति (Status) ट्रैक करने का क्या तरीका है?",
    "15. आवेदन अस्वीकृत होने पर प्रथम अपील अथवा शिकायत किस सक्षम प्राधिकारी के समक्ष होगी?"
  )

  val sampleGrievanceLetterTemplate: String = """
    सेवा में,
    श्रीमान् जिला कलेक्टर / सक्षम प्राधिकारी,
    जिला: ........................................, मध्य प्रदेश।

    विषय: शासकीय योजना (........................................) का लाभ न मिलने / आवेदन पर कार्यवाही न होने बाबत् शिकायत।

    महोदय / महोदया,

    विनम्र निवेदन है कि मैं ........................................ (आवेदक का नाम),
    पुत्र/पुत्री/पत्नी ........................................,
    ग्राम: ........................................, ग्राम पंचायत: ........................................,
    ब्लॉक: ........................................, जिला: ........................................ का मूल निवासी हूँ।
    मैं अनुसूचित जनजाति (ST) / विशेष पिछड़ी जनजाति (सहरिया/बैगा/भारिया) समुदाय से संबंधित हूँ।

    मैंने ........................................ योजना के अंतर्गत निर्धारित प्रारूप में दिनांक .................... को आवेदन प्रस्तुत किया था, जिसका आवेदन क्रमांक ........................................ है।

    उक्त आवेदन को प्रस्तुत किए .................... माह बीत जाने के उपरांत भी आज दिनांक तक मुझे योजना का कोई लाभ प्राप्त नहीं हुआ है, और न ही कोई लिखित कारण सूचित किया गया है।

    अतः आपसे विनम्र प्रार्थना है कि मेरे उक्त आवेदन की जांच करवाकर मुझे नियमानुसार योजना का लाभ दिलाए जाने के निर्देश प्रदान करने की कृपा करें। यदि मेरा आवेदन किसी कारणवश अपात्र माना गया है, तो उसका लिखित कारण उपलब्ध कराया जाए ताकि मैं सक्षम स्तर पर विधिक अपील प्रस्तुत कर सकूँ।

    संलग्न दस्तावेज:
    1. आवेदन पत्र की पावती रसीद
    2. आधार कार्ड एवं समग्र आईडी छायाप्रति
    3. स्थायी जाति प्रमाण पत्र छायाप्रति
    4. बैंक पासबुक छायाप्रति (NPCI लिंक)
    5. अन्य सुसंगत अभिलेख

    दिनांक: ........................................
    स्थान: ........................................
    आवेदक का नाम: ........................................
    मोबाइल नंबर: ........................................
    हस्ताक्षर / अंगूठा निशानी: ........................................
  """.trimIndent()

  /**
   * 10 Master Schemes derived directly from Part 1 and Part 5-10
   */
  val newGovernmentSchemes: List<GovernmentScheme> = listOf(
    GovernmentScheme(
      id = "sch-pm-janman",
      nameHindi = "प्रधानमंत्री जनजाति आदिवासी न्याय महा अभियान (PM-JANMAN)",
      nameEnglish = "Pradhan Mantri Janjati Adivasi Nyaya Maha Abhiyan",
      objectiveHindi = "देश के 75 PVTG समुदायों (म.प्र. में बैगा, भारिया और सहरिया) के परिवारों और बस्तियों तक 9 मंत्रालयों के 11 प्रमुख हस्तक्षेपों से पक्का आवास, शुद्ध पेयजल, सड़क, बिजली, स्वास्थ्य व आजीविका पहुँचाना।",
      objectiveEnglish = "Targeted mission for PVTG habitations delivering housing, water, roads, electricity, healthcare, and livelihood through 11 key interventions.",
      responsibleDepartment = "जनजातीय कार्य मंत्रालय, भारत सरकार एवं पंचायत व ग्रामीण विकास विभाग, म.प्र.",
      level = "Central",
      category = SchemeCategory.TRIBAL_WELFARE,
      eligibilityCriteriaHindi = listOf(
        "आवेदक परिवार मध्य प्रदेश के अधिसूचित 3 PVTG समुदायों में से हो: सहरिया, बैगा अथवा भारिया",
        "संबंधित PVTG बस्ती/परिवार विभागीय सर्वेक्षण व पहचान रिकॉर्ड में दर्ज हो",
        "परिवार बुनियादी सुविधा (पक्का आवास, नल-जल, सड़क, ग्रिड बिजली) से वंचित हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Must belong to notified PVTG: Sahariya, Baiga, or Bharia in MP",
        "Must be verified in the departmental PVTG baseline survey",
        "Lacking basic infrastructure (pucca house, tap water, road, power)"
      ),
      whoCanApplyHindi = "सहरिया, बैगा और भारिया PVTG परिवार एवं ग्राम सभा",
      whoCanApplyEnglish = "Sahariya, Baiga, and Bharia PVTG households and Gram Sabhas",
      benefitsHindi = listOf(
        "पक्का ग्रामीण आवास (PMAY-G के विशेष शिथिल नियमों के साथ)",
        "हर घर नल से स्वच्छ पेयजल एवं बस्ती तक पक्की सड़क संपर्क",
        "निःशुल्क घरेलू बिजली कनेक्शन व सोलर विद्युतीकरण",
        "मोबाइल कनेक्टिविटी, आंगनवाड़ी केंद्र, बहुउद्देशीय सामुदायिक केंद्र व कौशल आजीविका"
      ),
      benefitsEnglish = listOf(
        "Special rural pucca housing with relaxed norms",
        "Piped drinking water and all-weather road connectivity",
        "Free electricity/solar home lighting",
        "Mobile connectivity, Anganwadi, multipurpose center, livelihood"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड",
        "PVTG/ST जाति पहचान का सरकारी रिकॉर्ड",
        "समग्र परिवार आईडी",
        "बैंक पासबुक (आधार NPCI सक्रिय)",
        "वर्तमान आवास/कच्चे मकान की स्थिति",
        "ग्राम पंचायत का सर्वेक्षण/परिवार विवरण"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar Card",
        "PVTG/ST Caste Record",
        "Samagra Family ID",
        "Bank Passbook (NPCI Seeded)",
        "Current housing details",
        "Panchayat survey record"
      ),
      applicationProcedureHindi = "ग्राम पंचायत सचिव या रोजगार सहायक से संपर्क कर PM-JANMAN सर्वेक्षण सूची जाँचें। आवास व अन्य घटकों हेतु ग्राम सभा व जनपद में आवेदन प्रस्तुत करें।",
      applicationProcedureEnglish = "Check name in Panchayat PM-JANMAN baseline survey and apply through Gram Sabha and Janpad Panchayat.",
      onlineApplicationLink = "https://pmjanman.gov.in",
      offlineApplicationLocation = "ग्राम पंचायत कार्यालय / जनपद पंचायत / सहायक आयुक्त जनजातीय कार्य विभाग",
      trackingMethod = "ग्राम पंचायत एवं जनपद स्तर पर PM-JANMAN डैशबोर्ड के माध्यम से स्थिति ट्रैक करें।",
      grievanceRedressal = "जनपद पंचायत सीईओ, जिला कलेक्टर जनसुनवाई अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://tribal.nic.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "Justice Hub Society विधिक शोध प्रकोष्ठ",
      verifierRole = "State Legal Coordinator",
      targetAudiences = listOf("PVTG", "Tribal", "Farmers", "Women", "Workers")
    ),

    GovernmentScheme(
      id = "sch-dajgua",
      nameHindi = "धरती आबा जनजातीय ग्राम उत्कर्ष अभियान (DAJGUA)",
      nameEnglish = "Dharti Aaba Janjatiya Gram Utkarsh Abhiyan",
      objectiveHindi = "देश के 63,843 जनजातीय बहुल गाँवों (म.प्र. के 591+ गाँव) में 17 केंद्रीय मंत्रालयों के 25 प्रमुख हस्तक्षेपों के समन्वय से बुनियादी ढाँचे की कमियों को दूर करना।",
      objectiveEnglish = "Holistic development of 63,843 tribal majority villages through 25 interventions across 17 ministries.",
      responsibleDepartment = "जनजातीय कार्य मंत्रालय, भारत सरकार",
      level = "Central",
      category = SchemeCategory.TRIBAL_WELFARE,
      eligibilityCriteriaHindi = listOf(
        "गाँव की कुल आबादी में अनुसूचित जनजाति (ST) की हिस्सेदारी 50% या उससे अधिक हो",
        "सामान्यतः 500 या उससे अधिक जनसंख्या वाले जनजातीय बहुल गाँव (आकांक्षी ब्लॉकों में विशेष मानक)",
        "अभियान की आधिकारिक चयनित ग्राम सूची में गाँव शामिल हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Village with at least 50% Scheduled Tribe population",
        "Population generally 500+ (or special aspirational block norms)",
        "Notified in official DAJGUA village list"
      ),
      whoCanApplyHindi = "चयनित जनजातीय गाँव की ग्राम सभा एवं समस्त निवासी",
      whoCanApplyEnglish = "Gram Sabha and community members of selected tribal villages",
      benefitsHindi = listOf(
        "स्वास्थ्य केंद्रों का सुदृढ़ीकरण, पोषण सेवाएँ व आंगनवाड़ी",
        "सड़क, बिजली, पेयजल, डिजिटल व दूरसंचार अधोसंरचना",
        "कौशल प्रशिक्षण, आजीविका केंद्र, कृषि व ग्रामीण विकास कार्यक्रम"
      ),
      benefitsEnglish = listOf(
        "Strengthening healthcare, nutrition, Anganwadi",
        "Roads, electricity, piped water, telecom connectivity",
        "Skill development, livelihood, agriculture convergence"
      ),
      requiredDocumentsHindi = listOf(
        "ग्राम सभा का विकास प्रस्ताव",
        "गाँव का आधारभूत सर्वेक्षण प्रपत्र",
        "पंचायत अनुशंसा पत्र"
      ),
      requiredDocumentsEnglish = listOf(
        "Gram Sabha resolution",
        "Baseline village infrastructure survey",
        "Panchayat recommendation"
      ),
      applicationProcedureHindi = "ग्राम सभा में गाँव की बुनियादी सुविधाओं की मांग दर्ज कराएं और जनपद/जिला जनजातीय कार्य विभाग को कार्ययोजना प्रस्तुत करें।",
      applicationProcedureEnglish = "Submit community priorities through Gram Sabha resolution to Janpad and District Tribal Affairs.",
      onlineApplicationLink = "https://tribal.nic.in",
      offlineApplicationLocation = "ग्राम पंचायत / जनपद पंचायत / जिला कलेक्ट्रेट जनजातीय प्रकोष्ठ",
      trackingMethod = "ग्राम सभा कार्यवाही रजिस्टर एवं जनपद पंचायत कार्ययोजना से प्रगति देखें।",
      grievanceRedressal = "जिला जनजातीय कार्य अधिकारी, जिला कलेक्टर एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://tribal.nic.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Legal Researcher",
      targetAudiences = listOf("Tribal", "Farmers", "Rural", "Workers")
    ),

    GovernmentScheme(
      id = "sch-pvtg-development",
      nameHindi = "विशेष रूप से कमजोर जनजातीय समूह विकास योजना (PVTG Development Scheme)",
      nameEnglish = "Scheme for Development of Particularly Vulnerable Tribal Groups",
      objectiveHindi = "बैगा, भारिया और सहरिया समुदायों के पूरे पर्यावास (Habitat) के सामाजिक व आर्थिक विकास, संस्कृति संरक्षण, आवास, पेयजल, सिंचाई और सौर ऊर्जा हेतु शत-प्रतिशत सहायता।",
      objectiveEnglish = "Comprehensive habitat and socio-economic development, culture preservation, housing, irrigation, and clean energy for PVTG communities.",
      responsibleDepartment = "जनजातीय कार्य मंत्रालय, भारत सरकार एवं राज्य जनजातीय विकास अभिकरण",
      level = "Central",
      category = SchemeCategory.TRIBAL_WELFARE,
      eligibilityCriteriaHindi = listOf(
        "आवेदक बैगा, भारिया या सहरिया अधिसूचित PVTG समुदाय का सदस्य हो",
        "संबंधित जिले/क्षेत्र में PVTG पहचान व निवास का सत्यापन हो",
        "सहायता स्वीकृत क्षेत्रीय विकास परियोजना (Conservation-cum-Development Plan) के अंतर्गत आती हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Member of notified PVTG (Baiga, Bharia, or Sahariya)",
        "Verified residence in notified habitat area",
        "Part of approved Conservation-cum-Development Plan"
      ),
      whoCanApplyHindi = "सहरिया, बैगा और भारिया परिवार एवं उनकी ग्राम सभाएं",
      whoCanApplyEnglish = "PVTG families and their Gram Sabhas",
      benefitsHindi = listOf(
        "आवास निर्माण व सुधार, सौर ऊर्जा विद्युतीकरण",
        "पेयजल, सिंचाई कूप, खेत समतलीकरण व भूमि विकास",
        "पारंपरिक संस्कृति, ज्ञान संरक्षण, औषधीय पौधे व हस्तशिल्प आजीविका"
      ),
      benefitsEnglish = listOf(
        "Housing construction, solar electrification",
        "Drinking water, irrigation, land development",
        "Preservation of traditional culture, herbal medicine, handicrafts"
      ),
      requiredDocumentsHindi = listOf(
        "जाति/PVTG पहचान प्रमाण",
        "आधार कार्ड व समग्र आईडी",
        "निवास प्रमाण",
        "ग्राम सभा का प्रस्ताव"
      ),
      requiredDocumentsEnglish = listOf(
        "PVTG Caste Certificate",
        "Aadhaar and Samagra ID",
        "Domicile proof",
        "Gram Sabha resolution"
      ),
      applicationProcedureHindi = "ग्राम सभा में आवश्यक कार्यों का प्रस्ताव रखें। प्रस्ताव जनपद एवं जिला जनजातीय कार्य विभाग/ITDA को भेजा जाता है।",
      applicationProcedureEnglish = "Propose works via Gram Sabha to Janpad and District ITDA/Tribal Development Agency.",
      onlineApplicationLink = "https://tribal.nic.in",
      offlineApplicationLocation = "जनपद पंचायत / सहायक आयुक्त जनजातीय कार्य / ITDA कार्यालय",
      trackingMethod = "जिला जनजातीय कार्य विभाग के CCD प्लान प्रगति रजिस्टर से जानकारी प्राप्त करें।",
      grievanceRedressal = "कलेक्टर जनसुनवाई / जिला सहायक आयुक्त / RTI 2005.",
      officialSourceUrl = "https://tribal.nic.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Case Manager",
      targetAudiences = listOf("PVTG", "Tribal", "Farmers")
    ),

    GovernmentScheme(
      id = "sch-st-basti-vikas",
      nameHindi = "अनुसूचित जनजाति बस्ती विकास एवं विद्युतीकरण योजना (मध्य प्रदेश शासन)",
      nameEnglish = "ST Basti Development & Electrification Scheme (MP)",
      objectiveHindi = "कम से कम 50% अनुसूचित जनजाति आबादी वाली बस्तियों, मजरों, टोलों में पक्की सड़क, नाली, पुलिया, सामुदायिक भवन व विद्युतीकरण कार्य स्वीकृत करना।",
      objectiveEnglish = "Infrastructure development, drainage, paved roads, community halls, and electrification in habitations with at least 50% ST population.",
      responsibleDepartment = "जनजातीय कार्य विभाग, मध्य प्रदेश शासन",
      level = "State (MP)",
      category = SchemeCategory.TRIBAL_WELFARE,
      eligibilityCriteriaHindi = listOf(
        "बस्ती, मजरा, टोला, पारा या वार्ड में अनुसूचित जनजाति की आबादी कम से कम 50% हो",
        "संबंधित क्षेत्र मध्य प्रदेश के ग्रामीण अथवा शहरी सीमा में स्थित हो",
        "गाँव में नाली, पक्की सड़क, पुलिया या विद्युतीकरण की गंभीर कमी हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "At least 50% ST population in the hamlet/ward",
        "Located in Madhya Pradesh",
        "Lack of drainage, paved roads, culverts, or electricity"
      ),
      whoCanApplyHindi = "ग्राम सभा, पंचायत प्रतिनिधि एवं बस्ती के ग्रामीण नागरिक",
      whoCanApplyEnglish = "Gram Sabha, Panchayat representatives, and village residents",
      benefitsHindi = listOf(
        "बस्ती में पक्की सीसी सड़क व पक्की नालियों का निर्माण",
        "गाँव तक संपर्क मार्ग, पुलिया व रपटा निर्माण",
        "बस्ती का संपूर्ण विद्युतीकरण व कृषि पंपों का ऊर्जीकरण",
        "सामुदायिक भवन व शैक्षणिक संस्थाओं में सुविधा विस्तार"
      ),
      benefitsEnglish = listOf(
        "Paved concrete roads and covered drainage",
        "All-weather link roads, culverts, and causeways",
        "Complete electrification and energization of pumps",
        "Community centers and school infrastructure"
      ),
      requiredDocumentsHindi = listOf(
        "ग्राम सभा का सर्वसम्मत प्रस्ताव",
        "बस्ती की ST जनसंख्या का प्रमाण पत्र (सचिव/पटवारी द्वारा)",
        "आवश्यक निर्माण कार्यों की सूची व स्थल निरीक्षण रिपोर्ट"
      ),
      requiredDocumentsEnglish = listOf(
        "Gram Sabha unanimous resolution",
        "ST population percentage certification",
        "List of proposed works with spot inspection"
      ),
      applicationProcedureHindi = "गाँव में कार्यों की सूची बनाकर ग्राम सभा में प्रस्ताव पारित कराएं। प्रस्ताव जनपद पंचायत एवं सहायक आयुक्त जनजातीय कार्य विभाग को प्रस्तुत करें। जिला स्तरीय समिति अनुमोदन करती है।",
      applicationProcedureEnglish = "Pass Gram Sabha resolution and submit to Janpad Panchayat & Assistant Commissioner Tribal Affairs.",
      onlineApplicationLink = "https://tribal.mp.gov.in",
      offlineApplicationLocation = "कार्यालय सहायक आयुक्त जनजातीय कार्य विभाग / जनपद पंचायत",
      trackingMethod = "जनपद पंचायत एवं जनजातीय कार्य विभाग के निर्माण प्रकोष्ठ से स्वीकृति आदेश देखें।",
      grievanceRedressal = "प्रभारी मंत्री समिति, जिला कलेक्टर एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://tribal.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "रामदयाल सहरिया",
      verifierRole = "Field Coordinator",
      targetAudiences = listOf("Tribal", "Rural", "PVTG")
    ),

    GovernmentScheme(
      id = "sch-pmjvm-trifed",
      nameHindi = "प्रधानमंत्री जनजातीय विकास मिशन (PMJVM) एवं वन धन योजना",
      nameEnglish = "Pradhan Mantri Janjatiya Vikas Mission & Van Dhan Scheme",
      objectiveHindi = "आदिवासी वनोपज संग्राहकों, महिला स्वयं सहायता समूहों को लघु वनोपज (महुआ, चिरौंजी, तेन्दूपत्ता, शहद, लाख) का मूल्य संवर्धन, ग्रेडिंग, पैकेजिंग व न्यूनतम समर्थन मूल्य (MSP) दिलाना।",
      objectiveEnglish = "Empowering tribal minor forest produce gatherers and SHGs through value addition, processing, packaging, and MSP support under TRIFED.",
      responsibleDepartment = "जनजातीय कार्य मंत्रालय, भारत सरकार एवं TRIFED",
      level = "Central",
      category = SchemeCategory.AGRICULTURE_LIVELIHOOD,
      eligibilityCriteriaHindi = listOf(
        "आदिवासी लघु वनोपज संग्राहक, कारीगर अथवा महिला स्वयं सहायता समूह",
        "वन धन समूह (VDSHG) में न्यूनतम 70% सदस्य अनुसूचित जनजाति के हों",
        "स्थानीय स्तर पर लघु वनोपज का संग्रहण व पारंपरिक प्रसंस्करण होता हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Tribal minor forest produce gatherers, artisans, or SHGs",
        "At least 70% ST members in the Van Dhan Self Help Group",
        "Engaged in local NTFP collection and processing"
      ),
      whoCanApplyHindi = "जनजातीय वनोपज संग्राहक एवं महिला स्वयं सहायता समूह (SHG)",
      whoCanApplyEnglish = "Tribal MFP gatherers and Women SHGs",
      benefitsHindi = listOf(
        "वन धन विकास केंद्र (300 सदस्य) हेतु ₹15 लाख तक का केंद्रीय अनुदान",
        "लघु वनोपज की छंटाई, सुखाने, तेल निष्कासन व पैकेजिंग उपकरण",
        "बाजार से सीधा जुड़ाव, ट्राइब्स इंडिया (Tribes India) प्लेटफॉर्म पर बिक्री",
        "न्यूनतम समर्थन मूल्य (MSP for MFP) पर सरकारी खरीद गारंटी"
      ),
      benefitsEnglish = listOf(
        "Up to ₹15 Lakhs central grant per 300-member Van Dhan Center",
        "Processing, grading, drying, and packaging machinery",
        "Direct market linkage and marketing through Tribes India",
        "Minimum Support Price (MSP) purchase guarantee"
      ),
      requiredDocumentsHindi = listOf(
        "समूह सदस्यों की सूची (70%+ ST)",
        "सदस्यों के आधार कार्ड व जाति प्रमाण",
        "समूह का बैंक खाता विवरण",
        "ग्राम पंचायत का अनापत्ति प्रमाण पत्र",
        "वनोपज व्यवसाय योजना"
      ),
      requiredDocumentsEnglish = listOf(
        "Member list (70%+ ST)",
        "Aadhaar and Caste certificates",
        "Group Bank Account details",
        "Panchayat NOC for premises",
        "Business plan"
      ),
      applicationProcedureHindi = "लघु वनोपज संग्राहकों का 15-20 सदस्यीय समूह बनाएं। जिला वन मंडल (DFO) अथवा TRIFED राज्य कार्यान्वयन इकाई को प्रस्ताव प्रस्तुत करें।",
      applicationProcedureEnglish = "Form SHG of 15-20 gatherers and submit proposal to District Forest Officer (DFO) / TRIFED nodal agency.",
      onlineApplicationLink = "https://trifed.tribal.gov.in",
      offlineApplicationLocation = "कार्यालय उप वन संरक्षक (DFO) / जिला आजीविका मिशन / TRIFED कार्यालय",
      trackingMethod = "TRIFED Van Dhan पोर्टल पर समूह पंजीयन आईडी से प्रगति देखें।",
      grievanceRedressal = "प्रबंध निदेशक TRIFED, जिला वन अधिकारी एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://trifed.tribal.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Case Manager",
      targetAudiences = listOf("Tribal", "Women", "Workers", "PVTG")
    ),

    GovernmentScheme(
      id = "sch-dudharu-pashu",
      nameHindi = "मुख्यमंत्री दुधारू पशु प्रदाय कार्यक्रम (PVTG बैगा, भारिया, सहरिया)",
      nameEnglish = "Chief Minister Milch Cattle Distribution Scheme for PVTGs",
      objectiveHindi = "सहरिया, बैगा और भारिया परिवारों को 90% सरकारी अनुदान पर 2 दुधारू गाय या मुर्रा भैंस उपलब्ध कराकर उनकी आजीविका व पोषण में स्थायी सुधार करना।",
      objectiveEnglish = "Providing 2 milch cows or Murrah buffaloes to Sahariya, Baiga, and Bharia families with 90% government subsidy and 10% beneficiary share.",
      responsibleDepartment = "पशुपालन एवं डेयरी विभाग, मध्य प्रदेश शासन",
      level = "State (MP)",
      category = SchemeCategory.AGRICULTURE_LIVELIHOOD,
      eligibilityCriteriaHindi = listOf(
        "आवेदक सहरिया, बैगा या भारिया PVTG समुदाय का सदस्य हो",
        "अधिसूचित जिले (सहरिया: शिवपुरी, श्योपुर, गुना, ग्वालियर, मुरैना, भिंड, दतिया, अशोकनगर; बैगा: डिंडोरी, मंडला, बालाघाट, उमरिया; भारिया: छिंदवाड़ा) का निवासी हो",
        "ग्राम सभा व जनपद पंचायत की स्थायी कृषि समिति द्वारा अनुमोदित हो",
        "10% हितग्राही अंशदान वहन करने एवं पशु प्रबंधन की मूलभूत व्यवस्था हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Belongs to Sahariya, Baiga, or Bharia PVTG",
        "Resident in notified districts of MP",
        "Approved by Gram Sabha and Janpad Agriculture Committee",
        "Willing to contribute 10% share and maintain milch cattle"
      ),
      whoCanApplyHindi = "सहरिया, बैगा व भारिया समुदाय के पशुपालक परिवार",
      whoCanApplyEnglish = "PVTG cattle rearers and marginal households",
      benefitsHindi = listOf(
        "90% सरकारी अनुदान, केवल 10% हितग्राही अंशदान",
        "प्रति पात्र परिवार 2 देशी उन्नत दुधारू गाय (न्यूनतम 7 ली/दिन) अथवा मुर्रा भैंस (न्यूनतम 8 ली/दिन)",
        "दुग्ध विक्रय से नियमित दैनिक आय व परिवार में बाल कुपोषण का समाधान",
        "निःशुल्क पशुपालन व डेयरी प्रबंधन प्रशिक्षण व टीकाकरण सुरक्षा"
      ),
      benefitsEnglish = listOf(
        "90% Government grant, only 10% beneficiary contribution",
        "2 milch cows (7+ L/day) or Murrah buffaloes (8+ L/day)",
        "Daily regular income and eradication of child malnutrition",
        "Free dairy management training and cattle vaccination"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड",
        "PVTG स्थायी जाति प्रमाण पत्र",
        "मूल निवासी प्रमाण पत्र",
        "समग्र परिवार आईडी",
        "बैंक पासबुक",
        "ग्राम सभा अनुमोदन प्रस्ताव"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar Card",
        "PVTG Caste Certificate",
        "Domicile Certificate",
        "Samagra Family ID",
        "Bank Passbook",
        "Gram Sabha Resolution"
      ),
      applicationProcedureHindi = "निकटतम पशु चिकित्सा संस्था (पशु औषधालय/चिकित्सालय) से निर्धारित आवेदन फॉर्म प्राप्त कर ग्राम सभा में प्रस्तुत करें। उपसंचालक पशु चिकित्सा सेवाएँ द्वारा स्वीकृति दी जाती है।",
      applicationProcedureEnglish = "Obtain form from nearest Veterinary Hospital/Dispensary, get Gram Sabha approval, and submit to Deputy Director Veterinary Services.",
      onlineApplicationLink = "https://mpdah.gov.in",
      offlineApplicationLocation = "निकटतम पशु चिकित्सालय / जनपद पंचायत / उपसंचालक पशुपालन कार्यालय",
      trackingMethod = "पशु चिकित्सा अधिकारी एवं जनपद पंचायत कृषि समिति से स्थिति पता करें।",
      grievanceRedressal = "उपसंचालक पशु चिकित्सा सेवाएँ, जिला कलेक्टर एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://mpdah.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "दिनेश भील",
      verifierRole = "JHS Field Volunteer",
      targetAudiences = listOf("PVTG", "Farmers", "Tribal")
    ),

    GovernmentScheme(
      id = "sch-sickle-cell",
      nameHindi = "राष्ट्रीय सिकल सेल एनीमिया उन्मूलन मिशन (मध्य प्रदेश)",
      nameEnglish = "National Sickle Cell Anemia Elimination Mission",
      objectiveHindi = "आदिवासी आबादी में सिकल सेल एनीमिया बीमारी की निःशुल्क जांच, रंग-कोडित स्थिति कार्ड, काउंसलिंग एवं विशेष स्वास्थ्य उपचार उपलब्ध कराना।",
      objectiveEnglish = "Free genetic screening, counseling, color-coded health cards, and treatment for tribal communities to eliminate Sickle Cell Anemia by 2047.",
      responsibleDepartment = "लोक स्वास्थ्य एवं परिवार कल्याण विभाग तथा जनजातीय कार्य विभाग, म.प्र.",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश के समस्त अनुसूचित जनजाति (ST) एवं PVTG नागरिक (0 से 40 वर्ष के बच्चे व युवा)",
        "विवाह से पूर्व अथवा गर्भावस्था के दौरान स्क्रीनिंग करवाने वाले दंपति",
        "पारिवारिक इतिहास में एनीमिया या रक्त विकार से पीड़ित व्यक्ति"
      ),
      eligibilityCriteriaEnglish = listOf(
        "All ST and PVTG residents in MP aged 0-40 years",
        "Couples seeking pre-marital or antenatal genetic counseling",
        "Individuals with family history of anemia or blood disorder"
      ),
      whoCanApplyHindi = "समस्त जनजातीय व ग्रामीण नागरिक",
      whoCanApplyEnglish = "All tribal and rural citizens",
      benefitsHindi = listOf(
        "निःशुल्क सिकल सेल स्क्रीनिंग (Point of Care Test व HPLC टेस्ट)",
        "डिजिटल सिकल सेल स्वास्थ्य कार्ड (सामान्य/वाहक/रोगी रंग कोड)",
        "निःशुल्क हाइड्रोक्सीयूरिया दवाइयां व फोलिक एसिड गोलियां",
        "जिला अस्पतालों में डे-केयर सेंटर व आपातकालीन रक्त आधान (Blood Transfusion) सुविधा"
      ),
      benefitsEnglish = listOf(
        "Free Sickle Cell screening (POC test & HPLC test)",
        "Digital color-coded Sickle Cell status card",
        "Free Hydroxyurea and Folic Acid medications",
        "Day Care centers and free blood transfusion at District Hospital"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड",
        "समग्र आईडी",
        "मोबाइल नंबर"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar Card",
        "Samagra ID",
        "Mobile number"
      ),
      applicationProcedureHindi = "नजदीकी आयुष्मान आरोग्य मंदिर, प्राथमिक स्वास्थ्य केंद्र (PHC), सामुदायिक स्वास्थ्य केंद्र (CHC) या जिला अस्पताल में निःशुल्क जांच कराएं और अपना कार्ड प्राप्त करें।",
      applicationProcedureEnglish = "Visit nearest Ayushman Arogya Mandir, PHC, CHC, or District Hospital for on-the-spot screening and card.",
      onlineApplicationLink = "https://sickle.nhm.gov.in",
      offlineApplicationLocation = "आयुष्मान आरोग्य मंदिर / उप स्वास्थ्य केंद्र / PHC / CHC / जिला अस्पताल",
      trackingMethod = "सिकल सेल पोर्टल पर मोबाइल नंबर अथवा आभा (ABHA) आईडी से डिजिटल कार्ड डाउनलोड करें।",
      grievanceRedressal = "मुख्य चिकित्सा एवं स्वास्थ्य अधिकारी (CMHO) एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://sickle.nhm.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Researcher",
      targetAudiences = listOf("Tribal", "PVTG", "Children", "Women")
    ),

    GovernmentScheme(
      id = "sch-seekho-kamao",
      nameHindi = "मुख्यमंत्री सीखो-कमाओ योजना (मध्य प्रदेश)",
      nameEnglish = "Mukhyamantri Seekho-Kamao Yojana (MMSKY)",
      objectiveHindi = "मध्य प्रदेश के 18 से 29 वर्ष के युवाओं को उद्योगों व व्यावसायिक प्रतिष्ठानों में काम सीखने के साथ ₹8,000 से ₹10,000 प्रतिमाह स्टाइपेंड उपलब्ध कराना।",
      objectiveEnglish = "On-the-job training in industrial establishments with monthly stipend of ₹8,000 - ₹10,000 for youth aged 18-29.",
      responsibleDepartment = "तकनीकी शिक्षा, कौशल विकास एवं रोजगार विभाग, म.प्र.",
      level = "State (MP)",
      category = SchemeCategory.EMPLOYMENT_RURAL_DEV,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का स्थानीय मूल निवासी हो",
        "आयु 18 से 29 वर्ष के मध्य हो",
        "शैक्षणिक योग्यता: 12वीं पास, आईटीआई (ITI) अथवा डिप्लोमा/स्नातक",
        "बैंक खाता आधार NPCI से सक्रिय हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Domicile of Madhya Pradesh",
        "Age between 18 and 29 years",
        "Education: 12th pass, ITI, Diploma or Graduate",
        "Aadhaar NPCI linked bank account"
      ),
      whoCanApplyHindi = "18-29 वर्ष के शिक्षित बेरोजगार युवा",
      whoCanApplyEnglish = "Educated youth seeking vocational training and employment",
      benefitsHindi = listOf(
        "12वीं उत्तीर्ण हेतु ₹8,000 प्रतिमाह स्टाइपेंड",
        "आईटीआई उत्तीर्ण हेतु ₹8,500 प्रतिमाह स्टाइपेंड",
        "डिप्लोमा उत्तीर्ण हेतु ₹9,000 एवं स्नातक हेतु ₹10,000 प्रतिमाह स्टाइपेंड",
        "प्रशिक्षण उपरांत राज्य कौशल प्रमाण पत्र व उद्योग में नियमित नौकरी का अवसर"
      ),
      benefitsEnglish = listOf(
        "₹8,000/month for 12th pass",
        "₹8,500/month for ITI pass",
        "₹9,000/month for Diploma and ₹10,000/month for Graduates",
        "State skill certification and job placement opportunity"
      ),
      requiredDocumentsHindi = listOf(
        "समग्र आईडी व आधार कार्ड",
        "शैक्षणिक योग्यता अंकसूची (12वीं/ITI/डिप्लोमा/डिग्री)",
        "मध्य प्रदेश मूल निवासी प्रमाण पत्र",
        "बैंक पासबुक विवरण"
      ),
      requiredDocumentsEnglish = listOf(
        "Samagra ID and Aadhaar Card",
        "Educational marksheets",
        "MP Domicile Certificate",
        "Bank Passbook"
      ),
      applicationProcedureHindi = "MMSKY आधिकारिक पोर्टल पर युवा पंजीयन करें, अपनी योग्यता अनुसार ट्रेड व प्रतिष्ठान का चयन कर ऑनलाइन आवेदन करें।",
      applicationProcedureEnglish = "Register profile on MMSKY official portal, choose course & establishment, and submit online.",
      onlineApplicationLink = "https://mmsky.mp.gov.in",
      offlineApplicationLocation = "जिला रोजगार कार्यालय / शासकीय आईटीआई / कलेक्ट्रेट कौशल विकास प्रकोष्ठ",
      trackingMethod = "MMSKY पोर्टल पर लॉगिन कर अनुबंध स्थिति व स्टाइपेंड भुगतान देखें।",
      grievanceRedressal = "टोल-फ्री हेल्पलाइन 0755-2525258 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://mmsky.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "दिनेश भील",
      verifierRole = "JHS Field Volunteer",
      targetAudiences = listOf("Students", "Workers", "Tribal")
    ),

    GovernmentScheme(
      id = "sch-sbm-g",
      nameHindi = "स्वच्छ भारत मिशन – ग्रामीण (SBM-G व्यक्तिगत शौचालय)",
      nameEnglish = "Swachh Bharat Mission - Gramin (IHHL)",
      objectiveHindi = "ग्रामीण परिवारों में खुले में शौच मुक्ति हेतु पात्र नए बीपीएल व चिन्हित एपीएल (ST/SC/महिला मुखिया) परिवारों को ₹12,000 की प्रोत्साहन राशि।",
      objectiveEnglish = "Incentive of ₹12,000 for construction of Individual Household Latrines (IHHL) for rural ST/SC and eligible households.",
      responsibleDepartment = "पेयजल एवं स्वच्छता विभाग / पंचायत एवं ग्रामीण विकास विभाग",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "ग्रामीण क्षेत्र का ऐसा परिवार जिसके घर में पूर्व से पक्का शौचालय निर्मित न हो",
        "बीपीएल परिवार अथवा अनुसूचित जनजाति (ST), अनुसूचित जाति (SC), लघु-सीमांत किसान परिवार",
        "ग्राम पंचायत की बेसलाइन सर्वे सूची में नाम दर्ज हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Rural household without pre-existing pucca toilet",
        "BPL, ST, SC, or marginal farmer family",
        "Listed in Panchayat SBM-G baseline database"
      ),
      whoCanApplyHindi = "शौचालय विहीन ग्रामीण परिवार",
      whoCanApplyEnglish = "Rural households lacking sanitation facilities",
      benefitsHindi = listOf(
        "व्यक्तिगत घरेलू शौचालय निर्माण हेतु ₹12,000 की नकद प्रोत्साहन राशि",
        "माताओं व बहनों को सम्मान, सुरक्षा और परिवार को संक्रामक बीमारियों से मुक्ति"
      ),
      benefitsEnglish = listOf(
        "₹12,000 direct cash incentive on toilet completion and geotagging",
        "Dignity, safety, and health protection for family"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड",
        "समग्र आईडी",
        "बैंक पासबुक (आधार लिंक)",
        "जाति प्रमाण पत्र (ST/SC हेतु)",
        "निर्मित शौचालय के साथ लाभार्थी की फोटो (जियो-टैगिंग हेतु)"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar Card",
        "Samagra ID",
        "Bank Passbook",
        "Caste Certificate",
        "Photograph with constructed toilet for geotagging"
      ),
      applicationProcedureHindi = "ग्राम पंचायत में आवेदन दें या SBM-G पोर्टल पर ऑनलाइन IHHL आवेदन करें। स्वीकृति उपरांत निर्माण करें और सचिव से जियो-टैगिंग करवाएं।",
      applicationProcedureEnglish = "Apply through Gram Panchayat or SBM-G portal, construct as per specification, and get verified via geotagging.",
      onlineApplicationLink = "https://swachhbharatmission.ddws.gov.in",
      offlineApplicationLocation = "ग्राम पंचायत भवन / जनपद पंचायत स्वच्छ भारत मिशन प्रकोष्ठ",
      trackingMethod = "SBM पोर्टल पर आवेदन क्रमांक दर्ज कर जियो-टैग व भुगतान स्थिति देखें।",
      grievanceRedressal = "जनपद पंचायत समन्वयक (SBM), जिला पंचायत सीईओ एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://swachhbharatmission.ddws.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "रामदयाल सहरिया",
      verifierRole = "Field Coordinator",
      targetAudiences = listOf("Rural", "Tribal", "Women", "PVTG")
    ),

    GovernmentScheme(
      id = "sch-nstfdc-loan",
      nameHindi = "राष्ट्रीय अनुसूचित जनजाति वित्त एवं विकास निगम (NSTFDC) रियायती ऋण",
      nameEnglish = "National Scheduled Tribes Finance and Development Corporation Loan",
      objectiveHindi = "अनुसूचित जनजाति के युवाओं, महिलाओं व स्वयं सहायता समूहों को कृषि, डेयरी, दुकान, वाहन, लघु उद्योग हेतु 4% से 6% रियायती ब्याज दर पर सावधि ऋण उपलब्ध कराना।",
      objectiveEnglish = "Concessional term loans and microcredit at 4-6% interest for tribal entrepreneurs, women, and SHGs.",
      responsibleDepartment = "जनजातीय कार्य मंत्रालय, भारत सरकार एवं म.प्र. आदिवासी वित्त एवं विकास निगम",
      level = "Central",
      category = SchemeCategory.AGRICULTURE_LIVELIHOOD,
      eligibilityCriteriaHindi = listOf(
        "आवेदक अनुसूचित जनजाति (ST) का स्थायी निवासी हो",
        "वार्षिक पारिवारिक आय ग्रामीण क्षेत्र में ₹3.00 लाख तक हो",
        "पूर्व में किसी बैंक अथवा वित्तीय संस्था का डिफॉल्टर न हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Member of Scheduled Tribe",
        "Annual family income up to ₹3.00 Lakhs in rural areas",
        "No default history in banking system"
      ),
      whoCanApplyHindi = "जनजातीय युवा, महिलाएं, कारीगर एवं स्वयं सहायता समूह",
      whoCanApplyEnglish = "Tribal youth, women, artisans, and SHGs",
      benefitsHindi = listOf(
        "आदिवासी महिला सशक्तिकरण योजना अंतर्गत ₹2.00 लाख तक ऋण मात्र 4% ब्याज पर",
        "टर्म लोन योजना अंतर्गत ₹50 लाख तक की व्यावसायिक इकाइयों हेतु रियायती ऋण",
        "स्वयं सहायता समूहों हेतु माइक्रो क्रेडिट योजना"
      ),
      benefitsEnglish = listOf(
        "Adivasi Mahila Sashaktikaran: Up to ₹2.00 Lakhs at 4% interest",
        "Term Loan: Up to ₹50 Lakhs at concessional 6% interest",
        "Microcredit support for SHGs"
      ),
      requiredDocumentsHindi = listOf(
        "स्थायी डिजिटल जाति प्रमाण पत्र",
        "आधार कार्ड व पैन कार्ड",
        "आय व मूल निवासी प्रमाण पत्र",
        "परियोजना रिपोर्ट (Project Report / कोटेशन)",
        "बैंक पासबुक व जमीन/दुकान के कागजात"
      ),
      requiredDocumentsEnglish = listOf(
        "Digital Caste Certificate",
        "Aadhaar and PAN Card",
        "Income and Domicile proof",
        "Project Report / Quotation",
        "Bank details"
      ),
      applicationProcedureHindi = "जिला अंत्यावसायी / मध्य प्रदेश आदिवासी वित्त एवं विकास निगम कार्यालय में प्रोजेक्ट रिपोर्ट सहित आवेदन प्रस्तुत करें।",
      applicationProcedureEnglish = "Submit application with Project Report to District Tribal Finance & Development Corporation office.",
      onlineApplicationLink = "https://nstfdc.tribal.gov.in",
      offlineApplicationLocation = "कार्यालय जिला अंत्यावसायी / सहायक आयुक्त जनजातीय कार्य / कलेक्ट्रेट",
      trackingMethod = "चैनल पार्टनर बैंक व जिला अंत्यावसायी कार्यालय से ऋण संवितरण स्थिति देखें।",
      grievanceRedressal = "प्रबंध संचालक म.प्र. आदिवासी वित्त विकास निगम, जिला कलेक्टर एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://nstfdc.tribal.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Case Manager",
      targetAudiences = listOf("Tribal", "Women", "Workers", "PVTG")
    ),

    GovernmentScheme(
      id = "sch-jal-jeevan",
      nameHindi = "जल जीवन मिशन (हर घर जल - ग्रामीण नल जल योजना)",
      nameEnglish = "Jal Jeevan Mission - Har Ghar Nal Se Jal",
      objectiveHindi = "प्रत्येक ग्रामीण व आदिवासी परिवार के घर तक नल से 55 लीटर प्रति व्यक्ति प्रतिदिन सुरक्षित व शुद्ध पेयजल आपूर्ति सुनिश्चित करना।",
      objectiveEnglish = "Providing safe and adequate piped drinking water through individual household tap connections (55 LPCD) in rural habitations.",
      responsibleDepartment = "लोक स्वास्थ्य यांत्रिकी विभाग (PHED), मध्य प्रदेश शासन",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश के ग्रामीण अंचल व आदिवासी मजरे/टोले में स्थायी निवासी",
        "घर में पूर्व से नल-जल कनेक्शन उपलब्ध न हो",
        "ग्राम जल एवं स्वच्छता समिति (VWSC) सर्वेक्षण में सम्मिलित परिवार"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Permanent resident of rural tribal hamlet/village in MP",
        "Lacking pre-existing functional tap water connection",
        "Listed in VWSC village baseline survey"
      ),
      whoCanApplyHindi = "समस्त ग्रामीण व जनजातीय परिवार",
      whoCanApplyEnglish = "All rural and tribal households",
      benefitsHindi = listOf(
        "घर के आँगन/रसोई तक निःशुल्क क्रियाशील घरेलू नल कनेक्शन (FHTC)",
        "गुणवत्ता युक्त शुद्ध पेयजल (क्लोरीनेशन व नियमित परीक्षण युक्त)",
        "महिलाओं व बालिकाओं को दूर-दराज से पानी ढोने के श्रम से स्थायी मुक्ति"
      ),
      benefitsEnglish = listOf(
        "Free functional household tap connection (FHTC)",
        "Tested safe potable drinking water",
        "Relief for women and children from fetching water from distances"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड",
        "समग्र परिवार आईडी",
        "निवास प्रमाण पत्र / राशन कार्ड"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar Card",
        "Samagra Family ID",
        "Domicile proof / Ration Card"
      ),
      applicationProcedureHindi = "ग्राम जल एवं स्वच्छता समिति (VWSC) अथवा ग्राम पंचायत सरपंच/सचिव को नल कनेक्शन हेतु आवेदन प्रस्तुत करें। कार्यपालन यंत्री PHED द्वारा स्वीकृति दी जाती है।",
      applicationProcedureEnglish = "Submit application to Gram Jal & Swachhata Samiti (VWSC) or Gram Panchayat Secretary.",
      onlineApplicationLink = "https://jaljeevanmission.gov.in",
      offlineApplicationLocation = "ग्राम पंचायत भवन / कार्यालय कार्यपालन यंत्री, PHED",
      trackingMethod = "Jal Jeevan Mission डैशबोर्ड पर ग्राम पंचायत का नाम चुनकर प्रगति देखें।",
      grievanceRedressal = "PHED हेल्पलाइन 1800-233-0008, टोल-फ्री 181 अथवा जिला कलेक्टर जनसुनवाई।",
      officialSourceUrl = "https://jaljeevanmission.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "रामदयाल सहरिया",
      verifierRole = "Field Coordinator",
      targetAudiences = listOf("Rural", "Tribal", "Women", "PVTG")
    ),

    GovernmentScheme(
      id = "sch-kcc-pmfby",
      nameHindi = "किसान क्रेडिट कार्ड (KCC) एवं प्रधानमंत्री फसल बीमा योजना (PMFBY)",
      nameEnglish = "Kisan Credit Card (KCC) & Pradhan Mantri Fasal Bima Yojana",
      objectiveHindi = "आदिवासी व वन पट्टाधारक किसानों को खेती, खाद-बीज हेतु मात्र 4% रियायती ब्याज दर पर KCC ऋण तथा प्राकृतिक आपदा में शत-प्रतिशत फसल बीमा मुआवजा।",
      objectiveEnglish = "Concessional short-term crop loans at 4% effective interest via KCC and comprehensive natural calamity crop insurance cover.",
      responsibleDepartment = "कृषि कल्याण एवं किसान विकास विभाग, मध्य प्रदेश शासन",
      level = "Central",
      category = SchemeCategory.AGRICULTURE_LIVELIHOOD,
      eligibilityCriteriaHindi = listOf(
        "कृषक के पास कृषि भूमि स्वामित्व (ऋण पुस्तिका/खसरा) अथवा वैध वनाधिकार पट्टा (FRA Title) हो",
        "मध्य प्रदेश के अधिसूचित बैंक शाखा क्षेत्र का निवासी हो",
        "प्राकृतिक आपदा (अतिवृष्टि, पाला, कीट-प्रकोप) से फसल नुकसान होने पर 72 घंटे में सूचना दी गई हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Owner cultivator or valid FRA forest titleholder",
        "Resident in operational area of cooperative or commercial bank",
        "Crop loss report within 72 hours of localized calamity"
      ),
      whoCanApplyHindi = "समस्त किसान, वन पट्टाधारी एवं बटाईदार कृषक",
      whoCanApplyEnglish = "All farmers, FRA titleholders, and tenant cultivators",
      benefitsHindi = listOf(
        "समय पर भुगतान पर मात्र 4% प्रभावी वार्षिक ब्याज दर पर ₹3 लाख तक का KCC ऋण",
        "खरीफ फसलों हेतु मात्र 2% एवं रबी फसलों हेतु मात्र 1.5% किसान प्रीमियम अंशदान",
        "बाढ़, सूखा, कीट हमले या ओलावृष्टि पर सीधे बैंक खाते में शत-प्रतिशत क्षतिपूर्ति दावा"
      ),
      benefitsEnglish = listOf(
        "KCC crop loan up to ₹3 Lakhs at subsidized 4% interest rate",
        "Only 2% farmer premium for Kharif and 1.5% for Rabi crops",
        "Direct claim settlement to bank account for natural calamity damage"
      ),
      requiredDocumentsHindi = listOf(
        "खसरा-खतौनी / B-1 की नकल अथवा वनाधिकार पट्टा",
        "आधार कार्ड व समग्र आईडी",
        "बैंक पासबुक व 2 पासपोर्ट साइज फोटो",
        "बोई गई फसल का पटवारी बुवाई प्रमाण पत्र"
      ),
      requiredDocumentsEnglish = listOf(
        "Khasra/B-1 revenue copy or FRA Title Deed",
        "Aadhaar Card and Samagra ID",
        "Bank Passbook & 2 photos",
        "Sowing certificate from Patwari"
      ),
      applicationProcedureHindi = "नजदीकी प्राथमिक कृषि साख सहकारी समिति (पैक्स/सोसाइटी) अथवा बैंक शाखा में KCC आवेदन प्रस्तुत करें। फसल बीमा बैंक द्वारा स्वतः काटा जाता है।",
      applicationProcedureEnglish = "Submit KCC application to PACS/Cooperative Bank branch. Insurance is debited by lending bank.",
      onlineApplicationLink = "https://pmfby.gov.in",
      offlineApplicationLocation = "ग्राम सेवा सहकारी समिति (सोसाइटी) / राष्ट्रीयकृत या सहकारी बैंक शाखा",
      trackingMethod = "PMFBY पोर्टल या Crop Insurance मोबाइल ऐप पर पॉलिसी नंबर डालकर क्लेम देखें।",
      grievanceRedressal = "किसान कॉल सेंटर 1800-180-1551, उपसंचालक कृषि एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://pmfby.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Case Manager",
      targetAudiences = listOf("Farmers", "Tribal", "PVTG")
    ),

    GovernmentScheme(
      id = "sch-social-pension-mp",
      nameHindi = "मध्य प्रदेश सामाजिक सुरक्षा वृद्धावस्था व कल्याणी (विधवा) पेंशन योजना",
      nameEnglish = "MP Social Security Old Age & Kalyani (Widow) Pension Scheme",
      objectiveHindi = "60 वर्ष से अधिक आयु के वृद्धजनों एवं निराश्रित विधवा/कल्याणी माताओं-बहनों को ₹600 प्रतिमाह की नियमित सामाजिक पेंशन संबल प्रदान करना।",
      objectiveEnglish = "Monthly pension of ₹600 credited directly to bank accounts of senior citizens aged 60+ and destitute widow/kalyani women.",
      responsibleDepartment = "सामाजिक न्याय एवं दिव्यांगजन सशक्तिकरण विभाग, म.प्र. शासन",
      level = "State (MP)",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का मूल निवासी हो",
        "वृद्धावस्था पेंशन हेतु आयु 60 वर्ष या उससे अधिक हो",
        "कल्याणी पेंशन हेतु 18 वर्ष से अधिक आयु की विधवा/परित्यक्ता महिला हो",
        "परिवार गरीबी रेखा (BPL) सर्वेक्षण सूची में दर्ज हो अथवा आयकरदाता न हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Domicile of Madhya Pradesh",
        "Age 60 years or above for Old Age Pension",
        "Widow/destitute woman aged 18+ for Kalyani Pension",
        "Listed in BPL database or non-taxpayer"
      ),
      whoCanApplyHindi = "60 वर्ष से अधिक आयु के वृद्धजन एवं विधवा/कल्याणी महिलाएं",
      whoCanApplyEnglish = "Elderly citizens 60+ and widow women",
      benefitsHindi = listOf(
        "₹600 प्रतिमाह सीधे आधार लिंक बैंक खाते में नियमित भुगतान",
        "बीपीएल राशन, आयुष्मान भारत कार्ड एवं निःशुल्क स्वास्थ्य सुरक्षा की पात्रता"
      ),
      benefitsEnglish = listOf(
        "₹600 per month credited directly via DBT to bank account",
        "Eligibility for BPL food grains and Ayushman Bharat cover"
      ),
      requiredDocumentsHindi = listOf(
        "आयु प्रमाण पत्र (मतदाता परिचय पत्र / आधार कार्ड / अंकसूची)",
        "पति का मृत्यु प्रमाण पत्र (कल्याणी पेंशन हेतु)",
        "समग्र सदस्य आईडी व परिवार आईडी",
        "आधार कार्ड (e-KYC पूर्ण)",
        "बैंक पासबुक (आधार NPCI सक्रिय)"
      ),
      requiredDocumentsEnglish = listOf(
        "Age proof (Voter ID / Aadhaar)",
        "Husband death certificate (for Kalyani Pension)",
        "Samagra Member and Family ID",
        "Aadhaar Card",
        "Bank Passbook (NPCI Seeded)"
      ),
      applicationProcedureHindi = "लोक सेवा केंद्र (MP e-District) अथवा ग्राम पंचायत सचिव के माध्यम से आवेदन करें। अनुविभागीय अधिकारी (SDO) राजस्व द्वारा 15 दिवस में पेंशन स्वीकृत की जाती है।",
      applicationProcedureEnglish = "Apply via Lok Seva Kendra or Gram Panchayat. Sanctioned within 15 days by SDO Revenue.",
      onlineApplicationLink = "https://socialjustice.mp.gov.in",
      offlineApplicationLocation = "लोक सेवा केंद्र / ग्राम पंचायत कार्यालय / जनपद पंचायत सामाजिक सुरक्षा प्रकोष्ठ",
      trackingMethod = "समग्र सामाजिक सुरक्षा पेंशन पोर्टल पर सदस्य आईडी दर्ज कर भुगतान स्थिति देखें।",
      grievanceRedressal = "उपसंचालक सामाजिक न्याय, अनुविभागीय अधिकारी (SDO) एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://socialjustice.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Researcher",
      targetAudiences = listOf("Senior Citizens", "Women", "Tribal", "PVTG")
    ),

    GovernmentScheme(
      id = "sch-bal-aashirwad",
      nameHindi = "मुख्यमंत्री बाल आशीर्वाद एवं मिशन वात्सल्य बाल सुरक्षा योजना",
      nameEnglish = "Mukhyamantri Bal Aashirwad & Mission Vatsalya Scheme",
      objectiveHindi = "माता-पिता विहीन अनाथ बच्चों अथवा संकटग्रस्त परिवारों के बच्चों को 18 वर्ष की आयु तक ₹4,000 प्रतिमाह वित्तीय सहायता व उच्च शिक्षा में संपूर्ण फीस सहयोग।",
      objectiveEnglish = "Sponsorship of ₹4,000 per month and higher education support for orphan and highly vulnerable children until age 18.",
      responsibleDepartment = "महिला एवं बाल विकास विभाग (WCD), मध्य प्रदेश शासन",
      level = "State (MP)",
      category = SchemeCategory.WOMEN_CHILD,
      eligibilityCriteriaHindi = listOf(
        "ऐसे बच्चे जिनके माता-पिता दोनों की मृत्यु हो चुकी हो और वे किसी रिश्तेदार/संरक्षक के साथ रह रहे हों",
        "अथवा जिनके माता-पिता गंभीर असाध्य रोग या कारावास में हों",
        "बच्चे की आयु 18 वर्ष से कम हो तथा वह नियमित रूप से विद्यालय/आंगनवाड़ी में पंजीकृत हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Children who have lost both parents and live with extended family",
        "Or parents suffering from terminal illness or in custody",
        "Child below 18 years and regularly enrolled in school/Anganwadi"
      ),
      whoCanApplyHindi = "अनाथ अथवा संकटग्रस्त बच्चों के अभिभावक / संरक्षक",
      whoCanApplyEnglish = "Guardians of orphan or vulnerable children",
      benefitsHindi = listOf(
        "₹4,000 प्रतिमाह सीधे बच्चे अथवा संरक्षक के संयुक्त बैंक खाते में",
        "18 वर्ष पूर्ण होने पर आईटीआई, पॉलिटेक्निक या उच्च शिक्षा में शत-प्रतिशत निःशुल्क शिक्षण व स्टाइपेंड",
        "आयुष्मान भारत योजना अंतर्गत निःशुल्क स्वास्थ्य सुरक्षा"
      ),
      benefitsEnglish = listOf(
        "₹4,000 per month transferred directly to child/guardian joint account",
        "Free vocational/higher education and stipend after 18 years",
        "Free health coverage under Ayushman Bharat"
      ),
      requiredDocumentsHindi = listOf(
        "माता-पिता का मृत्यु प्रमाण पत्र",
        "बच्चे का जन्म प्रमाण पत्र / स्कूल दाखिला प्रमाण",
        "संरक्षक व बच्चे का आधार कार्ड",
        "समग्र आईडी व संयुक्त बैंक खाता पासबुक",
        "बाल कल्याण समिति (CWC) का अनुशंसा आदेश"
      ),
      requiredDocumentsEnglish = listOf(
        "Death certificate of parents",
        "Birth certificate / school enrollment record",
        "Aadhaar of child and guardian",
        "Samagra ID and joint bank passbook",
        "Child Welfare Committee (CWC) order"
      ),
      applicationProcedureHindi = "जिला बाल संरक्षण इकाई (DCPU) अथवा बाल कल्याण समिति (CWC) कार्यालय में आवेदन प्रस्तुत करें। जांच उपरांत जिला कलेक्टर द्वारा स्वीकृति जारी की जाती है।",
      applicationProcedureEnglish = "Submit application to District Child Protection Unit (DCPU) or Child Welfare Committee (CWC).",
      onlineApplicationLink = "https://mpwcdmis.gov.in",
      offlineApplicationLocation = "कार्यालय जिला कार्यक्रम अधिकारी (WCD) / जिला बाल संरक्षण इकाई (DCPU)",
      trackingMethod = "DCPU कार्यालय अथवा बाल कल्याण समिति से प्रकरण स्वीकृति क्रमांक की स्थिति देखें।",
      grievanceRedressal = "बाल हेल्पलाइन 1098, जिला कलेक्टर एवं CM हेल्पलाइन 181.",
      officialSourceUrl = "https://mpwcdmis.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "डॉ. आनंद वर्मा",
      verifierRole = "JHS Research Director",
      targetAudiences = listOf("Children", "Women", "Students", "Tribal")
    )
  )

  val masterLearningGuides: List<LearningGuide> = listOf(
    LearningGuide(
      id = "lg-master-pvtg",
      titleHindi = "आदिवासी एवं PVTG विशेष योजनाएँ मार्गदर्शिका (भाग 1 से 4)",
      titleEnglish = "Particularly Vulnerable Tribal Groups (PVTG) Schemes Master Guide (Parts 1-4)",
      category = "PVTG विशेष कल्याण",
      summaryHindi = "मध्य प्रदेश के 3 PVTG (सहरिया, बैगा, भारिया), PM-JANMAN के 11 हस्तक्षेप, DAJGUA के 25 हस्तक्षेप, आहार अनुदान (₹1,500/माह), बस्ती विकास व दुधारू पशु प्रदाय योजना (90% अनुदान)।",
      fullContentHindi = """
        1. मध्य प्रदेश में PVTG समुदायों की पहचान:
        • ST और PVTG में अंतर: PVTG अनुसूचित जनजातियों के भीतर वे समूह हैं जो अत्यधिक पिछड़े व सामाजिक-आर्थिक रूप से संवेदनशील माने गए हैं।
        • मध्य प्रदेश के 3 PVTG समुदाय:
          - सहरिया (Sahariya): श्योपुर, शिवपुरी, गुना, ग्वालियर, मुरैना, भिंड, दतिया, अशोकनगर आदि।
          - बैगा (Baiga): डिंडोरी, मंडला, बालाघाट, उमरिया, शहडोल, अनूपपुर आदि।
          - भारिया (Bharia): विशेषकर छिंदवाड़ा जिले का पातालकोट क्षेत्र।

        2. योजना 1 — PM-JANMAN (प्रधानमंत्री जनजाति आदिवासी न्याय महा अभियान):
        • 15 नवंबर 2023 से शुरू, 9 केंद्रीय मंत्रालयों के 11 प्रमुख हस्तक्षेप।
        • मुख्य सुविधाएं: पक्का आवास, सुरक्षित पेयजल, सड़क संपर्क, घरेलू बिजली/सोलर, मोबाइल टावर, स्वास्थ्य-पोषण, आंगनवाड़ी, छात्रावास, आजीविका व बहुउद्देशीय केंद्र।
        • आवास में विशेष छूट: PMAY-G के सामान्य अपात्रता नियमों में PVTG परिवारों हेतु ढील दी गई है।

        3. योजना 2 — धरती आबा जनजातीय ग्राम उत्कर्ष अभियान (DAJGUA):
        • 2 अक्टूबर 2024 से शुरू, 5 वर्षों में देश के 63,843 जनजातीय बहुल गाँवों में 17 मंत्रालयों के 25 हस्तक्षेप।
        • चयन मानदंड: गाँव की आबादी में कम से कम 50% ST निवासी हों।

        4. योजना 4 — आहार अनुदान योजना (मध्य प्रदेश शासन):
        • सहरिया, बैगा, भारिया परिवारों में कुपोषण उन्मूलन हेतु महिला मुखिया के बैंक खाते में ₹1,500 प्रतिमाह DBT सहायता।
        • अलग से आवेदन आवश्यक नहीं, विभागीय सर्वेक्षण व समग्र आधार मैपिंग से सत्यापन।

        5. योजना 9 — मुख्यमंत्री दुधारू पशु प्रदाय कार्यक्रम:
        • 90% सरकारी अनुदान, केवल 10% हितग्राही अंशदान। प्रति पात्र परिवार 2 देशी दुधारू गाय (7+ ली/दिन) या मुर्रा भैंस (8+ ली/दिन)।
      """.trimIndent(),
      keyTakeaways = listOf(
        "मध्य प्रदेश में केवल 3 समुदाय PVTG हैं: सहरिया, बैगा और भारिया",
        "PM-JANMAN आवास में सामान्य PMAY-G की कुछ अपात्रता शर्तों में छूट प्राप्त है",
        "आहार अनुदान में महिला मुखिया के खाते में प्रतिमाह ₹1,500 की पोषण सहायता मिलती है",
        "दुधारू पशु प्रदाय में 90% सरकारी अनुदान और केवल 10% हितग्राही अंशदान है"
      ),
      simplifiedGlossary = mapOf(
        "PVTG" to "विशेष रूप से कमजोर जनजातीय समूह (Particularly Vulnerable Tribal Groups)",
        "PM-JANMAN" to "पीएम जनजाति आदिवासी न्याय महा अभियान (11 बुनियादी सुविधाओं का मिशन)",
        "DAJGUA" to "धरती आबा जनजातीय ग्राम उत्कर्ष अभियान (25 हस्तक्षेपों का ग्राम विकास मिशन)",
        "DBT" to "प्रत्यक्ष लाभ अंतरण (सीधे बैंक खाते में आधार लिंक राशि जमा होना)"
      )
    ),

    LearningGuide(
      id = "lg-master-housing-infra",
      titleHindi = "आवास, बिजली, पानी, शौचालय और बुनियादी सुविधाएँ (भाग 5)",
      titleEnglish = "Housing, Electricity, Water, Sanitation and Infrastructure Guide (Part 5)",
      category = "आवास व बुनियादी ढाँचा",
      summaryHindi = "PM-JANMAN ग्रामीण आवास, PMAY-G (₹1.20 लाख), स्वच्छ भारत मिशन शौचालय (₹12,000), जल जीवन मिशन हर घर नल व बस्ती विद्युतीकरण के नियम।",
      fullContentHindi = """
        1. PM-JANMAN आवास योजना — ग्रामीण:
        • सहरिया, बैगा व भारिया परिवारों हेतु विशेष आवास घटक।
        • यदि परिवार का कच्चा मकान है और सर्वेक्षण सूची में नाम है, तो ग्राम पंचायत व जनपद नोडल अधिकारी से स्वीकृति आदेश प्राप्त करें।

        2. प्रधानमंत्री आवास योजना — ग्रामीण (PMAY-G):
        • बेघर या कच्चे/जर्जर मकान में रहने वाले ग्रामीण परिवारों को मैदानी क्षेत्रों में ₹1.20 लाख की इकाई सहायता (किस्तों में)।
        • साथ में शौचालय निर्माण व 90-95 मानव दिवस की मनरेगा अकुशल मजदूरी अभिसरण का लाभ।

        3. स्वच्छ भारत मिशन — ग्रामीण (SBM-G):
        • व्यक्तिगत घरेलू शौचालय (IHHL) निर्माण हेतु ₹12,000 की प्रोत्साहन राशि।
        • निर्माण उपरांत जियो-टैगिंग के आधार पर भुगतान सीधे बैंक खाते में।

        4. जल जीवन मिशन (हर घर जल):
        • ग्रामीण घरों तक नल से नियमित व सुरक्षित पेयजल की आपूर्ति।
        • शिकायत में केवल कनेक्शन नहीं, बल्कि पानी की आपूर्ति नियमितता व गुणवत्ता भी दर्ज कराएं।
      """.trimIndent(),
      keyTakeaways = listOf(
        "PMAY-G में मैदानी क्षेत्रों में ₹1.20 लाख की आवास सहायता देय है",
        "शौचालय निर्माण (SBM-G) हेतु ₹12,000 की प्रोत्साहन राशि मिलती है",
        "सूची में नाम जुड़वाने या आवास स्वीकृति के नाम पर किसी बिचौलिए को कोई पैसा न दें",
        "ग्राम सभा में SECC और Awaas+ सूची की लिखित प्रति मांगें"
      ),
      simplifiedGlossary = mapOf(
        "PMAY-G" to "प्रधानमंत्री आवास योजना ग्रामीण (पक्का मकान निर्माण सहायता)",
        "IHHL" to "व्यक्तिगत घरेलू शौचालय (Individual Household Latrine)",
        "Jal Jeevan" to "हर घर नल जल आपूर्ति मिशन",
        "Geo-tagging" to "निर्माण कार्य के स्थल की जीपीएस फोटो खींचकर सरकारी पोर्टल पर दर्ज करना"
      )
    ),

    LearningGuide(
      id = "lg-master-livelihood",
      titleHindi = "रोजगार, मनरेगा, कौशल विकास और आजीविका योजनाएँ (भाग 6)",
      titleEnglish = "Employment, MGNREGA, Skill Development & Livelihood Guide (Part 6)",
      category = "रोजगार व आजीविका",
      summaryHindi = "मनरेगा 100 दिन रोजगार अधिकार व मस्टर रोल, राष्ट्रीय ग्रामीण आजीविका मिशन (DAY-NRLM), PMJVM व वन धन केंद्र, और मुख्यमंत्री सीखो-कमाओ योजना।",
      fullContentHindi = """
        1. महात्मा गांधी नरेगा (MGNREGA):
        • प्रत्येक ग्रामीण परिवार को वित्तीय वर्ष में 100 दिन के अकुशल शारीरिक श्रम का विधिक अधिकार।
        • जॉब कार्ड निःशुल्क बनता है। काम की लिखित मांग करने पर 15 दिन में काम न मिलने पर बेरोजगारी भत्ता देय होता है।
        • 15 कार्य दिवसों में मजदूरी का भुगतान बैंक/डाकघर खाते में सीधे होना कानूनी रूप से अनिवार्य है।

        2. राष्ट्रीय ग्रामीण आजीविका मिशन (DAY-NRLM):
        • 10-15 ग्रामीण महिलाओं का स्वयं सहायता समूह (SHG)। नियमित बचत, रिवॉल्विंग फंड (RF), कम्युनिटी इन्वेस्टमेंट फंड (CIF) व बैंक लिंकेज से लघु उद्योग।

        3. PMJVM एवं वन धन विकास केंद्र (TRIFED):
        • महुआ, चिरौंजी, तेन्दूपत्ता, शहद, लाख आदि का संग्रहण, ग्रेडिंग, प्रसंस्करण व विपणन।
        • 300 सदस्यीय केंद्र हेतु ₹15 लाख तक का केंद्रीय अनुदान और MSP खरीद गारंटी।

        4. मुख्यमंत्री सीखो-कमाओ योजना (MMSKY):
        • 18 से 29 वर्ष के युवाओं को उद्योग में कार्य अनुभव और ₹8,000 से ₹10,000 प्रतिमाह स्टाइपेंड।
      """.trimIndent(),
      keyTakeaways = listOf(
        "मनरेगा में काम मांगना कानूनी अधिकार है, आवेदन की पावती अवश्य लें",
        "मजदूरी भुगतान 15 दिनों में न होने पर धारा 27 अंतर्गत विलंब मुआवजा देय होता है",
        "महिलाएं SHG बनाकर कम ब्याज पर आजीविका ऋण प्राप्त कर सकती हैं",
        "लघु वनोपज को सीधे बेचने की बजाय वन धन केंद्र के जरिए प्रसंस्करण करने से अधिक आय होती है"
      ),
      simplifiedGlossary = mapOf(
        "Muster Roll" to "काम पर उपस्थिति का दैनिक सरकारी रजिस्टर",
        "SHG" to "स्वयं सहायता समूह (Self Help Group)",
        "VDSHG" to "वन धन स्वयं सहायता समूह",
        "Stipend" to "प्रशिक्षण के दौरान प्रतिमाह मिलने वाला निर्वाह भत्ता"
      )
    ),

    LearningGuide(
      id = "lg-master-fra-pesa-health",
      titleHindi = "किसान, वनाधिकार (FRA), पेसा (PESA) व स्वास्थ्य-सिकल सेल (भाग 7 से 8)",
      titleEnglish = "Farmers, Forest Rights (FRA), PESA & Health-Sickle Cell Guide (Parts 7-8)",
      category = "विधिक अधिकार व स्वास्थ्य",
      summaryHindi = "FRA 2006 (व्यक्तिगत व सामुदायिक वनाधिकार), पेसा कानून 1996 में ग्राम सभा की शक्तियां, PM-KISAN (₹6,000), फसल बीमा, आयुष्मान भारत (₹5 लाख) व सिकल सेल उन्मूलन मिशन।",
      fullContentHindi = """
        1. वन अधिकार अधिनियम, 2006 (FRA):
        • व्यक्तिगत वन अधिकार (IFR): 13 दिसंबर 2005 से पूर्व काबिज वनभूमि पर अधिकतम 4 हेक्टेयर (लगभग 10 एकड़) तक स्थायी पट्टा।
        • पट्टा पति-पत्नी के संयुक्त नाम जारी होता है और अहस्तांतरणीय (Non-transferable) है।
        • धारा 4(5): दावा प्रक्रिया पूरी होने तक किसी भी काबिज परिवार की बेदखली पूर्णतः गैरकानूनी है।

        2. पेसा कानून, 1996 (PESA):
        • अनुसूचित क्षेत्रों (Scheduled Areas) में ग्राम सभा को सामुदायिक संसाधनों, लघु वनोपज, विकास योजनाओं व स्थानीय विवाद समाधान की सर्वोच्च शक्ति।

        3. किसान योजनाएँ:
        • PM-KISAN: ₹6,000 वार्षिक (₹2,000 की 3 किस्तें), e-KYC अनिवार्य।
        • PM फसल बीमा (PMFBY): प्राकृतिक आपदा में नुकसान भरपाई हेतु 72 घंटे में सूचना दें।
        • KCC: खेती व पशुपालन हेतु रियायती बैंक साख।

        4. स्वास्थ्य व सिकल सेल उन्मूलन मिशन:
        • आयुष्मान भारत: प्रति परिवार प्रति वर्ष ₹5 लाख तक का कैशलेस इलाज।
        • सिकल सेल मिशन: आदिवासियों में खून के आनुवंशिक विकार की निःशुल्क जांच, काउंसलिंग व डिजिटल रंग-कोडित कार्ड।
        • मध्य प्रदेश सामाजिक सुरक्षा पेंशन: वृद्ध, कल्याणी (विधवा) व दिव्यांगजनों को मासिक पेंशन।
      """.trimIndent(),
      keyTakeaways = listOf(
        "FRA 2006 की कट-ऑफ तारीख 13 दिसंबर 2005 है",
        "दावा लंबित रहने तक वन विभाग किसी को बेदखल नहीं कर सकता (धारा 4(5))",
        "आयुष्मान कार्ड में ₹5 लाख का स्वास्थ्य कवर पूरे परिवार का साझा होता है",
        "सिकल सेल जांच करवाकर अपना डिजिटल कार्ड अवश्य बनवाएं"
      ),
      simplifiedGlossary = mapOf(
        "IFR" to "व्यक्तिगत वन अधिकार (Individual Forest Rights)",
        "CFR" to "सामुदायिक वन संसाधन अधिकार (Community Forest Resource Rights)",
        "PESA" to "पंचायत उपबंध (अनुसूचित क्षेत्रों पर विस्तार) अधिनियम, 1996",
        "Sickle Cell" to "आनुवंशिक रक्त विकार जिसमें लाल रक्त कण हंसिए के आकार के हो जाते हैं"
      )
    ),

    LearningGuide(
      id = "lg-master-docs-fees-redressal",
      titleHindi = "16 अनिवार्य दस्तावेज़, सरकारी फीस नियम, CM 181 व RTI (भाग 11 से 16)",
      titleEnglish = "16 Essential Documents, Official Fee Rules, CM 181, RTI & Portals (Parts 11-16)",
      category = "दस्तावेज व कानूनी मदद",
      summaryHindi = "आधार, समग्र, जाति, निवास, आय, वन पट्टा; सरकारी शुल्क बनाम कियोस्क बनाम अवैध वसूली का अंतर; CM हेल्पलाइन 181, RTI, DLSA 15100 व 32 सरकारी पोर्टल डायरेक्टरी।",
      fullContentHindi = """
        1. परिवार के 16 महत्वपूर्ण दस्तावेज़:
        • आधार कार्ड (DBT व पहचान)
        • समग्र परिवार आईडी व सदस्य आईडी (मध्य प्रदेश की योजनाओं की रीढ़)
        • स्थायी डिजिटल जाति (ST) प्रमाण पत्र
        • निवास प्रमाण पत्र व आय प्रमाण पत्र
        • बैंक पासबुक (Aadhaar NPCI मैपर से सक्रिय)
        • राशन कार्ड, जॉब कार्ड, किसान खसरा-खतौनी, वनाधिकार पट्टा
        • जन्म व मृत्यु प्रमाण पत्र, दिव्यांगता UDID कार्ड।

        2. सरकारी फीस के नियम (सावधानी):
        • सरकारी शुल्क: कानून द्वारा निर्धारित (जैसे सामान्य आधार नामांकन निःशुल्क, जाति/आय/निवास सामान्यतः निःशुल्क या ₹10-₹30)।
        • सेवा केंद्र शुल्क: लोक सेवा केंद्र/कियोस्क का निर्धारित शुल्क (हमेशा पक्की कंप्यूटराइज्ड रसीद लें)।
        • अवैध वसूली: किसी कर्मचारी या दलाल द्वारा बिना रसीद पैसा मांगना गैरकानूनी है। भुगतान न करें, 181 पर शिकायत करें।

        3. शिकायत, RTI और कानूनी सहायता:
        • CM हेल्पलाइन 181: किसी भी विभाग में आवेदन लंबित होने या योजना लाभ न मिलने पर 181 पर कॉल कर शिकायत दर्ज करें।
        • सूचना का अधिकार (RTI Act 2005): पात्रता सूची, अस्वीकृति का कारण व मस्टर रोल की प्रमाणित प्रति प्राप्त करें।
        • मुफ्त विधिक सहायता (DLSA / NALSA 15100): अनुसूचित जनजाति के प्रत्येक नागरिक को न्यायालय व अपील में मुफ्त वकील का अधिकार प्राप्त है।
      """.trimIndent(),
      keyTakeaways = listOf(
        "बैंक खाते में आधार NPCI सीडिंग होना सरकारी DBT के लिए अनिवार्य है",
        "किसी भी ऑनलाइन सेवा केंद्र पर भुगतान के बदले हमेशा पक्की रसीद मांगें",
        "योजना का लाभ न मिलने पर CM हेल्पलाइन 181 पर शिकायत दर्ज कराएं",
        "अनुसूचित जनजाति के नागरिकों को DLSA (15100) से पूरी तरह मुफ्त वकील मिलता है"
      ),
      simplifiedGlossary = mapOf(
        "Samagra ID" to "मध्य प्रदेश शासन की परिवार व सदस्य पहचान संख्या (9 अंक सदस्य, 8 अंक परिवार)",
        "NPCI Mapping" to "बैंक खाते को राष्ट्रीय भुगतान निगम से आधार DBT हेतु जोड़ना",
        "DLSA" to "जिला विधिक सेवा प्राधिकरण (District Legal Services Authority)",
        "RTI" to "सूचना का अधिकार अधिनियम, 2005"
      )
    )
  )
}

