package com.example.data

import com.example.model.GovernmentScheme
import com.example.model.SchemeCategory
import com.example.model.SchemeStatus

object SchemesSeedData {
  val schemes: List<GovernmentScheme> = listOf(
    // 1. TRIBAL WELFARE: FRA Patta Development & Van Dhan
    GovernmentScheme(
      id = "sch-fra-mp",
      nameHindi = "वनाधिकार पट्टा धारक विकास योजना (मध्य प्रदेश)",
      nameEnglish = "Forest Rights Act (FRA) Titleholder Development Scheme",
      objectiveHindi = "वनाधिकार कानून, 2006 के तहत प्राप्त वन भूमि पट्टों पर कुआँ, सिंचाई, भूमि समतलीकरण व कृषि विकास हेतु शत-प्रतिशत सरकारी अनुदान।",
      objectiveEnglish = "100% government assistance for irrigation, wells, land leveling, and crop enhancement on land allocated under FRA 2006.",
      responsibleDepartment = "जनजातीय कार्य विभाग, मध्य प्रदेश शासन (Tribal Affairs Dept, MP)",
      level = "State (MP)",
      category = SchemeCategory.TRIBAL_WELFARE,
      eligibilityCriteriaHindi = listOf(
        "आवेदक अनुसूचित जनजाति (ST) अथवा 75 वर्षीय पारंपरिक वन निवासी (OTFD) हो",
        "ग्राम सभा व जिला स्तरीय समिति (DLC) द्वारा वैध वनाधिकार पट्टा (Form A / Form B) प्राप्त हो",
        "मध्य प्रदेश के अधिसूचित अथवा वनाच्छादित जिलों में भूमि धारक हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Scheduled Tribe (ST) or 75-year Other Traditional Forest Dweller (OTFD)",
        "Must hold valid FRA Title Deed issued by Gram Sabha & DLC",
        "Resident in MP forest districts"
      ),
      whoCanApplyHindi = "समस्त वनाधिकार पट्टा धारक परिवार (विशेषकर सहरिया, बैगा, भारिया पीवीटीजी परिवार)",
      whoCanApplyEnglish = "All FRA Titleholders with priority to PVTG families",
      benefitsHindi = listOf(
        "कपिलधारा योजना अंतर्गत निःशुल्क कूप (कुआँ) निर्माण (₹3,00,000 तक)",
        "खेत समतलीकरण व मेढ़ बंधान (मनरेगा अभिसरण द्वारा)",
        "निःशुल्क सोलर कृषि पंप अथवा विद्युत कनेक्शन",
        "किसान क्रेडिट कार्ड (KCC) व उन्नत बीज-खाद किट"
      ),
      benefitsEnglish = listOf(
        "Free farm well construction up to ₹3,00,000",
        "Land leveling and field bunding under MGNREGA convergence",
        "Free Solar irrigation pump",
        "Kisan Credit Card (KCC) and high-yield seeds"
      ),
      requiredDocumentsHindi = listOf(
        "वनाधिकार पट्टा (Title Deed) की प्रमाणित प्रति",
        "भू-स्वामित्व का B-1 खसरा नक्शा",
        "जाति प्रमाण पत्र",
        "आधार कार्ड व समग्र आईडी",
        "बैंक पासबुक (आधार NPCI लिंक)"
      ),
      requiredDocumentsEnglish = listOf(
        "Certified copy of FRA Title Deed",
        "B-1 Khasra map of allocated land",
        "Caste Certificate",
        "Aadhaar and Samagra ID",
        "NPCI-seeded Bank Passbook"
      ),
      applicationProcedureHindi = "ग्राम पंचायत अथवा जनपद पंचायत के मुख्य कार्यपालन अधिकारी (CEO Janpad) को आवेदन प्रस्तुत करें। सहायक आयुक्त जनजातीय कार्य विभाग द्वारा स्वीकृति उपरांत कार्य आदेश जारी होता है।",
      applicationProcedureEnglish = "Submit application to CEO Janpad Panchayat or Assistant Commissioner Tribal Affairs.",
      onlineApplicationLink = "https://tribal.mp.gov.in/MPVanMitra",
      offlineApplicationLocation = "जनपद पंचायत कार्यालय / ग्राम पंचायत भवन / अनुविभागीय अधिकारी (SDO) कार्यालय",
      trackingMethod = "MP VanMitra पोर्टल पर पट्टा आवेदन क्रमांक दर्ज करके स्थिति ट्रैक करें।",
      grievanceRedressal = "उपायुक्त जनजातीय कार्य विभाग अथवा जिला जनसुनवाई (प्रत्येक मंगलवार कलेक्टर कार्यालय)। हेल्पलाइन: 181",
      officialSourceUrl = "https://tribal.mp.gov.in",
      lastVerifiedDate = "28 Oct 2026",
      nextReviewDate = "28 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Senior Legal Case Manager",
      targetAudiences = listOf("Tribal", "Farmers", "PVTG")
    ),

    // 2. TRIBAL WELFARE: Sahariya Aahar Anudan Yojana
    GovernmentScheme(
      id = "sch-sahariya-aahar",
      nameHindi = "सहरिया विशेष आहार अनुदान योजना (DBT ₹1,500/माह)",
      nameEnglish = "Sahariya Nutrition Grant Scheme (Direct Benefit Transfer)",
      objectiveHindi = "अति पिछड़ी विशेष जनजाति (PVTG) सहरिया, बैगा और भारिया परिवारों में कुपोषण उन्मूलन हेतु महिला मुखिया के बैंक खाते में प्रतिमाह ₹1,500 की नकद पोषण सहायता।",
      objectiveEnglish = "Monthly nutrition financial assistance of ₹1,500 transferred directly to the female head of particularly vulnerable tribal families.",
      responsibleDepartment = "महिला एवं बाल विकास विभाग / जनजातीय कार्य विभाग, म.प्र.",
      level = "State (MP)",
      category = SchemeCategory.WOMEN_CHILD,
      eligibilityCriteriaHindi = listOf(
        "परिवार मध्य प्रदेश के सहरिया, बैगा अथवा भारिया (PVTG) समुदाय से हो",
        "श्योपुर, शिवपुरी, गुना, ग्वालियर, दतिया, मुरैना, भिंड, अशोकनगर आदि अधिसूचित जिलों का निवासी हो",
        "परिवार की महिला मुखिया के नाम बैंक खाता आधार NPCI से सक्रिय हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Must belong to Sahariya, Baiga or Bharia PVTG community",
        "Resident in Sheopur, Shivpuri, Guna, Gwalior, Ashoknagar etc.",
        "Aadhaar-seeded bank account in the name of the female head"
      ),
      whoCanApplyHindi = "सहरिया जनजाति परिवार की महिला मुखिया",
      whoCanApplyEnglish = "Female head of the Sahariya tribal family",
      benefitsHindi = listOf(
        "प्रतिमाह ₹1,500 सीधे बैंक खाते में (वार्षिक ₹18,000 पोषण अनुदान)",
        "पोषण आहार, फल, दूध, दाल आदि पौष्टिक खाद्य सामग्री क्रय हेतु स्वतंत्र अधिकार"
      ),
      benefitsEnglish = listOf(
        "₹1,500 per month credited directly via Aadhaar DBT (₹18,000 annually)",
        "Direct entitlement to buy nutritious food for the family"
      ),
      requiredDocumentsHindi = listOf(
        "सहरिया जनजाति जाति प्रमाण पत्र",
        "महिला मुखिया का आधार कार्ड",
        "समग्र परिवार आईडी (e-KYC पूर्ण)",
        "आधार लिंक बैंक पासबुक"
      ),
      requiredDocumentsEnglish = listOf(
        "Sahariya Tribe Caste Certificate",
        "Aadhaar card of female head",
        "Samagra Family ID (e-KYC verified)",
        "Bank Passbook linked with NPCI"
      ),
      applicationProcedureHindi = "निकटतम आँगनवाड़ी कार्यकर्ता अथवा बाल विकास परियोजना अधिकारी (CDPO) कार्यालय में निर्धारित प्रारूप में आवेदन जमा करें।",
      applicationProcedureEnglish = "Submit Form through local Anganwadi Worker or CDPO office.",
      onlineApplicationLink = "https://tribal.mp.gov.in/AaharAnudan",
      offlineApplicationLocation = "स्थानीय आँगनवाड़ी केंद्र / परियोजना अधिकारी (WCD) कार्यालय / ग्राम पंचायत",
      trackingMethod = "समग्र पोर्टल अथवा जनजातीय कार्य पोर्टल पर समग्र आईडी डालकर भुगतान स्थिति देखें।",
      grievanceRedressal = "CM हेल्पलाइन 181 पर शिकायत दर्ज कराएं अथवा JHS लीगल टीम से संपर्क करें।",
      officialSourceUrl = "https://mpwcdmis.gov.in",
      lastVerifiedDate = "25 Oct 2026",
      nextReviewDate = "25 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "डॉ. आनंद वर्मा",
      verifierRole = "JHS Research Director",
      targetAudiences = listOf("Women", "PVTG", "Children")
    ),

    // 3. AGRICULTURE: PM-KISAN & MP Kisan Kalyan
    GovernmentScheme(
      id = "sch-kisan-samman",
      nameHindi = "पीएम किसान सम्मान निधि + मुख्यमंत्री किसान कल्याण योजना (वार्षिक ₹12,000)",
      nameEnglish = "PM-KISAN + MP Mukhyamantri Kisan Kalyan Yojana",
      objectiveHindi = "लघु, सीमांत व वन पट्टाधारी किसानों को कृषि लागत, खाद-बीज क्रय हेतु केंद्र द्वारा ₹6,000 एवं म.प्र. शासन द्वारा ₹6,000 कुल ₹12,000 की वार्षिक आर्थिक संबलता।",
      objectiveEnglish = "Combined ₹12,000 annual income support for small and marginal farmers including FRA titleholders in Madhya Pradesh.",
      responsibleDepartment = "कृषि कल्याण एवं किसान विकास विभाग, भारत सरकार व म.प्र.",
      level = "Central",
      category = SchemeCategory.AGRICULTURE_LIVELIHOOD,
      eligibilityCriteriaHindi = listOf(
        "कृषक के नाम कृषि भूमि (अथवा वनाधिकार पट्टा) राजस्व अभिलेख में दर्ज हो",
        "ई-केवाईसी (e-KYC) व बैंक खाता आधार NPCI से मैप हो",
        "परिवार में कोई सदस्य संवैधानिक पद अथवा आयकरदाता न हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Landholding registered in revenue records or valid FRA title",
        "Active e-KYC and NPCI-mapped bank account",
        "Non-taxpayer rural farmer household"
      ),
      whoCanApplyHindi = "सभी भूमिधारक एवं वनाधिकार पट्टाधारी ग्रामीण किसान",
      whoCanApplyEnglish = "All landholding and FRA titleholder farmers",
      benefitsHindi = listOf(
        "₹2,000 की 6 समान किस्तों में ₹12,000 प्रतिवर्ष सीधे बैंक खाते में",
        "बीज व उर्वरक क्रय के लिए साहूकारों से मुक्ति"
      ),
      benefitsEnglish = listOf(
        "₹12,000 annually paid in 6 equal installments of ₹2,000",
        "Direct cash support for seeds and fertilizers"
      ),
      requiredDocumentsHindi = listOf(
        "खसरा खतौनी / B-1 की नकल (या FRA पट्टा)",
        "आधार कार्ड",
        "समग्र आईडी",
        "बैंक पासबुक व सक्रिय मोबाइल नंबर"
      ),
      requiredDocumentsEnglish = listOf(
        "Land Record Khasra copy or FRA Deed",
        "Aadhaar Card",
        "Samagra ID",
        "Bank Passbook with active mobile number"
      ),
      applicationProcedureHindi = "PM-Kisan पोर्टल अथवा स्थानीय पटवारी / सीएससी केंद्र के माध्यम से ऑनलाइन पंजीयन।",
      applicationProcedureEnglish = "Apply online via PM-Kisan portal, MP Bhulekh, or through local Patwari / CSC center.",
      onlineApplicationLink = "https://pmkisan.gov.in",
      offlineApplicationLocation = "हल्का पटवारी / तहसील कार्यालय / सीएससी कियोस्क",
      trackingMethod = "pmkisan.gov.in पर 'Know Your Status' में आधार अथवा मोबाइल नंबर दर्ज करें।",
      grievanceRedressal = "पीएम किसान हेल्पडेस्क 155261 / 011-24300606 अथवा तहसील जनसुनवाई।",
      officialSourceUrl = "https://pmkisan.gov.in",
      lastVerifiedDate = "20 Oct 2026",
      nextReviewDate = "20 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Case Manager",
      targetAudiences = listOf("Farmers", "Workers")
    ),

    // 4. EMPLOYMENT: MGNREGA 150 Days Tribal Guarantee
    GovernmentScheme(
      id = "sch-mgnrega-150",
      nameHindi = "महात्मा गांधी नरेगा (MGNREGA) जनजातीय 150 दिवस रोजगार गारंटी",
      nameEnglish = "MGNREGA 150-Day Guaranteed Wage Employment for Forest Dwellers",
      objectiveHindi = "ग्रामीण परिवारों को प्रत्येक वित्तीय वर्ष में अकुशल शारीरिक श्रम का वैधानिक गारंटीयुक्त रोजगार। अनुसूचित जनजाति एवं वनाधिकार पट्टाधारी परिवारों को 100 की जगह 150 दिवस का कार्य।",
      objectiveEnglish = "Statutory guarantee of 150 days of unskilled manual wage employment for ST and FRA titleholder households.",
      responsibleDepartment = "पंचायत एवं ग्रामीण विकास विभाग, म.प्र. शासन",
      level = "Central",
      category = SchemeCategory.EMPLOYMENT_RURAL_DEV,
      eligibilityCriteriaHindi = listOf(
        "ग्रामीण क्षेत्र का वयस्क सदस्य जो अकुशल शारीरिक श्रम हेतु इच्छुक हो",
        "ग्राम पंचायत द्वारा जारी वैध जॉब कार्ड (Job Card) धारक",
        "वनाधिकार पट्टाधारी परिवारों को 50 अतिरिक्त दिवस (कुल 150 दिवस) की पात्रता"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Adult rural resident willing to do manual labor",
        "Valid Job Card holder from Gram Panchayat",
        "FRA titleholders entitled to 150 days"
      ),
      whoCanApplyHindi = "समस्त ग्रामीण मजदूर, महिलाएँ एवं वन निवासी परिवार",
      whoCanApplyEnglish = "All rural job-card holding workers and forest dwellers",
      benefitsHindi = listOf(
        "म.प्र. अधिसूचित दैनिक मजदूरी दर ₹243+ प्रतिदिन",
        "आवेदन के 15 दिवस में कार्य न मिलने पर बेरोजगारी भत्ता पाने का विधिक अधिकार",
        "15 दिवस में मजदूरी भुगतान न होने पर धारा 27 के तहत विलंब मुआवजा (0.05% प्रतिदिन)",
        "कार्यस्थल पर पेयजल, छाया, प्राथमिक चिकित्सा व शिशु गृह सुविधा"
      ),
      benefitsEnglish = listOf(
        "Statutory daily minimum wage paid directly to bank account",
        "Unemployment allowance if work not allocated within 15 days",
        "Delay compensation under Section 27 if payment delayed beyond 15 days",
        "Creche, drinking water, and first aid at worksite"
      ),
      requiredDocumentsHindi = listOf(
        "जॉब कार्ड (Job Card)",
        "आधार कार्ड",
        "बैंक खाता पासबुक",
        "काम माँगने का लिखित आवेदन (फॉर्म 6)"
      ),
      requiredDocumentsEnglish = listOf(
        "Job Card",
        "Aadhaar Card",
        "Bank account passbook",
        "Work Application Form 6 with dated receipt"
      ),
      applicationProcedureHindi = "ग्राम रोजगार सहायक (GRS) अथवा ग्राम पंचायत सचिव को 'फॉर्म 6' में कार्य की माँग का आवेदन दें और अनिवार्य रूप से पावती (रसीद) लें।",
      applicationProcedureEnglish = "Submit work demand application (Form 6) to Gram Rozgar Sahayak and obtain signed receipt.",
      onlineApplicationLink = "https://nrega.nic.in",
      offlineApplicationLocation = "ग्राम पंचायत भवन / ग्राम रोजगार सहायक कार्यालय / जनपद पंचायत",
      trackingMethod = "nrega.nic.in पर जॉब कार्ड नंबर डालकर मस्टर रोल और भुगतान स्थिति देखें।",
      grievanceRedressal = "जनपद पंचायत कार्यक्रम अधिकारी (PO MGNREGA), जिला लोकपाल (Ombudsman नरेगा) अथवा टोल-फ्री 1913.",
      officialSourceUrl = "https://nrega.nic.in",
      lastVerifiedDate = "22 Oct 2026",
      nextReviewDate = "22 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "दिनेश भील",
      verifierRole = "Field Coordinator",
      targetAudiences = listOf("Workers", "Women", "Tribal")
    ),

    // 5. HOUSING & SOCIAL SECURITY: PM Awas Yojana (Gramin)
    GovernmentScheme(
      id = "sch-pmay-g",
      nameHindi = "प्रधानमंत्री आवास योजना (ग्रामीण) - पक्का मकान निर्माण अनुदान",
      nameEnglish = "Pradhan Mantri Awas Yojana - Gramin (PMAY-G)",
      objectiveHindi = "बेघर एवं कच्चे/जीर्ण-शीर्ण मकानों में रहने वाले ग्रामीण व जनजातीय परिवारों को 25 वर्गमीटर का पक्का मकान निर्माण हेतु ₹1,20,000 की नकद सहायता व मनरेगा मजदूरी।",
      objectiveEnglish = "Financial grant of ₹1,20,000 plus 90 days MGNREGA wages and toilet incentive to construct a permanent disaster-resilient house.",
      responsibleDepartment = "ग्रामीण विकास मंत्रालय, भारत सरकार",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "सामाजिक आर्थिक व जाति जनगणना (SECC) अथवा Awas+ सूची में पात्र परिवार",
        "परिवार के पास स्वयं का पक्का मकान न हो",
        "विशेष प्राथमिकता: PVTG सहरिया, निराश्रित, एकल महिला एवं दिव्यांग परिवार"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Listed in SECC or Awas Plus rural deprivation list",
        "Kutcha house or homeless household",
        "Priority for PVTG, single women, and persons with disabilities"
      ),
      whoCanApplyHindi = "ग्रामीण कच्चे घरों में रहने वाले निर्धन व जनजातीय परिवार",
      whoCanApplyEnglish = "Rural houseless and kutcha house families",
      benefitsHindi = listOf(
        "₹1,20,000 तीन किस्तों में मकान निर्माण हेतु",
        "90-95 दिवस की मनरेगा अकुशल मजदूरी (लगभग ₹23,000 अतिरिक्त)",
        "स्वच्छ भारत मिशन अंतर्गत ₹12,000 शौचालय निर्माण प्रोत्साहन",
        "उज्ज्वला योजना अंतर्गत निःशुल्क गैस कनेक्शन"
      ),
      benefitsEnglish = listOf(
        "₹1,20,000 direct bank grant across 3 construction milestones",
        "90 days MGNREGA wage support (approx ₹23,000)",
        "₹12,000 toilet grant under SBM",
        "Free LPG connection under Ujjwala"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड व समग्र आईडी",
        "जॉब कार्ड नंबर",
        "भूमि स्वामित्व / पट्टा / ग्राम सभा का रिहायशी प्रमाण",
        "बैंक पासबुक (आधार NPCI सक्रिय)",
        "वर्तमान कच्चे मकान का जियो-टैग्ड फोटो"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar and Samagra ID",
        "MGNREGA Job Card",
        "Land possession slip or Gram Sabha confirmation",
        "Bank Passbook",
        "Geotagged photo of existing kutcha house"
      ),
      applicationProcedureHindi = "ग्राम सभा द्वारा अनुमोदित आवास प्लस सूची के आधार पर जनपद पंचायत द्वारा स्वीकृति। ग्राम रोजगार सहायक से जियो-टैगिंग कराएं।",
      applicationProcedureEnglish = "Approved through Gram Sabha Awas Plus list. Geotagging done by Gram Rozgar Sahayak.",
      onlineApplicationLink = "https://pmayg.nic.in",
      offlineApplicationLocation = "ग्राम पंचायत / जनपद पंचायत आवास प्रकोष्ठ",
      trackingMethod = "AwaasSoft पोर्टल पर FTO ट्रैकर अथवा ग्राम पंचायत सूची में नाम देखें।",
      grievanceRedressal = "कलेक्टर जनसुनवाई / जिला पंचायत सीईओ / CM हेल्पलाइन 181.",
      officialSourceUrl = "https://pmayg.nic.in",
      lastVerifiedDate = "15 Oct 2026",
      nextReviewDate = "15 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate)",
      verifierRole = "Legal Case Manager",
      targetAudiences = listOf("Rural", "Tribal", "Women", "Senior Citizens")
    ),

    // 6. EDUCATION: Tribal Pre & Post-Matric Scholarships
    GovernmentScheme(
      id = "sch-tribal-scholarship",
      nameHindi = "जनजातीय प्री एवं पोस्ट-मैट्रिक छात्रवृत्ति व आवास सहायता योजना",
      nameEnglish = "Tribal Pre & Post-Matric Scholarship and Hostel Scheme",
      objectiveHindi = "अनुसूचित जनजाति के कक्षा 9वीं से स्नातकोत्तर एवं व्यावसायिक पाठ्यक्रमों के छात्र-छात्राओं को सम्पूर्ण शिक्षण शुल्क, छात्रवृत्ति एवं दूरस्थ अध्ययन हेतु आवास भत्ता।",
      objectiveEnglish = "Comprehensive scholarship, tuition fee waiver, and hostel accommodation allowance for tribal students from Class 9 to Postgraduation.",
      responsibleDepartment = "जनजातीय कार्य विभाग, मध्य प्रदेश शासन",
      level = "State (MP)",
      category = SchemeCategory.EDUCATION,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का मूल निवासी अनुसूचित जनजाति (ST) का विद्यार्थी",
        "माता-पिता / अभिभावक की वार्षिक आय ₹6.00 लाख से कम हो",
        "मान्यता प्राप्त विद्यालय / महाविद्यालय में नियमित अध्ययनरत हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Domicile of MP belonging to Scheduled Tribe",
        "Annual family income within ₹6.00 Lakhs",
        "Enrolled as regular student in recognized school/college"
      ),
      whoCanApplyHindi = "कक्षा 9वीं से उच्च शिक्षा में अध्ययनरत जनजातीय विद्यार्थी",
      whoCanApplyEnglish = "Tribal students studying in Class 9 onwards",
      benefitsHindi = listOf(
        "सम्पूर्ण ट्यूशन फीस व परीक्षा शुल्क की प्रतिपूर्ति",
        "पाठ्यपुस्तक, लेखन सामग्री व मासिक निर्वाह भत्ता",
        "संभागीय व जिला मुख्यालयों पर अध्ययन हेतु आवास सहायता (₹1,000 से ₹2,000 प्रतिमाह)",
        "पीवीटीजी सहरिया छात्राओं को विशेष साइकिल व प्रोत्साहन राशि"
      ),
      benefitsEnglish = listOf(
        "100% tuition and exam fee reimbursement",
        "Monthly maintenance and book allowance",
        "Housing assistance of ₹1,000 - ₹2,000/month if residing outside hostel",
        "Free bicycle and special incentive for PVTG girls"
      ),
      requiredDocumentsHindi = listOf(
        "स्थाई डिजिटल जाति प्रमाण पत्र",
        "मूल निवासी प्रमाण पत्र",
        "आय प्रमाण पत्र / स्व-घोषणा पत्र",
        "अंतिम उत्तीर्ण कक्षा की अंकसूची",
        "आधार कार्ड व बैंक पासबुक (आधार लिंक)",
        "संस्थान में प्रवेश शुल्क रसीद"
      ),
      requiredDocumentsEnglish = listOf(
        "Digital Caste Certificate",
        "Domicile Certificate",
        "Income Certificate",
        "Previous Year Marksheet",
        "Aadhaar-linked Bank Passbook",
        "Admission fee receipt"
      ),
      applicationProcedureHindi = "MP TAAS (Madhya Pradesh Tribal Affairs Automation System) पोर्टल पर ऑनलाइन पंजीयन व आवेदन प्रोफाइल तैयार करें।",
      applicationProcedureEnglish = "Register profile and apply online on MPTAAS portal.",
      onlineApplicationLink = "https://www.tribal.mp.gov.in/mptaas",
      offlineApplicationLocation = "संबंधित विद्यालय/महाविद्यालय का छात्रवृत्ति प्रकोष्ठ / सहायक आयुक्त जनजातीय कार्य",
      trackingMethod = "MPTAAS पोर्टल पर आवेदन क्रमांक दर्ज करके स्वीकृति व FTO स्थिति देखें।",
      grievanceRedressal = "जिला सहायक आयुक्त जनजातीय कार्य विभाग अथवा टोल-फ्री 1800-233-3951.",
      officialSourceUrl = "https://www.tribal.mp.gov.in/mptaas",
      lastVerifiedDate = "18 Oct 2026",
      nextReviewDate = "18 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "रामदयाल सहरिया",
      verifierRole = "Community Field Worker",
      targetAudiences = listOf("Students", "Tribal", "Children")
    ),

    // 7. HEALTH & SENIOR CITIZENS: Ayushman Bharat PM-JAY & Vaya Vandana
    GovernmentScheme(
      id = "sch-ayushman-pmjay",
      nameHindi = "आयुष्मान भारत - प्रधानमंत्री जन आरोग्य योजना (PM-JAY) व वय वंदना (70+ वरिष्ठ नागरिक)",
      nameEnglish = "Ayushman Bharat - PM Jan Arogya Yojana & Vaya Vandana Card (Free ₹5 Lakh Treatment)",
      objectiveHindi = "गरीब, बीपीएल, संबल व 70 वर्ष से अधिक आयु के प्रत्येक वरिष्ठ नागरिक को प्रतिवर्ष ₹5 लाख तक का शत-प्रतिशत निःशुल्क द्वितीयक व तृतीयक कैशलेस अस्पताल उपचार।",
      objectiveEnglish = "Free cashless hospital treatment up to ₹5 Lakhs per family per year, plus separate ₹5 Lakh top-up for every senior citizen aged 70+.",
      responsibleDepartment = "राष्ट्रीय स्वास्थ्य प्राधिकरण (NHA) एवं लोक स्वास्थ्य व चिकित्सा शिक्षा विभाग, म.प्र.",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "SECC-2011 सूची, राष्ट्रीय खाद्य सुरक्षा (NFSA) राशन कार्ड अथवा म.प्र. संबल योजना में पंजीकृत परिवार",
        "समस्त 70 वर्ष या उससे अधिक आयु के वरिष्ठ नागरिक (वय वंदना अंतर्गत बिना किसी आय सीमा के पात्र)",
        "सहरिया, बैगा एवं भारिया PVTG परिवारों के समस्त सदस्य स्वतः पूर्णतः पात्र"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Families registered under SECC-2011, NFSA Ration Card, or MP Sambal scheme",
        "All senior citizens aged 70 and above under Vaya Vandana (irrespective of income)",
        "All PVTG Sahariya, Baiga, Bharia households eligible automatically"
      ),
      whoCanApplyHindi = "समस्त बीपीएल/पात्र परिवार एवं 70 वर्ष से अधिक आयु के सभी वरिष्ठ नागरिक",
      whoCanApplyEnglish = "Eligible low-income families and all senior citizens aged 70+",
      benefitsHindi = listOf(
        "प्रति परिवार प्रतिवर्ष ₹5,00,000 तक का कैशलेस एवं पेपरलेस गंभीर बीमारियों का उपचार",
        "70 वर्ष या उससे अधिक आयु के वरिष्ठ नागरिकों के लिए पृथक ₹5 लाख का विशेष टॉप-अप कवर",
        "अस्पताल में भर्ती से 3 दिन पूर्व एवं डिस्चार्ज के 15 दिन बाद तक की दवाइयां व नैदानिक जांच निःशुल्क",
        "पूरे देश के 29,000+ किसी भी सूचीबद्ध सरकारी अथवा निजी अस्पताल में पोर्टेबिलिटी लाभ"
      ),
      benefitsEnglish = listOf(
        "Cashless hospital treatment up to ₹5 Lakhs per annum per family",
        "Dedicated ₹5 Lakh top-up cover for every senior citizen aged 70+",
        "Pre-hospitalization (3 days) and post-hospitalization (15 days) medicine/diagnostics included",
        "National portability across all empanelled public and private hospitals"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड (बायोमेट्रिक अथवा मोबाइल ओटीपी ई-केवाईसी हेतु)",
        "समग्र आईडी अथवा राशन कार्ड",
        "सक्रिय मोबाइल नंबर",
        "वरिष्ठ नागरिकों हेतु जन्म तिथि प्रमाण (आधार मान्य)"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar Card (with OTP or Biometric)",
        "Samagra Family ID / Ration Card",
        "Active mobile number",
        "Age proof (Aadhaar recognized for 70+ years)"
      ),
      applicationProcedureHindi = "beneficiary.nha.gov.in पोर्टल अथवा 'Ayushman App' पर स्वयं ई-केवाईसी करें, या नजदीकी प्राथमिक स्वास्थ्य केंद्र, जिला अस्पताल या सीएससी कियोस्क पर जाकर तुरंत निःशुल्क आयुष्मान कार्ड बनवाएं।",
      applicationProcedureEnglish = "Self e-KYC on beneficiary.nha.gov.in or Ayushman App, or visit nearest Govt Hospital / CSC for instant card generation.",
      onlineApplicationLink = "https://beneficiary.nha.gov.in",
      offlineApplicationLocation = "शासकीय अस्पताल / आयुष्मान मित्र हेल्पडेस्क / सीएससी कियोस्क",
      trackingMethod = "beneficiary.nha.gov.in पर आधार नंबर दर्ज कर कार्ड डाउनलोड करें अथवा स्थिति देखें।",
      grievanceRedressal = "राष्ट्रीय आयुष्मान टोल-फ्री 14555 / 1800-180-1104 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://nha.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Health Rights Legal Desk",
      targetAudiences = listOf("Senior Citizens", "Women", "Workers", "Rural", "Tribal", "PwD")
    ),

    // 8. WOMEN & CHILD: Mukhyamantri Ladli Behna Yojana (MP)
    GovernmentScheme(
      id = "sch-ladli-behna",
      nameHindi = "मुख्यमंत्री लाड़ली बहना योजना (मध्य प्रदेश शासन)",
      nameEnglish = "Mukhyamantri Ladli Behna Yojana (MP Direct Benefit Transfer ₹1,250/Month)",
      objectiveHindi = "मध्य प्रदेश की 21 से 60 वर्ष आयु की विवाहित, विधवा, तलाकशुदा व परित्यक्ता बहनों को आर्थिक स्वावलंबन एवं स्वास्थ्य-पोषण सुधार हेतु ₹1,250 प्रतिमाह सीधे आधार लिंक बैंक खाते में।",
      objectiveEnglish = "Direct cash assistance of ₹1,250 per month into bank accounts of women aged 21-60 to foster economic autonomy, health, and family nutrition.",
      responsibleDepartment = "महिला एवं बाल विकास विभाग, मध्य प्रदेश शासन",
      level = "State (MP)",
      category = SchemeCategory.WOMEN_CHILD,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश की स्थानीय निवासी महिला जिसकी आयु 21 से 60 वर्ष के मध्य हो",
        "विवाहित, विधवा, परित्यक्ता अथवा तलाकशुदा महिला",
        "परिवार की सम्मिलित वार्षिक आय ₹2.50 लाख से कम हो एवं परिवार आयकरदाता न हो",
        "परिवार के पास कुल 5 एकड़ (लगभग 2 हेक्टेयर) से कम कृषि भूमि हो",
        "परिवार में कोई सदस्य चार पहिया वाहन (ट्रैक्टर को छोड़कर) का स्वामी न हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Resident woman of MP aged 21 to 60 years",
        "Married, widowed, divorced, or abandoned",
        "Combined family income less than ₹2.5 Lakhs and non-taxpayer",
        "Own less than 5 acres of agricultural land",
        "No four-wheeler vehicle owned by household (excluding tractor)"
      ),
      whoCanApplyHindi = "मध्य प्रदेश की 21-60 वर्ष की विवाहित, विधवा व परित्यक्ता महिलाएं",
      whoCanApplyEnglish = "Married, widowed, and abandoned women of MP aged 21-60",
      benefitsHindi = listOf(
        "₹1,250 प्रतिमाह (वार्षिक ₹15,000) प्रत्येक माह की 10 तारीख को सीधे बैंक खाते में (DBT)",
        "गैस सिलेंडर रिफिल योजना में ₹450 में घरेलू गैस सिलेंडर प्राप्त करने की विशेष पात्रता",
        "म.प्र. राज्य ग्रामीण आजीविका मिशन के स्व-सहायता समूहों के माध्यम से सूक्ष्म उद्यम ऋण वरीयता"
      ),
      benefitsEnglish = listOf(
        "₹1,250 monthly (₹15,000 per year) credited via DBT on the 10th of every month",
        "Subsidized LPG cylinder refill at ₹450 for registered beneficiaries",
        "Priority micro-enterprise loan access via NRLM Self Help Groups"
      ),
      requiredDocumentsHindi = listOf(
        "समग्र परिवार आईडी एवं व्यक्तिगत सदस्य समग्र आईडी (e-KYC पूर्ण)",
        "आधार कार्ड (सक्रिय मोबाइल नंबर लिंक)",
        "स्वयं का एकल बैंक खाता पासबुक (आधार NPCI डायरेक्ट बेनिफिट ट्रांसफर सक्रिय)",
        "स्व-घोषणा पत्र (आय व भूमि मानक हेतु)"
      ),
      requiredDocumentsEnglish = listOf(
        "Samagra Family and Member ID (e-KYC completed)",
        "Aadhaar Card linked with active mobile",
        "Individual Bank Passbook (Aadhaar NPCI DBT enabled)",
        "Self-declaration for income and landholding"
      ),
      applicationProcedureHindi = "ग्राम पंचायत भवन / वार्ड कार्यालय अथवा विशेष शिविर में सचिव/जीआरएस द्वारा पोर्टल पर ऑनलाइन प्रविष्टि। फोटो व बायोमेट्रिक मिलान उपरांत निःशुल्क पावती रसीद प्राप्त करें।",
      applicationProcedureEnglish = "Apply at Gram Panchayat / Ward camp through Secretary / GRS. Obtain free printed receipt after biometric authentication.",
      onlineApplicationLink = "https://cmladlibehna.mp.gov.in",
      offlineApplicationLocation = "ग्राम पंचायत कार्यालय / आंगनवाड़ी केंद्र / वार्ड कार्यालय / जनपद पंचायत",
      trackingMethod = "cmladlibehna.mp.gov.in पर समग्र आईडी अथवा आवेदन क्रमांक दर्ज करके भुगतान एवं स्थिति देखें।",
      grievanceRedressal = "महिला एवं बाल विकास हेल्पडेस्क 0755-2700800 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://cmladlibehna.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "State Legal Coordinator",
      targetAudiences = listOf("Women", "Rural", "Tribal", "Workers")
    ),

    // 9. ENERGY & HEALTH: Pradhan Mantri Ujjwala Yojana 2.0
    GovernmentScheme(
      id = "sch-pm-ujjwala",
      nameHindi = "प्रधानमंत्री उज्ज्वला योजना 2.0 - निःशुल्क घरेलू एलपीजी गैस कनेक्शन",
      nameEnglish = "Pradhan Mantri Ujjwala Yojana 2.0 (PMUY Free LPG Connection & ₹450 Refill)",
      objectiveHindi = "ग्रामीण व निर्धन परिवारों की महिलाओं को रसोई के विषैले धुएं से मुक्ति दिलाने हेतु निःशुल्क गैस चूल्हा, भरा हुआ सिलेंडर एवं रेग्युलेटर उपलब्ध कराना तथा ₹450 में सिलेंडर रिफिल अनुदान।",
      objectiveEnglish = "Free LPG gas connection with stove and first refill to rural women, with subsidized refills at ₹450 in MP.",
      responsibleDepartment = "पेट्रोलियम एवं प्राकृतिक गैस मंत्रालय, भारत सरकार",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "आवेदक केवल 18 वर्ष या उससे अधिक आयु की महिला होनी चाहिए",
        "परिवार के किसी भी सदस्य के नाम पर पहले से कोई एलपीजी गैस कनेक्शन न हो",
        "अनुसूचित जाति (SC), अनुसूचित जनजाति (ST), प्रधानमंत्री आवास (PMAY), अंत्योदय या 14-सूत्रीय बीपीएल घोषणा में शामिल परिवार"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Applicant must be an adult woman (18+ years)",
        "No existing LPG connection in the entire household",
        "Belonging to SC, ST, PMAY, Antyodaya, or 14-point BPL declaration"
      ),
      whoCanApplyHindi = "निर्धन ग्रामीण परिवारों की वयस्क महिलाएँ",
      whoCanApplyEnglish = "Adult women of rural low-income families",
      benefitsHindi = listOf(
        "शून्य धरोहर राशि (₹0 सिक्योरिटी) पर नया घरेलू एलपीजी कनेक्शन (14.2 किग्रा सिलेंडर व रेग्युलेटर)",
        "प्रथम भरा हुआ गैस सिलेंडर एवं दो बर्नर वाला गैस चूल्हा (हॉटप्लेट) 100% निःशुल्क",
        "मध्य प्रदेश शासन द्वारा लाड़ली बहना व उज्ज्वला हितग्राहियों को ₹450 में एलपीजी रिफिल सब्सिडी",
        "सुरक्षा नली (सुरक्षा होज) एवं उपभोक्ता पासबुक निःशुल्क"
      ),
      benefitsEnglish = listOf(
        "Free LPG connection with zero security deposit (14.2 kg cylinder & regulator)",
        "First filled cylinder and standard 2-burner gas stove 100% free",
        "State subsidy providing LPG refills at ₹450 per cylinder in MP",
        "Safety hose pipe and passbook provided free of charge"
      ),
      requiredDocumentsHindi = listOf(
        "आवेदक महिला एवं परिवार के सभी वयस्क सदस्यों का आधार कार्ड",
        "राशन कार्ड / समग्र परिवार आईडी",
        "बैंक पासबुक (आधार NPCI सक्रिय)",
        "निवास प्रमाण पत्र अथवा 14-सूत्रीय बीपीएल स्व-घोषणा पत्र"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar cards of applicant and all adult family members",
        "Ration Card or Samagra Family ID",
        "Bank Passbook (NPCI seeded)",
        "Address proof or 14-point declaration"
      ),
      applicationProcedureHindi = "निकटतम एलपीजी गैस वितरक एजेंसी (इंडेन, भारत गैस या एचपी) अथवा सीएससी कियोस्क पर फॉर्म भरकर जमा करें या pmuy.gov.in पर ऑनलाइन आवेदन करें।",
      applicationProcedureEnglish = "Submit application to nearest Indane / Bharat Gas / HP Gas distributor or CSC, or apply online at pmuy.gov.in.",
      onlineApplicationLink = "https://pmuy.gov.in",
      offlineApplicationLocation = "स्थानीय गैस वितरक एजेंसी / सीएससी केंद्र / ग्राम पंचायत शिविर",
      trackingMethod = "pmuy.gov.in पर आवेदन संदर्भ संख्या से स्थिति ट्रैक करें।",
      grievanceRedressal = "उज्ज्वला टोल-फ्री हेल्पलाइन 1800-266-6696 / 1906 (आपातकालीन) अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://pmuy.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "दिनेश भील (Field Coordinator)",
      verifierRole = "Field Rights Coordinator",
      targetAudiences = listOf("Women", "Rural", "Tribal")
    ),

    // 10. DISABILITY & SOCIAL SECURITY: UDID & Divyang Pension
    GovernmentScheme(
      id = "sch-udid-divyang",
      nameHindi = "विशिष्ट दिव्यांगता पहचान पत्र (UDID) एवं दिव्यांग पेंशन व सहायक उपकरण योजना",
      nameEnglish = "Unique Disability ID (UDID) Card & Divyang Pension / Assistive Aids Scheme",
      objectiveHindi = "दिव्यांगजनों को एक राष्ट्र एक पहचान (UDID स्मार्ट कार्ड) प्रदान कर ₹600 से ₹1,000 प्रतिमाह पेंशन, कृत्रिम अंग/सहायक उपकरण (मोटराइज्ड ट्राइसाइकिल, श्रवण यंत्र) एवं निःशुल्क यात्रा सुविधा।",
      objectiveEnglish = "National Unique Disability ID (UDID) smart card, monthly disability pension of ₹600-₹1,000, free assistive aids, and free public transport pass.",
      responsibleDepartment = "दिव्यांगजन सशक्तिकरण विभाग, भारत सरकार एवं सामाजिक न्याय विभाग, म.प्र.",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का मूल निवासी जिसके पास 40% या अधिक दिव्यांगता हो",
        "जिला मेडिकल बोर्ड द्वारा विधिवत परीक्षण एवं प्रमाणीकरण",
        "पेंशन हेतु: गरीबी रेखा (BPL) परिवार अथवा परिवार आयकरदाता न हो",
        "सहायक उपकरण हेतु: पारिवारिक मासिक आय ₹22,500 से कम हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "MP resident with certified benchmark disability of 40% or more",
        "Certified by District Medical Board",
        "Pension: BPL status or non-taxpayer household",
        "Assistive aids: Monthly family income below ₹22,500"
      ),
      whoCanApplyHindi = "40% या अधिक दिव्यांगता वाले समस्त नागरिक एवं बच्चे",
      whoCanApplyEnglish = "Persons with certified benchmark disability of 40% and above",
      benefitsHindi = listOf(
        "राष्ट्रीय स्तर पर मान्य विशिष्ट दिव्यांगता पहचान (UDID) स्मार्ट कार्ड",
        "40% या अधिक दिव्यांगता पर ₹600 प्रतिमाह (बहुदिव्यांगता/मानसिक मंदता पर ₹1,000 प्रतिमाह) पेंशन",
        "एलिम्को (ALIMCO) शिविरों के माध्यम से मोटराइज्ड ट्राइसाइकिल, व्हीलचेयर, कैलिपर्स, श्रवण यंत्र शत-प्रतिशत निःशुल्क",
        "राज्य सड़क परिवहन निगम की बसों में 100% निःशुल्क यात्रा पास एवं रेलवे टिकट में रियायत"
      ),
      benefitsEnglish = listOf(
        "Nationally accepted digital UDID smart card with QR code",
        "Monthly pension of ₹600 (₹1,000 for severe multiple disabilities)",
        "Free motorized tricycles, wheelchairs, hearing aids, and calipers via ALIMCO camps",
        "Free bus travel pass and concessional railway pass"
      ),
      requiredDocumentsHindi = listOf(
        "जिला मेडिकल बोर्ड द्वारा जारी दिव्यांगता प्रमाण पत्र",
        "आधार कार्ड व समग्र सदस्य आईडी",
        "पासपोर्ट साइज रंगीन फोटो (दिव्यांगता स्पष्ट दर्शाती हुई)",
        "बैंक पासबुक (आधार लिंक) व मूल निवास प्रमाण पत्र"
      ),
      requiredDocumentsEnglish = listOf(
        "Disability Medical Certificate from District Medical Board",
        "Aadhaar Card and Samagra Member ID",
        "Color passport photograph showing disability",
        "Aadhaar-linked Bank Passbook and Domicile proof"
      ),
      applicationProcedureHindi = "swavlambancard.gov.in पोर्टल पर ऑनलाइन पंजीयन करें। जिला अस्पताल के मेडिकल बोर्ड के समक्ष उपस्थित होकर सत्यापन कराएं। पेंशन हेतु सामाजिक न्याय विभाग या समग्र पोर्टल पर आवेदन करें।",
      applicationProcedureEnglish = "Register on swavlambancard.gov.in. Verify before District Medical Board. Apply for pension via Samagra or Social Justice Portal.",
      onlineApplicationLink = "https://www.swavlambancard.gov.in",
      offlineApplicationLocation = "जिला अस्पताल (मेडिकल बोर्ड) / उप संचालक सामाजिक न्याय एवं दिव्यांगजन कल्याण कार्यालय / जनपद पंचायत",
      trackingMethod = "swavlambancard.gov.in पर आवेदन संख्या या आधार नंबर डालकर कार्ड व पेंशन स्थिति देखें।",
      grievanceRedressal = "दिव्यांगजन राष्ट्रीय हेल्पलाइन 1800-180-5125 / सामाजिक न्याय संचालनालय अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://socialjustice.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Legal Researcher",
      targetAudiences = listOf("Workers", "Senior Citizens", "Rural", "Tribal", "PwD")
    ),

    // 11. WOMEN & NUTRITION: Pradhan Mantri Matru Vandana Yojana (PMMVY)
    GovernmentScheme(
      id = "sch-pmmvy",
      nameHindi = "प्रधानमंत्री मातृ वंदना योजना (PMMVY) - मातृत्व पोषण व नकद सहायता",
      nameEnglish = "Pradhan Mantri Matru Vandana Yojana (PMMVY Maternity Benefit ₹5,000/₹6,000)",
      objectiveHindi = "गर्भवती व धात्री माताओं को गर्भावस्था और प्रसव के दौरान मजदूरी के नुकसान की भरपाई तथा उत्तम पोषण हेतु ₹5,000 (प्रथम संतान) तथा ₹6,000 (द्वितीय संतान बालिका होने पर) की नकद प्रोत्साहन राशि।",
      objectiveEnglish = "Maternity benefit grant of ₹5,000 for first child and ₹6,000 for second girl child to compensate wage loss and ensure adequate nutrition.",
      responsibleDepartment = "महिला एवं बाल विकास मंत्रालय, भारत सरकार",
      level = "Central",
      category = SchemeCategory.WOMEN_CHILD,
      eligibilityCriteriaHindi = listOf(
        "गर्भवती महिला एवं स्तनपान कराने वाली माताएं (आयु 19 वर्ष या अधिक)",
        "नियमित सरकारी अथवा सार्वजनिक उपक्रम (PSU) की कर्मचारी न हों",
        "बीपीएल/ई-श्रम कार्डधारक, मनरेगा 100 दिन मजदूर, दिव्यांग महिला, पीएम किसान लाभार्थी अथवा ₹8 लाख से कम वार्षिक आय वाले परिवार"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Pregnant and lactating mothers aged 19 years and above",
        "Not regular employees of Central/State Govt or PSUs",
        "Belonging to BPL, e-Shram, MGNREGA 100 days, PwD, PM-Kisan, or income under ₹8 Lakhs"
      ),
      whoCanApplyHindi = "गर्भवती व धात्री माताएं (प्रथम संतान व द्वितीय बालिका)",
      whoCanApplyEnglish = "Pregnant and lactating mothers (1st child & 2nd girl child)",
      benefitsHindi = listOf(
        "प्रथम जीवित संतान के जन्म पर ₹5,000 दो किस्तों में (पंजीयन व प्रसव पूर्व जांच पर ₹3,000 तथा शिशु जन्म व प्रथम टीकाकरण पर ₹2,000)",
        "द्वितीय संतान बालिका (बेटी) होने पर एकमुश्त ₹6,000 का विशेष प्रोत्साहन अनुदान",
        "संस्थागत प्रसव को बढ़ावा एवं जननी सुरक्षा योजना (₹1,400 ग्रामीण) का दोहरा लाभ"
      ),
      benefitsEnglish = listOf(
        "₹5,000 in two installments for first child (₹3,000 on ANC, ₹2,000 on childbirth & immunization)",
        "₹6,000 lump-sum incentive on birth of second girl child",
        "Combined with Janani Suraksha Yojana (₹1,400 in rural areas)"
      ),
      requiredDocumentsHindi = listOf(
        "माता-पिता (पति-पत्नी) दोनों का आधार कार्ड",
        "मातृ एवं शिशु सुरक्षा (MCP) कार्ड (आंगनवाड़ी से प्रदत्त)",
        "माता का स्वयं का एकल बैंक खाता पासबुक (आधार NPCI सक्रिय)",
        "शिशु का जन्म प्रमाण पत्र (द्वितीय किस्त हेतु)"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar cards of mother and husband",
        "Mother and Child Protection (MCP) card",
        "Mother's individual bank passbook (NPCI seeded)",
        "Child birth certificate (for second installment)"
      ),
      applicationProcedureHindi = "गर्भावस्था की पुष्टि होते ही निकटतम आंगनवाड़ी केंद्र में एएनएम या आशा कार्यकर्ता के माध्यम से pmmvy.wcd.gov.in पर फॉर्म 1A/1B भरें।",
      applicationProcedureEnglish = "Register at nearest Anganwadi centre through ASHA/ANM worker on pmmvy.wcd.gov.in portal.",
      onlineApplicationLink = "https://pmmvy.wcd.gov.in",
      offlineApplicationLocation = "स्थानीय आंगनवाड़ी केंद्र / प्राथमिक स्वास्थ्य केंद्र (PHC) / परियोजना अधिकारी महिला एवं बाल विकास",
      trackingMethod = "pmmvy.wcd.gov.in पर लाभार्थी आधार नंबर से स्थिति ट्रैक करें।",
      grievanceRedressal = "राष्ट्रीय टोल-फ्री 1098 / महिला हेल्पलाइन 181 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://wcd.nic.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Legal Researcher",
      targetAudiences = listOf("Women", "Rural", "Tribal")
    ),

    // 12. AGRICULTURE: PM KUSUM Component B (Solar Water Pump 90% Subsidy)
    GovernmentScheme(
      id = "sch-pm-kusum",
      nameHindi = "प्रधानमंत्री कुसुम योजना (PM-KUSUM B) - 90% अनुदानित सोलर कृषि सिंचाई पंप",
      nameEnglish = "PM-KUSUM Component B (Solar Agriculture Water Pump 90% Subsidy)",
      objectiveHindi = "डीजल पंपों पर निर्भरता समाप्त कर किसानों को दिन में सुनिश्चित व मुफ्त सिंचाई सुविधा उपलब्ध कराने हेतु 3HP, 5HP और 7.5HP सौर ऊर्जा कृषि पंपों पर 90% तक सरकारी अनुदान।",
      objectiveEnglish = "Free daytime irrigation for farmers by providing up to 90% government subsidy on 3HP, 5HP, and 7.5HP standalone solar agriculture pumps.",
      responsibleDepartment = "नवीन एवं नवीकरणीय ऊर्जा मंत्रालय, भारत सरकार एवं म.प्र. ऊर्जा विकास निगम",
      level = "Central",
      category = SchemeCategory.AGRICULTURE_LIVELIHOOD,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का किसान जिसके पास कृषि योग्य भूमि एवं वैध जल स्रोत (कुआं, बोरवेल, नदी, तालाब) उपलब्ध हो",
        "संबंधित खसरे पर पूर्व से कोई विद्युत पंप कनेक्शन कार्यरत न हो",
        "विशेष प्राथमिकता: लघु-सीमांत किसान, वनाधिकार पट्टाधारी (FRA) एवं अनुसूचित जनजाति (ST) कृषक"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Farmer with cultivable land and verified surface/groundwater source",
        "No existing grid-connected electric pump on the surveyed khasra",
        "High priority for small/marginal farmers, FRA patta holders, and ST farmers"
      ),
      whoCanApplyHindi = "समस्त किसान जिनके पास सिंचाई हेतु जल स्रोत है (विशेषतः आदिवासी व लघु किसान)",
      whoCanApplyEnglish = "Farmers with verifiable water source (priority ST & smallholders)",
      benefitsHindi = listOf(
        "सोलर पंप पर 60% केंद्र व राज्य अनुदान + अनुसूचित जनजाति हेतु विशेष अतिरिक्त राज्य अंशदान (किसान का अंश मात्र 10%)",
        "डीजल पंप की भारी लागत (₹50,000+ प्रतिवर्ष) से पूर्ण मुक्ति",
        "25 वर्ष तक सोलर पैनलों से निःशुल्क बिजली एवं 5 वर्ष की संपूर्ण ऑन-साइट वारंटी व बीमा",
        "सूखाग्रस्त क्षेत्रों में भी दिन के समय निरंतर 6-8 घंटे सिंचाई"
      ),
      benefitsEnglish = listOf(
        "Up to 90% subsidy for ST and marginal farmers (farmer share only 10%)",
        "Complete freedom from high recurring diesel costs",
        "25-year solar module performance warranty and 5-year comprehensive maintenance & insurance",
        "Reliable daytime irrigation for 6 to 8 hours daily"
      ),
      requiredDocumentsHindi = listOf(
        "खसरा/खतौनी (B-1) एवं भू-नक्शा प्रति",
        "आधार कार्ड व समग्र परिवार आईडी",
        "जाति प्रमाण पत्र (SC/ST किसानों के लिए)",
        "बैंक पासबुक एवं जल स्रोत (कुआं/बोरवेल) की पुष्टि का स्व-प्रमाणन"
      ),
      requiredDocumentsEnglish = listOf(
        "Land Record Khasra B-1 and land map",
        "Aadhaar Card and Samagra ID",
        "Caste Certificate (for SC/ST subsidy benefits)",
        "Bank Passbook and water source self-certification"
      ),
      applicationProcedureHindi = "mpurja.com अथवा pmkusum.mnre.gov.in पर ऑनलाइन पंजीयन करें। निर्धारित किसान अंश की ड्राफ्ट/ऑनलाइन रसीद जमा करने पर एमपी ऊर्जा विकास निगम द्वारा सोलर पंप स्थापित किया जाता है।",
      applicationProcedureEnglish = "Register on mpurja.com or pmkusum.mnre.gov.in. Deposit farmer share to receive installation through MP Urja Vikas Nigam.",
      onlineApplicationLink = "https://mpurja.com",
      offlineApplicationLocation = "जिला ऊर्जा विकास निगम कार्यालय / उप संचालक कृषि कार्यालय / सीएससी कियोस्क",
      trackingMethod = "mpurja.com पर पंजीकृत मोबाइल नंबर व आवेदन क्रमांक से स्थापना स्थिति ट्रैक करें।",
      grievanceRedressal = "म.प्र. ऊर्जा विकास निगम 0755-2553595 / 2553596 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://mnre.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "रामदयाल सहरिया (Field Worker)",
      verifierRole = "Agricultural Rights Worker",
      targetAudiences = listOf("Farmers", "Tribal", "Rural", "Workers")
    ),

    // 13. EMPLOYMENT: Mukhyamantri Udyam Kranti Yojana (MP)
    GovernmentScheme(
      id = "sch-udyam-kranti",
      nameHindi = "मुख्यमंत्री उद्यम क्रांति योजना (म.प्र.) - स्वरोजगार ऋण व 3% ब्याज अनुदान",
      nameEnglish = "Mukhyamantri Udyam Kranti Yojana (MP ₹1-50 Lakh Self-Employment Loan & 3% Interest Subsidy)",
      objectiveHindi = "प्रदेश के 12वीं उत्तीर्ण युवाओं को विनिर्माण (मैन्युफैक्चरिंग) इकाई हेतु ₹1 लाख से ₹50 लाख तथा सेवा/व्यवसाय हेतु ₹1 लाख से ₹25 लाख तक बैंक ऋण, 3% ब्याज अनुदान व बिना किसी बंधक (कोलेटरल) के क्रेडिट गारंटी।",
      objectiveEnglish = "Collateral-free self-employment bank loans from ₹1 Lakh to ₹50 Lakhs with 3% annual interest subsidy for 7 years for educated youth in MP.",
      responsibleDepartment = "सूक्ष्म, लघु और मध्यम उद्यम विभाग (MSME), मध्य प्रदेश शासन",
      level = "State (MP)",
      category = SchemeCategory.EMPLOYMENT_RURAL_DEV,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का मूल निवासी जिसकी आयु 18 से 40 वर्ष के मध्य हो",
        "न्यूनतम शैक्षणिक योग्यता 12वीं कक्षा उत्तीर्ण",
        "परिवार की वार्षिक आय ₹12 लाख से कम हो एवं किसी बैंक/वित्तीय संस्था का डिफाल्टर न हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Resident of MP aged between 18 and 40 years",
        "Minimum educational qualification: 12th standard pass",
        "Annual family income less than ₹12 Lakhs and non-defaulter"
      ),
      whoCanApplyHindi = "12वीं उत्तीर्ण शिक्षित बेरोजगार युवक एवं युवतियां",
      whoCanApplyEnglish = "Educated youth (12th pass) setting up manufacturing or service enterprises",
      benefitsHindi = listOf(
        "परियोजना लागत का 100% तक बैंक ऋण (विनिर्माण ₹50 लाख, सेवा/व्यवसाय ₹25 लाख)",
        "प्रतिवर्ष 3% की दर से अधिकतम 7 वर्षों तक निरंतर ब्याज अनुदान (Interest Subsidy)",
        "CGTMSE गारंटी शुल्क का राज्य शासन द्वारा शत-प्रतिशत भुगतान (बैंक को कोई निजी जमीन/मकान गिरवी रखने की आवश्यकता नहीं)"
      ),
      benefitsEnglish = listOf(
        "Bank loan up to ₹50 Lakhs for manufacturing and ₹25 Lakhs for service/retail",
        "3% annual interest subsidy directly credited to loan account for 7 years",
        "100% reimbursement of CGTMSE credit guarantee fee by MP Government"
      ),
      requiredDocumentsHindi = listOf(
        "12वीं कक्षा की अंकसूची / शैक्षणिक योग्यता प्रमाण",
        "आधार कार्ड, समग्र आईडी व पैन कार्ड",
        "मूल निवासी प्रमाण पत्र व जाति प्रमाण पत्र (यदि लागू हो)",
        "परियोजना प्रस्ताव (DPR / Project Report) एवं मशीनरी कोटेशन"
      ),
      requiredDocumentsEnglish = listOf(
        "12th Standard marksheet / certificate",
        "Aadhaar, Samagra ID, and PAN card",
        "Domicile certificate and Caste certificate (if applicable)",
        "Detailed Project Report (DPR) and machinery quotations"
      ),
      applicationProcedureHindi = "samast.mponline.gov.in पोर्टल पर ऑनलाइन आवेदन प्रोफाइल बनाएं। जिला व्यापार एवं उद्योग केंद्र (DTIC) की टास्क फोर्स समिति द्वारा बैंक शाखा को प्रकरण अग्रेषित किया जाता है।",
      applicationProcedureEnglish = "Submit online profile on samast.mponline.gov.in. Forwarded to banks after DTIC Taskforce scrutiny.",
      onlineApplicationLink = "https://samast.mponline.gov.in",
      offlineApplicationLocation = "जिला व्यापार एवं उद्योग केंद्र (DTIC) / महाप्रबंधक उद्योग कार्यालय",
      trackingMethod = "samast.mponline.gov.in पर आवेदन आईडी से बैंक स्वीकृति व सब्सिडी स्थिति ट्रैक करें।",
      grievanceRedressal = "उद्योग संचालनालय हेल्पलाइन 0755-6720200 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://industry.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Legal Researcher",
      targetAudiences = listOf("Workers", "Students", "Rural")
    ),

    // 14. ARTISANS & WORKERS: PM Vishwakarma Yojana
    GovernmentScheme(
      id = "sch-pm-vishwakarma",
      nameHindi = "प्रधानमंत्री विश्वकर्मा योजना - 18 पारंपरिक कारीगर व शिल्पकार संबल",
      nameEnglish = "PM Vishwakarma Scheme (Support for 18 Traditional Trades, ₹15,000 Toolkit & 5% Loan)",
      objectiveHindi = "हाथ और औजारों से कार्य करने वाले 18 पारंपरिक व्यवसायों (लोहार, बढ़ई, कुम्हार, मोची, दर्जी, राजमिस्त्री आदि) के कारीगरों को पहचान पत्र, ₹15,000 टूलकिट वाउचर, आधुनिक प्रशिक्षण व 5% ब्याज पर ₹3 लाख तक कोलेटरल-फ्री ऋण।",
      objectiveEnglish = "Holistic support for 18 traditional artisan trades with digital ID, ₹15,000 toolkit voucher, training stipend, and collateral-free loan up to ₹3 Lakhs at 5% interest.",
      responsibleDepartment = "सूक्ष्म, लघु एवं मध्यम उद्यम मंत्रालय (MSME), भारत सरकार",
      level = "Central",
      category = SchemeCategory.EMPLOYMENT_RURAL_DEV,
      eligibilityCriteriaHindi = listOf(
        "18 पारंपरिक ट्रेड (बढ़ई, नाव निर्माता, अस्त्रकार, लोहार, हथौड़ा/टूलकिट निर्माता, तालासाज, स्वर्णकार, कुम्हार, मूर्तिकार, मोची, राजमिस्त्री, डलिया/चटाई/झाड़ू निर्माता, गुड़िया/खिलौना निर्माता, नाई, मालाकार, धोबी, दर्जी, मछली जाल निर्माता) में से किसी एक में स्वरोजगाररत हो",
        "न्यूनतम आयु 18 वर्ष हो",
        "परिवार में केवल एक सदस्य को योजना का लाभ मिलेगा",
        "सरकारी सेवा में कार्यरत व्यक्ति या उसके परिजन अपात्र"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Practicing one of the 18 traditional family-based craft trades",
        "Minimum age 18 years on the date of registration",
        "Only one member per family eligible",
        "Government employees and their immediate family ineligible"
      ),
      whoCanApplyHindi = "18 पारंपरिक व्यवसायों में कार्यरत कारीगर व शिल्पकार",
      whoCanApplyEnglish = "Artisans and craftsmen engaged in 18 traditional family trades",
      benefitsHindi = listOf(
        "पीएम विश्वकर्मा डिजिटल प्रमाण पत्र एवं राष्ट्रीय पहचान पत्र",
        "5-7 दिवसीय बुनियादी कौशल प्रशिक्षण (₹500 प्रतिदिन मानदेय भत्ता)",
        "आधुनिक उन्नत औजार क्रय हेतु ₹15,000 का निःशुल्क ई-वाउचर अनुदान",
        "बिना किसी गारंटी (कोलेटरल-फ्री) के मात्र 5% रियायती ब्याज दर पर ऋण (प्रथम चरण में ₹1 लाख, सफल भुगतान पर ₹2 लाख)",
        "डिजिटल लेनदेन पर ₹1 प्रति ट्रांजैक्शन (अधिकतम 100 ट्रांजैक्शन/माह) प्रोत्साहन राशि"
      ),
      benefitsEnglish = listOf(
        "PM Vishwakarma Certificate and National ID card",
        "Basic training for 5-7 days with ₹500/day stipend",
        "₹15,000 digital e-voucher grant for modern toolkits",
        "Collateral-free enterprise loan at concessional 5% interest (Tranche 1: ₹1 Lakh, Tranche 2: ₹2 Lakhs)",
        "Digital transaction incentive up to ₹100 per month"
      ),
      requiredDocumentsHindi = listOf(
        "आधार कार्ड (सक्रिय मोबाइल नंबर लिंक)",
        "बैंक खाता पासबुक",
        "व्यवसाय संबंधी स्व-घोषणा एवं कारीगरी का प्रमाण",
        "राशन कार्ड / समग्र परिवार आईडी"
      ),
      requiredDocumentsEnglish = listOf(
        "Aadhaar Card linked to active mobile",
        "Bank account passbook",
        "Trade declaration and proof of craftsmanship",
        "Ration Card or Samagra Family ID"
      ),
      applicationProcedureHindi = "सीएससी (CSC) कियोस्क पर जाकर बायोमेट्रिक प्रमाणीकरण के साथ pmvishwakarma.gov.in पर ऑनलाइन पंजीयन कराएं। ग्राम पंचायत सचिव व जनपद द्वारा त्रि-स्तरीय सत्यापन।",
      applicationProcedureEnglish = "Register through CSC kiosk via biometric authentication on pmvishwakarma.gov.in. Scrutinized by Gram Panchayat and Janpad.",
      onlineApplicationLink = "https://pmvishwakarma.gov.in",
      offlineApplicationLocation = "सीएससी (कॉमन सर्विस सेंटर) कियोस्क / ग्राम पंचायत / जिला उद्योग केंद्र",
      trackingMethod = "pmvishwakarma.gov.in पर आधार व ओटीपी से लॉगिन कर आवेदन व प्रमाणपत्र स्थिति देखें।",
      grievanceRedressal = "राष्ट्रीय विश्वकर्मा टोल-फ्री 1800-267-7777 / 17923 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://pmvishwakarma.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Legal Researcher",
      targetAudiences = listOf("Workers", "Rural", "Tribal", "Women")
    ),

    // 15. FOOD SECURITY: NFSA Free Ration (PMGKAY)
    GovernmentScheme(
      id = "sch-nfsa-ration",
      nameHindi = "राष्ट्रीय खाद्य सुरक्षा अधिनियम (NFSA) - निःशुल्क राशन योजना (PMGKAY)",
      nameEnglish = "National Food Security Act & PMGKAY (100% Free Foodgrain 5kg/Unit)",
      objectiveHindi = "गरीब और वंचित परिवारों की खाद्य सुरक्षा सुनिश्चित करने हेतु अंत्योदय (AAY) एवं प्राथमिकता (PHH) परिवारों को पूर्णतः निःशुल्क (₹0) गेहूं, चावल एवं मोटा अनाज वितरण।",
      objectiveEnglish = "Statutory entitlement of 100% free foodgrains to priority households (5kg per person) and Antyodaya households (35kg per family).",
      responsibleDepartment = "खाद्य, नागरिक आपूर्ति एवं उपभोक्ता संरक्षण विभाग, म.प्र. शासन",
      level = "Central",
      category = SchemeCategory.HOUSING_SOCIAL_SECURITY,
      eligibilityCriteriaHindi = listOf(
        "समग्र पोर्टल पर 28 चिन्हित वंचित श्रेणियों (बीपीएल, भूमिहीन कृषि मजदूर, वनाधिकार पट्टाधारी, दिव्यांग, निराश्रित, स्ट्रीट वेंडर आदि) में पात्रता पर्ची धारक",
        "परिवार के सभी सदस्यों की ई-केवाईसी समग्र व आधार से पूर्ण हो",
        "सहरिया, बैगा, भारिया PVTG परिवारों को अंत्योदय श्रेणी का स्वतः अधिकार"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Possessing eligibility slip under 28 identified deprivation categories on Samagra",
        "Aadhaar-Samagra e-KYC completed for all family members",
        "PVTG Sahariya, Baiga, Bharia entitled automatically under AAY"
      ),
      whoCanApplyHindi = "समस्त बीपीएल, अंत्योदय, श्रमिक एवं वनाधिकार पट्टाधारक परिवार",
      whoCanApplyEnglish = "All BPL, Antyodaya, daily-wage workers, and FRA forest dwellers",
      benefitsHindi = listOf(
        "प्राथमिकता परिवार (PHH) को प्रति सदस्य प्रति माह 5 किलोग्राम खाद्यान्न 100% निःशुल्क",
        "अंत्योदय अन्न योजना (AAY) परिवारों को प्रति परिवार प्रति माह 35 किलोग्राम खाद्यान्न निःशुल्क",
        "वन नेशन वन राशन कार्ड (ONORC) के तहत देश भर में किसी भी उचित मूल्य दुकान (FPS) से राशन प्राप्त करने की पोर्टेबिलिटी",
        "बायोमेट्रिक ई-पॉस मशीन द्वारा पारदर्शी वितरण एवं पर्ची की रसीद"
      ),
      benefitsEnglish = listOf(
        "Priority Households (PHH): 5kg foodgrain per unit per month completely free",
        "Antyodaya (AAY): 35kg foodgrain per household per month completely free",
        "One Nation One Ration Card (ONORC) nationwide portability",
        "Biometric e-POS dispensing with digital printed receipt"
      ),
      requiredDocumentsHindi = listOf(
        "समग्र परिवार एवं सदस्य आईडी",
        "डिजिटल राशन कार्ड / पात्रता पर्ची (e-Ration Slip)",
        "सभी सदस्यों के आधार कार्ड (ई-केवाईसी हेतु)",
        "जाति / बीपीएल / वनाधिकार पट्टा प्रमाण पत्र"
      ),
      requiredDocumentsEnglish = listOf(
        "Samagra Family and Member ID",
        "Digital Ration Card / Eligibility Slip",
        "Aadhaar cards of all family members",
        "Category certificate (BPL / FRA / Caste)"
      ),
      applicationProcedureHindi = "ग्राम पंचायत या जनपद पंचायत में समग्र पोर्टल के माध्यम से पात्रता पर्ची हेतु आवेदन प्रस्तुत करें। अनुमोदन पश्चात उचित मूल्य दुकान (कंट्रोल की दुकान) पर बायोमेट्रिक अंगूठा लगाकर राशन प्राप्त करें।",
      applicationProcedureEnglish = "Apply through Panchayat on Samagra portal for eligibility slip. Collect foodgrains from FPS through biometric authentication.",
      onlineApplicationLink = "https://rationmitra.nic.in",
      offlineApplicationLocation = "शासकीय उचित मूल्य दुकान (FPS) / खाद्य एवं नागरिक आपूर्ति विभाग कार्यालय / ग्राम पंचायत",
      trackingMethod = "rationmitra.nic.in पर समग्र परिवार आईडी दर्ज कर पात्रता पर्ची व वितरण स्थिति देखें।",
      grievanceRedressal = "खाद्य एवं उपभोक्ता संरक्षण टोल-फ्री 1967 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://nfsa.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "रामदयाल सहरिया (Field Worker)",
      verifierRole = "Food Rights Researcher",
      targetAudiences = listOf("Rural", "Tribal", "Workers", "Senior Citizens", "Women", "PwD")
    ),

    // 16. EDUCATION: Akanksha Yojana (Free JEE/NEET/CLAT Coaching)
    GovernmentScheme(
      id = "sch-akanksha-coaching",
      nameHindi = "आकांक्षा योजना (जनजातीय कार्य विभाग, म.प्र.) - JEE, NEET, CLAT निःशुल्क कोचिंग",
      nameEnglish = "Akanksha Yojana (Free JEE/NEET/CLAT Residential Coaching for ST Students)",
      objectiveHindi = "अनुसूचित जनजाति के कक्षा 10वीं उत्तीर्ण प्रतिभावान विद्यार्थियों को राष्ट्रीय स्तर की इंजीनियरिंग (JEE), मेडिकल (NEET) एवं विधि (CLAT) प्रवेश परीक्षाओं की तैयारी हेतु भोपाल, इंदौर, जबलपुर एवं ग्वालियर में प्रतिष्ठित कोचिंग संस्थानों में शत-प्रतिशत निःशुल्क आवासीय कोचिंग।",
      objectiveEnglish = "100% free residential coaching at premier national institutes in MP for meritorious tribal students aiming for JEE, NEET, and CLAT.",
      responsibleDepartment = "जनजातीय कार्य विभाग, मध्य प्रदेश शासन",
      level = "State (MP)",
      category = SchemeCategory.EDUCATION,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का मूल निवासी अनुसूचित जनजाति (ST) का छात्र/छात्रा",
        "कक्षा 10वीं में न्यूनतम 60% अंकों के साथ उत्तीर्ण",
        "माता-पिता/अभिभावक की वार्षिक आय ₹6.00 लाख से अधिक न हो",
        "जनजातीय कार्य विभाग द्वारा आयोजित राज्य स्तरीय प्रवेश परीक्षा (Entrance Exam) में मेरिट सूची में स्थान"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Domicile of MP belonging to Scheduled Tribe (ST)",
        "Passed Class 10 with minimum 60% aggregate marks",
        "Annual family income within ₹6.00 Lakhs",
        "Qualified in the departmental state-level merit entrance exam"
      ),
      whoCanApplyHindi = "कक्षा 10वीं उत्तीर्ण प्रतिभावान जनजातीय छात्र-छात्राएं",
      whoCanApplyEnglish = "Meritorious tribal students passed Class 10",
      benefitsHindi = listOf(
        "प्रतिष्ठित राष्ट्रीय कोचिंग संस्थानों (Allen, Resonance, Career Point आदि) में 100% निःशुल्क कोचिंग",
        "निःशुल्क वातानुकूलित छात्रावास आवास एवं पौष्टिक भोजन व्यवस्था",
        "पाठ्यपुस्तकें, अध्ययन सामग्री, टेस्ट सीरीज एवं टैबलेट/लैपटॉप सहायता",
        "मासिक जेबखर्च भत्ता एवं व्यक्तिगत मेंटरशिप"
      ),
      benefitsEnglish = listOf(
        "100% tuition and coaching fee covered at premier national coaching centres",
        "Free hostel accommodation with nutritious dining facilities",
        "Free standard reference books, mock test series, and study tablets",
        "Monthly stipend and one-on-one academic mentoring"
      ),
      requiredDocumentsHindi = listOf(
        "कक्षा 10वीं की अंकसूची",
        "स्थाई डिजिटल जाति प्रमाण पत्र (ST)",
        "मूल निवासी प्रमाण पत्र व आय प्रमाण पत्र",
        "आधार कार्ड व समग्र आईडी",
        "प्रवेश परीक्षा का एडमिट कार्ड व स्कोर कार्ड"
      ),
      requiredDocumentsEnglish = listOf(
        "Class 10 marksheet",
        "Digital Caste Certificate (ST)",
        "Domicile and Income Certificate",
        "Aadhaar Card and Samagra ID",
        "Entrance exam admit card and score card"
      ),
      applicationProcedureHindi = "MPTAAS पोर्टल (tribal.mp.gov.in/mptaas) पर कक्षा 10वीं परीक्षा परिणाम उपरांत ऑनलाइन आवेदन आमंत्रित किए जाते हैं। लिखित परीक्षा में मेरिट के आधार पर कोचिंग केंद्र व बैच आवंटित होता है।",
      applicationProcedureEnglish = "Apply online via MPTAAS portal after Class 10 results. Allotted coaching centers based on departmental entrance test merit.",
      onlineApplicationLink = "https://www.tribal.mp.gov.in/mptaas",
      offlineApplicationLocation = "संभागीय उपायुक्त / सहायक आयुक्त जनजातीय कार्य विभाग कार्यालय",
      trackingMethod = "MPTAAS पोर्टल पर प्रोफाइल लॉगिन से परीक्षा परिणाम व सीट आवंटन देखें।",
      grievanceRedressal = "जनजातीय कार्य विभाग टोल-फ्री 1800-233-3951 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://www.tribal.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "Education Rights Specialist",
      targetAudiences = listOf("Students", "Tribal")
    ),

    // 17. TRIBAL LIVELIHOOD: Bhagwan Birsa Munda Swavalamban & Tantya Mama Yojana
    GovernmentScheme(
      id = "sch-birsa-munda-swavalamban",
      nameHindi = "भगवान बिरसा मुंडा स्वरोजगार योजना एवं टंट्या मामा आर्थिक कल्याण योजना",
      nameEnglish = "Bhagwan Birsa Munda Swavalamban & Tantya Mama Economic Welfare Scheme",
      objectiveHindi = "अनुसूचित जनजाति (ST) वर्ग के बेरोजगार युवाओं को विनिर्माण इकाई हेतु ₹1 लाख से ₹50 लाख एवं सेवा/व्यवसाय हेतु ₹1 लाख से ₹25 लाख तक (टंट्या मामा योजना अंतर्गत ₹10 हजार से ₹1 लाख) ऋण, 5% ब्याज अनुदान एवं ऋण गारंटी।",
      objectiveEnglish = "Enterprise loans up to ₹50 Lakhs with 5% interest subsidy and collateral guarantee for tribal youth in MP.",
      responsibleDepartment = "म.प्र. आदिवासी वित्त एवं विकास निगम (MPAVVN) व जनजातीय कार्य विभाग, म.प्र.",
      level = "State (MP)",
      category = SchemeCategory.AGRICULTURE_LIVELIHOOD,
      eligibilityCriteriaHindi = listOf(
        "मध्य प्रदेश का मूल निवासी अनुसूचित जनजाति (ST) का युवा जिसकी आयु 18 से 45 वर्ष हो",
        "शैक्षणिक योग्यता: विनिर्माण हेतु न्यूनतम 8वीं उत्तीर्ण (टंट्या मामा योजना में कोई शैक्षणिक बाध्यता नहीं)",
        "परिवार की वार्षिक आय ₹12 लाख से अधिक न हो",
        "पूर्व से किसी शासकीय स्वरोजगार योजना का ऋणी अथवा डिफाल्टर न हो"
      ),
      eligibilityCriteriaEnglish = listOf(
        "Domicile of MP belonging to ST aged 18 to 45 years",
        "Minimum 8th pass for manufacturing units (no educational criteria for Tantya Mama scheme)",
        "Annual family income within ₹12 Lakhs",
        "Non-defaulter with any financial institution"
      ),
      whoCanApplyHindi = "अनुसूचित जनजाति (ST) के शिक्षित व हुनरमंद बेरोजगार युवा",
      whoCanApplyEnglish = "Tribal youth seeking self-employment in manufacturing, service, or retail",
      benefitsHindi = listOf(
        "बैंक ऋण पर 5% प्रतिवर्ष की दर से 5 वर्षों तक नियमित ब्याज अनुदान",
        "टंट्या मामा आर्थिक कल्याण योजना अंतर्गत ₹10,000 से ₹1,00,000 तक अत्यंत सरल प्रक्रिया में कुटीर उद्योग हेतु ऋण",
        "क्रेडिट गारंटी ट्रस्ट (CGTMSE) शुल्क का शासन द्वारा 100% भुगतान (कोई कोलेटरल/बंधक संपत्ति नहीं चाहिए)",
        "विभागीय उद्यमिता विकास केंद्र (CEDMAP) द्वारा निःशुल्क कौशल व व्यवसाय प्रबंधन प्रशिक्षण"
      ),
      benefitsEnglish = listOf(
        "5% annual interest subsidy for 5 years directly credited to bank account",
        "Micro-enterprise loans from ₹10,000 to ₹1 Lakh under Tantya Mama scheme with simplified paperwork",
        "100% guarantee fee reimbursement under CGTMSE (zero collateral required)",
        "Free entrepreneurship skill development training via CEDMAP"
      ),
      requiredDocumentsHindi = listOf(
        "स्थाई डिजिटल जाति प्रमाण पत्र (ST)",
        "आधार कार्ड, समग्र आईडी व पैन कार्ड",
        "शैक्षणिक योग्यता अंकसूची (यदि लागू हो)",
        "बैंक पासबुक एवं विस्तृत प्रोजेक्ट रिपोर्ट (DPR / कोटेशन)"
      ),
      requiredDocumentsEnglish = listOf(
        "Digital ST Caste Certificate",
        "Aadhaar, Samagra ID, and PAN Card",
        "Educational qualification marksheet (if applicable)",
        "Bank Passbook and Detailed Project Report / quotation"
      ),
      applicationProcedureHindi = "samast.mponline.gov.in पोर्टल पर ऑनलाइन आवेदन भरें। मध्य प्रदेश आदिवासी वित्त एवं विकास निगम (MPAVVN) द्वारा जांच उपरांत बैंक शाखा को ऋण स्वीकृति हेतु भेजा जाता है।",
      applicationProcedureEnglish = "Apply online on samast.mponline.gov.in. Scrutinized and sponsored by MPAVVN to designated bank branches.",
      onlineApplicationLink = "https://samast.mponline.gov.in",
      offlineApplicationLocation = "जिला कार्यालय, म.प्र. आदिवासी वित्त एवं विकास निगम (MPAVVN) / सहायक आयुक्त जनजातीय कार्य",
      trackingMethod = "samast.mponline.gov.in पर आवेदन आईडी से बैंक स्वीकृति व सब्सिडी स्थिति ट्रैक करें।",
      grievanceRedressal = "आदिवासी वित्त निगम 0755-2553139 अथवा CM हेल्पलाइन 181.",
      officialSourceUrl = "https://www.tribal.mp.gov.in",
      lastVerifiedDate = "31 Oct 2026",
      nextReviewDate = "31 Jan 2027",
      status = SchemeStatus.VERIFIED_CURRENT,
      verifierName = "सुनीता शर्मा (Advocate, JHS)",
      verifierRole = "State Legal Coordinator",
      targetAudiences = listOf("Tribal", "Workers", "Rural")
    )
  ) + PvtgAndTribalMasterGuideData.newGovernmentSchemes
}
