package com.example.ai

import com.example.data.NyaySetuRepository
import com.example.data.PvtgAndTribalMasterGuideData
import com.example.data.SchemesSeedData
import com.example.model.AssistantMessage
import com.example.model.GovernmentScheme
import com.example.model.KnowledgeArticle
import com.example.model.StoryItem
import com.example.model.ApplicationTemplate
import com.example.model.UnansweredQuestionLog
import java.util.Locale

/**
 * JhsKnowledgeEngine
 * 
 * Intelligent, multilingual Retrieval-Augmented Generation (RAG) and reasoning engine
 * for Justice Hub Society's NyaySetu app.
 *
 * It parses natural language queries in Hindi, English, Bundeli, Sahariya dialects, and Hinglish,
 * searches and verifies information directly from the application's comprehensive database
 * (Schemes, Master Guide Parts 1-16, Legal Articles, 32 Portals, 16 Documents, Application Templates, Stories),
 * and generates step-by-step, actionable community guidance with official verification metadata.
 */
object JhsKnowledgeEngine {

  data class EngineResult(
    val message: AssistantMessage,
    val unansweredLog: UnansweredQuestionLog? = null
  )

  /**
   * Process a user query against the verified database
   */
  fun processQuery(rawQuery: String, preferredLang: String): EngineResult {
    val q = rawQuery.trim()
    val lowerQ = q.lowercase(Locale.ROOT)
    val detectedLang = detectLanguage(q, preferredLang)

    // 1. Check for Case Tracking intent
    if (matchesAny(lowerQ, listOf("ट्रैक", "track", "status", "स्थिति", "केस नंबर", "case id", "आवेदन की स्थिति", "शायद मिला"))) {
      return generateTrackingResponse(q, detectedLang)
    }

    // 2. Check for Direct Contact / Helpline intent
    if (matchesAny(lowerQ, listOf("हेल्पलाइन", "helpline", "फोन", "phone", "call", "नंबर", "सम्पर्क", "बात करनी", "वकील से बात", "टीम", "contact"))) {
      return generateHelplineResponse(q, detectedLang)
    }

    // 3. Search Government Schemes
    val matchedScheme = searchSchemes(lowerQ)
    if (matchedScheme != null) {
      return generateSchemeGuidance(q, matchedScheme, detectedLang)
    }

    // 4. Search Master Guide (Parts 1 - 16)
    val matchedGuideTopic = searchMasterGuide(lowerQ)
    if (matchedGuideTopic != null) {
      return generateMasterGuideGuidance(q, matchedGuideTopic, detectedLang)
    }

    // 5. Search Legal & Rights Articles (FRA, Section 170-B, PESA, Land, RTI)
    val matchedArticle = searchKnowledgeArticles(lowerQ)
    if (matchedArticle != null) {
      return generateArticleGuidance(q, matchedArticle, detectedLang)
    }

    // 6. Search 32 Portals Directory
    val matchedPortal = searchPortals(lowerQ)
    if (matchedPortal != null) {
      return generatePortalGuidance(q, matchedPortal, detectedLang)
    }

    // 7. Search Community Stories & Traditional Knowledge
    val matchedStory = searchStories(lowerQ)
    if (matchedStory != null) {
      return generateStoryGuidance(q, matchedStory, detectedLang)
    }

    // 8. Search Application Templates
    val matchedTemplate = searchTemplates(lowerQ)
    if (matchedTemplate != null) {
      return generateTemplateGuidance(q, matchedTemplate, detectedLang)
    }

    // 9. Database Gap Identified: When no verified match is found in app database
    return handleDatabaseGap(q, detectedLang)
  }

  // -------------------------------------------------------------
  // Language & Dialect Detection
  // -------------------------------------------------------------
  private fun detectLanguage(text: String, fallback: String): String {
    val lower = text.lowercase(Locale.ROOT)
    val bundeliMarkers = listOf("काहे", "कैसो", "कइसे", "लगिहें", "पइसा", "नाय आओ", "नाय मिलो", "हमाओ", "तोहार", "मोहे", "हमरे", "का कागज", "पत्ता", "जमीन")
    if (bundeliMarkers.any { lower.contains(it) }) {
      return "bundeli_sahariya"
    }

    val englishWordCount = lower.split("\\s+".toRegex()).count { word ->
      word.all { it in 'a'..'z' }
    }
    val devanagariCount = text.count { it in '\u0900'..'\u097F' }

    if (devanagariCount > text.length * 0.3) {
      return "hi"
    }
    if (englishWordCount > 2 && devanagariCount == 0) {
      return if (fallback == "hi") "en" else fallback
    }
    return fallback
  }

  private fun matchesAny(text: String, keywords: List<String>): Boolean {
    return keywords.any { text.contains(it) }
  }

  // -------------------------------------------------------------
  // Domain Search Routines
  // -------------------------------------------------------------
  private fun searchSchemes(lowerQ: String): GovernmentScheme? {
    val allSchemes = SchemesSeedData.schemes + PvtgAndTribalMasterGuideData.newGovernmentSchemes
    
    // Priority specific scheme keyword matches
    if (lowerQ.contains("आहार") || lowerQ.contains("1500") || lowerQ.contains("पोषण अनुदान")) {
      return allSchemes.firstOrNull { it.id == "pvtg-04-aahar-anudan" || it.nameHindi.contains("आहार अनुदान") }
    }
    if (lowerQ.contains("janman") || lowerQ.contains("जनमन") || lowerQ.contains("जन्मन")) {
      return allSchemes.firstOrNull { it.id == "pvtg-01-pm-janman" || it.nameHindi.contains("पीएम-जनमन") }
    }
    if (lowerQ.contains("dajgua") || lowerQ.contains("धरती आबा") || lowerQ.contains("ग्राम उत्कर्ष")) {
      return allSchemes.firstOrNull { it.id == "pvtg-02-dajgua" || it.nameHindi.contains("धरती आबा") }
    }
    if (lowerQ.contains("दुधारू") || lowerQ.contains("गाय") || lowerQ.contains("भैंस") || lowerQ.contains("पशु प्रदाय") || lowerQ.contains("मुर्रा")) {
      return allSchemes.firstOrNull { it.id == "pvtg-09-dudharu-pashu" || it.nameHindi.contains("दुधारू पशु") }
    }
    if (lowerQ.contains("सिकल सेल") || lowerQ.contains("sickle") || lowerQ.contains("खून की कमी") || lowerQ.contains("एनीमिया")) {
      return allSchemes.firstOrNull { it.id == "tribal-08-sickle-cell" || it.nameHindi.contains("सिकल सेल") }
    }
    if (lowerQ.contains("वन धन") || lowerQ.contains("van dhan") || lowerQ.contains("त्रिफेड") || lowerQ.contains("लघु वनोपज")) {
      return allSchemes.firstOrNull { it.id == "pvtg-08-van-dhan" || it.nameHindi.contains("वन धन") }
    }
    if (lowerQ.contains("आवास") || lowerQ.contains("pmay") || lowerQ.contains("मकान") || lowerQ.contains("कुटीर")) {
      return allSchemes.firstOrNull { it.id == "sch-pmayg" || it.id == "tribal-05-housing" || it.nameHindi.contains("आवास") }
    }
    if (lowerQ.contains("मनरेगा") || lowerQ.contains("mgnrega") || lowerQ.contains("मजदूरी") || lowerQ.contains("100 दिन") || lowerQ.contains("जॉब कार्ड")) {
      return allSchemes.firstOrNull { it.id == "sch-mgnrega" || it.id == "tribal-06-employment" }
    }
    if (lowerQ.contains("आयुष्मान") || lowerQ.contains("pmjay") || lowerQ.contains("5 लाख") || lowerQ.contains("इलाज")) {
      return allSchemes.firstOrNull { it.id == "sch-pmjay" }
    }
    if (lowerQ.contains("राशन") || lowerQ.contains("pds") || lowerQ.contains("अनाज") || lowerQ.contains("कोटा")) {
      return allSchemes.firstOrNull { it.id == "sch-pds-ration" }
    }

    // General scoring
    return allSchemes.maxByOrNull { scheme ->
      var score = 0
      val hName = scheme.nameHindi.lowercase(Locale.ROOT)
      val eName = scheme.nameEnglish.lowercase(Locale.ROOT)
      val obj = scheme.objectiveHindi.lowercase(Locale.ROOT)
      val dept = scheme.responsibleDepartment.lowercase(Locale.ROOT)

      lowerQ.split("\\s+".toRegex()).forEach { token ->
        if (token.length > 2) {
          if (hName.contains(token)) score += 5
          if (eName.contains(token)) score += 5
          if (obj.contains(token)) score += 2
          if (dept.contains(token)) score += 2
        }
      }
      score
    }?.takeIf { s ->
      val hName = s.nameHindi.lowercase(Locale.ROOT)
      lowerQ.split("\\s+".toRegex()).any { it.length > 2 && (hName.contains(it) || s.objectiveHindi.contains(it)) }
    }
  }

  data class MasterGuideTopicMatch(
    val title: String,
    val category: String,
    val content: String,
    val docs: List<String>,
    val steps: List<String>,
    val portal: String,
    val feeRule: String
  )

  private fun searchMasterGuide(lowerQ: String): MasterGuideTopicMatch? {
    if (lowerQ.contains("जाति प्रमाण") || lowerQ.contains("caste certificate") || lowerQ.contains("st प्रमाण") || lowerQ.contains("जाति प्रमाण पत्र")) {
      return MasterGuideTopicMatch(
        title = "डिजिटल जाति प्रमाण पत्र (ST / PVTG Certificate)",
        category = "अनिवार्य दस्तावेज़ (भाग 11)",
        content = "सहरिया, बैगा, भारिया एवं अनुसूचित जनजाति (ST) परिवारों के लिए डिजिटल जाति प्रमाण पत्र लोक सेवा केंद्र या MP e-District पोर्टल (mpedistrict.gov.in) से बनाया जाता है।\n\n• आवश्यक कागज़: 1. आवेदक व पिता का आधार कार्ड | 2. समग्र परिवार व सदस्य आईडी | 3. वर्ष 1950 या उससे पूर्व का पारिवारिक राजस्व रिकॉर्ड (मिसल बंदोबस्त, खसरा, या वंशावली) अथवा पिता/रक्त संबंधी का पहले से जारी जाति प्रमाण पत्र | 4. पासपोर्ट फोटो व स्व-घोषणा।\n• सरकारी फीस: लोक सेवा केंद्र की निर्धारित फीस ₹30 है। कानूनन जाति प्रमाण पत्र का कोई अतिरिक्त शुल्क नहीं है। बिना रसीद अतिरिक्त पैसे की मांग गैरकानूनी है।\n• कहाँ जाएँ: नजदीकी लोक सेवा केंद्र (LSK) अथवा MP e-District पोर्टल।",
        docs = listOf("आवेदक व पिता का आधार कार्ड", "समग्र परिवार एवं सदस्य आईडी", "1950 का राजस्व रिकॉर्ड / पिता का जाति प्रमाण पत्र", "पासपोर्ट फोटो व निवास प्रमाण"),
        steps = listOf("1. समग्र आईडी व आधार लिंक करवाएं।", "2. लोक सेवा केंद्र या CSC पर फॉर्म 'जाति प्रमाण पत्र' भरें।", "3. राजस्व रिकॉर्ड (मिसल/खसरा) संलग्न करें।", "4. कंप्यूटराइज्ड पावती (आवेदन क्रमांक) प्राप्त करें।", "5. 30 कार्यदिवसों में डिजिटल प्रमाण पत्र जारी होता है।"),
        portal = "https://mpedistrict.gov.in",
        feeRule = "सरकारी निर्धारित शुल्क ₹30 (रसीद सहित)। किसी भी दलाल को अतिरिक्त राशि न दें।"
      )
    }

    if (lowerQ.contains("समग्र") || lowerQ.contains("samagra") || lowerQ.contains("ईकेवाईसी") || lowerQ.contains("ekyc")) {
      return MasterGuideTopicMatch(
        title = "समग्र परिवार व सदस्य आईडी एवं e-KYC",
        category = "पहचान दस्तावेज़ (भाग 11)",
        content = "मध्य प्रदेश में प्रत्येक परिवार को 8 अंकों की समग्र परिवार आईडी तथा प्रत्येक व्यक्ति को 9 अंकों की समग्र सदस्य आईडी दी जाती है।\n\n• समग्र e-KYC: आधार से नाम, जन्मतिथि व लिंग का मिलान अनिवार्य है। आहार अनुदान, लाडली बहना, राशन व छात्रवृत्ति इसी से प्राप्त होती है।\n• कहाँ कराएं: ग्राम पंचायत सचिव, वार्ड कार्यालय, या समग्र पोर्टल (samagra.gov.in) पर स्वयं।\n• सरकारी फीस: समग्र में नाम जोड़ना एवं e-KYC शासन द्वारा निःशुल्क (Free) है। CSC कियोस्क पर अधिकतम ₹10-₹15 सेवा शुल्क मान्य है।",
        docs = listOf("आधार कार्ड (मोबाइल लिंक)", "राशन कार्ड या मुखिया का घोषणा पत्र", "पासपोर्ट फोटो"),
        steps = listOf("1. samagra.gov.in खोलें या ग्राम पंचायत सचिव के पास जाएं।", "2. 'e-KYC करें' विकल्प पर आधार नंबर दर्ज करें।", "3. बायोमेट्रिक (फिंगरप्रिंट) या मोबाइल OTP से सत्यापन करें।", "4. सचिव से अनुमोदन प्राप्त करें।"),
        portal = "https://samagra.gov.in",
        feeRule = "कानूनन निःशुल्क (Free)। कियोस्क पर अधिकतम ₹10-₹15 शुल्क।"
      )
    }

    if (lowerQ.contains("फीस") || lowerQ.contains("शुल्क") || lowerQ.contains("दलाली") || lowerQ.contains("रिश्वत") || lowerQ.contains("पैसे मांग") || lowerQ.contains("अवैध वसूली")) {
      return MasterGuideTopicMatch(
        title = "सरकारी फीस नियम एवं अवैध वसूली रोकथाम (भाग 12)",
        category = "नागरिक विधिक अधिकार",
        content = "■ सरकारी फीस के स्पष्ट नियम:\n1. सरकारी शुल्क: कानूनन निर्धारित और नियमानुसार निःशुल्क या न्यूनतम (उदा. जाति/आय ₹30, आधार नामांकन निःशुल्क)।\n2. कियोस्क सेवा शुल्क: लोक सेवा केंद्र की अधिकृत दर (हमेशा कंप्यूटराइज्ड रसीद प्राप्त करें)।\n3. अवैध वसूली (रिश्वत): किसी भी अधिकारी, पंचायत सचिव या दलाल द्वारा बिना रसीद पैसा मांगना भ्रष्टाचार निवारण अधिनियम के तहत दंडनीय अपराध है।\n\n• क्या करें: बिना रसीद एक रुपया भी न दें। तुरंत CM हेल्पलाइन 181 पर शिकायत दर्ज कराएं या JHS लीगल टीम 7440323972 पर बताएं।",
        docs = listOf("मांगे गए पैसे या अस्वीकृति का विवरण", "आवेदन पावती या रसीद यदि मिली हो"),
        steps = listOf("1. अधिकारी/कर्मचारी से अधिकृत कंप्यूटराइज्ड रसीद मांगें।", "2. मना करने पर तुरंत 181 पर डायल करें और अधिकारी का नाम दर्ज कराएं।", "3. DLSA (15100) या JHS विधिक सहायता डेस्क पर संपर्क करें।"),
        portal = "https://cmhelpline.mp.gov.in",
        feeRule = "बिना रसीद किसी को भी एक रुपया न दें। अवैध वसूली के खिलाफ 181 पर कॉल करें।"
      )
    }

    if (lowerQ.contains("181") || lowerQ.contains("शिकायत") || lowerQ.contains("complaint") || lowerQ.contains("cm helpline") || lowerQ.contains("समाधान")) {
      return MasterGuideTopicMatch(
        title = "CM हेल्पलाइन 181 शिकायत निवारण प्रणाली (भाग 14)",
        category = "शिकायत निवारण व विधिक अधिकार",
        content = "मध्य प्रदेश के किसी भी विभाग (राशन, आवास, मजदूरी, आहार अनुदान, बिजली, पानी, जमीन विवाद) में लापरवाही होने पर CM हेल्पलाइन 181 सबसे प्रभावी माध्यम है।\n\n• प्रक्रिया: 181 पर सीधे कॉल करें। अपनी समस्या, गाँव, ब्लॉक और जिले का नाम बताएं।\n• शिकायत क्रमांक: फोन पर प्राप्त शिकायत नंबर (Grievance ID) सुरक्षित रखें।\n• विधिक समय-सीमा: L-1 अधिकारी को 7 दिन में कार्यवाही करनी होती है। संतुष्ट न होने पर शिकायत स्वतः L-2, L-3 और कलेक्टर तक पहुँचती है।",
        docs = listOf("आधार नंबर", "समस्या से जुड़े पुराने आवेदन की तारीख व पावती"),
        steps = listOf("1. टोल-फ्री 181 पर कॉल करें।", "2. ऑपरेटर को पूरी समस्या और संबंधित अधिकारी का विवरण दें।", "3. SMS पर प्राप्त शिकायत क्रमांक डायरी में नोट करें।", "4. यदि समाधान न हो तो 'असंतोष' दर्ज कराएं।"),
        portal = "https://cmhelpline.mp.gov.in",
        feeRule = "टोल-फ्री कॉल: पूर्णतः निःशुल्क (₹0)"
      )
    }

    if (lowerQ.contains("वकील") || lowerQ.contains("मुफ्त कानूनी") || lowerQ.contains("dlsa") || lowerQ.contains("15100") || lowerQ.contains("न्यायालय") || lowerQ.contains("legal aid")) {
      return MasterGuideTopicMatch(
        title = "मुफ्त कानूनी सहायता (Legal Services Authorities Act - DLSA)",
        category = "संवैधानिक विधिक सहायता (भाग 14)",
        content = "विधिक सेवा प्राधिकरण अधिनियम (LSAA) 1987 की धारा 12 के अंतर्गत हर अनुसूचित जनजाति (ST) नागरिक, महिला, बच्चे एवं हिरासत में रखे व्यक्ति को जिला न्यायालय एवं उच्च न्यायालय में निःशुल्क सरकारी वकील और कानूनी सहायता पाने का वैधानिक अधिकार है।\n\n• राष्ट्रीय टोल-फ्री नंबर: 15100\n• कहाँ जाएँ: जिला न्यायालय परिसर में स्थित जिला विधिक सेवा प्राधिकरण (DLSA) कार्यालय या तालुका विधिक सेवा समिति।\n• JHS सहायता: जस्टिस हब सोसाइटी की लीगल टीम (7440323972) आपके लिए मुफ्त वकील की अर्जी तैयार करने में मदद करती है।",
        docs = listOf("ST जाति प्रमाण पत्र", "आधार कार्ड", "केस या विवाद से संबंधित कागजात"),
        steps = listOf("1. राष्ट्रीय विधिक सेवा टोल-फ्री 15100 पर कॉल करें।", "2. या जिला न्यायालय के DLSA कक्ष में जाकर आवेदन दें।", "3. शासन द्वारा पैनल अधिवक्ता नियुक्त किया जाएगा, जिसका कोई खर्च आपको नहीं देना होगा।"),
        portal = "https://nalsa.gov.in",
        feeRule = "संवैधानिक अधिकार: पूर्णतः निःशुल्क (Free Legal Aid)"
      )
    }

    if (lowerQ.contains("rti") || lowerQ.contains("सूचना का अधिकार") || lowerQ.contains("मस्टर रोल") || lowerQ.contains("रिकॉर्ड")) {
      return MasterGuideTopicMatch(
        title = "सूचना का अधिकार (RTI Act 2005) - भाग 14",
        category = "सूचना व पारदर्शिता अधिकार",
        content = "RTI कानून 2005 के तहत आप किसी भी सरकारी कार्यालय से योजनाओं की स्वीकृति सूची, खर्च का ब्यौरा, मनरेगा मस्टर रोल और अपने लंबित आवेदन की स्थिति की प्रमाणित प्रति प्राप्त कर सकते हैं।\n\n• BPL परिवारों हेतु छूट: गरीबी रेखा (BPL/अंत्योदय) राशन कार्ड धारकों को ₹10 का आवेदन शुल्क और प्रति पेज फोटोकॉपी शुल्क पूर्णतः माफ है।\n• सामान्य शुल्क: मात्र ₹10 का भारतीय पोस्टल आर्डर (IPO) या ट्रेजरी चालान।\n• समय-सीमा: लोक सूचना अधिकारी (PIO) को 30 दिन के भीतर लिखित सूचना देना अनिवार्य है।",
        docs = listOf("BPL राशन कार्ड (शुल्क छूट हेतु)", "आवेदन पत्र (Application Form)"),
        steps = listOf("1. ऐप के 'आवेदन' टैब से RTI आवेदन पत्र तैयार करें।", "2. लोक सूचना अधिकारी (ग्राम पंचायत/जनपद/कलेक्टर) को पंजीकृत डाक से भेजें।", "3. 30 दिन में उत्तर न मिलने पर प्रथम अपीलीय अधिकारी के पास अपील करें।"),
        portal = "https://rtionline.mp.gov.in",
        feeRule = "BPL परिवारों हेतु ₹0 (निःशुल्क)। सामान्य हेतु ₹10 शुल्क।"
      )
    }

    return null
  }

  private fun searchKnowledgeArticles(lowerQ: String): KnowledgeArticle? {
    val articles = NyaySetuRepository.knowledgeArticles.value
    if (lowerQ.contains("वनाधिकार") || lowerQ.contains("fra") || lowerQ.contains("पट्टा") || lowerQ.contains("forest rights")) {
      return articles.firstOrNull { it.id == "kb-01-fra" }
    }
    if (lowerQ.contains("170") || lowerQ.contains("जमीन वापसी") || lowerQ.contains("बेदखली") || lowerQ.contains("कब्जा") || lowerQ.contains("भूमि")) {
      return articles.firstOrNull { it.id == "kb-02-sec170b" }
    }
    if (lowerQ.contains("pesa") || lowerQ.contains("पेसा") || lowerQ.contains("ग्राम सभा") || lowerQ.contains("जल जंगल जमीन")) {
      return articles.firstOrNull { it.titleHindi.contains("पेसा") || it.id.contains("pesa") } ?: articles.firstOrNull()
    }
    return articles.firstOrNull { art ->
      lowerQ.split("\\s+".toRegex()).any { it.length > 2 && (art.titleHindi.contains(it) || art.summaryHindi.contains(it)) }
    }
  }

  private fun searchPortals(lowerQ: String): PvtgAndTribalMasterGuideData.PortalEntry? {
    val portals = PvtgAndTribalMasterGuideData.officialPortalsList
    return portals.firstOrNull { p ->
      val pName = p.name.lowercase(Locale.ROOT)
      val pSubject = p.subject.lowercase(Locale.ROOT)
      lowerQ.split("\\s+".toRegex()).any { token ->
        token.length > 2 && (pName.contains(token) || pSubject.contains(token))
      }
    }
  }

  private fun searchStories(lowerQ: String): StoryItem? {
    val stories = NyaySetuRepository.stories.value
    if (lowerQ.contains("कहानी") || lowerQ.contains("story") || lowerQ.contains("पारंपरिक") || lowerQ.contains("जड़ी बूटी") || lowerQ.contains("ज्ञान")) {
      return stories.firstOrNull()
    }
    return null
  }

  private fun searchTemplates(lowerQ: String): ApplicationTemplate? {
    val templates = NyaySetuRepository.applicationTemplates.value
    if (lowerQ.contains("आवेदन") || lowerQ.contains("फॉर्म") || lowerQ.contains("दरख्वास्त") || lowerQ.contains("draft")) {
      return templates.firstOrNull()
    }
    return null
  }

  // -------------------------------------------------------------
  // Response Generators with Verified Metadata
  // -------------------------------------------------------------
  private fun generateTrackingResponse(q: String, lang: String): EngineResult {
    val text = when (lang) {
      "en" -> "You can securely track your submitted grievance or application status right inside the app.\n\n1. Go to the 'Track' tab in the bottom bar.\n2. Enter your Case ID (e.g., NYAY-2026-0041) and 4-digit PIN.\n3. You will see every statutory stage: from Initial Review, Legal Assessment, Submission to Jan Sunwai, to final Resolution.\n\nFor personal follow-up, call the JHS Legal Desk at 7440323972."
      "bundeli_sahariya" -> "भैया/दीदी, आप अपने आवेदन या शिकायत की स्थिति सीधे न्यायसेतु ऐप में देख सकत हो।\n\n1. नीचे दिए गए 'स्थिति देखें' (Track) टैब पर जाइये।\n2. अपना केस नंबर (जैसे NYAY-2026-0041) और 4 अंकों को पिन डालिये।\n3. आपको सरकारी दफ्तर की पूरी प्रगति दिख जैहै।\n\nकौनो दिक्कत होवे तो JHS टीम को फोन लगाओ: 7440323972।"
      else -> "आप अपने दर्ज मामले अथवा आवेदन की अद्यतन स्थिति न्यायसेतु में सीधे ट्रैक कर सकते हैं:\n\n1. नीचे नेविगेशन में 'स्थिति देखें' (Track) टैब पर क्लिक करें।\n2. अपनी केस आईडी (उदा. NYAY-2026-0041) एवं 4-अंकों का पिन दर्ज करें।\n3. सिस्टम आपको वर्तमान विधिक चरण, अधिकारी समीक्षा व आगामी कार्यवाही का विवरण दिखाएगा।\n\nव्यक्तिगत सहायता हेतु JHS लीगल डेस्क 7440323972 पर संपर्क करें।"
    }

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = text,
        timestamp = "अभी",
        quickAction = "OPEN_TRACKER",
        sourceTitle = "NyaySetu विधिक निगरानी प्रणाली",
        sourceDepartment = "Justice Hub Society विधिक प्रकोष्ठ",
        verificationStatus = "Verified Information",
        lastVerifiedDate = "2026-10-31",
        categoryTag = "केस ट्रैकिंग",
        detectedLanguage = lang
      )
    )
  }

  private fun generateHelplineResponse(q: String, lang: String): EngineResult {
    val text = when (lang) {
      "en" -> "Justice Hub Society (JHS) provides direct telephonic legal aid and field support:\n\n• JHS Central Legal Desk: 7440323972\n• JHS Field Coordination Helpdesk: 8103056522\n• MP CM Helpline (Grievance Escalation): 181 (Toll-Free)\n• National Free Legal Aid Helpline (DLSA): 15100 (Toll-Free)\n• Childline: 1098 | Women Helpline: 181 / 1090"
      "bundeli_sahariya" -> "दीदी/भैया, आप सीधे फोन करके अपनी बात कह सकत हो:\n\n• JHS केंद्रीय विधिक डेस्क: 7440323972\n• JHS मैदानी कार्यकर्ता सहायता: 8103056522\n• सरकारी शिकायत (CM हेल्पलाइन): 181 (मुफ्त फोन)\n• सरकारी मुफ्त वकील हेल्पलाइन: 15100 (मुफ्त फोन)\n\nहमरी टीम सहरिया व ग्रामीण परिवारों की पूरी कानूनी मदद करे खातिर तैयार है।"
      else -> "जस्टिस हब सोसाइटी एवं अधिकृत सरकारी सहायता नंबर निम्न हैं:\n\n• JHS केंद्रीय विधिक डेस्क: 7440323972\n• JHS मैदानी सहायता डेस्क: 8103056522\n• म.प्र. CM हेल्पलाइन (लापरवाही व शिकायत निवारण): 181 (टोल-फ्री)\n• राष्ट्रीय विधिक सेवा प्राधिकरण (मुफ्त सरकारी वकील): 15100 (टोल-फ्री)\n• महिला सहायता: 181 / 1090 | बाल संरक्षण: 1098"
    }

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = text,
        timestamp = "अभी",
        quickAction = "CALL_HELPDESK",
        sourceTitle = "JHS विधिक सहायता निर्देशिका",
        sourceDepartment = "न्याय विभाग एवं म.प्र. शासन",
        verificationStatus = "Verified Information",
        lastVerifiedDate = "2026-10-31",
        categoryTag = "हेल्पलाइन",
        detectedLanguage = lang
      )
    )
  }

  private fun generateSchemeGuidance(q: String, scheme: GovernmentScheme, lang: String): EngineResult {
    val isBundeli = lang == "bundeli_sahariya"
    val isEn = lang == "en"

    val intro = if (isBundeli) {
      "भैया/दीदी, '${scheme.nameHindi}' की पूरी जानकारी हम आपको आसान भाषा में बता रहे हैं:\n\n■ योजना को मुख्य लाभ:\n${scheme.objectiveHindi}"
    } else if (isEn) {
      "Here is the verified information for '${scheme.nameEnglish}':\n\n■ Benefits & Purpose:\n${scheme.objectiveEnglish}"
    } else {
      "योजना '${scheme.nameHindi}' का सत्यापित विधिक विवरण निम्नलिखित है:\n\n■ मुख्य लाभ एवं उद्देश्य:\n${scheme.objectiveHindi}"
    }

    val eligibilitySection = "\n\n■ कौन पात्र है (पात्रता):\n" + (if (isEn) scheme.eligibilityCriteriaEnglish else scheme.eligibilityCriteriaHindi).joinToString("\n") { "• $it" }
    val docsSection = "\n\n■ आवश्यक दस्तावेज़:\n" + (if (isEn) scheme.requiredDocumentsEnglish else scheme.requiredDocumentsHindi).joinToString("\n") { "• $it" }
    val whereSection = "\n\n■ कहाँ और कैसे आवेदन करें:\n" + if (isEn) scheme.applicationProcedureEnglish else scheme.applicationProcedureHindi
    val feeSection = "\n\n■ सरकारी फीस नियम:\nसरकारी नियमानुसार इस योजना का आवेदन निःशुल्क (Free) है। कियोस्क पर केवल निर्धारित रसीद शुल्क देय है।"

    val fullText = "$intro$eligibilitySection$docsSection$whereSection$feeSection\n\nस्रोत: ${scheme.officialSourceUrl} (सत्यापित: ${scheme.lastVerifiedDate})"

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = fullText,
        timestamp = "अभी",
        quickAction = "OPEN_SCHEMES",
        sourceTitle = scheme.nameHindi,
        sourceDepartment = scheme.responsibleDepartment,
        verificationStatus = "Verified Information",
        lastVerifiedDate = scheme.lastVerifiedDate,
        categoryTag = scheme.category.name,
        detectedLanguage = lang,
        portalUrl = scheme.onlineApplicationLink,
        requiredDocs = scheme.requiredDocumentsHindi,
        feeInfo = "कानूनन निःशुल्क (Free)। किसी को रिश्वत या अतिरिक्त पैसा न दें।"
      )
    )
  }

  private fun generateMasterGuideGuidance(q: String, topic: MasterGuideTopicMatch, lang: String): EngineResult {
    val isBundeli = lang == "bundeli_sahariya"
    val isEn = lang == "en"

    val prefix = if (isBundeli) {
      "भैया/दीदी, '${topic.title}' के बारे में सरकारी नियम व तरीका:\n\n"
    } else if (isEn) {
      "Verified Field Guide for '${topic.title}':\n\n"
    } else {
      "📜 महा-मार्गदर्शिका सत्यापित जानकारी: '${topic.title}'\n\n"
    }

    val stepsText = "\n\n■ आवेदन व कार्यवाही के चरण:\n" + topic.steps.joinToString("\n")
    val docsText = "\n\n■ जरूरी कागज़ात:\n" + topic.docs.joinToString("\n") { "• $it" }
    val feeText = "\n\n■ फीस नियम:\n${topic.feeRule}"

    val fullText = "$prefix${topic.content}$stepsText$docsText$feeText\n\nआधिकारिक पोर्टल: ${topic.portal}"

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = fullText,
        timestamp = "अभी",
        quickAction = "OPEN_MASTER_GUIDE",
        sourceTitle = topic.title,
        sourceDepartment = "म.प्र. शासन एवं भारत सरकार अधिकृत नियम",
        verificationStatus = "Verified Information",
        lastVerifiedDate = "2026-10-31",
        categoryTag = topic.category,
        detectedLanguage = lang,
        portalUrl = topic.portal,
        stepList = topic.steps,
        requiredDocs = topic.docs,
        feeInfo = topic.feeRule
      )
    )
  }

  private fun generateArticleGuidance(q: String, article: KnowledgeArticle, lang: String): EngineResult {
    val isEn = lang == "en"
    val title = if (isEn) article.titleEnglish else article.titleHindi
    val summary = if (isEn) article.summaryEnglish else article.summaryHindi
    val content = if (isEn) article.contentEnglish else article.contentHindi

    val fullText = "⚖️ $title\n\n■ सारांश:\n$summary\n\n■ विधिक प्रावधान:\n$content\n\nस्रोत: ${article.officialSource} (सत्यापित: ${article.verificationDate})"

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = fullText,
        timestamp = "अभी",
        quickAction = "OPEN_BUILDER",
        sourceTitle = title,
        sourceDepartment = "जनजातीय कार्य विभाग एवं विधिक प्रकोष्ठ",
        verificationStatus = "Verified Information",
        lastVerifiedDate = article.verificationDate,
        categoryTag = article.category.labelHi,
        detectedLanguage = lang,
        requiredDocs = article.documentChecklistHindi
      )
    )
  }

  private fun generatePortalGuidance(q: String, portal: PvtgAndTribalMasterGuideData.PortalEntry, lang: String): EngineResult {
    val fullText = "🌐 आधिकारिक सरकारी पोर्टल: ${portal.name}\n\n■ विषय/सेवा:\n${portal.subject}\n\n■ आधिकारिक वेबसाइट लिंक:\n${portal.url}\n\nसुझाव: हमेशा आधिकारिक '.gov.in' या '.nic.in' वेबसाइट का ही प्रयोग करें। किसी निजी अनजान लिंक पर अपना आधार या ओटीपी न डालें।"

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = fullText,
        timestamp = "अभी",
        quickAction = "OPEN_PORTAL",
        sourceTitle = portal.name,
        sourceDepartment = "भारत सरकार / म.प्र. शासन पोर्टल",
        verificationStatus = "Verified Information",
        lastVerifiedDate = "2026-10-31",
        categoryTag = "सरकारी पोर्टल",
        detectedLanguage = lang,
        portalUrl = portal.url
      )
    )
  }

  private fun generateStoryGuidance(q: String, story: StoryItem, lang: String): EngineResult {
    val fullText = "📖 समुदाय की प्रेरक कहानी: ${story.titleHi}\n\nलेखक/प्रस्तुतकर्ता: ${story.authorName} (${story.village}, ${story.district})\n\n■ कहानी:\n${story.contentHi}\n\nपारंपरिक ज्ञान और सामुदायिक एकता हमारी असली ताकत है।"

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = fullText,
        timestamp = "अभी",
        quickAction = "OPEN_STORIES",
        sourceTitle = story.titleHi,
        sourceDepartment = "न्यायसेतु सामुदायिक अभिलेखागार",
        verificationStatus = "Verified Information",
        lastVerifiedDate = "2026-10-31",
        categoryTag = "पारंपरिक ज्ञान",
        detectedLanguage = lang
      )
    )
  }

  private fun generateTemplateGuidance(q: String, template: ApplicationTemplate, lang: String): EngineResult {
    val fullText = "📝 आवेदन प्रारूप: ${template.titleHindi}\n\nप्रस्तुति प्राधिकारी: ${template.recipientAuthorityHindi}\n\n■ संलग्न किए जाने वाले दस्तावेज़:\n" +
        template.requiredDocuments.joinToString("\n") { "• $it" } +
        "\n\nआप न्यायसेतु के 'आवेदन' टैब में जाकर सरल प्रश्नों के उत्तर देकर इस आवेदन का प्रिंट निकालने हेतु कानूनी ड्राफ्ट तुरंत तैयार कर सकते हैं।"

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = fullText,
        timestamp = "अभी",
        quickAction = "OPEN_BUILDER",
        sourceTitle = template.titleHindi,
        sourceDepartment = template.recipientAuthorityHindi,
        verificationStatus = "Verified Information",
        lastVerifiedDate = "2026-10-31",
        categoryTag = "आवेदन प्रारूप",
        detectedLanguage = lang,
        requiredDocs = template.requiredDocuments
      )
    )
  }

  private fun handleDatabaseGap(q: String, lang: String): EngineResult {
    val isBundeli = lang == "bundeli_sahariya"
    val isEn = lang == "en"

    val text = if (isBundeli) {
      "भैया/दीदी, आपके सवाल ('$q') के बारे में न्यायसेतु के सरकारी सत्यापित डेटाबेस में अभी पूरी जानकारी नहीं मिली है।\n\nगलत जानकारी या अफवाह से बचने के लिए, हमने इस सवाल को JHS एडमिन टीम को नोट करा दिया है।\n\nसीधे सहायता खातिर JHS टीम को फोन लगाओ: 7440323972।"
    } else if (isEn) {
      "The information for your query ('$q') is not currently available in the verified application database.\n\nTo prevent misinformation, our AI never fabricates government rules or eligibility criteria. We have logged this topic for JHS Administrators to verify and add.\n\nFor immediate assistance, please call the JHS Legal Team at 7440323972."
    } else {
      "आपके प्रश्न ('$q') से संबंधित जानकारी न्यायसेतु के वर्तमान सत्यापित डेटाबेस में उपलब्ध नहीं है।\n\nभ्रामक जानकारी से बचाने के लिए हमारा AI सहायक मनगढ़ंत नियम या फीस नहीं बनाता। हमने आपके इस प्रश्न को JHS एडमिनिस्ट्रेशन टीम को ज्ञानकोश में जोड़ने हेतु प्रेषित कर दिया है।\n\nतात्कालिक विधिक सलाह हेतु JHS हेल्पलाइन 7440323972 पर सीधे कॉल करें।"
    }

    val gapLog = UnansweredQuestionLog(
      id = "gap_${System.currentTimeMillis()}",
      query = q,
      category = "अन्वेषण प्रतीक्षित (Knowledge Gap)",
      timestamp = "31 अक्टूबर 2026",
      frequencyCount = 1,
      isResolved = false,
      suggestedAction = "शासकीय राजपत्र अथवा विभाग से नियम सत्यापित कर ज्ञानकोश में जोड़ें"
    )

    return EngineResult(
      message = AssistantMessage(
        id = "msg_${System.currentTimeMillis()}",
        isUser = false,
        text = text,
        timestamp = "अभी",
        quickAction = "CALL_HELPDESK",
        sourceTitle = "JHS ज्ञानकोश अंतराल संज्ञान",
        sourceDepartment = "Justice Hub Society विधिक प्रकोष्ठ",
        verificationStatus = "Information Not Available",
        lastVerifiedDate = "2026-10-31",
        categoryTag = "डेटाबेस अंतराल",
        detectedLanguage = lang
      ),
      unansweredLog = gapLog
    )
  }
}
