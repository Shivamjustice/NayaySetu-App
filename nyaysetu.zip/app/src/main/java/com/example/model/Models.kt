package com.example.model

enum class UserRole(val labelHi: String, val labelEn: String, val labelHinglish: String) {
  SUPER_ADMIN("सुपर एडमिन", "Super Admin", "Super Admin"),
  DEPT_ADMIN("विभाग प्रशासक", "Department Administrator", "Department Admin"),
  CASE_MANAGER("विधिक केस प्रबंधक", "Legal Case Manager", "Legal Case Manager"),
  VOLUNTEER("ग्राम कार्यकर्ता", "Field Volunteer", "Gram Volunteer"),
  COMMUNITY_MEMBER("समुदाय नागरिक", "Community Member", "Community Member");

  fun labelFor(lang: String): String = when (lang) {
    "en" -> labelEn
    "hinglish" -> labelHinglish
    else -> labelHi
  }

  companion object {
    // Backwards compatibility alias for ADMIN
    val ADMIN: UserRole get() = SUPER_ADMIN
  }
}

data class AppUser(
  val id: String,
  val username: String,
  val passwordHash: String,
  val name: String,
  val phone: String,
  val email: String = "",
  val district: String,
  val block: String,
  val village: String,
  val role: UserRole,
  val avatarColorHex: Long = 0xFF176B63,
  val isVerifiedByAdmin: Boolean = true,
  val isSuspended: Boolean = false,
  val bio: String = "",
  val avatarIndex: Int = 0,
  val assignedDepartment: String = "All",
  val profilePhotoUri: String = ""
)

sealed class LoginAuthResult {
  data class Success(val user: AppUser) : LoginAuthResult()
  data class PendingApproval(val user: AppUser) : LoginAuthResult()
  data class AccountSuspended(val user: AppUser) : LoginAuthResult()
  object InvalidCredentials : LoginAuthResult()
}

enum class CaseStatus(
  val stepIndex: Int,
  val labelHi: String,
  val labelEn: String,
  val labelHinglish: String,
  val descriptionHi: String,
  val descriptionEn: String,
  val descriptionHinglish: String
) {
  RECEIVED(1, "प्राप्त हुआ", "Received", "Receive Hua", "शिकायत या सहायता आग्रह सिस्टम में दर्ज हुआ", "Grievance entered into system", "Grievance system mein successfully register hui"),
  INITIAL_REVIEW(2, "प्रारंभिक समीक्षा", "Initial Review", "Initial Review", "दस्तावेज़ व प्राथमिक पात्रता की प्रारंभिक जाँच", "Initial screening of eligibility & docs", "Document aur eligibility ki shuruati jaanch"),
  AWAITING_INFO(3, "अतिरिक्त जानकारी प्रतीक्षित", "Awaiting Info", "Info Awaited", "आवेदक से आवश्यक कागजात या तथ्य प्रतीक्षित", "Additional facts or records needed", "Applicant se documents ya details aana baaki hai"),
  UNDER_ASSESSMENT(4, "मूल्यांकन जारी", "Under Assessment", "Assessment Chalu", "विधिक टीम द्वारा कानूनी प्रावधानों का परीक्षण", "Legal assessment by JHS advocates", "Legal team dwara niyam aur kanoon ki jaanch"),
  PLAN_PREPARED(5, "सहायता योजना तैयार", "Plan Prepared", "Plan Ready", "कार्ययोजना व कानूनी रणनीति निर्धारित", "Support roadmap established", "Help roadmap aur action plan taiyaar"),
  REFERRED(6, "विशेषज्ञ/संस्था को प्रेषित", "Referred", "Referred to DLSA", "DLSA या विशेषज्ञ संस्थान को संदर्भ पत्र प्रेषित", "Referred to DLSA or statutory body", "DLSA ya Sarkari Legal Cell ko bhej diya gaya"),
  APP_IN_PREP(7, "आवेदन तैयार हो रहा है", "Draft in Prep", "Application Taiyaar", "औपचारिक कानूनी प्रारूप तैयार किया जा रहा है", "Drafting statutory petition", "Official form aur petition draft ki jaa rahi hai"),
  APP_SUBMITTED(8, "आवेदन जमा किया गया", "Application Submitted", "App Jama Hua", "सक्षम प्राधिकारी या जनसुनवाई में प्रस्तुतीकरण", "Filed with competent authority", "Collectorate ya Jan Sunwai mein file ho gaya"),
  AWAITING_RESPONSE(9, "उत्तर प्रतीक्षित", "Awaiting Response", "Jawab Pratikshit", "सरकारी विभाग से विधिक समय-सीमा में उत्तर प्रतीक्षित", "Statutory response awaited from govt", "Sarkari vibhag se official reply aana baaki hai"),
  FOLLOWUP_REQUIRED(10, "फॉलो-अप आवश्यक", "Follow-up Required", "Follow-up Zaroori", "कार्यालय में व्यक्तिगत स्मरण पत्र या पूछताछ", "Physical follow-up required", "Office mein jaakar reminder aur enquiry zaroori"),
  RESOLUTION_REPORTED(11, "समाधान प्रतिवेदित", "Resolution Reported", "Samadhan Mila", "आदेश पारित अथवा राहत प्राप्त", "Official order passed or relief secured", "Official aadesh pass hua aur relief mili"),
  CLOSED(12, "बंद किया गया", "Closed", "Case Closed", "प्रक्रिया पूर्ण एवं आवेदक द्वारा संतुष्टि पुष्ट", "Case closed with community confirmation", "Puri relief milne ke baad case close hua"),
  REOPENED(13, "पुनः खोला गया", "Reopened", "Case Reopened", "नए साक्ष्य अथवा अनुपालन में बाधा पर पुनः सक्रिय", "Reactivated due to non-compliance", "Adhikaron ke ulanghan par dobara open kiya gaya");

  fun labelFor(lang: String): String = when (lang) {
    "en" -> labelEn
    "hinglish" -> labelHinglish
    else -> labelHi
  }
}

enum class CaseCategory(val idName: String, val labelHi: String, val labelEn: String, val labelHinglish: String) {
  FOREST_RIGHTS("forest_rights", "वनाधिकार (FRA)", "Forest Rights (FRA)", "Van Adhikar (FRA)"),
  LAND_RIGHTS("land_rights", "भूमि अधिकार व 170-B", "Land Rights & Sec 170-B", "Zameen Adhikar (170-B)"),
  GOVT_SCHEMES("govt_schemes", "सरकारी योजनाएँ व पात्रता", "Govt Schemes & Entitlements", "Sarkari Yojanayein"),
  IDENTITY_DOCS("identity_docs", "पहचान व दस्तावेज सहायता", "Identity & Documentation", "Documents & ID Help"),
  WAGES_LIVELIHOOD("wages_livelihood", "मजदूरी व मनरेगा", "Wages & MGNREGA", "Mazdoori & MGNREGA"),
  EDUCATION("education", "शिक्षा व छात्रावास", "Education & Hostels", "Education & Hostel"),
  HEALTH("health", "स्वास्थ्य सेवाएँ व पोषण", "Health & Nutrition", "Health & Poshan"),
  WOMENS_RIGHTS("womens_rights", "महिला अधिकार व सुरक्षा", "Women's Rights", "Mahila Adhikar & Safety"),
  CHILD_PROTECTION("child_protection", "बाल संरक्षण व अधिकार", "Child Protection", "Child Protection"),
  SOCIAL_DISCRIMINATION("social_discrimination", "सामाजिक भेदभाव व अत्याचार", "Social Discrimination", "Bhedbhav & Atyachar"),
  PUBLIC_SERVICES("public_services", "राशन व सार्वजनिक वितरण (PDS)", "PDS Ration & Services", "Ration (PDS) & Services"),
  VILLAGE_INFRASTRUCTURE("village_infrastructure", "गाँव का बुनियादी ढाँचा", "Village Infrastructure", "Gaon Sadak & Paani"),
  ENVIRONMENTAL_CONCERNS("environmental_concerns", "पर्यावरण व जल संरक्षण", "Environmental Concerns", "Paryavaran & Jungle"),
  OTHER("other", "अन्य सहायता", "Other Grievances", "Other Help");

  fun labelFor(lang: String): String = when (lang) {
    "en" -> labelEn
    "hinglish" -> labelHinglish
    else -> labelHi
  }
}

enum class PriorityLevel(val labelHi: String, val labelEn: String, val labelHinglish: String) {
  URGENT("अति आवश्यक", "Urgent", "Bohat Zaroori"),
  HIGH("उच्च प्राथमिकता", "High", "High Priority"),
  MEDIUM("मध्यम", "Medium", "Medium"),
  LOW("सामान्य", "Low", "Normal");

  fun labelFor(lang: String): String = when (lang) {
    "en" -> labelEn
    "hinglish" -> labelHinglish
    else -> labelHi
  }
}

data class GranularConsent(
  val dataCollectionConsent: Boolean = true,
  val whoCanAccessAcknowledged: Boolean = true,
  val thirdPartyReferralConsent: Boolean = true,
  val confidentialityLimitsUnderstood: Boolean = true,
  val consentTimestamp: String = "",
  val consentedBy: String = ""
)

data class DocumentChecklistItem(
  val id: String,
  val title: String,
  val description: String,
  val isMandatory: Boolean,
  val isVerified: Boolean,
  val notes: String? = null
)

data class CaseReferral(
  val id: String,
  val expertOrAgencyId: String,
  val expertName: String,
  val agencyName: String,
  val category: String,
  val referredDate: String,
  val consentObtained: Boolean,
  val informationSharedSummary: String,
  val followUpStatus: String = "acknowledged",
  val responseNotes: String? = null
)

data class CaseNote(
  val id: String,
  val authorName: String,
  val authorRole: UserRole,
  val isInternal: Boolean, // true = confidential staff note; false = public citizen update
  val content: String,
  val timestamp: String
)

data class CaseRecord(
  val id: String, // e.g. NYAY-2026-0041
  val verificationPin: String, // 4-digit PIN e.g. 4192
  val userId: String? = null,
  val category: CaseCategory,
  val title: String,
  val applicantName: String = "",
  val isAnonymous: Boolean = false,
  val isSensitive: Boolean = false, // for women & child confidential complaints
  val contactPhone: String = "",
  val preferredLanguage: String = "hi",
  val district: String,
  val block: String,
  val gramPanchayat: String,
  val village: String,
  val description: String,
  val assistanceRequested: String,
  val relevantDate: String = "",
  val status: CaseStatus,
  val priority: PriorityLevel,
  val assignedManagerName: String = "",
  val assignedVolunteerName: String = "",
  val dateReceived: String,
  val lastActionDate: String,
  val nextFollowUpDate: String? = null,
  val consent: GranularConsent = GranularConsent(),
  val documentChecklist: List<DocumentChecklistItem> = emptyList(),
  val referrals: List<CaseReferral> = emptyList(),
  val notes: List<CaseNote> = emptyList(),
  val closureReason: String? = null
)

// ----------------------------------------------------
// MODULE TWO & THREE: Government Schemes & Verification
// ----------------------------------------------------

enum class SchemeCategory(val labelHi: String, val labelEn: String) {
  TRIBAL_WELFARE("जनजातीय कल्याण व PVTG", "Tribal Welfare & PVTG"),
  AGRICULTURE_LIVELIHOOD("कृषि, पशुपालन व आजीविका", "Agriculture & Livelihood"),
  WOMEN_CHILD("महिला व बाल विकास", "Women & Child Development"),
  EDUCATION("शिक्षा व छात्रवृत्ति", "Education & Scholarships"),
  HOUSING_SOCIAL_SECURITY("आवास, पेंशन व खाद्य सुरक्षा", "Housing & Social Security"),
  EMPLOYMENT_RURAL_DEV("मनरेगा व ग्रामीण विकास", "Employment & Rural Development")
}

enum class SchemeStatus(val labelHi: String, val labelEn: String) {
  VERIFIED_CURRENT("सत्यापित व सक्रिय", "Verified and Current"),
  UPDATE_REQUIRED("समीक्षा आवश्यक", "Update Required"),
  UNDER_VERIFICATION("सत्यापन प्रक्रियाधीन", "Under Verification"),
  TEMPORARILY_UNAVAILABLE("अस्थायी रूप से अनुपलब्ध", "Temporarily Unavailable"),
  DISCONTINUED("बंद / समाप्त", "Discontinued or Closed")
}

data class GovernmentScheme(
  val id: String,
  val nameHindi: String,
  val nameEnglish: String,
  val objectiveHindi: String,
  val objectiveEnglish: String,
  val responsibleDepartment: String,
  val level: String, // "Central", "State (MP)", "District"
  val category: SchemeCategory,
  val eligibilityCriteriaHindi: List<String>,
  val eligibilityCriteriaEnglish: List<String>,
  val whoCanApplyHindi: String,
  val whoCanApplyEnglish: String,
  val benefitsHindi: List<String>,
  val benefitsEnglish: List<String>,
  val requiredDocumentsHindi: List<String>,
  val requiredDocumentsEnglish: List<String>,
  val applicationProcedureHindi: String,
  val applicationProcedureEnglish: String,
  val onlineApplicationLink: String? = null,
  val offlineApplicationLocation: String,
  val trackingMethod: String,
  val grievanceRedressal: String,
  val officialSourceUrl: String,
  val lastVerifiedDate: String,
  val nextReviewDate: String,
  val status: SchemeStatus = SchemeStatus.VERIFIED_CURRENT,
  val verifierName: String = "JHS Verification Desk",
  val verifierRole: String = "Legal Researcher",
  val targetAudiences: List<String> = emptyList() // "Women", "Farmers", "Students", "Workers", "PVTG", "Senior Citizens", "PwD"
)

data class SchemeErrorReport(
  val id: String,
  val schemeId: String,
  val schemeName: String,
  val reportedBy: String,
  val userRole: UserRole,
  val description: String,
  val timestamp: String,
  val isResolved: Boolean = false
)

// ----------------------------------------------------
// MODULE SIX: RTI Assistance Centre
// ----------------------------------------------------

data class RtiAuthority(
  val id: String,
  val departmentNameHindi: String,
  val departmentNameEnglish: String,
  val designationHindi: String,
  val designationEnglish: String,
  val district: String,
  val addressHindi: String,
  val feeDetails: String,
  val onlinePortalUrl: String? = null
)

data class RtiDraft(
  val id: String,
  val applicantName: String,
  val applicantAddress: String,
  val phone: String,
  val publicAuthority: String,
  val subject: String,
  val requestedInformation: String,
  val periodCovered: String,
  val isBpl: Boolean,
  val paymentMode: String,
  val generatedText: String,
  val timestamp: String,
  val isFirstAppeal: Boolean = false
)

// ----------------------------------------------------
// MODULE SEVEN & EIGHT: Village Profile & Gram Sabha
// ----------------------------------------------------

data class VillageDigitalProfile(
  val id: String,
  val villageName: String,
  val gramPanchayat: String,
  val block: String,
  val district: String,
  val population: Int,
  val schoolsCount: Int,
  val anganwadiCount: Int,
  val healthFacility: String,
  val drinkingWaterStatus: String,
  val roadsStatus: String,
  val electricityStatus: String,
  val primaryLivelihood: String,
  val developmentPriorities: List<String>,
  val ongoingWorks: List<String>,
  val verifiedDate: String
)

data class GramSabhaMeeting(
  val id: String,
  val village: String,
  val gramPanchayat: String,
  val meetingDate: String,
  val agenda: String,
  val keyProposals: List<String>,
  val resolutionsPassed: List<String>,
  val attendeesCount: Int
)

enum class CommunityActionStage(val step: Int, val labelHi: String, val labelEn: String) {
  IDENTIFIED(1, "समस्या पहचानी गई", "Problem Identified"),
  DISCUSSION(2, "सामुदायिक चर्चा", "Community Discussion"),
  COLLECTIVE_PETITION(3, "सामूहिक आवेदन तैयार", "Collective Application"),
  DEPT_CONTACT(4, "विभाग से संपर्क", "Department Contact"),
  FOLLOWUP(5, "फॉलो-अप व स्मरण पत्र", "Follow-up"),
  COMMUNITY_CONFIRMATION(6, "समुदाय पुष्टि व समाधान", "Community Confirmation")
}

data class CommunityActionIssue(
  val id: String,
  val title: String,
  val village: String,
  val category: String,
  val currentStage: CommunityActionStage,
  val description: String,
  val responsibleDept: String,
  val progressNotes: List<String>,
  val updatedDate: String
)

// ----------------------------------------------------
// MODULE TEN: Women and Child Support Corner
// ----------------------------------------------------

data class WomenChildResource(
  val id: String,
  val titleHindi: String,
  val titleEnglish: String,
  val category: String, // "Domestic Violence Legal Relief", "POCSO & Child Safety", "Nutrition & Maternal", "Scholarships & Hostels"
  val descriptionHindi: String,
  val descriptionEnglish: String,
  val legalProvisions: String,
  val emergencyContacts: List<String>,
  val procedureHindi: String
)

// ----------------------------------------------------
// MODULE TWELVE: Learning and Awareness Centre
// ----------------------------------------------------

data class LearningGuide(
  val id: String,
  val titleHindi: String,
  val titleEnglish: String,
  val category: String,
  val summaryHindi: String,
  val fullContentHindi: String,
  val keyTakeaways: List<String>,
  val simplifiedGlossary: Map<String, String> = emptyMap()
)

// ----------------------------------------------------
// Existing Application, Stories, Knowledge & Admin
// ----------------------------------------------------

data class StoryItem(
  val id: String,
  val authorName: String,
  val authorRole: UserRole,
  val village: String,
  val district: String,
  val titleHi: String,
  val titleEn: String,
  val titleHinglish: String,
  val contentHi: String,
  val contentEn: String,
  val contentHinglish: String,
  val category: String,
  val imageUrl: String? = null,
  val videoUrl: String? = null,
  val audioNote: String? = null,
  val likesCount: Int = 0,
  val timestamp: String,
  val isApproved: Boolean = true
)

data class AssistantMessage(
  val id: String,
  val isUser: Boolean,
  val text: String,
  val timestamp: String,
  val quickAction: String? = null,
  val sourceTitle: String? = null,
  val sourceDepartment: String? = null,
  val verificationStatus: String? = "JHS Verified",
  val lastVerifiedDate: String? = "2026-10-31",
  val categoryTag: String? = null,
  val userFeedback: String? = null,
  val detectedLanguage: String? = "hi",
  val portalUrl: String? = null,
  val stepList: List<String> = emptyList(),
  val requiredDocs: List<String> = emptyList(),
  val feeInfo: String? = null
)

data class UnansweredQuestionLog(
  val id: String,
  val query: String,
  val category: String,
  val timestamp: String,
  val frequencyCount: Int = 1,
  val isResolved: Boolean = false,
  val suggestedAction: String = "ज्ञानकोश में नई जानकारी जोड़ने की आवश्यकता"
)

data class AiFeedbackRecord(
  val id: String,
  val messageId: String,
  val userQuery: String,
  val aiResponse: String,
  val feedbackType: String,
  val timestamp: String
)

data class AiAssistantSettings(
  val isEnabled: Boolean = true,
  val continuousListeningEnabled: Boolean = false,
  val defaultLanguage: String = "hi",
  val speechRate: Float = 1.0f,
  val autoSpeakResponse: Boolean = true
)

data class KnowledgeArticle(
  val id: String,
  val titleHindi: String,
  val titleEnglish: String,
  val category: CaseCategory,
  val summaryHindi: String,
  val summaryEnglish: String,
  val contentHindi: String,
  val contentEnglish: String,
  val applicableLocation: String,
  val eligibilityHindi: List<String> = emptyList(),
  val eligibilityEnglish: List<String> = emptyList(),
  val documentChecklistHindi: List<String> = emptyList(),
  val documentChecklistEnglish: List<String> = emptyList(),
  val officialSource: String,
  val verificationDate: String,
  val reviewer: String
)

data class ApplicationFormField(
  val key: String,
  val labelHindi: String,
  val labelEnglish: String,
  val placeholder: String = "",
  val required: Boolean = true
)

data class ApplicationTemplate(
  val id: String,
  val titleHindi: String,
  val titleEnglish: String,
  val category: CaseCategory,
  val descriptionHindi: String,
  val descriptionEnglish: String,
  val recipientAuthorityHindi: String,
  val recipientAuthorityEnglish: String,
  val requiredDocuments: List<String>,
  val fields: List<ApplicationFormField>
)

data class VillagePriorityItem(
  val id: String,
  val village: String,
  val gramPanchayat: String,
  val block: String,
  val district: String,
  val theme: String,
  val communityPriority: String,
  val sourceOfInfo: String,
  val meetingDate: String,
  val participantsCount: Int = 0,
  val proposedAction: String,
  val responsibleInstitution: String,
  val followUpDate: String,
  val status: String,
  val recordedBy: String
)

data class LivelihoodOpportunity(
  val id: String,
  val titleHindi: String,
  val titleEnglish: String,
  val sector: String,
  val geographicCoverage: String,
  val descriptionHindi: String,
  val descriptionEnglish: String,
  val eligibilityHindi: String,
  val eligibilityEnglish: String,
  val processHindi: String,
  val processEnglish: String,
  val contactInfo: String,
  val verifiedSource: String
)

data class ExpertListing(
  val id: String,
  val name: String,
  val organization: String,
  val category: String,
  val geographicCoverage: String,
  val publicContact: String,
  val referralProcess: String,
  val descriptionHindi: String,
  val descriptionEnglish: String
)

data class HelplineItem(
  val number: String,
  val nameHindi: String,
  val nameEnglish: String,
  val descriptionHindi: String,
  val descriptionEnglish: String,
  val tollFree: Boolean = true,
  val timing: String = "24x7"
)

data class VolunteerVisitRecord(
  val id: String,
  val volunteerName: String,
  val village: String,
  val gramPanchayat: String,
  val block: String,
  val district: String,
  val visitDate: String,
  val participantsCount: Int,
  val meetingPurpose: String,
  val observations: String,
  val verbalConsentConfirmed: Boolean = true,
  val actionItems: String,
  val submittedAt: String,
  val isSynced: Boolean = true
)

data class InAppNotification(
  val id: String,
  val timestamp: String,
  val titleHindi: String,
  val titleEnglish: String,
  val messageHindi: String,
  val messageEnglish: String,
  val caseId: String? = null,
  val isRead: Boolean = false,
  val severity: String = "info"
)

data class AuditLogEntry(
  val id: String,
  val timestamp: String,
  val userName: String,
  val userRole: UserRole,
  val action: String,
  val targetType: String,
  val targetId: String,
  val details: String
)
