package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.NyaySetuRepository
import com.example.model.*
import com.example.util.TtsHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.*

enum class ScreenTab {
  HOME,
  SCHEMES,
  TRACK,
  BUILDER,
  RIGHTS,
  RTI,
  VILLAGE_PROFILE,
  GRAM_SABHA,
  LIVELIHOOD,
  WOMEN_CHILD,
  STORIES,
  LEARNING,
  ABOUT_JHS,
  PROFILE,
  DIRECTORY,
  HELPLINE,
  VOLUNTEER,
  ADMIN,
  ASSISTANT,
  PRIORITIES
}

class NyaySetuViewModel(application: Application) : AndroidViewModel(application) {

  val ttsHelper = TtsHelper(application)
  private val sessionPrefs = application.getSharedPreferences("jhs_user_session", android.content.Context.MODE_PRIVATE)

  // Languages: "hi" (Hindi), "en" (English), "hinglish" (Hinglish)
  private val _currentLanguage = MutableStateFlow(sessionPrefs.getString("app_language", "hi") ?: "hi")
  val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

  private val _activeTab = MutableStateFlow(ScreenTab.HOME)
  val activeTab: StateFlow<ScreenTab> = _activeTab.asStateFlow()

  val currentUser = NyaySetuRepository.currentUser
  val allUsers = NyaySetuRepository.users

  private val _highContrastMode = MutableStateFlow(false)
  val highContrastMode: StateFlow<Boolean> = _highContrastMode.asStateFlow()

  private val _fontScaleLevel = MutableStateFlow(1) // 0=Normal, 1=Large, 2=Extra Large
  val fontScaleLevel: StateFlow<Int> = _fontScaleLevel.asStateFlow()

  // Core Data Flows
  val cases = NyaySetuRepository.cases
  val stories = NyaySetuRepository.stories
  val knowledgeArticles = NyaySetuRepository.knowledgeArticles
  val applicationTemplates = NyaySetuRepository.applicationTemplates
  val villagePriorities = NyaySetuRepository.villagePriorities
  val livelihoods = NyaySetuRepository.livelihoods
  val experts = NyaySetuRepository.experts
  val helplines = NyaySetuRepository.helplines
  val volunteerVisits = NyaySetuRepository.volunteerVisits
  val notifications = NyaySetuRepository.notifications
  val auditLogs = NyaySetuRepository.auditLogs
  val assistantMessages = NyaySetuRepository.assistantMessages
  val aiAssistantSettings = NyaySetuRepository.aiAssistantSettings
  val unansweredQuestions = NyaySetuRepository.unansweredQuestions
  val aiFeedbackRecords = NyaySetuRepository.aiFeedbackRecords

  // Voice Interaction State
  val isListeningByVoice = MutableStateFlow(false)
  val isProcessingAiQuery = MutableStateFlow(false)
  val assistantSelectedLanguage = MutableStateFlow(_currentLanguage.value) // "hi", "en", "bundeli_sahariya"

  // New Platform Modules Flows
  val schemes = NyaySetuRepository.schemes
  val schemeErrorReports = NyaySetuRepository.schemeErrorReports
  val rtiAuthorities = NyaySetuRepository.rtiAuthorities
  val rtiDrafts = NyaySetuRepository.rtiDrafts
  val villageDigitalProfiles = NyaySetuRepository.villageDigitalProfiles
  val gramSabhaMeetings = NyaySetuRepository.gramSabhaMeetings
  val communityActionIssues = NyaySetuRepository.communityActionIssues
  val womenChildResources = NyaySetuRepository.womenChildResources
  val learningGuides = NyaySetuRepository.learningGuides

  // Filtered cases scoped to current user:
  // Community Member sees ONLY their own cases; Case Manager sees assigned; Admin sees ALL
  val userVisibleCases: StateFlow<List<CaseRecord>> = combine(
    cases,
    currentUser
  ) { allCases, user ->
    if (user == null) emptyList()
    else if (user.role == UserRole.SUPER_ADMIN || user.role == UserRole.DEPT_ADMIN) allCases
    else if (user.role == UserRole.CASE_MANAGER) {
      allCases.filter { c ->
        c.assignedManagerName.contains(user.name, ignoreCase = true) || !c.isSensitive
      }
    } else allCases.filter { c ->
      c.userId == user.id ||
      c.applicantName.contains(user.name, ignoreCase = true) ||
      (user.phone.isNotBlank() && c.contactPhone == user.phone) ||
      c.assignedVolunteerName.contains(user.name, ignoreCase = true)
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  // Auth Screen State
  val authIsNewUser = MutableStateFlow(false)
  val authUsername = MutableStateFlow("")
  val authPassword = MutableStateFlow("")
  val authErrorMessage = MutableStateFlow<String?>(null)
  val authSuccessNotice = MutableStateFlow<String?>(null)

  // Forgot Password & Contact Admin Dialog State
  val showForgotPassDialog = MutableStateFlow(false)
  val forgotPassIdentifier = MutableStateFlow("")
  val forgotPassNewPass = MutableStateFlow("")
  val forgotPassStatusMsg = MutableStateFlow<String?>(null)

  val showContactAdminDialog = MutableStateFlow(false)
  val contactAdminName = MutableStateFlow("")
  val contactAdminPhone = MutableStateFlow("")
  val contactAdminMsg = MutableStateFlow("")
  val contactAdminStatusMsg = MutableStateFlow<String?>(null)

  // Registration Fields
  val regName = MutableStateFlow("")
  val regUsername = MutableStateFlow("")
  val regPassword = MutableStateFlow("")
  val regPhone = MutableStateFlow("")
  val regEmail = MutableStateFlow("")
  val regDistrict = MutableStateFlow("श्योपुर (Sheopur)")
  val regBlock = MutableStateFlow("कराहल (Karahal)")
  val regVillage = MutableStateFlow("")
  val regRole = MutableStateFlow(UserRole.COMMUNITY_MEMBER)

  // Case Tracker Screen State
  val trackerCaseId = MutableStateFlow("NYAY-2026-0041")
  val trackerPin = MutableStateFlow("4192")
  val trackedCase = MutableStateFlow<CaseRecord?>(null)
  val trackerErrorMessage = MutableStateFlow<String?>(null)

  // Support Request Wizard State
  val isWizardOpen = MutableStateFlow(false)
  val wizardStep = MutableStateFlow(1) // 1..4
  val wizardCategory = MutableStateFlow(CaseCategory.FOREST_RIGHTS)
  val wizardTitle = MutableStateFlow("")
  val wizardApplicantName = MutableStateFlow("")
  val wizardIsAnonymous = MutableStateFlow(false)
  val wizardIsSensitive = MutableStateFlow(false)
  val wizardContactPhone = MutableStateFlow("")
  val wizardDistrict = MutableStateFlow("श्योपुर (Sheopur)")
  val wizardBlock = MutableStateFlow("कराहल (Karahal)")
  val wizardGramPanchayat = MutableStateFlow("गोरस (Goras)")
  val wizardVillage = MutableStateFlow("सहरिया डांडा (Sahariya Danda)")
  val wizardDescription = MutableStateFlow("")
  val wizardAssistanceRequested = MutableStateFlow("")
  val wizardConsentPurpose = MutableStateFlow(true)
  val wizardConsentLimits = MutableStateFlow(true)
  val wizardConsentReferral = MutableStateFlow(true)
  val wizardCreatedReceipt = MutableStateFlow<Pair<String, String>?>(null)

  // Knowledge Bank Search & Filter
  val knowledgeSearchQuery = MutableStateFlow("")
  val knowledgeSelectedCategory = MutableStateFlow<CaseCategory?>(null)

  val filteredKnowledge = combine(
    knowledgeArticles,
    knowledgeSearchQuery,
    knowledgeSelectedCategory
  ) { list, query, cat ->
    list.filter { article ->
      val matchesCat = cat == null || article.category == cat
      val matchesQuery = query.isBlank() ||
        article.titleHindi.contains(query, ignoreCase = true) ||
        article.titleEnglish.contains(query, ignoreCase = true) ||
        article.summaryHindi.contains(query, ignoreCase = true) ||
        article.summaryEnglish.contains(query, ignoreCase = true)
      matchesCat && matchesQuery
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  // Scheme Search & Filter
  val schemeSearchQuery = MutableStateFlow("")
  val schemeSelectedCategory = MutableStateFlow<SchemeCategory?>(null)
  val schemeTargetFilter = MutableStateFlow<String?>(null) // "Women", "Farmers", "Students", "Workers", "PVTG"

  val filteredSchemes = combine(
    schemes,
    schemeSearchQuery,
    schemeSelectedCategory,
    schemeTargetFilter
  ) { list, query, cat, target ->
    list.filter { s ->
      val matchesCat = cat == null || s.category == cat
      val matchesTarget = target == null || s.targetAudiences.any { it.contains(target, ignoreCase = true) }
      val matchesQuery = query.isBlank() ||
        s.nameHindi.contains(query, ignoreCase = true) ||
        s.nameEnglish.contains(query, ignoreCase = true) ||
        s.objectiveHindi.contains(query, ignoreCase = true) ||
        s.objectiveEnglish.contains(query, ignoreCase = true) ||
        s.responsibleDepartment.contains(query, ignoreCase = true) ||
        s.benefitsHindi.any { it.contains(query, ignoreCase = true) } ||
        s.benefitsEnglish.any { it.contains(query, ignoreCase = true) }
      matchesCat && matchesTarget && matchesQuery
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  // Scheme Eligibility Interactive Checker: "क्या मैं इस योजना के लिए पात्र हूँ?"
  val eligibilitySocialCategory = MutableStateFlow("PVTG (सहरिया/बैगा/भारिया)")
  val eligibilityOccupation = MutableStateFlow("कृषक व वनोपज संग्राहक")
  val eligibilityGender = MutableStateFlow("महिला")
  val eligibilityHasLandOrFra = MutableStateFlow(true)
  val eligibleSchemesResult = MutableStateFlow<List<GovernmentScheme>>(emptyList())
  val isEligibilityChecked = MutableStateFlow(false)

  // Application Builder State
  val selectedTemplate = MutableStateFlow<ApplicationTemplate?>(null)
  val templateFormValues = MutableStateFlow<Map<String, String>>(emptyMap())
  val generatedDocumentPreview = MutableStateFlow<String?>(null)

  // RTI Assistance Center State
  val rtiApplicantName = MutableStateFlow("")
  val rtiAddress = MutableStateFlow("")
  val rtiPhone = MutableStateFlow("")
  val rtiSelectedAuthority = MutableStateFlow<RtiAuthority?>(null)
  val rtiSubject = MutableStateFlow("")
  val rtiInformationDetails = MutableStateFlow("")
  val rtiPeriod = MutableStateFlow("2024-2026")
  val rtiIsBpl = MutableStateFlow(true)
  val rtiPaymentMode = MutableStateFlow("बीपीएल कार्डधारक (निःशुल्क)")
  val generatedRtiDraft = MutableStateFlow<String?>(null)

  // Assistant Input State
  val assistantInputText = MutableStateFlow("")

  // Notifications Drawer
  val isNotificationDrawerOpen = MutableStateFlow(false)

  init {
    com.example.data.NyaySetuRepository.init(application)
    com.example.data.FirestoreSyncManager.init(application)
    lookupCase()
  }

  // Trilingual / Multilingual string helper
  fun tr(hi: String, en: String, hinglish: String): String {
    return when (_currentLanguage.value) {
      "en" -> en
      "hinglish" -> hinglish
      else -> hi
    }
  }

  fun setTab(tab: ScreenTab) {
    _activeTab.value = tab
  }

  fun setLanguage(lang: String) {
    _currentLanguage.value = lang
    assistantSelectedLanguage.value = lang
    sessionPrefs.edit().putString("app_language", lang).apply()
  }

  fun cycleLanguage() {
    val nextLang = when (_currentLanguage.value) {
      "hi" -> "hinglish"
      "hinglish" -> "en"
      else -> "hi"
    }
    _currentLanguage.value = nextLang
    assistantSelectedLanguage.value = nextLang
    sessionPrefs.edit().putString("app_language", nextLang).apply()
  }

  fun toggleHighContrast() {
    _highContrastMode.value = !_highContrastMode.value
  }

  fun cycleFontScale() {
    _fontScaleLevel.value = (_fontScaleLevel.value + 1) % 3
  }

  // ----------------------------------------------------
  // Authentication & Access Control
  // ----------------------------------------------------
  fun login() {
    authErrorMessage.value = null
    authSuccessNotice.value = null
    when (val result = NyaySetuRepository.login(authUsername.value, authPassword.value)) {
      is LoginAuthResult.Success -> {
        authErrorMessage.value = null
        _activeTab.value = if (result.user.role == UserRole.SUPER_ADMIN || result.user.role == UserRole.DEPT_ADMIN) ScreenTab.ADMIN else ScreenTab.HOME
      }
      is LoginAuthResult.PendingApproval -> {
        authErrorMessage.value = tr(
          hi = "⚠️ आपका खाता (@${result.user.username}) समीक्षाधीन है। JHS प्रशासन (Admin) द्वारा सत्यापन के पश्चात ही लॉगिन होगा।",
          en = "⚠️ Your account (@${result.user.username}) is pending admin verification. You can log in once approved by JHS Administration.",
          hinglish = "⚠️ Aapka account (@${result.user.username}) admin verification ke liye pending hai. Approval ke baad hi login hoga."
        )
      }
      is LoginAuthResult.AccountSuspended -> {
        authErrorMessage.value = tr(
          hi = "⛔ यह खाता सुरक्षा अथवा प्रशासनिक कारणों से अस्थायी रूप से निलंबित (Suspended) है। JHS केंद्रीय प्रशासन से संपर्क करें।",
          en = "⛔ This account is suspended by JHS Administration. Please contact the administrator.",
          hinglish = "⛔ Yeh account admin dwara suspend kiya gaya hai. JHS administration se contact karein."
        )
      }
      is LoginAuthResult.InvalidCredentials -> {
        authErrorMessage.value = tr(
          hi = "यूज़र आईडी/मोबाइल/ईमेल अथवा पासवर्ड अमान्य है। कृपया पुनः प्रयास करें।",
          en = "Invalid User ID, Mobile/Email or Password. Please try again.",
          hinglish = "User ID, Phone/Email ya Password galat hai. Dobara check karein."
        )
      }
    }
  }

  fun register() {
    authErrorMessage.value = null
    authSuccessNotice.value = null
    if (regName.value.isBlank() || regUsername.value.isBlank() || regPassword.value.isBlank()) {
      authErrorMessage.value = tr(
        hi = "कृपया नाम, यूज़र आईडी और पासवर्ड भरें।",
        en = "Please provide Name, User ID, and Password.",
        hinglish = "Please Name, User ID aur Password zaroor bharein."
      )
      return
    }

    val user = NyaySetuRepository.registerUser(
      username = regUsername.value,
      password = regPassword.value,
      name = regName.value,
      phone = regPhone.value,
      email = regEmail.value,
      district = regDistrict.value,
      block = regBlock.value,
      village = regVillage.value.ifBlank { "ग्वालियर-चंबल" },
      role = regRole.value
    )

    if (user.role == UserRole.SUPER_ADMIN) {
      _activeTab.value = ScreenTab.ADMIN
    } else {
      authUsername.value = user.username
      authPassword.value = ""
      authIsNewUser.value = false
      authSuccessNotice.value = tr(
        hi = "✅ पंजीकरण प्राप्त! आपका खाता (@${user.username}) JHS एडमिनिस्ट्रेशन सत्यापन के लिए प्रेषित किया गया है। एडमिन स्वीकृति के पश्चात आप लॉगिन कर सकेंगे।",
        en = "✅ Registration received! Your account (@${user.username}) is pending JHS Admin verification. You can login once approved.",
        hinglish = "✅ Registration successful! Admin verification ke baad aap login kar sakenge."
      )
    }
  }

  fun resetPassword() {
    forgotPassStatusMsg.value = null
    if (forgotPassIdentifier.value.isBlank() || forgotPassNewPass.value.isBlank()) {
      forgotPassStatusMsg.value = "कृपया यूज़रनेम/मोबाइल तथा नया पासवर्ड दर्ज करें।"
      return
    }
    val ok = NyaySetuRepository.resetPassword(forgotPassIdentifier.value, forgotPassNewPass.value)
    if (ok) {
      forgotPassStatusMsg.value = "✅ पासवर्ड सफलतापूर्वक रीसेट हो गया! अब आप लॉगिन कर सकते हैं।"
      authUsername.value = forgotPassIdentifier.value
      authPassword.value = forgotPassNewPass.value
    } else {
      forgotPassStatusMsg.value = "❌ कोई पंजीकृत खाता नहीं मिला। कृपया सही यूज़रनेम या मोबाइल नंबर दें।"
    }
  }

  fun submitContactAdmin() {
    contactAdminStatusMsg.value = null
    if (contactAdminName.value.isBlank() || contactAdminPhone.value.isBlank()) {
      contactAdminStatusMsg.value = "कृपया नाम और संपर्क नंबर अवश्य दर्ज करें।"
      return
    }
    NyaySetuRepository.contactAdmin(contactAdminName.value, contactAdminPhone.value, contactAdminMsg.value)
    contactAdminStatusMsg.value = "✅ आपका अनुरोध JHS प्रशासन को भेज दिया गया है। टीम शीघ्र आपसे संपर्क करेगी।"
  }

  fun quickLoginAs(user: AppUser) {
    NyaySetuRepository.switchUser(user)
    _activeTab.value = if (user.role == UserRole.SUPER_ADMIN || user.role == UserRole.DEPT_ADMIN) ScreenTab.ADMIN else ScreenTab.HOME
  }

  fun onGoogleSignInSuccess(firebaseUser: com.google.firebase.auth.FirebaseUser) {
    val email = firebaseUser.email ?: ""
    val name = firebaseUser.displayName ?: email.substringBefore("@").ifBlank { "नागरिक (Google)" }
    val uid = firebaseUser.uid

    val existing = allUsers.value.find { it.email.equals(email, ignoreCase = true) || it.id == uid }
    val user = existing ?: AppUser(
      id = uid,
      username = email.substringBefore("@").ifBlank { "user_$uid" },
      passwordHash = "",
      name = name,
      phone = firebaseUser.phoneNumber ?: "",
      email = email,
      district = "श्योपुर (MP)",
      block = "विजयपुर",
      village = "पीपलखेड़ा",
      role = UserRole.COMMUNITY_MEMBER,
      avatarColorHex = 0xFF176B63,
      isVerifiedByAdmin = true,
      bio = "Google सत्यापित JHS नागरिक"
    )

    if (existing == null) {
      NyaySetuRepository.addGoogleUser(user)
    }
    NyaySetuRepository.switchUser(user)
    com.example.data.FirestoreSyncManager.syncUserProfileToCloud(user)
    authErrorMessage.value = null
    _activeTab.value = ScreenTab.HOME
  }

  fun logout() {
    NyaySetuRepository.logout()
  }

  // ----------------------------------------------------
  // Super Admin Central Controls
  // ----------------------------------------------------
  fun approveUser(userId: String) {
    NyaySetuRepository.approveUser(userId)
  }

  fun toggleUserSuspension(userId: String) {
    NyaySetuRepository.toggleUserSuspension(userId)
  }

  fun changeUserRole(userId: String, newRole: UserRole) {
    NyaySetuRepository.changeUserRole(userId, newRole)
  }

  fun deleteUser(userId: String) {
    NyaySetuRepository.deleteUser(userId)
  }

  fun deleteCase(caseId: String) {
    NyaySetuRepository.deleteCase(caseId)
  }

  fun updateCase(updated: CaseRecord) {
    NyaySetuRepository.updateCase(updated)
  }

  // Scheme Management
  fun updateSchemeStatus(schemeId: String, status: SchemeStatus) {
    NyaySetuRepository.updateSchemeStatus(schemeId, status)
  }

  fun reportSchemeError(schemeId: String, schemeName: String, desc: String) {
    val reporter = currentUser.value?.name ?: "नागरिक"
    val role = currentUser.value?.role ?: UserRole.COMMUNITY_MEMBER
    NyaySetuRepository.reportSchemeError(schemeId, schemeName, reporter, role, desc)
  }

  fun resolveSchemeError(reportId: String) {
    NyaySetuRepository.resolveSchemeError(reportId)
  }

  // Scheme Eligibility Evaluation: "क्या मैं इस योजना के लिए पात्र हूँ?"
  fun checkEligibility() {
    val all = schemes.value
    val isPvtg = eligibilitySocialCategory.value.contains("PVTG", ignoreCase = true)
    val isSt = eligibilitySocialCategory.value.contains("ST", ignoreCase = true) || isPvtg
    val isFemale = eligibilityGender.value.contains("महिला", ignoreCase = true)
    val hasLand = eligibilityHasLandOrFra.value
    val occ = eligibilityOccupation.value

    val matched = all.filter { s ->
      when (s.id) {
        "sch-sahariya-aahar" -> isPvtg && isFemale
        "sch-fra-mp" -> isSt && hasLand
        "sch-kisan-samman" -> hasLand || occ.contains("कृषक")
        "sch-mgnrega-150" -> true
        "sch-pmay-g" -> true
        "sch-tribal-scholarship" -> isSt
        else -> true
      }
    }
    eligibleSchemesResult.value = matched
    isEligibilityChecked.value = true
  }

  // ----------------------------------------------------
  // RTI Assistance Drafting
  // ----------------------------------------------------
  fun generateRtiDraft(isFirstAppeal: Boolean = false) {
    val auth = rtiSelectedAuthority.value ?: rtiAuthorities.value.firstOrNull() ?: return
    val applicant = rtiApplicantName.value.ifBlank { currentUser.value?.name ?: "आवेदक" }
    val address = rtiAddress.value.ifBlank { "${currentUser.value?.village ?: "ग्राम"}, जिला ${currentUser.value?.district ?: "मध्य प्रदेश"}" }
    val phone = rtiPhone.value.ifBlank { currentUser.value?.phone ?: "" }
    val subject = rtiSubject.value.ifBlank { "सूचना का अधिकार अधिनियम, 2005 के अंतर्गत चाही गई जानकारी" }
    val details = rtiInformationDetails.value.ifBlank { "संबंधित विषय का पूर्ण अभिलेख व प्रमाणित प्रतियां" }
    val period = rtiPeriod.value

    val draft = buildString {
      appendLine("==================================================")
      if (!isFirstAppeal) {
        appendLine("सूचना का अधिकार अधिनियम, 2005 की धारा 6(1) के अंतर्गत आवेदन")
      } else {
        appendLine("सूचना का अधिकार अधिनियम, 2005 की धारा 19(1) के अंतर्गत प्रथम अपील")
      }
      appendLine("==================================================")
      appendLine()
      appendLine("सेवा में,")
      if (!isFirstAppeal) {
        appendLine("श्रीमान लोक सूचना अधिकारी (PIO),")
      } else {
        appendLine("श्रीमान प्रथम अपीलीय प्राधिकारी (First Appellate Authority),")
      }
      appendLine("${auth.designationHindi},")
      appendLine("${auth.departmentNameHindi},")
      appendLine("${auth.addressHindi}, जिला ${auth.district}")
      appendLine()
      appendLine("विषय: $subject")
      appendLine()
      appendLine("महोदय / महोदया,")
      if (!isFirstAppeal) {
        appendLine("सविनय निवेदन है कि सूचना का अधिकार अधिनियम, 2005 की धारा 6(1) के अंतर्गत निम्नलिखित विशिष्ट बिंदुवार जानकारी की प्रमाणित प्रतियाँ प्रदान करने का कष्ट करें:")
        appendLine()
        appendLine("1. जानकारी का विशिष्ट विवरण:")
        appendLine("   $details")
        appendLine()
        appendLine("2. संबंधित समयावधि: $period")
        appendLine()
        appendLine("3. शुल्क विवरण:")
        if (rtiIsBpl.value) {
          appendLine("   आवेदक गरीबी रेखा से नीचे (BPL) श्रेणी का है, अतः नियमानुसार कोई शुल्क देय नहीं है। BPL राशन कार्ड की प्रति संलग्न है।")
        } else {
          appendLine("   आवेदन शुल्क ₹10/- का गैर-न्यायिक स्टाम्प / पोस्टल आर्डर संलग्न है।")
        }
      } else {
        appendLine("सविनय निवेदन है कि आवेदक द्वारा प्रस्तुत आरटीआई आवेदन पर निर्धारित 30 दिवस की समय-सीमा में सूचना प्राप्त न होने / भ्रामक सूचना मिलने के कारण यह प्रथम अपील प्रस्तुत की जा रही है:")
        appendLine()
        appendLine("1. मूल आवेदन का विषय: $subject")
        appendLine("2. चाही गई जानकारी: $details")
        appendLine("3. अपील का आधार: विधिक समयावधि में यथोचित उत्तर अप्राप्त।")
      }
      appendLine()
      appendLine("4. संपर्क विवरण:")
      appendLine("   आवेदक का नाम: $applicant")
      appendLine("   पता: $address")
      appendLine("   मोबाइल नंबर: $phone")
      appendLine()
      appendLine("संलग्नक:")
      appendLine("  1. मूल आवेदन / पहचान पत्र")
      if (rtiIsBpl.value) appendLine("  2. बीपीएल कार्ड की स्व-प्रमाणित प्रति")
      else appendLine("  2. ₹10/- शुल्क रसीद / स्टाम्प")
      appendLine()
      appendLine("दिनांक: 30 अक्टूबर 2026")
      appendLine()
      appendLine("हस्ताक्षर / अंगूठा निशानी: _______________________")
      appendLine("                           ($applicant)")
    }

    generatedRtiDraft.value = draft

    val record = RtiDraft(
      id = "rti_${System.currentTimeMillis()}",
      applicantName = applicant,
      applicantAddress = address,
      phone = phone,
      publicAuthority = auth.departmentNameHindi,
      subject = subject,
      requestedInformation = details,
      periodCovered = period,
      isBpl = rtiIsBpl.value,
      paymentMode = if (rtiIsBpl.value) "BPL Exemption" else "₹10 Fee",
      generatedText = draft,
      timestamp = "30 Oct 2026",
      isFirstAppeal = isFirstAppeal
    )
    NyaySetuRepository.saveRtiDraft(record)
  }

  // ----------------------------------------------------
  // Community Action Tracking
  // ----------------------------------------------------
  fun updateCommunityActionStage(issueId: String, newStage: CommunityActionStage, note: String) {
    NyaySetuRepository.updateCommunityActionStage(issueId, newStage, note)
  }

  fun addCommunityActionIssue(title: String, village: String, category: String, desc: String, dept: String) {
    NyaySetuRepository.addCommunityActionIssue(title, village, category, desc, dept)
  }

  // ----------------------------------------------------
  // Profile Update
  // ----------------------------------------------------
  fun updateProfile(
    name: String,
    phone: String,
    village: String,
    block: String,
    district: String,
    bio: String,
    avatarIndex: Int
  ) {
    val uid = currentUser.value?.id ?: return
    NyaySetuRepository.updateUserProfile(uid, name, phone, village, block, district, bio, avatarIndex)
  }

  fun updateProfilePhoto(photoUri: String) {
    val uid = currentUser.value?.id ?: return
    NyaySetuRepository.updateProfilePhoto(uid, photoUri)
  }

  // Case Tracker Operations
  fun lookupCase() {
    trackerErrorMessage.value = null
    val result = NyaySetuRepository.lookupCase(trackerCaseId.value, trackerPin.value)
    if (result != null) {
      trackedCase.value = result
    } else {
      trackedCase.value = null
      trackerErrorMessage.value = tr(
        hi = "कोई मामला नहीं मिला। कृपया केस आईडी (उदा. NYAY-2026-0041) एवं 4-अंकों का पिन (उदा. 4192) जाँचें।",
        en = "No case record found. Please verify Case ID (e.g. NYAY-2026-0041) and 4-digit PIN (e.g. 4192).",
        hinglish = "Koi case nahi mila. Apna Case ID (jaise NYAY-2026-0041) aur 4-digit PIN verify karein."
      )
    }
  }

  fun setTrackingTarget(caseId: String, pin: String) {
    trackerCaseId.value = caseId
    trackerPin.value = pin
    lookupCase()
    _activeTab.value = ScreenTab.TRACK
  }

  fun openWizard() {
    wizardStep.value = 1
    wizardCreatedReceipt.value = null
    isWizardOpen.value = true
  }

  fun closeWizard() {
    isWizardOpen.value = false
  }

  fun submitSupportRequest() {
    val result = NyaySetuRepository.addCase(
      category = wizardCategory.value,
      title = wizardTitle.value,
      applicantName = wizardApplicantName.value,
      isAnonymous = wizardIsAnonymous.value,
      contactPhone = wizardContactPhone.value,
      preferredLanguage = _currentLanguage.value,
      district = wizardDistrict.value,
      block = wizardBlock.value,
      gramPanchayat = wizardGramPanchayat.value,
      village = wizardVillage.value,
      description = wizardDescription.value,
      assistanceRequested = wizardAssistanceRequested.value,
      userId = currentUser.value?.id
    )
    wizardCreatedReceipt.value = result
    wizardStep.value = 4
  }

  // Application Builder
  fun selectApplicationTemplate(template: ApplicationTemplate) {
    selectedTemplate.value = template
    templateFormValues.value = emptyMap()
    generatedDocumentPreview.value = null
  }

  fun updateFormField(key: String, value: String) {
    templateFormValues.value = templateFormValues.value + (key to value)
  }

  fun openApplicationForScheme(scheme: GovernmentScheme) {
    val templateId = when (scheme.id) {
      "sch-fra-mp" -> "tpl-fra-patta-vikas"
      "sch-sahariya-aahar" -> "tpl-sahariya-aahar"
      "sch-dudharu-pashu" -> "tpl-dudharu-pashu"
      "sch-sbm-g" -> "tpl-sbm-g"
      "sch-ladli-behna" -> "tpl-ladli-behna"
      "sch-pm-kusum" -> "tpl-pm-kusum"
      "sch-udid-divyang" -> "tpl-udid-divyang"
      "sch-pm-vishwakarma" -> "tpl-pm-vishwakarma"
      "sch-akanksha-coaching" -> "tpl-akanksha"
      else -> "tpl-jansunwai-grievance"
    }
    val match = applicationTemplates.value.find { it.id == templateId }
      ?: applicationTemplates.value.firstOrNull()
    if (match != null) {
      selectApplicationTemplate(match)
      // Pre-fill some values if user is logged in
      val user = currentUser.value
      if (user != null) {
        updateFormField("applicant_name", user.name)
        updateFormField("phone", user.phone)
        updateFormField("district", user.district)
        updateFormField("block", user.block)
        updateFormField("village", user.village)
      }
      if (templateId == "tpl-jansunwai-grievance") {
        updateFormField("scheme_name", if (_currentLanguage.value == "hi") scheme.nameHindi else scheme.nameEnglish)
      }
    }
    _activeTab.value = ScreenTab.BUILDER
  }

  fun generateApplicationDraft() {
    val tpl = selectedTemplate.value ?: return
    val values = templateFormValues.value
    val isHi = _currentLanguage.value != "en"

    if (!isHi) {
      generatedDocumentPreview.value = buildString {
        appendLine("==================================================")
        appendLine(tpl.titleEnglish)
        appendLine("To: ${tpl.recipientAuthorityEnglish}")
        appendLine("District: ${values["district"] ?: "Madhya Pradesh"}")
        appendLine("Date: 31 October 2026")
        appendLine("==================================================")
        appendLine()
        appendLine("Subject: Formal Application / Petition under ${tpl.titleEnglish}")
        appendLine()
        appendLine("Respected Authority,")
        appendLine("I respectfully submit the following particulars for your kind consideration and necessary statutory action:")
        appendLine()
        tpl.fields.forEach { f ->
          val value = values[f.key]?.ifBlank { "—" } ?: "—"
          appendLine("• ${f.labelEnglish}: $value")
        }
        appendLine()
        appendLine("Enclosures (Supporting Documents):")
        tpl.requiredDocuments.forEachIndexed { i, doc ->
          appendLine("  ${i + 1}. $doc")
        }
        appendLine()
        appendLine("Verification & Declaration:")
        appendLine("I hereby solemnly affirm that all facts stated above are true, complete, and authentic to the best of my knowledge.")
        appendLine()
        appendLine("Applicant Name: ${values["applicant_name"] ?: "................"}")
        appendLine("Contact Phone: ${values["phone"] ?: "................"}")
        appendLine("Signature / Thumb Impression: _______________________")
      }
      return
    }

    val draft = when (tpl.id) {
      "tpl-jansunwai-grievance" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् जिला कलेक्टर / सक्षम प्राधिकारी महोदय,")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}, मध्य प्रदेश।")
          appendLine()
          appendLine("विषय: शासकीय योजना (${values["scheme_name"] ?: "शासकीय योजना"}) का लाभ न मिलने / आवेदन पर कार्यवाही न होने बाबत् शिकायत।")
          appendLine()
          appendLine("महोदय / महोदया,")
          appendLine("विनम्र निवेदन है कि मैं ${values["applicant_name"] ?: "................"} पुत्र/पुत्री/पत्नी ${values["father_spouse"] ?: "................"},")
          appendLine("ग्राम: ${values["village"] ?: "................"}, ग्राम पंचायत: ${values["gram_panchayat"] ?: "................"},")
          appendLine("ब्लॉक/तहसील: ${values["block"] ?: "................"}, जिला: ${values["district"] ?: "................"} का मूल निवासी हूँ।")
          appendLine("मैं ${values["caste_category"] ?: "अनुसूचित जनजाति (ST) / विशेष पिछड़ी जनजाति (PVTG)"} समुदाय से संबंधित हूँ।")
          appendLine()
          appendLine("मैंने ${values["scheme_name"] ?: "संबंधित योजना"} के अंतर्गत निर्धारित प्रारूप में दिनांक ${values["application_date"] ?: "................"} को आवेदन प्रस्तुत किया था, जिसका आवेदन क्रमांक / पावती रसीद संख्या ${values["application_receipt_no"] ?: "................"} है।")
          appendLine()
          appendLine("उक्त आवेदन को प्रस्तुत किए ${values["months_pending"] ?: "निर्धारित समय"} बीत जाने के उपरांत भी आज दिनांक तक मुझे योजना का कोई लाभ प्राप्त नहीं हुआ है, और न ही कोई लिखित कारण सूचित किया गया है।")
          appendLine()
          appendLine("समस्या का संक्षिप्त विवरण:")
          appendLine("${values["grievance_details"] ?: "कई बार संबंधित कार्यालय में संपर्क करने पर भी कोई संतोषजनक उत्तर नहीं दिया गया।"}")
          appendLine()
          appendLine("अतः आपसे विनम्र प्रार्थना है कि मेरे उक्त आवेदन की जांच करवाकर मुझे नियमानुसार योजना का लाभ दिलाए जाने के निर्देश प्रदान करने की कृपा करें। यदि मेरा आवेदन किसी कारणवश अपात्र माना गया है, तो उसका लिखित विधिक कारण उपलब्ध कराया जाए ताकि मैं सक्षम अपीलीय स्तर पर अपील प्रस्तुत कर सकूँ।")
          appendLine()
          appendLine("अपेक्षित विधिक राहत:")
          appendLine("${values["relief_sought"] ?: "योजना का लाभ तुरंत स्वीकृत किया जाए।"}")
          appendLine()
          appendLine("संलग्न दस्तावेज:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("स्थान: ${values["village"] ?: "ग्राम"}, ${values["district"] ?: "मध्य प्रदेश"}")
          appendLine()
          appendLine("आवेदक का नाम: ${values["applicant_name"] ?: "................"}")
          appendLine("मोबाइल नंबर: ${values["phone"] ?: "................"}")
          appendLine("हस्ताक्षर / अंगूठा निशानी: _______________________")
        }
      }
      "tpl-ladli-behna" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् बाल विकास परियोजना अधिकारी (CDPO) / सचिव, ग्राम पंचायत,")
          appendLine("जनपद पंचायत: ${values["block"] ?: "........"}, जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: मुख्यमंत्री लाड़ली बहना योजना अंतर्गत ₹1,250 प्रतिमाह राशि भुगतान / DBT सुधार बाबत्।")
          appendLine()
          appendLine("महोदया / महोदय,")
          appendLine("सविनय निवेदन है कि प्रार्थी बहिन ${values["applicant_name"] ?: "................"} पत्नी/पुत्री ${values["husband_name"] ?: "................"}, आयु ${values["age"] ?: "...."} वर्ष, निवासी ग्राम ${values["village"] ?: "................"}, ग्राम पंचायत ${values["gram_panchayat"] ?: "................"}, ब्लॉक ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} की स्थायी निवासी हूँ।")
          appendLine()
          appendLine("विवरण निम्नानुसार है:")
          appendLine("1. सदस्य समग्र आईडी: ${values["samagra_id"] ?: "—"}")
          appendLine("2. आधार कार्ड संख्या: ${values["aadhaar_no"] ?: "—"}")
          appendLine("3. बैंक खाता विवरण: ${values["bank_details"] ?: "—"}")
          appendLine("4. पंजीकृत मोबाइल नंबर: ${values["phone"] ?: "—"}")
          appendLine("5. समस्या / निवेदन: ${values["request_type"] ?: "लाड़ली बहना योजना में नाम स्वीकृत होने के बाद भी खाते में मासिक राशि प्राप्त नहीं हो रही है।"}")
          appendLine()
          appendLine("प्रार्थिया योजना के समस्त पात्रता मानदंडों को पूर्ण करती है और बैंक खाता आधार NPCI से सक्रिय कराया जा चुका है।")
          appendLine("अतः नम्र निवेदन है कि पोर्टल पर ई-केवाईसी व बैंक डीबीटी स्थिति सत्यापित कर प्रार्थी बहिन को योजना की मासिक किस्त नियमित रूप से प्रदान कराने की कृपा करें।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदिका बहिन के हस्ताक्षर / अंगूठा: _______________________")
        }
      }
      "tpl-pm-kusum" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् जिला अक्षय ऊर्जा अधिकारी महोदय,")
          appendLine("म.प्र. ऊर्जा विकास निगम लिमिटेड,")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: प्रधानमंत्री कुसुम योजना (घटक-बी) अंतर्गत 90% अनुदान पर सोलर कृषि पंप स्थापना बाबत्।")
          appendLine()
          appendLine("महोदय,")
          appendLine("सविनय निवेदन है कि प्रार्थी कृषक ${values["applicant_name"] ?: "................"} आत्मज ${values["father_name"] ?: "................"}, निवासी ग्राम ${values["village"] ?: "................"}, ब्लॉक ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} का मूल निवासी एवं ${values["social_category"] ?: "अनुसूचित जनजाति (ST) / लघु कृषक"} वर्ग का कृषक है।")
          appendLine()
          appendLine("खेत एवं जल स्रोत का विवरण:")
          appendLine("1. खसरा क्रमांक: ${values["khasra_no"] ?: "—"}")
          appendLine("2. कुल रकबा (एकड़): ${values["land_area"] ?: "—"}")
          appendLine("3. जल स्रोत: ${values["water_source"] ?: "कुआं / बोरवेल"}")
          appendLine("4. वांछित पंप क्षमता: ${values["pump_capacity"] ?: "5 HP सोलर पंप"}")
          appendLine("5. संपर्क मोबाइल नंबर: ${values["phone"] ?: "—"}")
          appendLine()
          appendLine("प्रार्थी के खेत पर कोई पूर्व ग्रिड विद्युत कनेक्शन नहीं है और प्रार्थी शासन द्वारा निर्धारित कृषक अंश जमा करने हेतु पूर्णतः तैयार है।")
          appendLine("अतः श्रीमान् से प्रार्थना है कि स्थल निरीक्षण करवाकर प्रार्थी के खेत पर 90% शासकीय अनुदान पर सोलर सिंचाई पंप स्वीकृत व स्थापित कराने की कृपा करें।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदक कृषक के हस्ताक्षर: _______________________")
        }
      }
      "tpl-udid-divyang" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् मुख्य चिकित्सा एवं स्वास्थ्य अधिकारी (CMHO) / उप संचालक सामाजिक न्याय,")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: विशिष्ट दिव्यांगता पहचान (UDID) स्मार्ट कार्ड जारी करने एवं पेंशन/सहायता स्वीकृति बाबत्।")
          appendLine()
          appendLine("महोदय,")
          appendLine("सविनय निवेदन है कि प्रार्थी ${values["applicant_name"] ?: "................"} सुपुत्र/सुपुत्री/अभिभावक ${values["guardian_name"] ?: "................"}, आयु ${values["age"] ?: "...."} वर्ष, निवासी ग्राम ${values["village"] ?: "................"}, ब्लॉक ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} का स्थायी निवासी है।")
          appendLine()
          appendLine("दिव्यांगता का विवरण:")
          appendLine("1. दिव्यांगता का प्रकार: ${values["disability_type"] ?: "—"}")
          appendLine("2. दिव्यांगता का प्रतिशत: ${values["disability_percent"] ?: "—"}")
          appendLine("3. समग्र सदस्य आईडी: ${values["samagra_id"] ?: "—"}")
          appendLine("4. आधार नंबर: ${values["aadhaar_no"] ?: "—"}")
          appendLine("5. चाही गई सहायता: ${values["relief_sought"] ?: "UDID कार्ड एवं मासिक पेंशन"}")
          appendLine()
          appendLine("प्रार्थी दैनिक जीवन में आत्मनिर्भरता हेतु शासन द्वारा प्रदत्त विधिक अधिकारों एवं सामाजिक सुरक्षा पेंशन का आकांक्षी है।")
          appendLine("अतः विनम्र प्रार्थना है कि प्रार्थी का मेडिकल बोर्ड परीक्षण कराकर UDID कार्ड व नियमानुसार दिव्यांग पेंशन स्वीकृत कराने की कृपा करें।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदक / अभिभावक के हस्ताक्षर / अंगूठा: _______________________")
        }
      }
      "tpl-pm-vishwakarma" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् महाप्रबंधक महोदय,")
          appendLine("जिला व्यापार एवं उद्योग केंद्र (DTIC),")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: प्रधानमंत्री विश्वकर्मा योजना अंतर्गत कारीगर पहचान, ₹15,000 टूलकिट व रियायती ऋण सहायता बाबत्।")
          appendLine()
          appendLine("महोदय,")
          appendLine("सविनय निवेदन है कि प्रार्थी ${values["applicant_name"] ?: "................"} आत्मज/पत्नी ${values["father_spouse"] ?: "................"}, निवासी ग्राम ${values["village"] ?: "................"}, ब्लॉक ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} का मूल निवासी एवं पारंपरिक कारीगर है।")
          appendLine()
          appendLine("कारीगरी एवं व्यवसाय विवरण:")
          appendLine("1. पारंपरिक ट्रेड (शिल्पकला): ${values["trade_name"] ?: "लोहार / बढ़ई / राजमिस्त्री"}")
          appendLine("2. कार्य अनुभव: ${values["experience_years"] ?: "—"}")
          appendLine("3. आधार कार्ड नंबर: ${values["aadhaar_no"] ?: "—"}")
          appendLine("4. बैंक खाता विवरण: ${values["bank_account"] ?: "—"}")
          appendLine("5. संपर्क मोबाइल: ${values["phone"] ?: "—"}")
          appendLine()
          appendLine("प्रार्थी अपने पुश्तैनी हुनर से परिवार का भरण-पोषण करता है। औजारों के आधुनिकीकरण एवं कार्य विस्तार हेतु पीएम विश्वकर्मा योजना के तहत पंजीयन कराकर ₹15,000 टूलकिट वाउचर एवं 5% ब्याज दर पर ऋण दिलाने की कृपा की जाए।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदक कारीगर के हस्ताक्षर / अंगूठा: _______________________")
        }
      }
      "tpl-akanksha" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् सहायक आयुक्त / संभागीय उपायुक्त महोदय,")
          appendLine("जनजातीय कार्य विभाग, मध्य प्रदेश शासन,")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: आकांक्षा योजना अंतर्गत राष्ट्रीय स्तर की प्रतियोगी परीक्षा (JEE/NEET/CLAT) हेतु निःशुल्क कोचिंग में प्रवेश बाबत्।")
          appendLine()
          appendLine("महोदय,")
          appendLine("सविनय निवेदन है कि प्रार्थी विद्यार्थी ${values["applicant_name"] ?: "................"} आत्मज ${values["father_name"] ?: "................"}, निवासी ग्राम ${values["village"] ?: "................"}, ब्लॉक ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} का मूल निवासी एवं अनुसूचित जनजाति (ST) वर्ग का प्रतिभावान छात्र है।")
          appendLine()
          appendLine("शैक्षणिक एवं पारिवारिक विवरण:")
          appendLine("1. कक्षा 10वीं के प्राप्तांक: ${values["class_10_percent"] ?: "—"}%")
          appendLine("2. उत्तीर्ण विद्यालय: ${values["school_name"] ?: "—"}")
          appendLine("3. लक्षित राष्ट्रीय प्रवेश परीक्षा: ${values["target_exam"] ?: "NEET / JEE / CLAT"}")
          appendLine("4. स्थाई डिजिटल जाति प्रमाण पत्र क्र.: ${values["caste_cert_no"] ?: "—"}")
          appendLine("5. परिवार की कुल वार्षिक आय: ${values["annual_income"] ?: "—"}")
          appendLine("6. इच्छित कोचिंग शहर: ${values["preferred_city"] ?: "भोपाल / इंदौर"}")
          appendLine("7. संपर्क मोबाइल नंबर: ${values["phone"] ?: "—"}")
          appendLine()
          appendLine("प्रार्थी उच्च शिक्षा में उत्कृष्ट प्रदर्शन कर समाज व देश की सेवा करना चाहता है। अतः आकांक्षा योजना की मेरिट चयन सूची में स्थान देकर प्रतिष्ठित कोचिंग केंद्र एवं निःशुल्क छात्रावास आवंटित करने की कृपा करें।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("विद्यार्थी के हस्ताक्षर: _______________________")
          appendLine("अभिभावक के हस्ताक्षर: _______________________")
        }
      }
      "tpl-fra-patta-vikas" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् मुख्य कार्यपालन अधिकारी (CEO), जनपद पंचायत /")
          appendLine("सहायक आयुक्त, जनजातीय कार्य विभाग,")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: वनाधिकार पट्टा धारक विकास योजना अंतर्गत कपिलधारा कूप / खेत समतलीकरण अनुदान स्वीकृति बाबत्।")
          appendLine()
          appendLine("महोदय / महोदया,")
          appendLine("सविनय निवेदन है कि प्रार्थी ${values["applicant_name"] ?: "................"} आत्मज ${values["father_spouse"] ?: "................"}, निवासी ग्राम ${values["village"] ?: "................"}, ग्राम पंचायत ${values["gram_panchayat"] ?: "................"}, जनपद पंचायत ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} का मूल निवासी एवं अनुसूचित जनजाति वर्ग का वनाधिकार पट्टाधारी कृषक है।")
          appendLine()
          appendLine("विधिक विवरण:")
          appendLine("1. वनाधिकार पट्टा क्रमांक: ${values["fra_patta_no"] ?: "—"}")
          appendLine("2. वनभूमि खसरा / कम्पार्टमेंट नंबर: ${values["khasra_no"] ?: "—"}")
          appendLine("3. आबंटित पट्टा भूमि का रकबा: ${values["land_area"] ?: "—"}")
          appendLine("4. चाही गई विकास सहायता: ${values["work_type"] ?: "कपिलधारा कूप निर्माण एवं खेत समतलीकरण"}")
          appendLine()
          appendLine("प्रार्थी के पास सिंचाई का कोई साधन नहीं है। वर्षा आधारित कृषि पर निर्भरता के कारण परिवार की आजीविका संकट में रहती है। मध्य प्रदेश शासन जनजातीय कार्य विभाग के परिपत्र अनुसार वनाधिकार पट्टा धारकों को कपिलधारा कूप व खेत सुधार का शत-प्रतिशत शासकीय अनुदान स्वीकृत करने का प्रावधान है।")
          appendLine()
          appendLine("अतः श्रीमान् से विनम्र प्रार्थना है कि स्थल निरीक्षण करवाकर प्रार्थी के पट्टे पर कपिलधारा कूप व भूमि विकास कार्य स्वीकृत कराने की कृपा करें।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदक: ${values["applicant_name"] ?: "................"} (मोबाइल: ${values["phone"] ?: "—"})")
          appendLine("हस्ताक्षर / अंगूठा निशानी: _______________________")
        }
      }
      "tpl-sahariya-aahar" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् बाल विकास परियोजना अधिकारी (CDPO) / सहायक आयुक्त,")
          appendLine("जनजातीय कार्य विभाग, जिला ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: विशेष पिछड़ी जनजाति (PVTG) आहार अनुदान योजना अंतर्गत ₹1,500 प्रतिमाह पोषण सहायता स्वीकृति बाबत्।")
          appendLine()
          appendLine("महोदय / महोदया,")
          appendLine("सविनय निवेदन है कि मैं ${values["applicant_name"] ?: "................"} पत्नी/पुत्री ${values["husband_father_name"] ?: "................"}, ग्राम ${values["village"] ?: "................"}, ग्राम पंचायत ${values["gram_panchayat"] ?: "................"}, जनपद पंचायत ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} की स्थायी निवासी हूँ।")
          appendLine("मैं मध्य प्रदेश की अधिसूचित विशेष पिछड़ी जनजाति (${values["pvtg_community"] ?: "सहरिया/बैगा/भारिया"}) समुदाय से संबंध रखती हूँ और अपने परिवार की महिला मुखिया हूँ।")
          appendLine()
          appendLine("पारिवारिक व बैंक विवरण:")
          appendLine("1. समग्र परिवार आईडी: ${values["samagra_family_id"] ?: "—"}")
          appendLine("2. महिला मुखिया सदस्य आईडी: ${values["samagra_member_id"] ?: "—"}")
          appendLine("3. आधार नंबर: ${values["aadhaar_no"] ?: "—"}")
          appendLine("4. बैंक खाता क्रमांक: ${values["bank_account_no"] ?: "—"}")
          appendLine("5. बैंक शाखा व IFSC: ${values["bank_name_ifsc"] ?: "—"}")
          appendLine()
          appendLine("मेरा बैंक खाता सक्रिय है और आधार NPCI DBT मैपर से लिंक है। शासन के नियमानुसार मुझे परिवार के पोषण आहार हेतु प्रतिमाह ₹1,500 की आहार अनुदान राशि सीधे खाते में अंतरित की जाने की कृपा की जाए।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदिका (महिला मुखिया): ${values["applicant_name"] ?: "................"}")
          appendLine("मोबाइल: ${values["phone"] ?: "—"}")
          appendLine("हस्ताक्षर / अंगूठा निशानी: _______________________")
        }
      }
      "tpl-dudharu-pashu" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् उपसंचालक महोदय,")
          appendLine("पशुपालन एवं डेयरी विकास विभाग,")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: मुख्यमंत्री दुधारू पशु प्रदाय योजना (90% अनुदान) अंतर्गत 2 दुधारू पशु प्रदाय हेतु आवेदन पत्र।")
          appendLine()
          appendLine("महोदय / महोदया,")
          appendLine("सविनय निवेदन है कि प्रार्थी ${values["applicant_name"] ?: "................"} आत्मज ${values["father_spouse"] ?: "................"}, निवासी ग्राम ${values["village"] ?: "................"}, ग्राम पंचायत ${values["gram_panchayat"] ?: "................"}, ब्लॉक ${values["block"] ?: "................"}, जिला ${values["district"] ?: "................"} का मूल निवासी है।")
          appendLine("प्रार्थी मध्य प्रदेश के अधिसूचित PVTG (${values["pvtg_community"] ?: "सहरिया/बैगा/भारिया"}) समुदाय से है।")
          appendLine()
          appendLine("आवेदन विवरण:")
          appendLine("1. इच्छित पशु विकल्प: ${values["cattle_type"] ?: "2 देशी दुधारू गाय"}")
          appendLine("2. 10% हितग्राही अंशदान वहन करने की सहमति: ${values["beneficiary_share"] ?: "पूर्णतः सहमत"}")
          appendLine("3. पशु बाड़ा व हरा चारा प्रबंधन: ${values["shed_facility"] ?: "पर्याप्त व्यवस्था उपलब्ध"}")
          appendLine()
          appendLine("प्रार्थी दुग्ध उत्पादन से परिवार की आजीविका को सुदृढ़ करने एवं बच्चों के पोषण सुधार हेतु पूर्ण समर्पित है।")
          appendLine("अतः श्रीमान् से प्रार्थना है कि शासन के 90% अनुदान नियम अनुसार प्रार्थी का प्रकरण स्वीकृत करने की कृपा करें।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदक: ${values["applicant_name"] ?: "................"} (मोबाइल: ${values["phone"] ?: "—"})")
          appendLine("हस्ताक्षर / अंगूठा निशानी: _______________________")
        }
      }
      "tpl-sbm-g" -> {
        buildString {
          appendLine("सेवा में,")
          appendLine("श्रीमान् सरपंच / सचिव महोदय, ग्राम पंचायत,")
          appendLine("ग्राम पंचायत: ${values["gram_panchayat"] ?: "........"}, ब्लॉक: ${values["block"] ?: "........"},")
          appendLine("जिला: ${values["district"] ?: "मध्य प्रदेश"}।")
          appendLine()
          appendLine("विषय: स्वच्छ भारत मिशन (ग्रामीण) अंतर्गत व्यक्तिगत घरेलू शौचालय (IHHL) ₹12,000 प्रोत्साहन राशि भुगतान बाबत्।")
          appendLine()
          appendLine("महोदय,")
          appendLine("सविनय निवेदन है कि प्रार्थी ${values["applicant_name"] ?: "................"} आत्मज/पत्नी ${values["father_spouse"] ?: "................"}, निवासी ग्राम ${values["village"] ?: "................"}, ग्राम पंचायत ${values["gram_panchayat"] ?: "................"}, जिला ${values["district"] ?: "................"} का मूल निवासी है।")
          appendLine()
          appendLine("विवरण:")
          appendLine("1. सामाजिक श्रेणी: ${values["category"] ?: "ST (सहरिया PVTG)"}")
          appendLine("2. मनरेगा जॉब कार्ड संख्या: ${values["job_card_no"] ?: "—"}")
          appendLine("3. शौचालय निर्माण पूर्ण माह/वर्ष: ${values["toilet_construction_date"] ?: "अक्टूबर 2026"}")
          appendLine("4. संपर्क मोबाइल नंबर: ${values["phone"] ?: "—"}")
          appendLine()
          appendLine("प्रार्थी ने अपने आवास परिसर में निर्धारित तकनीकी मानकों के अनुसार व्यक्तिगत घरेलू शौचालय का निर्माण पूर्ण कर लिया है और परिवार द्वारा उसका नियमित उपयोग किया जा रहा है।")
          appendLine("अतः श्रीमान् से प्रार्थना है कि निर्मित शौचालय का भौतिक सत्यापन एवं जियो-टैगिंग कराकर शासन द्वारा देय ₹12,000 की प्रोत्साहन राशि प्रार्थी के बैंक खाते में शीघ्र अंतरित कराने की कृपा करें।")
          appendLine()
          appendLine("संलग्नक:")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine("दिनांक: 31 अक्टूबर 2026")
          appendLine("आवेदक के हस्ताक्षर / अंगूठा निशानी: _______________________")
        }
      }
      else -> {
        buildString {
          appendLine("==================================================")
          appendLine(if (isHi) tpl.titleHindi else tpl.titleEnglish)
          appendLine(if (isHi) "प्रस्तुति: ${tpl.recipientAuthorityHindi}" else "To: ${tpl.recipientAuthorityEnglish}")
          appendLine(if (isHi) "दिनांक: 31 अक्टूबर 2026" else "Date: 31 October 2026")
          appendLine("==================================================")
          appendLine()
          appendLine(if (isHi) "महोदय / महोदया," else "Respected Authority,")
          appendLine(if (isHi) "सविनय निवेदन है कि उपरोक्त विषयांतर्गत निम्नलिखित विधिक तथ्यों पर यथोचित कार्यवाही करने की कृपा करें:" else "We respectfully submit the following statutory facts for immediate administrative action:")
          appendLine()

          tpl.fields.forEach { f ->
            val label = if (isHi) f.labelHindi else f.labelEnglish
            val value = values[f.key]?.ifBlank { "—" } ?: "—"
            appendLine("• $label: $value")
          }

          appendLine()
          appendLine(if (isHi) "संलग्नक (दस्तावेज़ सूची):" else "Enclosures (Documents Attached):")
          tpl.requiredDocuments.forEachIndexed { i, doc ->
            appendLine("  ${i + 1}. $doc")
          }
          appendLine()
          appendLine(if (isHi) "सत्यापन एवं घोषणा:" else "Verification & Declaration:")
          appendLine(if (isHi) {
            "मैं एतद्द्वारा घोषित करता/करती हूँ कि ऊपर दी गई समस्त जानकारी मेरे ज्ञान व विश्वास के अनुसार पूर्णतः सत्य एवं प्रामाणिक है।"
          } else {
            "I hereby solemnly affirm that all facts stated above are true, complete, and authentic to the best of my knowledge."
          })
          appendLine()
          appendLine(if (isHi) "आवेदक के हस्ताक्षर / अंगूठा निशानी: _______________________" else "Signature / Thumb Impression: _______________________")
        }
      }
    }

    generatedDocumentPreview.value = draft
  }

  fun publishStory(
    title: String,
    content: String,
    category: String,
    videoUrl: String?,
    audioNote: String? = null
  ) {
    val user = currentUser.value
    NyaySetuRepository.addStory(
      authorName = user?.name ?: "समुदाय सदस्य",
      authorRole = user?.role ?: UserRole.COMMUNITY_MEMBER,
      village = user?.village ?: "सहरिया बस्ती",
      district = user?.district ?: "श्योपुर (Sheopur)",
      title = title,
      content = content,
      category = category,
      videoUrl = videoUrl,
      audioNote = audioNote
    )
  }

  fun deleteStory(storyId: String) = NyaySetuRepository.deleteStory(storyId)
  fun updateStory(storyId: String, title: String, content: String, category: String, videoUrl: String?, audioNote: String? = null) =
    NyaySetuRepository.updateStory(storyId, title, content, category, videoUrl, audioNote)

  // Assistant Query & Voice Interaction
  fun processAiVoiceQuery(spokenText: String) {
    val q = spokenText.trim()
    if (q.isBlank()) return
    isListeningByVoice.value = false
    isProcessingAiQuery.value = true
    viewModelScope.launch {
      delay(350)
      val botMsg = NyaySetuRepository.sendAssistantQuery(q, assistantSelectedLanguage.value)
      isProcessingAiQuery.value = false
      if (aiAssistantSettings.value.autoSpeakResponse) {
        speak(botMsg.text, assistantSelectedLanguage.value != "en")
      }
    }
  }

  fun sendAssistantMessage() {
    val query = assistantInputText.value.trim()
    if (query.isBlank()) return
    assistantInputText.value = ""
    isProcessingAiQuery.value = true
    viewModelScope.launch {
      delay(250)
      val botMsg = NyaySetuRepository.sendAssistantQuery(query, assistantSelectedLanguage.value)
      isProcessingAiQuery.value = false
      if (aiAssistantSettings.value.autoSpeakResponse) {
        speak(botMsg.text, assistantSelectedLanguage.value != "en")
      }
    }
  }

  fun sendQuickAssistantPrompt(promptText: String) {
    isProcessingAiQuery.value = true
    viewModelScope.launch {
      delay(250)
      val botMsg = NyaySetuRepository.sendAssistantQuery(promptText, assistantSelectedLanguage.value)
      isProcessingAiQuery.value = false
      if (aiAssistantSettings.value.autoSpeakResponse) {
        speak(botMsg.text, assistantSelectedLanguage.value != "en")
      }
    }
  }

  fun submitAssistantFeedback(messageId: String, feedbackType: String) {
    NyaySetuRepository.recordAssistantFeedback(messageId, feedbackType)
  }

  fun updateAiAssistantSettings(settings: AiAssistantSettings) {
    NyaySetuRepository.updateAiAssistantSettings(settings)
  }

  fun resolveUnansweredQuestion(id: String) {
    NyaySetuRepository.resolveUnansweredQuestion(id)
  }

  fun clearAssistantHistory() {
    NyaySetuRepository.clearAssistantHistory()
  }

  fun repeatLastSpeech() {
    ttsHelper.repeatLast()
  }

  fun speak(text: String, isHindi: Boolean = true) {
    ttsHelper.speak(text, isHindi)
  }

  fun stopSpeech() {
    ttsHelper.stop()
  }

  override fun onCleared() {
    super.onCleared()
    ttsHelper.shutdown()
  }
}
