package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.AssistantMessage
import com.example.ui.components.jhsInputColors
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel
import com.example.viewmodel.ScreenTab
import java.util.Locale

@Composable
fun AiVoiceAssistantScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val context = LocalContext.current
  val messages by viewModel.assistantMessages.collectAsState()
  val inputText by viewModel.assistantInputText.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  val isListening by viewModel.isListeningByVoice.collectAsState()
  val isProcessing by viewModel.isProcessingAiQuery.collectAsState()
  val settings by viewModel.aiAssistantSettings.collectAsState()
  val selectedLang by viewModel.assistantSelectedLanguage.collectAsState()

  var showLanguageDialog by remember { mutableStateOf(false) }
  var feedbackToastMessage by remember { mutableStateOf<String?>(null) }
  var showSimulatedVoiceDialog by remember { mutableStateOf(false) }

  // Speech Recognizer Activity Result
  val sttLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    viewModel.isListeningByVoice.value = false
    if (result.resultCode == Activity.RESULT_OK && result.data != null) {
      val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
      val spoken = matches?.firstOrNull()
      if (!spoken.isNullOrBlank()) {
        viewModel.processAiVoiceQuery(spoken)
      }
    }
  }

  // Audio Recording Runtime Permission
  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    if (isGranted) {
      try {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
          putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
          val localeStr = when (selectedLang) {
            "en" -> "en-IN"
            else -> "hi-IN"
          }
          putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeStr)
          putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए, न्यायसेतु AI वाणी सहायक सुन रहा है...")
        }
        viewModel.isListeningByVoice.value = true
        sttLauncher.launch(intent)
      } catch (e: Exception) {
        viewModel.isListeningByVoice.value = false
        showSimulatedVoiceDialog = true
      }
    } else {
      showSimulatedVoiceDialog = true
    }
  }

  fun startVoiceInput() {
    val permCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
    if (permCheck == PackageManager.PERMISSION_GRANTED) {
      try {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
          putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
          val localeStr = if (selectedLang == "en") "en-IN" else "hi-IN"
          putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeStr)
          putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए, न्यायसेतु AI वाणी सहायक सुन रहा है...")
        }
        viewModel.isListeningByVoice.value = true
        sttLauncher.launch(intent)
      } catch (e: Exception) {
        viewModel.isListeningByVoice.value = false
        showSimulatedVoiceDialog = true
      }
    } else {
      permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  val quickPrompts = listOf(
    "जाति प्रमाण पत्र कैसे बनेगा?",
    "आहार अनुदान ₹1500 नहीं मिला",
    "वनाधिकार पट्टा (FRA) के नियम",
    "मनरेगा मजदूरी विलंब मुआवजा",
    "सरकारी फीस व अवैध वसूली नियम",
    "मुफ्त सरकारी वकील (DLSA 15100)",
    "सिकल सेल एनीमिया जांच केंद्र",
    "32 सरकारी पोर्टल लिंक",
    "मेरा केस कैसे ट्रैक करें?"
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp)
      .testTag("ai_voice_assistant_screen")
  ) {
    Spacer(modifier = Modifier.height(8.dp))

    // 1. Assistant Identity & Controls Header Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = JhsWhite),
      border = BorderStroke(1.dp, JhsBorder),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(JhsTeal),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "JHS AI वाणी सहायक (Voice Assistant)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = JhsHeadingText
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (settings.isEnabled) JhsTeal else Color.Gray)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (settings.isEnabled) "सत्यापित डेटाबेस से सक्रिय" else "निष्क्रिय",
                  fontSize = 11.sp,
                  color = JhsSecondaryText
                )
              }
            }
          }

          // Language Selector Pill
          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsBorder),
            modifier = Modifier.clickable { showLanguageDialog = true }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Translate, contentDescription = "Language", tint = JhsTeal, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = when (selectedLang) {
                  "en" -> "English"
                  "bundeli_sahariya" -> "बुंदेली/सहरिया"
                  else -> "हिंदी"
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTeal
              )
            }
          }
        }

        // Secondary Audio Control Strip
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            // Auto-speak Toggle
            AssistChip(
              onClick = {
                viewModel.updateAiAssistantSettings(
                  settings.copy(autoSpeakResponse = !settings.autoSpeakResponse)
                )
              },
              label = {
                Text(
                  text = if (settings.autoSpeakResponse) "ध्वनि वाचन: चालू" else "ध्वनि वाचन: म्यूट",
                  fontSize = 11.sp
                )
              },
              leadingIcon = {
                Icon(
                  if (settings.autoSpeakResponse) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                  contentDescription = null,
                  modifier = Modifier.size(14.dp),
                  tint = if (settings.autoSpeakResponse) JhsTeal else Color.Gray
                )
              },
              shape = RoundedCornerShape(8.dp)
            )

            // Repeat last spoken
            IconButton(
              onClick = { viewModel.repeatLastSpeech() },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Default.Replay, contentDescription = "Repeat", tint = JhsHeadingText, modifier = Modifier.size(18.dp))
            }

            // Stop Speaking
            if (isSpeaking) {
              FilledTonalButton(
                onClick = { viewModel.stopSpeech() },
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = JhsTerracottaContainer, contentColor = JhsTerracotta),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(28.dp)
              ) {
                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("रोकें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          // Clear history button
          TextButton(
            onClick = { viewModel.clearAssistantHistory() },
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
          ) {
            Text("इतिहास हटाएं", fontSize = 11.sp, color = JhsSecondaryText)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // 2. Interactive Voice Microphone Box with Animated Sound Waves
    VoiceMicrophoneInteractionBox(
      isListening = isListening,
      isProcessing = isProcessing,
      isSpeaking = isSpeaking,
      onMicClick = {
        if (isSpeaking) {
          viewModel.stopSpeech()
        }
        startVoiceInput()
      }
    )

    Spacer(modifier = Modifier.height(8.dp))

    // 3. Quick Suggestion Prompts Horizontal Scroll
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(quickPrompts) { prompt ->
        SuggestionChip(
          onClick = { viewModel.sendQuickAssistantPrompt(prompt) },
          label = { Text(prompt, fontSize = 12.sp, color = JhsHeadingText) },
          shape = RoundedCornerShape(10.dp),
          colors = SuggestionChipDefaults.suggestionChipColors(containerColor = JhsWhite),
          border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = JhsBorder)
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Toast acknowledgement if user provided feedback
    if (feedbackToastMessage != null) {
      Surface(
        color = JhsTealContainer,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = feedbackToastMessage ?: "", fontSize = 11.sp, color = JhsTealDark, fontWeight = FontWeight.SemiBold)
          IconButton(onClick = { feedbackToastMessage = null }, modifier = Modifier.size(20.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(14.dp), tint = JhsTealDark)
          }
        }
      }
    }

    // 4. Conversation Messages Stream
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      contentPadding = PaddingValues(vertical = 8.dp)
    ) {
      if (messages.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JhsSecondaryBg.copy(alpha = 0.5f)),
            border = BorderStroke(1.dp, JhsBorder)
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(Icons.Default.Hearing, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(36.dp))
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "नमस्ते! मैं आपका न्यायसेतु AI वाणी सहायक हूँ।",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = JhsHeadingText,
                textAlign = TextAlign.Center
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "माइक बटन दबाकर बोलें या नीचे लिखें। मैं मध्य प्रदेश की सरकारी योजनाओं, 16 जरूरी कागजातों, वनाधिकार (FRA), CM 181 और विधिक अधिकारों की पूरी सत्यापित जानकारी दूंगा।",
                fontSize = 12.sp,
                color = JhsSecondaryText,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
              )
            }
          }
        }
      }

      items(messages) { msg ->
        AssistantMessageBubble(
          message = msg,
          viewModel = viewModel,
          onFeedbackGiven = { feedbackText ->
            feedbackToastMessage = "प्रतिक्रिया दर्ज हुई: $feedbackText (JHS गुणवत्ता टीम को भेजी गई)"
          }
        )
      }
    }

    // 5. Bottom Text Input Bar with Mic Icon
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 75.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      OutlinedTextField(
        value = inputText,
        onValueChange = { viewModel.assistantInputText.value = it },
        placeholder = { Text("प्रश्न पूछें (उदा. जाति प्रमाण पत्र कैसे बनेगा)...", fontSize = 12.sp, color = JhsPlaceholderText) },
        shape = RoundedCornerShape(12.dp),
        colors = jhsInputColors(),
        modifier = Modifier
          .weight(1f)
          .testTag("assistant_input_text"),
        singleLine = true,
        leadingIcon = {
          IconButton(onClick = { startVoiceInput() }) {
            Icon(Icons.Default.Mic, contentDescription = "Voice Input", tint = JhsTeal)
          }
        }
      )

      FilledIconButton(
        onClick = { viewModel.sendAssistantMessage() },
        colors = IconButtonDefaults.filledIconButtonColors(containerColor = JhsTeal),
        modifier = Modifier
          .size(48.dp)
          .testTag("assistant_send_button")
      ) {
        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
      }
    }
  }

  // Language Selection Dialog
  if (showLanguageDialog) {
    AlertDialog(
      onDismissRequest = { showLanguageDialog = false },
      title = { Text("सहायक की भाषा चुनें (Select Language)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          val langs = listOf(
            Triple("hi", "हिंदी (Hindi)", "मानक सरल हिंदी"),
            Triple("bundeli_sahariya", "बुंदेली / सहरिया (Rural)", "ग्रामीण बोलचाल एवं स्थानीय शब्द"),
            Triple("en", "English", "Clear and simple English")
          )
          langs.forEach { (code, title, desc) ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  viewModel.assistantSelectedLanguage.value = code
                  showLanguageDialog = false
                },
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(
                containerColor = if (selectedLang == code) JhsTealContainer else JhsWhite
              ),
              border = BorderStroke(1.dp, if (selectedLang == code) JhsTeal else JhsBorder)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
                Text(text = desc, fontSize = 11.sp, color = JhsSecondaryText)
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showLanguageDialog = false }) {
          Text("बंद करें", color = JhsTeal)
        }
      }
    )
  }

  // Simulated Voice Input Dialog (Fallback for emulators without speech recognition service)
  if (showSimulatedVoiceDialog) {
    var customQuery by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showSimulatedVoiceDialog = false },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Mic, contentDescription = null, tint = JhsTeal)
          Spacer(modifier = Modifier.width(8.dp))
          Text("बोलकर पूछें (Voice Assistant)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "नीचे दिए गए लोकप्रिय प्रश्नों में से चुनें अथवा अपना प्रश्न बोलकर दर्ज करें:",
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
          OutlinedTextField(
            value = customQuery,
            onValueChange = { customQuery = it },
            placeholder = { Text("उदा. जाति प्रमाण पत्र कैसे बनेगा?") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )
          Text(text = "त्वरित विकल्प:", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = JhsHeadingText)
          listOf(
            "मुझे जाति प्रमाण पत्र बनवाना है, क्या कागज लगेंगे?",
            "आहार अनुदान ₹1500 की राशि खाते में नहीं आई",
            "वनाधिकार 4 हेक्टेयर पट्टा कैसे प्राप्त करें?",
            "मनरेगा में 15 दिन बाद भी मजदूरी नहीं मिली"
          ).forEach { sample ->
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  showSimulatedVoiceDialog = false
                  viewModel.processAiVoiceQuery(sample)
                }
            ) {
              Text(text = "🗣️ $sample", fontSize = 11.sp, modifier = Modifier.padding(8.dp), color = JhsHeadingText)
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (customQuery.isNotBlank()) {
              showSimulatedVoiceDialog = false
              viewModel.processAiVoiceQuery(customQuery)
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = JhsTeal)
        ) {
          Text("प्रश्न भेजें")
        }
      },
      dismissButton = {
        TextButton(onClick = { showSimulatedVoiceDialog = false }) {
          Text("रद्द करें")
        }
      }
    )
  }
}

/**
 * Animated Microphone Box displaying ripples, sound waves, and state indicator
 */
@Composable
fun VoiceMicrophoneInteractionBox(
  isListening: Boolean,
  isProcessing: Boolean,
  isSpeaking: Boolean,
  onMicClick: () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "mic_waves")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = if (isListening || isSpeaking) 1.15f else 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_scale"
  )

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = when {
        isListening -> JhsTerracottaContainer.copy(alpha = 0.5f)
        isProcessing -> JhsGoldContainer.copy(alpha = 0.5f)
        isSpeaking -> JhsTealContainer.copy(alpha = 0.6f)
        else -> JhsSecondaryBg
      }
    ),
    border = BorderStroke(
      1.dp,
      when {
        isListening -> JhsTerracotta
        isProcessing -> JhsGold
        isSpeaking -> JhsTeal
        else -> JhsBorder
      }
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(contentAlignment = Alignment.Center) {
        // Outer pulsing ring when active
        if (isListening || isSpeaking) {
          Box(
            modifier = Modifier
              .size(76.dp)
              .scale(pulseScale)
              .clip(CircleShape)
              .background(if (isListening) JhsTerracotta.copy(alpha = 0.25f) else JhsTeal.copy(alpha = 0.25f))
          )
        }

        // Central Microphone Button
        FilledIconButton(
          onClick = onMicClick,
          colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = when {
              isListening -> JhsTerracotta
              isProcessing -> JhsGoldDark
              isSpeaking -> JhsTealDark
              else -> JhsTeal
            }
          ),
          modifier = Modifier
            .size(62.dp)
            .testTag("voice_assistant_mic_button")
        ) {
          Icon(
            imageVector = when {
              isListening -> Icons.Default.Mic
              isProcessing -> Icons.Default.HourglassTop
              isSpeaking -> Icons.Default.VolumeUp
              else -> Icons.Default.Mic
            },
            contentDescription = "Microphone",
            tint = Color.White,
            modifier = Modifier.size(32.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = when {
          isListening -> "🎙️ बोलिए, मैं ध्यान से सुन रहा हूँ..."
          isProcessing -> "⏳ सत्यापित डेटाबेस में खोज व विश्लेषण हो रहा है..."
          isSpeaking -> "🔊 उत्तर वाचन जारी है... (माइक दबाकर रोकें)"
          else -> "बोलकर प्रश्न पूछने के लिए माइक दबाएं"
        },
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = when {
          isListening -> JhsTerracotta
          isProcessing -> JhsGoldDark
          isSpeaking -> JhsTealDark
          else -> JhsHeadingText
        }
      )

      Text(
        text = "सहरिया, बुंदेली, हिंदी अथवा हिंगलिश में सीधे बात करें",
        fontSize = 11.sp,
        color = JhsSecondaryText
      )
    }
  }
}

/**
 * Message Bubble with source verification badge, step list, and feedback buttons
 */
@Composable
fun AssistantMessageBubble(
  message: AssistantMessage,
  viewModel: NyaySetuViewModel,
  onFeedbackGiven: (String) -> Unit
) {
  val context = LocalContext.current
  val isUser = message.isUser

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
  ) {
    if (!isUser) {
      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(JhsTeal),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
      }
      Spacer(modifier = Modifier.width(8.dp))
    }

    Card(
      shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (isUser) 16.dp else 4.dp,
        bottomEnd = if (isUser) 4.dp else 16.dp
      ),
      colors = CardDefaults.cardColors(
        containerColor = if (isUser) JhsTeal else JhsWhite
      ),
      border = if (isUser) null else BorderStroke(1.dp, JhsBorder),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      modifier = Modifier.widthIn(max = 320.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        // Verification badge for Assistant
        if (!isUser) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = if (message.verificationStatus == "Information Not Available") JhsTerracottaContainer else JhsTealContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  if (message.verificationStatus == "Information Not Available") Icons.Default.Info else Icons.Default.Verified,
                  contentDescription = null,
                  tint = if (message.verificationStatus == "Information Not Available") JhsTerracotta else JhsTeal,
                  modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = message.verificationStatus ?: "JHS Verified",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (message.verificationStatus == "Information Not Available") JhsTerracotta else JhsTealDark
                )
              }
            }

            // Audio Listen Button for this specific message
            IconButton(
              onClick = { viewModel.speak(message.text) },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(Icons.Default.VolumeUp, contentDescription = "Listen", tint = JhsTeal, modifier = Modifier.size(16.dp))
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
        }

        // Message text
        Text(
          text = message.text,
          fontSize = 13.sp,
          lineHeight = 18.sp,
          color = if (isUser) Color.White else JhsHeadingText
        )

        // Portal link if available
        if (!message.portalUrl.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, JhsBorder),
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(message.portalUrl))
                context.startActivity(intent)
              }
          ) {
            Row(
              modifier = Modifier.padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.OpenInNew, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "आधिकारिक पोर्टल खोलें (${message.portalUrl})",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = JhsTeal
              )
            }
          }
        }

        // Quick In-App Action Button
        if (!message.quickAction.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(8.dp))
          when (message.quickAction) {
            "OPEN_TRACKER" -> {
              FilledTonalButton(
                onClick = { viewModel.setTab(ScreenTab.TRACK) },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = JhsSecondaryBg, contentColor = JhsTeal),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text("केस स्थिति देखें (Track Tab) ➔", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              }
            }
            "OPEN_SCHEMES" -> {
              FilledTonalButton(
                onClick = { viewModel.setTab(ScreenTab.SCHEMES) },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = JhsSecondaryBg, contentColor = JhsTeal),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text("सरकारी योजनाएं देखें ➔", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              }
            }
            "OPEN_BUILDER" -> {
              FilledTonalButton(
                onClick = { viewModel.setTab(ScreenTab.BUILDER) },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = JhsSecondaryBg, contentColor = JhsTeal),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text("आवेदन तैयार करें ➔", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              }
            }
            "CALL_HELPDESK" -> {
              Button(
                onClick = {
                  val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:7440323972"))
                  context.startActivity(intent)
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text("7440323972 पर फोन लगाएं 📞", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              }
            }
          }
        }

        // Feedback Bar for Assistant Responses
        if (!isUser) {
          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(color = JhsBorder.copy(alpha = 0.6f))
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "क्या यह उत्तर उपयोगी था?", fontSize = 10.sp, color = JhsSecondaryText)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              IconButton(
                onClick = {
                  viewModel.submitAssistantFeedback(message.id, "HELPFUL")
                  onFeedbackGiven("उपयोगी (Helpful)")
                },
                modifier = Modifier.size(24.dp)
              ) {
                Text("👍", fontSize = 12.sp)
              }
              IconButton(
                onClick = {
                  viewModel.submitAssistantFeedback(message.id, "NOT_HELPFUL")
                  onFeedbackGiven("उपयोगी नहीं (Not Helpful)")
                },
                modifier = Modifier.size(24.dp)
              ) {
                Text("👎", fontSize = 12.sp)
              }
              IconButton(
                onClick = {
                  viewModel.submitAssistantFeedback(message.id, "INCORRECT")
                  onFeedbackGiven("गलत जानकारी (Incorrect)")
                },
                modifier = Modifier.size(24.dp)
              ) {
                Text("⚠️", fontSize = 12.sp)
              }
              IconButton(
                onClick = {
                  viewModel.submitAssistantFeedback(message.id, "INCOMPLETE")
                  onFeedbackGiven("अधूरी जानकारी (Incomplete)")
                },
                modifier = Modifier.size(24.dp)
              ) {
                Text("📝", fontSize = 12.sp)
              }
            }
          }
        }
      }
    }
  }
}
