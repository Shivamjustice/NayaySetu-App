package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel
import com.example.viewmodel.ScreenTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val user by viewModel.currentUser.collectAsState()
  val highContrast by viewModel.highContrastMode.collectAsState()
  val fontScale by viewModel.fontScaleLevel.collectAsState()
  val notifications by viewModel.notifications.collectAsState()
  val unreadCount = notifications.count { !it.isRead }

  val activeTab by viewModel.activeTab.collectAsState()

  Surface(
    color = MaterialTheme.colorScheme.primary,
    contentColor = MaterialTheme.colorScheme.onPrimary,
    tonalElevation = 4.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Back Button if on subscreen
        if (activeTab != ScreenTab.HOME) {
          IconButton(
            onClick = { viewModel.setTab(ScreenTab.HOME) },
            modifier = Modifier.size(36.dp).testTag("topbar_back_button")
          ) {
            Icon(
              imageVector = Icons.Default.ArrowBack,
              contentDescription = "Back to Home",
              tint = Color.White
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
        }

        // App Identity with Official JHS Emblem
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .weight(1f)
            .clickable { viewModel.setTab(ScreenTab.ABOUT_JHS) }
        ) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Color.White),
            contentAlignment = Alignment.Center
          ) {
            Image(
              painter = painterResource(id = R.drawable.jhs_emblem),
              contentDescription = "JHS Emblem",
              contentScale = ContentScale.Fit,
              modifier = Modifier.size(34.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = when (lang) {
                "en" -> "NyaySetu"
                "hinglish" -> "NyaySetu"
                else -> "न्यायसेतु"
              },
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
              )
            )
            Text(
              text = "Justice Hub Society (JHS)",
              style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
              )
            )
          }
        }

        // Accessibility & Utility Controls
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          // Trilingual Language Dropdown Selector (हिन्दी / English / Hinglish)
          var showLangMenu by remember { mutableStateOf(false) }

          Box {
            OutlinedButton(
              onClick = { showLangMenu = true },
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color.White.copy(alpha = 0.2f),
                contentColor = Color.White
              ),
              shape = RoundedCornerShape(14.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
              modifier = Modifier
                .defaultMinSize(minHeight = 32.dp)
                .testTag("lang_toggle_button")
            ) {
              Text(
                text = when (lang) {
                  "hi" -> "हिन्दी ▼"
                  "hinglish" -> "Hinglish ▼"
                  else -> "English ▼"
                },
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
              )
            }

            DropdownMenu(
              expanded = showLangMenu,
              onDismissRequest = { showLangMenu = false },
              modifier = Modifier.background(Color.White)
            ) {
              DropdownMenuItem(
                text = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "🇮🇳 हिन्दी (Hindi)",
                      fontWeight = if (lang == "hi") FontWeight.Bold else FontWeight.Normal,
                      color = if (lang == "hi") JhsTeal else JhsHeadingText,
                      fontSize = 13.sp
                    )
                    if (lang == "hi") {
                      Spacer(modifier = Modifier.width(8.dp))
                      Icon(Icons.Default.Check, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
                    }
                  }
                },
                onClick = {
                  viewModel.setLanguage("hi")
                  showLangMenu = false
                }
              )
              DropdownMenuItem(
                text = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "🌐 English",
                      fontWeight = if (lang == "en") FontWeight.Bold else FontWeight.Normal,
                      color = if (lang == "en") JhsTeal else JhsHeadingText,
                      fontSize = 13.sp
                    )
                    if (lang == "en") {
                      Spacer(modifier = Modifier.width(8.dp))
                      Icon(Icons.Default.Check, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
                    }
                  }
                },
                onClick = {
                  viewModel.setLanguage("en")
                  showLangMenu = false
                }
              )
              DropdownMenuItem(
                text = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "💬 Hinglish (मिक्स)",
                      fontWeight = if (lang == "hinglish") FontWeight.Bold else FontWeight.Normal,
                      color = if (lang == "hinglish") JhsTeal else JhsHeadingText,
                      fontSize = 13.sp
                    )
                    if (lang == "hinglish") {
                      Spacer(modifier = Modifier.width(8.dp))
                      Icon(Icons.Default.Check, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
                    }
                  }
                },
                onClick = {
                  viewModel.setLanguage("hinglish")
                  showLangMenu = false
                }
              )
            }
          }

          // Text Size Switcher
          IconButton(
            onClick = { viewModel.cycleFontScale() },
            modifier = Modifier
              .size(34.dp)
              .testTag("font_scale_button")
          ) {
            val scaleLabel = when (fontScale) {
              0 -> "A"
              1 -> "A+"
              else -> "A++"
            }
            Text(
              text = scaleLabel,
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }

          // High Contrast Sunlight Mode Toggle
          IconButton(
            onClick = { viewModel.toggleHighContrast() },
            modifier = Modifier
              .size(34.dp)
              .testTag("sunlight_mode_button")
          ) {
            Icon(
              imageVector = if (highContrast) Icons.Default.WbSunny else Icons.Outlined.WbSunny,
              contentDescription = "Sunlight Mode",
              tint = if (highContrast) JhsGold else Color.White,
              modifier = Modifier.size(18.dp)
            )
          }

          // Notifications Bell
          IconButton(
            onClick = { viewModel.isNotificationDrawerOpen.value = true },
            modifier = Modifier
              .size(34.dp)
              .testTag("notifications_button")
          ) {
            BadgedBox(
              badge = {
                if (unreadCount > 0) {
                  Badge(
                    containerColor = JhsTerracotta,
                    contentColor = Color.White
                  ) {
                    Text("$unreadCount")
                  }
                }
              }
            ) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notifications",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          // Profile Avatar Icon
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(Color(user?.avatarColorHex ?: 0xFFC56A3D))
              .clickable { viewModel.setTab(ScreenTab.PROFILE) }
              .testTag("topbar_profile_button"),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = user?.name?.take(1) ?: "U",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      }

      // Role Pill & Slogan Strip
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        val isCloudConnected by com.example.data.FirestoreSyncManager.isCloudConnected.collectAsState()
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = viewModel.tr("अधिकार से न्याय तक | समुदाय से बदलाव तक", "From Rights to Justice | Community to Change", "Adhikar Se Nyay Tak | Samuday Se Badlav"),
            style = MaterialTheme.typography.labelSmall.copy(
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f),
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold
            ),
            maxLines = 1,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Surface(
            color = if (isCloudConnected) Color(0xFF1B5E20).copy(alpha = 0.6f) else Color.White.copy(alpha = 0.2f),
            shape = RoundedCornerShape(8.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .clip(CircleShape)
                  .background(if (isCloudConnected) Color(0xFF69F0AE) else Color(0xFFFFB74D))
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = if (isCloudConnected) {
                  viewModel.tr("ऑनलाइन (Cloud)", "Online (Cloud)", "Online (Cloud)")
                } else {
                  viewModel.tr("ऑफ़लाइन", "Offline", "Offline")
                },
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                softWrap = false
              )
            }
          }
        }

        Spacer(modifier = Modifier.width(6.dp))

        Surface(
          onClick = {
            if (user?.role == UserRole.ADMIN || user?.role == UserRole.DEPT_ADMIN) {
              viewModel.setTab(ScreenTab.ADMIN)
            } else {
              viewModel.setTab(ScreenTab.PROFILE)
            }
          },
          color = if (user?.role == UserRole.ADMIN || user?.role == UserRole.DEPT_ADMIN) JhsTerracotta else Color.White.copy(alpha = 0.2f),
          shape = RoundedCornerShape(10.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
          ) {
            Icon(
              imageVector = if (user?.role == UserRole.ADMIN || user?.role == UserRole.DEPT_ADMIN) Icons.Default.AdminPanelSettings else Icons.Default.Person,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = user?.role?.labelFor(lang) ?: viewModel.tr("नागरिक", "Citizen", "Citizen"),
              style = MaterialTheme.typography.labelSmall.copy(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
              ),
              maxLines = 1,
              softWrap = false
            )
          }
        }
      }
    }
  }
}
