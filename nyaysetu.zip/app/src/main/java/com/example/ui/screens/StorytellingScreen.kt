package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NyaySetuRepository
import com.example.model.StoryItem
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun StorytellingScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val stories by viewModel.stories.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  val context = LocalContext.current

  var showAddStoryDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Storytelling Header
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = viewModel.tr("समुदाय की आवाज व कहानियाँ", "Community Voices & Storytelling", "Community Stories & Video Feed"),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Text(
                text = viewModel.tr(
                  "वनाधिकार, आजीविका व न्याय संघर्ष के जमीनी अनुभव",
                  "Grassroots experiences of rights, justice and empowerment",
                  "Zameeni sangharsh, photos, videos aur jeet ki kahaniyan"
                ),
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
            }

            Button(
              onClick = { showAddStoryDialog = true },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
              modifier = Modifier.testTag("add_story_button")
            ) {
              Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(viewModel.tr("कहानी जोड़ें", "Share Story", "Post Story"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 2. Story Feed Items
    items(stories) { story ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Author Header
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(JhsTeal),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = story.authorName.take(1),
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = story.authorName,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
                Text(
                  text = "${story.village}, ${story.district} • ${story.timestamp}",
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.outline
                )
              }
            }

            Surface(
              color = JhsGoldContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = story.category,
                color = JhsOnGoldContainer,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Story Title
          Text(
            text = when (lang) {
              "en" -> story.titleEn
              "hinglish" -> story.titleHinglish
              else -> story.titleHi
            },
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = JhsTealDark
            )
          )

          Spacer(modifier = Modifier.height(6.dp))

          // Story Content
          Text(
            text = when (lang) {
              "en" -> story.contentEn
              "hinglish" -> story.contentHinglish
              else -> story.contentHi
            },
            fontSize = 12.sp,
            lineHeight = 17.sp,
            color = MaterialTheme.colorScheme.onSurface
          )

          // Video / Media link banner if available
          if (!story.videoUrl.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(story.videoUrl))
                context.startActivity(intent)
              },
              color = JhsTerracotta.copy(alpha = 0.1f),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.PlayCircle, contentDescription = null, tint = JhsTerracotta)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = viewModel.tr("समुदाय वीडियो डॉक्युमेंट्री देखें", "Watch Community Video Documentary", "Community Video dekhein"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = JhsTerracottaDark
                  )
                  Text(
                    text = "वीडियो लिंक / मोबाइल क्लिप पर क्लिक करें",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.outline
                  )
                }
              }
            }
          }

          // Audio voice note banner if available
          if (!story.audioNote.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
              onClick = {
                try {
                  val intent = Intent(Intent.ACTION_VIEW, Uri.parse(story.audioNote))
                  context.startActivity(intent)
                } catch (e: Exception) {
                  viewModel.speak("ध्वनि संदेश: ${story.titleHi}")
                }
              },
              color = JhsTealContainer,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.dp, JhsSubtleTealBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Audiotrack, contentDescription = null, tint = JhsTeal)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "संलग्न ध्वनि रिकॉर्डिंग (Audio Note)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = JhsTealDark
                  )
                  Text(
                    text = "सुनने हेतु क्लिक करें",
                    fontSize = 10.sp,
                    color = JhsSecondaryText
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Footer: Likes, Read Aloud Audio, and Share
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { NyaySetuRepository.likeStory(story.id) },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Favorite,
                  contentDescription = "Like",
                  tint = JhsTerracotta,
                  modifier = Modifier.size(20.dp)
                )
              }
              Text(
                text = "${story.likesCount} ${viewModel.tr("सराहना", "Applauds", "Likes")}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              // Audio button
              IconButton(
                onClick = {
                  if (isSpeaking) {
                    viewModel.stopSpeech()
                  } else {
                    val readText = when (lang) {
                      "en" -> "${story.titleEn}. By ${story.authorName}. ${story.contentEn}"
                      else -> "${story.titleHi}। लेखक: ${story.authorName}। ${story.contentHi}"
                    }
                    viewModel.speak(readText)
                  }
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                  contentDescription = "Listen Story",
                  tint = JhsTeal
                )
              }

              // Share button
              IconButton(
                onClick = {
                  val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "NyaySetu Community Voice:\n${story.titleHi}\n\n${story.contentHi}\n\nShared via NyaySetu App")
                  }
                  context.startActivity(Intent.createChooser(shareIntent, "Share Story"))
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Share,
                  contentDescription = "Share",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    }
  }

  // Dialog: Share New Story
  if (showAddStoryDialog) {
    var sTitle by remember { mutableStateOf("") }
    var sContent by remember { mutableStateOf("") }
    var sCategory by remember { mutableStateOf("वनाधिकार जीत") }
    var sVideoUrl by remember { mutableStateOf("") }
    var sAudioNote by remember { mutableStateOf("") }

    val videoPickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
      contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
      uri?.let { sVideoUrl = it.toString() }
    }

    val audioPickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
      contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
      uri?.let { sAudioNote = it.toString() }
    }

    AlertDialog(
      onDismissRequest = { showAddStoryDialog = false },
      title = {
        Text(
          text = viewModel.tr("अपनी कहानी या अनुभव साझा करें", "Share Your Story or Experience", "Apni Kahani Post Karein"),
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = sTitle,
            onValueChange = { sTitle = it },
            label = { Text(viewModel.tr("कहानी का शीर्षक *", "Story Title *", "Title *")) },
            placeholder = { Text("उदा. हमारी ग्राम सभा की जीत") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = sContent,
            onValueChange = { sContent = it },
            label = { Text(viewModel.tr("आपका अनुभव / कहानी *", "Story Content *", "Aapki Kahani *")) },
            placeholder = { Text("विस्तार से लिखें कि क्या समस्या थी और समाधान कैसे हुआ...") },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = sCategory,
            onValueChange = { sCategory = it },
            label = { Text(viewModel.tr("श्रेणी", "Category", "Category")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          // Mobile Media Pickers Row (Video and Audio)
          Text(
            text = "मोबाइल से वीडियो या ऑडियो जोड़ें:",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = JhsHeadingText
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = { videoPickerLauncher.launch("video/*") },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp), tint = JhsTerracotta)
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (sVideoUrl.isNotBlank()) "वीडियो जुड़ा" else "वीडियो चुनें", fontSize = 11.sp)
            }

            OutlinedButton(
              onClick = { audioPickerLauncher.launch("audio/*") },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp), tint = JhsTeal)
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (sAudioNote.isNotBlank()) "ऑडियो जुड़ा" else "ऑडियो चुनें", fontSize = 11.sp)
            }
          }

          if (sVideoUrl.isNotBlank()) {
            Text(
              text = "🎥 वीडियो: ${sVideoUrl.takeLast(28)}",
              fontSize = 10.sp,
              color = JhsTerracottaDark,
              maxLines = 1
            )
          }

          if (sAudioNote.isNotBlank()) {
            Text(
              text = "🎙️ ऑडियो: ${sAudioNote.takeLast(28)}",
              fontSize = 10.sp,
              color = JhsTealDark,
              maxLines = 1
            )
          }

          OutlinedTextField(
            value = sVideoUrl,
            onValueChange = { sVideoUrl = it },
            label = { Text(viewModel.tr("वीडियो लिंक (वैकल्पिक यूट्यूब)", "Video URL (Optional)", "Video Link")) },
            placeholder = { Text("https://youtube.com/...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (sTitle.isNotBlank() && sContent.isNotBlank()) {
              viewModel.publishStory(sTitle, sContent, sCategory, sVideoUrl, sAudioNote)
              showAddStoryDialog = false
            }
          }
        ) {
          Text(viewModel.tr("प्रकाशित करें", "Publish Story", "Publish Karein"))
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddStoryDialog = false }) {
          Text(viewModel.tr("रद्द करें", "Cancel", "Cancel"))
        }
      }
    )
  }
}
