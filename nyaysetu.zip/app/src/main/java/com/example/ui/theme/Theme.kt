package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// NyaySetu Light, Soft & Clean Colour Scheme
// Main Background: Soft Cream (#FAF7F0)
// Card Background: Pure White (#FFFFFF)
// Primary Colour: Teal (#176B63)
// Secondary Colour: Light Beige (#F1EBDD)
// Accent Colour: Soft Terracotta (#C56A3D)
// Highlight Colour: Muted Gold (#E3A72F)
// Text Colour: Dark Charcoal (#263238)
private val LightColorScheme = lightColorScheme(
  primary = JhsTeal,
  onPrimary = Color.White,
  primaryContainer = JhsSecondaryButtonBg,
  onPrimaryContainer = JhsOnTealContainer,
  secondary = JhsSecondaryBg,
  onSecondary = JhsHeadingText,
  secondaryContainer = JhsSecondaryBg,
  onSecondaryContainer = JhsHeadingText,
  tertiary = JhsTerracotta,
  onTertiary = Color.White,
  tertiaryContainer = JhsTerracottaContainer,
  onTertiaryContainer = JhsOnTerracottaContainer,
  background = JhsCream,
  onBackground = JhsHeadingText,
  surface = JhsWhite,
  onSurface = JhsHeadingText,
  surfaceVariant = JhsSecondaryBg,
  onSurfaceVariant = JhsSecondaryText,
  outline = JhsBorder,
  outlineVariant = JhsBorderSubtle
)

private val HighContrastColorScheme = lightColorScheme(
  primary = Color(0xFF0B443E),
  onPrimary = Color.White,
  primaryContainer = Color(0xFFB2DFDB),
  onPrimaryContainer = Color.Black,
  secondary = Color(0xFF8D360B),
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFFFCCBC),
  onSecondaryContainer = Color.Black,
  tertiary = Color(0xFF8F6000),
  onTertiary = Color.White,
  background = Color.White,
  onBackground = Color.Black,
  surface = Color.White,
  onSurface = Color.Black,
  surfaceVariant = Color(0xFFEFEFEF),
  onSurfaceVariant = Color.Black,
  outline = Color.Black
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false, // Always enforce the peaceful light & soft cream theme
  highContrast: Boolean = false,
  dynamicColor: Boolean = false, // Preserve branded JHS teal/terracotta/cream palette
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    highContrast -> HighContrastColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
