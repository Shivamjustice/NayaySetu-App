package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ApplicationTemplate
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun ApplicationBuilderScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val templates by viewModel.applicationTemplates.collectAsState()
  val selectedTemplate by viewModel.selectedTemplate.collectAsState()
  val formValues by viewModel.templateFormValues.collectAsState()
  val generatedPreview by viewModel.generatedDocumentPreview.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  val context = LocalContext.current

  // Select first template by default if none selected
  LaunchedEffect(templates) {
    if (selectedTemplate == null && templates.isNotEmpty()) {
      viewModel.selectApplicationTemplate(templates.first())
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Header Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = if (lang == "hi") "विधिक आवेदन व याचिका निर्माता" else "Application & Legal Petition Builder",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (lang == "hi") {
              "7 आसान चरणों में सक्षम प्राधिकारियों, जनसुनवाई व वनाधिकार समिति हेतु औपचारिक आवेदन पत्र तैयार करें।"
            } else {
              "Generate formal administrative petitions for District Collector, Jan Sunwai, and FRA Gram Sabha in 7 simple steps."
            },
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
        }
      }
    }

    // 7-Step Wizard Flow Tracker
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JhsSecondaryBg),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(
            text = if (lang == "hi") "7-चरणीय आवेदन निर्माण प्रक्रिया:" else "7-Step Application Process:",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = JhsTealDark
          )
          Spacer(modifier = Modifier.height(8.dp))
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val steps = if (lang == "hi") {
              listOf(
                "1. प्रकार",
                "2. अधिकारी",
                "3. नाम व गाँव",
                "4. समस्या",
                "5. कार्रवाई",
                "6. जाँच",
                "7. PDF डाउनलोड"
              )
            } else {
              listOf(
                "1. Type",
                "2. Authority",
                "3. Applicant",
                "4. Issue",
                "5. Relief",
                "6. Verify",
                "7. Download PDF"
              )
            }
            items(steps) { step ->
              Surface(
                color = Color.White,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Text(
                  text = step,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = JhsHeadingText,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }
        }
      }
    }

    // 2. Template Selector Horizontal Carousel
    item {
      Text(
        text = if (lang == "hi") "आवेदन प्रारूप चुनें:" else "Select Application Template:",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = JhsHeadingText
      )
      Spacer(modifier = Modifier.height(6.dp))

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(templates) { tpl ->
          val isSelected = tpl.id == selectedTemplate?.id
          Card(
            modifier = Modifier
              .width(200.dp)
              .clickable { viewModel.selectApplicationTemplate(tpl) },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) JhsSecondaryBg else Color.White
            ),
            border = BorderStroke(1.dp, if (isSelected) JhsTeal else JhsBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Icon(
                imageVector = Icons.Default.Description,
                contentDescription = null,
                tint = if (isSelected) JhsTeal else JhsSecondaryText,
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = if (lang == "hi") tpl.titleHindi else tpl.titleEnglish,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = JhsHeadingText,
                maxLines = 2
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = if (lang == "hi") tpl.recipientAuthorityHindi else tpl.recipientAuthorityEnglish,
                fontSize = 10.sp,
                color = JhsSecondaryText,
                maxLines = 1
              )
            }
          }
        }
      }
    }

    // 3. Dynamic Form Input Card
    val currentTpl = selectedTemplate
    if (currentTpl != null) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = if (lang == "hi") currentTpl.titleHindi else currentTpl.titleEnglish,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = if (lang == "hi") currentTpl.descriptionHindi else currentTpl.descriptionEnglish,
              fontSize = 12.sp,
              color = JhsSecondaryText
            )

            Spacer(modifier = Modifier.height(14.dp))

            currentTpl.fields.forEach { field ->
              val value = formValues[field.key] ?: ""
              OutlinedTextField(
                value = value,
                onValueChange = { viewModel.updateFormField(field.key, it) },
                label = { Text(if (lang == "hi") field.labelHindi else field.labelEnglish, fontSize = 12.sp) },
                placeholder = { Text(field.placeholder, fontSize = 11.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = JhsInputBg,
                  unfocusedContainerColor = JhsInputBg,
                  focusedBorderColor = JhsTeal,
                  unfocusedBorderColor = JhsBorder,
                  focusedTextColor = JhsHeadingText,
                  unfocusedTextColor = JhsHeadingText,
                  focusedPlaceholderColor = JhsPlaceholderText,
                  unfocusedPlaceholderColor = JhsPlaceholderText
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
              )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
              onClick = { viewModel.generateApplicationDraft() },
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("generate_draft_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = JhsTeal,
                contentColor = Color.White
              )
            ) {
              Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (lang == "hi") "औपचारिक विधिक प्रारूप तैयार करें" else "Generate Formal Draft",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
              )
            }
          }
        }
      }
    }

    // 4. Formatted Document Preview Card (if generated)
    if (generatedPreview != null) {
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("generated_preview_card"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = JhsTeal)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (lang == "hi") "तैयार औपचारिक आवेदन" else "Generated Official Draft",
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = JhsHeadingText
                )
              }

              // Audio Read Draft Aloud
              IconButton(
                onClick = {
                  if (isSpeaking) {
                    viewModel.stopSpeech()
                  } else {
                    viewModel.speak(generatedPreview ?: "")
                  }
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                  contentDescription = "Read Draft",
                  tint = JhsTeal
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
              color = JhsInputBg,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.dp, JhsBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = generatedPreview ?: "",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = JhsHeadingText,
                modifier = Modifier.padding(12.dp)
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Official Submission Disclaimer
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.2f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = viewModel.tr(
                  "⚠️ विधिक सूचना: पीडीएफ (PDF) डाउनलोड या प्रिंट करने का यह अर्थ नहीं है कि आवेदन आधिकारिक रूप से शासकीय कार्यालय में जमा हो गया है। इसे सक्षम प्राधिकारी/जनसुनवाई में व्यक्तिगत अथवा रजिस्टर्ड डाक से प्रस्तुत करें।",
                  "⚠️ Legal Notice: Downloading or printing the PDF does not mean the application is officially filed. Please submit the signed print at the competent office / Jan Sunwai or via Registered Post.",
                  "⚠️ Legal Notice: PDF download ya print karne ka matlab official submission nahi hai. Ise Jan Sunwai ya sarkari office mein jama karein."
                ),
                fontSize = 10.sp,
                lineHeight = 14.sp,
                color = JhsTealDark,
                modifier = Modifier.padding(8.dp)
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3 Prominent Actions: "आवेदन देखें", "बदलाव करें", "PDF डाउनलोड करें"
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedButton(
                onClick = {
                  viewModel.generateApplicationDraft()
                  Toast.makeText(context, if (lang == "hi") "आवेदन प्रारूप अद्यतन हो गया" else "Draft refreshed", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f).height(48.dp).testTag("action_view_draft"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, JhsBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsHeadingText)
              ) {
                Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(15.dp), tint = JhsTeal)
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (lang == "hi") "आवेदन देखें" else "View Draft", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }

              OutlinedButton(
                onClick = {
                  Toast.makeText(context, if (lang == "hi") "ऊपर दिए गए फ़ील्ड में बदलाव करें" else "Modify fields above", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f).height(48.dp).testTag("action_edit_draft"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, JhsBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsHeadingText)
              ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp), tint = JhsTeal)
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (lang == "hi") "बदलाव करें" else "Edit Draft", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }

              Button(
                onClick = {
                  val title = selectedTemplate?.titleHindi ?: "NyaySetu_Application"
                  val html = """
                    <!DOCTYPE html>
                    <html>
                    <head>
                      <meta charset="utf-8">
                      <style>
                        body { font-family: sans-serif; font-size: 13pt; line-height: 1.6; padding: 25px; margin: 0; color: #111; }
                        .header { text-align: center; border-bottom: 2px solid #176B63; padding-bottom: 8px; margin-bottom: 18px; }
                        .title { font-size: 15pt; font-weight: bold; color: #176B63; }
                        .subtitle { font-size: 10pt; color: #666; }
                        .content { white-space: pre-wrap; font-family: monospace; font-size: 11pt; border: 1px solid #ccc; padding: 16px; border-radius: 6px; }
                        .sign-box { margin-top: 40px; text-align: right; font-weight: bold; }
                        .footer { margin-top: 30px; border-top: 1px solid #ccc; padding-top: 8px; font-size: 9pt; color: #777; text-align: center; }
                      </style>
                    </head>
                    <body>
                      <div class="header">
                        <div class="title">जस्टिस हब सोसाइटी (JHS) — न्यायसेतु विधिक मंच</div>
                        <div class="subtitle">औपचारिक विधिक प्रारूप व जनसुनवाई आवेदन (Official Application)</div>
                      </div>
                      <div class="content">${generatedPreview ?: ""}</div>
                      <div class="sign-box">आवेदक के हस्ताक्षर / अंगूठा निशानी</div>
                      <div class="footer">तैयार किया गया: NyaySetu Legal Platform | संपर्क: 7440323972</div>
                    </body>
                    </html>
                  """.trimIndent()

                  val webView = android.webkit.WebView(context)
                  webView.webViewClient = object : android.webkit.WebViewClient() {
                    override fun onPageFinished(view: android.webkit.WebView?, url: String?) {
                      val printManager = context.getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                      val printAdapter = webView.createPrintDocumentAdapter(title)
                      val printAttributes = android.print.PrintAttributes.Builder()
                        .setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS)
                        .build()
                      printManager.print(title, printAdapter, printAttributes)
                    }
                  }
                  webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                },
                modifier = Modifier.weight(1.2f).height(48.dp).testTag("action_download_pdf"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JhsTeal, contentColor = Color.White)
              ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (lang == "hi") "PDF डाउनलोड करें" else "Download PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}
