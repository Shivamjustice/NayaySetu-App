package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NyaySetuRepository
import com.example.model.VolunteerVisitRecord
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun VolunteerWorkspaceScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val visits by viewModel.volunteerVisits.collectAsState()
  val cases by viewModel.cases.collectAsState()

  var showLogVisitDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Volunteer Header & Profile
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.VolunteerActivism, contentDescription = null, tint = JhsTeal)
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = if (lang == "hi") "ग्राम कार्यकर्ता कार्यक्षेत्र (Volunteer Space)" else "Field Volunteer Workspace",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
                )
                Text(
                  text = if (lang == "hi") "कार्यकर्ता: रमेश सहरिया | क्षेत्र: कराहल व पोहरी" else "Worker: Ramesh Sahariya | Karahal & Pohri",
                  fontSize = 12.sp,
                  color = JhsSecondaryText
                )
              }
            }

            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = if (lang == "hi") "ऑफलाइन सुरक्षित" else "Offline Ready",
                color = JhsTealDark,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = { showLogVisitDialog = true },
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("log_visit_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal, contentColor = Color.White)
          ) {
            Icon(Icons.Default.AddLocationAlt, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (lang == "hi") "नयी ग्राम बैठक / भ्रमण दर्ज करें" else "Log Field Visit",
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp
            )
          }
        }
      }
    }

    // 2. Section: Assigned Cases
    item {
      Text(
        text = if (lang == "hi") "आवंटित ग्राम मामले (Assigned Village Cases):" else "Assigned Village Cases:",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
      )
    }

    items(cases.take(3)) { c ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = c.id, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = JhsTeal)
            Surface(
              color = JhsTealContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = if (lang == "hi") c.status.labelHi else c.status.labelEn,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = JhsOnTealContainer,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = c.title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
          Text(text = "${c.village}, ${c.block}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
        }
      }
    }

    // 3. Section: Recent Field Visit Records
    item {
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = if (lang == "hi") "हालिया क्षेत्र भ्रमण विवरण (Field Visit Logbook):" else "Recent Field Visit Logbook:",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
      )
    }

    items(visits) { v ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Groups, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${v.village} (${v.participantsCount} ${if (lang == "hi") "उपस्थित" else "participants"})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }

            Surface(
              color = JhsGoldContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = v.visitDate,
                color = JhsOnGoldContainer,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "${if (lang == "hi") "बैठक उद्देश्य" else "Purpose"}: ${v.meetingPurpose}",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "${if (lang == "hi") "प्रेक्षण" else "Observations"}: ${v.observations}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${if (lang == "hi") "कार्य योजना" else "Action"}: ${v.actionItems}",
            fontSize = 11.sp,
            color = JhsTealDark,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }

  // Log Visit Dialog
  if (showLogVisitDialog) {
    var dVillage by remember { mutableStateOf("") }
    var dBlock by remember { mutableStateOf("कराहल (Karahal)") }
    var dDistrict by remember { mutableStateOf("श्योपुर (Sheopur)") }
    var dCount by remember { mutableStateOf("15") }
    var dPurpose by remember { mutableStateOf("") }
    var dObs by remember { mutableStateOf("") }
    var dAction by remember { mutableStateOf("") }

    AlertDialog(
      onDismissRequest = { showLogVisitDialog = false },
      title = { Text(if (lang == "hi") "नयी ग्राम बैठक व भ्रमण दर्ज करें" else "Log Field Visit") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = dVillage,
            onValueChange = { dVillage = it },
            label = { Text(if (lang == "hi") "गाँव / टोला *" else "Village *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = dBlock,
              onValueChange = { dBlock = it },
              label = { Text(if (lang == "hi") "ब्लॉक" else "Block") },
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
              value = dCount,
              onValueChange = { dCount = it },
              label = { Text(if (lang == "hi") "उपस्थिति" else "Count") },
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }
          OutlinedTextField(
            value = dPurpose,
            onValueChange = { dPurpose = it },
            label = { Text(if (lang == "hi") "बैठक का उद्देश्य *" else "Meeting Purpose *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = dObs,
            onValueChange = { dObs = it },
            label = { Text(if (lang == "hi") "अवलोकन / समस्या विवरण" else "Observations") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = dAction,
            onValueChange = { dAction = it },
            label = { Text(if (lang == "hi") "अगला कदम / कार्य योजना" else "Action Items") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (dVillage.isNotBlank() && dPurpose.isNotBlank()) {
              NyaySetuRepository.addVolunteerVisit(
                volunteerName = "रमेश सहरिया",
                village = dVillage,
                gramPanchayat = dVillage,
                block = dBlock,
                district = dDistrict,
                participantCount = dCount.toIntOrNull() ?: 10,
                meetingPurpose = dPurpose,
                observations = dObs,
                actionItems = dAction
              )
              showLogVisitDialog = false
            }
          }
        ) {
          Text(if (lang == "hi") "सहेजें" else "Save Log")
        }
      },
      dismissButton = {
        TextButton(onClick = { showLogVisitDialog = false }) {
          Text(if (lang == "hi") "रद्द करें" else "Cancel")
        }
      }
    )
  }
}
