package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VillageDigitalProfile
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun VillageDigitalProfileScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val profiles by viewModel.villageDigitalProfiles.collectAsState()
  var selectedProfile by remember { mutableStateOf<VillageDigitalProfile?>(null) }

  LaunchedEffect(profiles) {
    if (selectedProfile == null && profiles.isNotEmpty()) {
      selectedProfile = profiles.first()
    }
  }

  val profile = selectedProfile

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Header Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "ग्राम डिजिटल प्रोफ़ाइल (Village Digital Profile)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "सहभागी ग्रामों की बुनियादी संरचना, सार्वजनिक सेवाएँ, विकास प्राथमिकताएं एवं सरकारी कार्यक्रम",
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
        }
      }
    }

    // 2. Select Village Carousel
    item {
      Text(text = "गाँव चुनें (Select Village):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
      Spacer(modifier = Modifier.height(6.dp))
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(profiles) { p ->
          val isSel = p.id == profile?.id
          FilterChip(
            selected = isSel,
            onClick = { selectedProfile = p },
            label = { Text(p.villageName, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
            shape = RoundedCornerShape(10.dp),
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = JhsTeal,
              selectedLabelColor = Color.White,
              containerColor = JhsWhite,
              labelColor = JhsHeadingText
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = isSel,
              borderColor = if (isSel) JhsTeal else JhsBorder
            )
          )
        }
      }
    }

    // 3. Selected Village Profile Details
    if (profile != null) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            // Village Name & Population
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = profile.villageName,
                  style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = JhsHeadingText)
                )
                Text(
                  text = "ग्रा.पं. ${profile.gramPanchayat} • ब्लॉक: ${profile.block} • जिला: ${profile.district}",
                  fontSize = 12.sp,
                  color = JhsSecondaryText
                )
              }
              Surface(
                color = JhsSecondaryBg,
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = "${profile.population} आबादी",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTeal,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Infrastructure Grid Matrix
            Text(text = "बुनियादी सुविधाएँ व सार्वजनिक सेवाएँ:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              InfraRow("विद्यालय (Schools)", "${profile.schoolsCount} शासकीय प्राथमिक/माध्यमिक शाला", Icons.Default.School)
              InfraRow("आँगनवाड़ी (Anganwadi)", "${profile.anganwadiCount} केंद्र (पोषण व टीकाकरण)", Icons.Default.ChildCare)
              InfraRow("स्वास्थ्य सेवा (Health)", profile.healthFacility, Icons.Default.LocalHospital)
              InfraRow("पेयजल (Drinking Water)", profile.drinkingWaterStatus, Icons.Default.WaterDrop)
              InfraRow("सड़क (Roads)", profile.roadsStatus, Icons.Default.AddRoad)
              InfraRow("विद्युत (Electricity)", profile.electricityStatus, Icons.Default.Bolt)
              InfraRow("मुख्य आजीविका (Livelihood)", profile.primaryLivelihood, Icons.Default.Work)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Community Development Priorities
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, JhsBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "🎯 ग्राम समुदाय की प्रमुख विकास प्राथमिकताएं:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
                Spacer(modifier = Modifier.height(6.dp))
                profile.developmentPriorities.forEachIndexed { idx, pri ->
                  Text(text = "${idx + 1}. $pri", fontSize = 12.sp, lineHeight = 17.sp, color = JhsBodyText, modifier = Modifier.padding(vertical = 1.dp))
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Ongoing Works
            Surface(
              color = JhsSecondaryBg.copy(alpha = 0.5f),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, JhsBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "🏗️ वर्तमान में प्रगतिरत शासकीय कार्य:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsTerracotta)
                Spacer(modifier = Modifier.height(6.dp))
                profile.ongoingWorks.forEach { work ->
                  Text(text = "✓ $work", fontSize = 12.sp, color = JhsBodyText, modifier = Modifier.padding(vertical = 1.dp))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "सत्यापन तिथि: ${profile.verifiedDate} (JHS फील्ड टीम द्वारा सत्यापित)",
                  fontSize = 10.sp,
                  color = JhsSecondaryText
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun InfraRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(icon, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(18.dp))
    Spacer(modifier = Modifier.width(8.dp))
    Text(text = "$label: ", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = JhsHeadingText)
    Text(text = value, fontSize = 12.sp, color = JhsBodyText)
  }
}
