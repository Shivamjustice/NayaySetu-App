package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

// JHS Official Typography System
// Hindi: Noto Sans Devanagari | English: Inter
val JhsFontFamily = FontFamily(
  Font(R.font.inter),
  Font(R.font.noto_sans_devanagari)
)

// Standardized JHS Typography System per JHS Brand Design System
object JhsTypography {
  // Main App Heading: 24px, Bold 700
  val mainAppHeading = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Bold,
    fontSize = 24.sp,
    lineHeight = 32.sp,
    letterSpacing = 0.sp
  )

  // Page Heading: 22px, Bold 700
  val pageHeading = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Bold,
    fontSize = 22.sp,
    lineHeight = 30.sp,
    letterSpacing = 0.sp
  )

  // Section Heading: 19px, Semi-bold 600
  val sectionHeading = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.SemiBold,
    fontSize = 19.sp,
    lineHeight = 26.sp,
    letterSpacing = 0.1.sp
  )

  // Card Heading: 16px, Semi-bold 600
  val cardHeading = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.SemiBold,
    fontSize = 16.sp,
    lineHeight = 24.sp,
    letterSpacing = 0.15.sp
  )

  // Body Text: 16px, Regular 400
  val bodyText = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Normal,
    fontSize = 16.sp,
    lineHeight = 24.sp,
    letterSpacing = 0.25.sp
  )

  // Form Labels: 15px, Medium 500
  val formLabel = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Medium,
    fontSize = 15.sp,
    lineHeight = 22.sp,
    letterSpacing = 0.1.sp
  )

  // Input Text: 16px, Regular 400
  val inputText = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Normal,
    fontSize = 16.sp,
    lineHeight = 24.sp,
    letterSpacing = 0.25.sp
  )

  // Button Text: 16px, Semi-bold 600
  val buttonText = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.SemiBold,
    fontSize = 16.sp,
    lineHeight = 24.sp,
    letterSpacing = 0.1.sp
  )

  // Supporting Text: 14px, Regular 400
  val supportingText = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Normal,
    fontSize = 14.sp,
    lineHeight = 20.sp,
    letterSpacing = 0.25.sp
  )
}

val Typography = Typography(
  displayLarge = JhsTypography.mainAppHeading,
  headlineLarge = JhsTypography.mainAppHeading,
  headlineMedium = JhsTypography.pageHeading,
  headlineSmall = JhsTypography.sectionHeading,
  titleLarge = JhsTypography.sectionHeading,
  titleMedium = JhsTypography.cardHeading,
  titleSmall = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.SemiBold,
    fontSize = 14.sp,
    lineHeight = 20.sp,
    letterSpacing = 0.1.sp
  ),
  bodyLarge = JhsTypography.bodyText,
  bodyMedium = JhsTypography.supportingText,
  bodySmall = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Normal,
    fontSize = 12.sp,
    lineHeight = 16.sp,
    letterSpacing = 0.4.sp
  ),
  labelLarge = JhsTypography.buttonText,
  labelMedium = JhsTypography.formLabel,
  labelSmall = TextStyle(
    fontFamily = JhsFontFamily,
    fontWeight = FontWeight.Medium,
    fontSize = 12.sp,
    lineHeight = 16.sp,
    letterSpacing = 0.5.sp
  )
)
