package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * Standard JHS Card: White background, subtle light beige border (#E8E1D5),
 * 16dp rounded corners, and soft elevation.
 */
@Composable
fun JhsCard(
  modifier: Modifier = Modifier,
  shape: RoundedCornerShape = RoundedCornerShape(16.dp),
  border: BorderStroke? = BorderStroke(1.dp, JhsBorder),
  elevation: Dp = 1.dp,
  content: @Composable ColumnScope.() -> Unit
) {
  Card(
    modifier = modifier,
    shape = shape,
    colors = CardDefaults.cardColors(containerColor = JhsWhite),
    border = border,
    elevation = CardDefaults.cardElevation(defaultElevation = elevation),
    content = content
  )
}

/**
 * Standard clickable JHS Card.
 */
@Composable
fun JhsClickableCard(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  shape: RoundedCornerShape = RoundedCornerShape(16.dp),
  border: BorderStroke? = BorderStroke(1.dp, JhsBorder),
  elevation: Dp = 1.dp,
  content: @Composable ColumnScope.() -> Unit
) {
  Card(
    onClick = onClick,
    modifier = modifier,
    shape = shape,
    colors = CardDefaults.cardColors(containerColor = JhsWhite),
    border = border,
    elevation = CardDefaults.cardElevation(defaultElevation = elevation),
    content = content
  )
}

/**
 * Standard JHS Primary Button: Deep Teal (#176B63) with White text,
 * 12dp rounded corners, and minimum 48dp height.
 */
@Composable
fun JhsPrimaryButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  leadingIcon: ImageVector? = null
) {
  Button(
    onClick = onClick,
    enabled = enabled,
    shape = RoundedCornerShape(12.dp),
    colors = ButtonDefaults.buttonColors(
      containerColor = JhsTeal,
      contentColor = Color.White,
      disabledContainerColor = JhsTeal.copy(alpha = 0.4f),
      disabledContentColor = Color.White.copy(alpha = 0.7f)
    ),
    modifier = modifier
      .defaultMinSize(minHeight = 48.dp)
      .fillMaxWidth(),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
  ) {
    if (leadingIcon != null) {
      Icon(
        imageVector = leadingIcon,
        contentDescription = null,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
    }
    Text(
      text = text,
      style = JhsTypography.buttonText,
      color = Color.White
    )
  }
}

/**
 * Standard JHS Secondary Button: Soft Mint (#E8F1ED) with Teal text,
 * 12dp rounded corners, and minimum 48dp height.
 */
@Composable
fun JhsSecondaryButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  leadingIcon: ImageVector? = null
) {
  Button(
    onClick = onClick,
    enabled = enabled,
    shape = RoundedCornerShape(12.dp),
    colors = ButtonDefaults.buttonColors(
      containerColor = JhsSecondaryBg,
      contentColor = JhsTeal,
      disabledContainerColor = JhsSecondaryBg.copy(alpha = 0.4f),
      disabledContentColor = JhsTeal.copy(alpha = 0.5f)
    ),
    modifier = modifier
      .defaultMinSize(minHeight = 48.dp)
      .fillMaxWidth(),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
  ) {
    if (leadingIcon != null) {
      Icon(
        imageVector = leadingIcon,
        contentDescription = null,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
    }
    Text(
      text = text,
      style = JhsTypography.buttonText,
      color = JhsTeal
    )
  }
}

/**
 * Standard JHS Input Colors for OutlinedTextField
 */
@Composable
fun jhsInputColors() = OutlinedTextFieldDefaults.colors(
  focusedContainerColor = JhsInputBg,
  unfocusedContainerColor = JhsInputBg,
  focusedBorderColor = JhsTeal,
  unfocusedBorderColor = JhsBorder,
  focusedLabelColor = JhsImportantLabel,
  unfocusedLabelColor = JhsSecondaryText,
  focusedTextColor = JhsHeadingText,
  unfocusedTextColor = JhsHeadingText,
  focusedPlaceholderColor = JhsPlaceholderText,
  unfocusedPlaceholderColor = JhsPlaceholderText,
  focusedLeadingIconColor = JhsTeal,
  unfocusedLeadingIconColor = JhsTeal,
  focusedTrailingIconColor = JhsTeal,
  unfocusedTrailingIconColor = JhsSecondaryText
)

/**
 * Standard Page Header with clean typography and optional back button.
 */
@Composable
fun JhsPageHeader(
  title: String,
  subtitle: String? = null,
  onBack: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
  actions: @Composable (RowScope.() -> Unit)? = null
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    if (onBack != null) {
      IconButton(onClick = onBack) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = JhsHeadingText
        )
      }
      Spacer(modifier = Modifier.width(4.dp))
    }

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        style = JhsTypography.pageHeading,
        color = JhsHeadingText,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      if (subtitle != null) {
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = subtitle,
          style = JhsTypography.supportingText,
          color = JhsSecondaryText,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }

    if (actions != null) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        content = actions
      )
    }
  }
}

/**
 * Standard Section Heading with supporting caption.
 */
@Composable
fun JhsSectionHeader(
  title: String,
  subtitle: String? = null,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Text(
      text = title,
      style = JhsTypography.sectionHeading,
      color = JhsHeadingText
    )
    if (subtitle != null) {
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = subtitle,
        style = JhsTypography.supportingText,
        color = JhsSecondaryText
      )
    }
  }
}
