package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel
import com.example.viewmodel.ScreenTab

data class ModuleItem(
  val tab: ScreenTab,
  val icon: ImageVector,
  val titleHi: String,
  val titleEn: String,
  val titleHinglish: String,
  val badge: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreModulesSheet(
  viewModel: NyaySetuViewModel,
  onDismiss: () -> Unit
) {
  val lang by viewModel.currentLanguage.collectAsState()
  val user by viewModel.currentUser.collectAsState()

  val modules = listOf(
    ModuleItem(ScreenTab.ASSISTANT, Icons.Default.RecordVoiceOver, "AI वाणी सहायक", "AI Voice Assistant", "AI Voice", "AI Voice"),
    ModuleItem(ScreenTab.SCHEMES, Icons.Default.AccountBalance, "सरकारी योजनाएँ व पात्रता", "Govt Schemes & Eligibility", "Govt Schemes", "Verified"),
    ModuleItem(ScreenTab.RTI, Icons.Default.Gavel, "आरटीआई सहायता केंद्र", "RTI Assistance Centre", "RTI Centre", "Sec 6(1)"),
    ModuleItem(ScreenTab.VILLAGE_PROFILE, Icons.Default.LocationCity, "गाँव डिजिटल प्रोफ़ाइल", "Village Digital Profile", "Gaon Profile", "MP"),
    ModuleItem(ScreenTab.GRAM_SABHA, Icons.Default.Groups, "ग्राम सभा व जन भागीदारी", "Gram Sabha Participation", "Gram Sabha", "Action"),
    ModuleItem(ScreenTab.WOMEN_CHILD, Icons.Default.Shield, "महिला व बाल सहायता", "Women & Child Support", "Women & Child", "Confidential"),
    ModuleItem(ScreenTab.LEARNING, Icons.Default.School, "सीखें व कानूनी शब्दावली", "Learning & Legal Glossary", "Learning Centre", "Guides"),
    ModuleItem(ScreenTab.RIGHTS, Icons.Default.MenuBook, "वनाधिकार व विधिक ज्ञान", "Rights & Laws", "Rights & FRA", "FRA"),
    ModuleItem(ScreenTab.BUILDER, Icons.Default.Description, "विधिक आवेदन ड्राफ्टर (PDF)", "Petition Builder (PDF)", "App Drafter", "PDF"),
    ModuleItem(ScreenTab.LIVELIHOOD, Icons.Default.Eco, "आजीविका व वनोपज", "Livelihoods & MSP", "Livelihoods", "MSP"),
    ModuleItem(ScreenTab.STORIES, Icons.Default.AutoStories, "समुदाय की कहानियाँ", "Community Stories", "Stories & Voices", "Voices"),
    ModuleItem(ScreenTab.DIRECTORY, Icons.Default.Diversity3, "विशेषज्ञ निर्देशिका", "Legal Experts", "DLSA Experts", "DLSA"),
    ModuleItem(ScreenTab.HELPLINE, Icons.Default.Call, "आपातकालीन हेल्पलाइन", "Helplines Directory", "Emergency Call", "24x7"),
    ModuleItem(ScreenTab.VOLUNTEER, Icons.Default.VolunteerActivism, "कार्यकर्ता कार्यक्षेत्र", "Volunteer Space", "Volunteer Space", "Field"),
    ModuleItem(ScreenTab.ADMIN, Icons.Default.AdminPanelSettings, "JHS एडमिन डैशबोर्ड", "Super Admin Dashboard", "Admin Control", if (user?.role == UserRole.SUPER_ADMIN || user?.role == UserRole.DEPT_ADMIN) "Full Access" else "Admin"),
    ModuleItem(ScreenTab.ABOUT_JHS, Icons.Default.Info, "JHS संस्था परिचय", "About JHS Society", "About JHS", "JHS"),
    ModuleItem(ScreenTab.PROFILE, Icons.Default.AccountCircle, "मेरी प्रोफ़ाइल", "My Profile", "Member Profile", "User")
  )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = JhsCream,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 8.dp)
        .navigationBarsPadding()
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = viewModel.tr("समस्त सेवाएँ एवं मॉड्यूल", "All Services & Modules", "All Modules & Features"),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Text(
            text = viewModel.tr("जस्टिस हब सोसाइटी (JHS) — अधिकार से न्याय तक", "Justice Hub Society (JHS) — Rights to Justice", "Justice Hub Society (JHS) — Adhikar Se Nyay"),
            style = MaterialTheme.typography.bodySmall.copy(color = JhsTeal, fontWeight = FontWeight.Bold)
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = JhsHeadingText)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.padding(bottom = 24.dp)
      ) {
        items(modules) { mod ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                viewModel.setTab(mod.tab)
                onDismiss()
              },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (mod.tab == ScreenTab.ABOUT_JHS) JhsSecondaryBg else JhsWhite
            ),
            border = BorderStroke(1.dp, if (mod.tab == ScreenTab.ABOUT_JHS) JhsTeal else JhsBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              horizontalAlignment = Alignment.Start
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier.size(36.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = mod.icon,
                    contentDescription = null,
                    tint = if (mod.tab == ScreenTab.ADMIN) JhsTerracotta else JhsTeal,
                    modifier = Modifier.size(24.dp)
                  )
                }

                if (mod.badge != null) {
                  Surface(
                    color = if (mod.tab == ScreenTab.ADMIN) JhsTerracotta.copy(alpha = 0.15f) else JhsSecondaryBg,
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text(
                      text = mod.badge,
                      color = if (mod.tab == ScreenTab.ADMIN) JhsTerracotta else JhsTeal,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = viewModel.tr(mod.titleHi, mod.titleEn, mod.titleHinglish),
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = JhsHeadingText,
                lineHeight = 16.sp
              )
            }
          }
        }
      }
    }
  }
}
