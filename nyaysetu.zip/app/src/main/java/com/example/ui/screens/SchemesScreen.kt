package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GovernmentScheme
import com.example.model.SchemeCategory
import com.example.model.SchemeStatus
import com.example.ui.components.PvtgMasterGuideViewerDialog
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun SchemesScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val schemes by viewModel.filteredSchemes.collectAsState()
  val searchQuery by viewModel.schemeSearchQuery.collectAsState()
  val selectedCategory by viewModel.schemeSelectedCategory.collectAsState()
  val targetFilter by viewModel.schemeTargetFilter.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  val context = LocalContext.current

  // Eligibility Checker State
  var showEligibilityChecker by remember { mutableStateOf(false) }
  val socialCategory by viewModel.eligibilitySocialCategory.collectAsState()
  val occupation by viewModel.eligibilityOccupation.collectAsState()
  val gender by viewModel.eligibilityGender.collectAsState()
  val hasLand by viewModel.eligibilityHasLandOrFra.collectAsState()
  val isChecked by viewModel.isEligibilityChecked.collectAsState()
  val matchedSchemes by viewModel.eligibleSchemesResult.collectAsState()

  // Report Error Dialog State
  var reportingScheme by remember { mutableStateOf<GovernmentScheme?>(null) }
  var errorReportDesc by remember { mutableStateOf("") }
  var errorReportSuccessMsg by remember { mutableStateOf<String?>(null) }

  // Expanded Scheme detail state (defaults to Image 3's FRA Patta Vikas Scheme)
  var expandedSchemeId by remember { mutableStateOf<String?>("sch-fra-mp") }
  var showMasterGuideSheet by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Header Card with Verification Guarantee
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = viewModel.tr(
                  "सरकारी योजनाएँ व लाभ सूचना केंद्र",
                  "Government Schemes Information Centre",
                  "Sarkari Yojanayein Information Centre"
                ),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Text(
                text = viewModel.tr(
                  "मध्य प्रदेश एवं भारत सरकार की सत्यापित जनकल्याणकारी योजनाएँ",
                  "Verified Public Welfare Schemes of Govt. of MP & Govt. of India",
                  "MP aur Bharat Sarkar ki Verified Public Welfare Schemes"
                ),
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
            }
            Surface(
              color = JhsTealContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "JHS Verified",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTealDark
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Search Input
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.schemeSearchQuery.value = it },
            placeholder = {
              Text(
                viewModel.tr(
                  "योजना का नाम, विभाग अथवा लाभ खोजें...",
                  "Search scheme name, department or benefits...",
                  "Yojana ka naam, vibhag ya labh khojein..."
                ),
                fontSize = 12.sp
              )
            },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = JhsTeal) },
            trailingIcon = {
              if (searchQuery.isNotBlank()) {
                IconButton(onClick = { viewModel.schemeSearchQuery.value = "" }) {
                  Icon(Icons.Default.Close, contentDescription = "Clear")
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = JhsInputBg,
              unfocusedContainerColor = JhsInputBg,
              focusedBorderColor = JhsTeal,
              unfocusedBorderColor = JhsBorder,
              focusedTextColor = JhsHeadingText,
              unfocusedTextColor = JhsHeadingText,
              focusedPlaceholderColor = JhsPlaceholderText,
              unfocusedPlaceholderColor = JhsPlaceholderText
            ),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("scheme_search_input")
          )
        }
      }
    }

    // Special Banner: PVTG & Tribal Master Guide (Part 1 - 16)
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { showMasterGuideSheet = true }
          .testTag("schemes_pvtg_master_guide_banner"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.5.dp, JhsTeal.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsTealContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = viewModel.tr(
                  "📜 विशेष महा-मार्गदर्शिका (भाग 1 - 16)",
                  "📜 Special Master Guide (Part 1 - 16)",
                  "📜 Special Master Guide (Part 1 - 16)"
                ),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTealDark,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
            TextButton(
              onClick = { showMasterGuideSheet = true },
              contentPadding = PaddingValues(0.dp)
            ) {
              Text(
                viewModel.tr("सम्पूर्ण खोलें ›", "Open Full Guide ›", "Poora Guide Kholein ›"),
                color = JhsTeal,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = viewModel.tr(
              "आदिवासी व विशेष रूप से कमजोर जनजातीय समूह (PVTG) सम्पूर्ण गाइड",
              "Complete Guide for Tribal & PVTG Communities (MP)",
              "Adivasi & PVTG Complete Master Guide (MP)"
            ),
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = JhsHeadingText
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = viewModel.tr(
              "सहरिया, बैगा, भारिया योजनाएँ, 16 अनिवार्य दस्तावेज़, सरकारी फीस नियम, 32 सरकारी पोर्टल व 12 केस स्टडीज़।",
              "Sahariya, Baiga, Bharia schemes, 16 essential documents, govt fee rules, 32 official portals & 12 case studies.",
              "Sahariya, Baiga, Bharia schemes, 16 zaroori documents, govt fee rules, 32 official portals & 12 case studies."
            ),
            fontSize = 11.sp,
            color = JhsBodyText,
            lineHeight = 15.sp
          )
        }
      }
    }

    // 2. Interactive Eligibility Checker Card ("क्या मैं इस योजना के लिए पात्र हूँ?")
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { showEligibilityChecker = !showEligibilityChecker },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(JhsGold),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Rule, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = viewModel.tr(
                    "क्या मैं इस योजना के लिए पात्र हूँ?",
                    "Am I Eligible for These Schemes?",
                    "Kya Main Is Yojana Ke Liye Patra Hoon?"
                  ),
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = JhsCharcoal
                )
                Text(
                  text = viewModel.tr(
                    "सरल प्रश्नों के उत्तर दें और अपने लिए उपयुक्त योजनाएँ जानें",
                    "Answer simple questions to find schemes matching your profile",
                    "Saral sawalon ke jawab dein aur apne liye sahi yojanayein jaanein"
                  ),
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            Icon(
              imageVector = if (showEligibilityChecker) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
              contentDescription = null,
              tint = JhsCharcoal
            )
          }

          AnimatedVisibility(visible = showEligibilityChecker) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

              // 1. Social Category Selection
              Text(
                viewModel.tr(
                  "1. आपकी सामाजिक श्रेणी / समुदाय:",
                  "1. Your Social Category / Community:",
                  "1. Aapki Social Category / Samuday:"
                ),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              val socialCats = listOf(
                "PVTG (सहरिया/बैगा/भारिया)" to viewModel.tr("PVTG (सहरिया/बैगा/भारिया)", "PVTG (Sahariya/Baiga/Bharia)", "PVTG (Sahariya/Baiga/Bharia)"),
                "ST (जनजाति)" to viewModel.tr("ST (जनजाति)", "ST (Scheduled Tribe)", "ST (Tribal)"),
                "SC" to "SC",
                "OBC" to "OBC",
                "सामान्य (General)" to viewModel.tr("सामान्य (General)", "General", "General")
              )
              LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(socialCats) { (key, label) ->
                  val isSel = key == socialCategory
                  FilterChip(
                    selected = isSel,
                    onClick = { viewModel.eligibilitySocialCategory.value = key },
                    label = { Text(label, fontSize = 10.sp) }
                  )
                }
              }

              // 2. Occupation Selection
              Text(
                viewModel.tr(
                  "2. मुख्य व्यवसाय / कार्यक्षेत्र:",
                  "2. Primary Occupation / Livelihood:",
                  "2. Mukhya Vyavsay / Occupation:"
                ),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              val occupations = listOf(
                "कृषक व वनोपज संग्राहक" to viewModel.tr("कृषक व वनोपज संग्राहक", "Farmer & Forest Produce Collector", "Kisan & Vanopaj Collector"),
                "मजदूर (मनरेगा)" to viewModel.tr("मजदूर (मनरेगा)", "Worker (MGNREGA)", "Mazdoor (MGNREGA)"),
                "हस्तशिल्प / कारीगर" to viewModel.tr("हस्तशिल्प / कारीगर", "Artisan / Craftsperson", "Artisan / Karigar"),
                "विद्यार्थी / युवा" to viewModel.tr("विद्यार्थी / युवा", "Student / Youth", "Student / Yuva")
              )
              LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(occupations) { (key, label) ->
                  val isSel = key == occupation
                  FilterChip(
                    selected = isSel,
                    onClick = { viewModel.eligibilityOccupation.value = key },
                    label = { Text(label, fontSize = 10.sp) }
                  )
                }
              }

              // 3. Gender Selection
              Text(
                viewModel.tr("3. जेंडर / लिंग:", "3. Gender:", "3. Gender:"),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              val genders = listOf(
                "महिला" to viewModel.tr("महिला", "Female", "Mahila (Female)"),
                "पुरुष" to viewModel.tr("पुरुष", "Male", "Purush (Male)"),
                "अन्य" to viewModel.tr("अन्य", "Other", "Other")
              )
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                genders.forEach { (key, label) ->
                  val isSel = key == gender
                  FilterChip(
                    selected = isSel,
                    onClick = { viewModel.eligibilityGender.value = key },
                    label = { Text(label, fontSize = 11.sp) }
                  )
                }
              }

              // 4. Land holding / FRA title
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  viewModel.tr(
                    "क्या आपके पास कृषि भूमि या वनाधिकार पट्टा है?",
                    "Do you hold agricultural land or an FRA Title (Patta)?",
                    "Kya aapke paas krishi bhoomi ya Van Adhikar Patta hai?"
                  ),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium,
                  modifier = Modifier.weight(1f)
                )
                Switch(
                  checked = hasLand,
                  onCheckedChange = { viewModel.eligibilityHasLandOrFra.value = it }
                )
              }

              // Check Button
              Button(
                onClick = { viewModel.checkEligibility() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JhsTeal)
              ) {
                Icon(Icons.Default.CheckCircleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  viewModel.tr(
                    "पात्र योजनाएँ देखें (Check Matches)",
                    "Check Eligible Schemes",
                    "Matching Schemes Dekhein"
                  ),
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp
                )
              }

              // Results
              if (isChecked) {
                Surface(
                  color = Color.White,
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                      text = viewModel.tr(
                        "✅ आपके विवरण के आधार पर ${matchedSchemes.size} संभावित योजनाएँ मिलीं:",
                        "✅ Found ${matchedSchemes.size} eligible schemes based on your profile:",
                        "✅ Aapke details ke aadhar par ${matchedSchemes.size} eligible schemes mili:"
                      ),
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      color = JhsTealDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    matchedSchemes.forEach { ms ->
                      Row(
                        modifier = Modifier
                          .fillMaxWidth()
                          .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(Icons.Default.ArrowRight, contentDescription = null, tint = JhsTerracotta)
                        Text(
                          text = if (lang == "hi") ms.nameHindi else ms.nameEnglish,
                          fontSize = 11.sp,
                          fontWeight = FontWeight.SemiBold
                        )
                      }
                    }
                    Text(
                      text = viewModel.tr(
                        "* यह प्रारंभिक मार्गदर्शन है। अंतिम स्वीकृति संबंधित शासकीय विभाग के नियमों पर निर्भर है।",
                        "* This is preliminary guidance. Final sanction depends on official departmental verification.",
                        "* Yeh shuruati guidance hai. Final approval sarkari vibhag ke niyamon par nirbhar hai."
                      ),
                      fontSize = 9.sp,
                      color = MaterialTheme.colorScheme.outline,
                      modifier = Modifier.padding(top = 4.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // 3. Category Filter Chips
    item {
      Text(
        text = viewModel.tr("योजना वर्ग (Categories):", "Scheme Categories:", "Yojana Categories:"),
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = JhsHeadingText
      )
      Spacer(modifier = Modifier.height(6.dp))

      // Row 1: Primary Category Filters
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        item {
          val isAllSelected = selectedCategory == null && targetFilter == null
          FilterChip(
            selected = isAllSelected,
            onClick = {
              viewModel.schemeSelectedCategory.value = null
              viewModel.schemeTargetFilter.value = null
            },
            label = {
              Text(
                viewModel.tr("सभी योजनाएँ", "All Schemes", "Sabhi Yojanayein"),
                fontSize = 11.sp,
                fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = JhsTealContainer,
              selectedLabelColor = JhsTealDark
            )
          )
        }
        item {
          val isSel = selectedCategory == SchemeCategory.TRIBAL_WELFARE && targetFilter == null
          FilterChip(
            selected = isSel,
            onClick = {
              viewModel.schemeSelectedCategory.value = if (isSel) null else SchemeCategory.TRIBAL_WELFARE
              viewModel.schemeTargetFilter.value = null
            },
            label = {
              Text(
                viewModel.tr("जनजातीय कल्याण व PVTG", "Tribal Welfare & PVTG", "Tribal Welfare & PVTG"),
                fontSize = 11.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = JhsTealContainer,
              selectedLabelColor = JhsTealDark
            )
          )
        }
        item {
          val isSel = selectedCategory == SchemeCategory.AGRICULTURE_LIVELIHOOD && targetFilter == null
          FilterChip(
            selected = isSel,
            onClick = {
              viewModel.schemeSelectedCategory.value = if (isSel) null else SchemeCategory.AGRICULTURE_LIVELIHOOD
              viewModel.schemeTargetFilter.value = null
            },
            label = {
              Text(
                viewModel.tr("कृषि, पशुपालन व आजीविका", "Agriculture, Dairy & Livelihood", "Krishi, Pashupalan & Aajeevika"),
                fontSize = 11.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = JhsTealContainer,
              selectedLabelColor = JhsTealDark
            )
          )
        }
        item {
          val isSel = selectedCategory == SchemeCategory.HOUSING_SOCIAL_SECURITY && targetFilter == null
          FilterChip(
            selected = isSel,
            onClick = {
              viewModel.schemeSelectedCategory.value = if (isSel) null else SchemeCategory.HOUSING_SOCIAL_SECURITY
              viewModel.schemeTargetFilter.value = null
            },
            label = {
              Text(
                viewModel.tr("आवास व सामाजिक सुरक्षा", "Housing & Social Security", "Aawas & Social Security"),
                fontSize = 11.sp
              )
            }
          )
        }
        item {
          val isSel = selectedCategory == SchemeCategory.EDUCATION && targetFilter == null
          FilterChip(
            selected = isSel,
            onClick = {
              viewModel.schemeSelectedCategory.value = if (isSel) null else SchemeCategory.EDUCATION
              viewModel.schemeTargetFilter.value = null
            },
            label = {
              Text(
                viewModel.tr("शिक्षा व छात्रवृत्ति", "Education & Scholarships", "Shiksha & Scholarship"),
                fontSize = 11.sp
              )
            }
          )
        }
        item {
          val isSel = selectedCategory == SchemeCategory.EMPLOYMENT_RURAL_DEV && targetFilter == null
          FilterChip(
            selected = isSel,
            onClick = {
              viewModel.schemeSelectedCategory.value = if (isSel) null else SchemeCategory.EMPLOYMENT_RURAL_DEV
              viewModel.schemeTargetFilter.value = null
            },
            label = {
              Text(
                viewModel.tr("मनरेगा व ग्रामीण विकास", "MGNREGA & Rural Development", "MGNREGA & Gramin Vikas"),
                fontSize = 11.sp
              )
            }
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Row 2: Target Audience Quick Filters
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        val targets = listOf(
          "Women" to viewModel.tr("👩 महिला विशेष", "👩 Women Special", "👩 Mahila Vishesh"),
          "Farmers" to viewModel.tr("🌾 कृषक विशेष", "🌾 Farmers", "🌾 Kisan Vishesh"),
          "Students" to viewModel.tr("🎓 विद्यार्थी", "🎓 Students", "🎓 Students"),
          "Workers" to viewModel.tr("🛠️ मजदूर", "🛠️ Workers", "🛠️ Mazdoor"),
          "PVTG" to viewModel.tr("🏹 PVTG सहरिया", "🏹 PVTG Sahariya", "🏹 PVTG Sahariya"),
          "Senior Citizens" to viewModel.tr("👴 वरिष्ठ नागरिक", "👴 Senior Citizens", "👴 Senior Citizens"),
          "PwD" to viewModel.tr("♿ दिव्यांगजन", "♿ Persons with Disability", "♿ Divyangjan")
        )
        items(targets) { (key, label) ->
          val isSel = targetFilter == key
          FilterChip(
            selected = isSel,
            onClick = {
              viewModel.schemeTargetFilter.value = if (isSel) null else key
              viewModel.schemeSelectedCategory.value = null
            },
            label = {
              Text(
                label,
                fontSize = 11.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = JhsGoldContainer,
              selectedLabelColor = JhsCharcoal
            )
          )
        }
      }
    }

    // 4. Schemes List Cards
    if (schemes.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
            Text(
              viewModel.tr(
                "कोई योजना नहीं मिली। कृपया फ़िल्टर बदलें।",
                "No schemes found. Please adjust your search or filters.",
                "Koi yojana nahi mili. Kripya filter badlein."
              ),
              color = MaterialTheme.colorScheme.outline
            )
          }
        }
      }
    } else {
      items(schemes) { scheme ->
        val isExpanded = expandedSchemeId == scheme.id
        val isHindiLang = lang == "hi"
        val schemeTitle = if (isHindiLang) scheme.nameHindi else scheme.nameEnglish
        val schemeObjective = if (isHindiLang) scheme.objectiveHindi else scheme.objectiveEnglish
        val schemeBenefits = if (isHindiLang) scheme.benefitsHindi else scheme.benefitsEnglish
        val schemeEligibility = if (isHindiLang) scheme.eligibilityCriteriaHindi else scheme.eligibilityCriteriaEnglish
        val schemeDocs = if (isHindiLang) scheme.requiredDocumentsHindi else scheme.requiredDocumentsEnglish
        val schemeProcedure = if (isHindiLang) scheme.applicationProcedureHindi else scheme.applicationProcedureEnglish
        val statusLabel = if (isHindiLang) scheme.status.labelHi else scheme.status.labelEn
        val deptLabel = translateDepartment(scheme.responsibleDepartment, isHindiLang)
        val officeLabel = translateOfficeLocation(scheme.offlineApplicationLocation, isHindiLang)
        val grievanceLabel = translateGrievance(scheme.grievanceRedressal, isHindiLang)

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { expandedSchemeId = if (isExpanded) null else scheme.id }
            .testTag("scheme_card_${scheme.id}"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, if (isExpanded) JhsTeal.copy(alpha = 0.6f) else JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = if (isExpanded) 3.dp else 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            // Badges Row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                color = JhsTealContainer,
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = scheme.level,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsOnTealContainer,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }

              Surface(
                color = when (scheme.status) {
                  SchemeStatus.VERIFIED_CURRENT -> Color(0xFFE8F5E9)
                  SchemeStatus.UPDATE_REQUIRED -> JhsGoldContainer
                  else -> JhsTerracotta.copy(alpha = 0.15f)
                },
                shape = RoundedCornerShape(8.dp)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = when (scheme.status) {
                      SchemeStatus.VERIFIED_CURRENT -> Icons.Default.Verified
                      SchemeStatus.UPDATE_REQUIRED -> Icons.Default.Update
                      else -> Icons.Default.Info
                    },
                    contentDescription = null,
                    tint = when (scheme.status) {
                      SchemeStatus.VERIFIED_CURRENT -> Color(0xFF2E7D32)
                      SchemeStatus.UPDATE_REQUIRED -> JhsGoldDark
                      else -> JhsTerracotta
                    },
                    modifier = Modifier.size(12.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "$statusLabel (${scheme.lastVerifiedDate})",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (scheme.status) {
                      SchemeStatus.VERIFIED_CURRENT -> Color(0xFF2E7D32)
                      SchemeStatus.UPDATE_REQUIRED -> JhsGoldDark
                      else -> JhsTerracottaDark
                    }
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Scheme Title & Audio Reading Icon Button
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = schemeTitle,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsCharcoal),
                modifier = Modifier.weight(1f)
              )
              Spacer(modifier = Modifier.width(8.dp))
              IconButton(
                onClick = {
                  if (isSpeaking) {
                    viewModel.stopSpeech()
                  } else {
                    val readText = if (isHindiLang) {
                      "${scheme.nameHindi}. विभाग: ${scheme.responsibleDepartment}. उद्देश्य: ${scheme.objectiveHindi}. मुख्य लाभ: ${scheme.benefitsHindi.joinToString(". ")}. पात्रता: ${scheme.eligibilityCriteriaHindi.joinToString(". ")}. आवश्यक दस्तावेज़: ${scheme.requiredDocumentsHindi.joinToString(". ")}. आवेदन प्रक्रिया: ${scheme.applicationProcedureHindi}."
                    } else {
                      "${scheme.nameEnglish}. Department: $deptLabel. Objective: ${scheme.objectiveEnglish}. Key Benefits: ${scheme.benefitsEnglish.joinToString(". ")}. Eligibility: ${scheme.eligibilityCriteriaEnglish.joinToString(". ")}. Required Documents: ${scheme.requiredDocumentsEnglish.joinToString(". ")}. Application Procedure: ${scheme.applicationProcedureEnglish}."
                    }
                    viewModel.speak(readText, isHindiLang)
                  }
                },
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(JhsTealContainer)
              ) {
                Icon(
                  imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                  contentDescription = "Read Aloud Scheme Details",
                  tint = JhsTeal,
                  modifier = Modifier.size(20.dp)
                )
              }
            }

            // Responsible Department Subtitle
            Text(
              text = deptLabel,
              fontSize = 11.sp,
              color = JhsTeal,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Objective description
            Text(
              text = schemeObjective,
              fontSize = 12.sp,
              lineHeight = 17.sp,
              color = JhsHeadingText
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Key Benefits Container Box
            Surface(
              color = Color(0xFFF9F7F4),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, Color(0xFFEBE6DD)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = viewModel.tr("मुख्य लाभ व सहायता:", "Key Benefits & Assistance:", "Mukhya Labh & Sahayata:"),
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = JhsTerracottaDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                val benefitsToShow = if (isExpanded) schemeBenefits else schemeBenefits.take(2)
                benefitsToShow.forEach { benefit ->
                  Row(
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier.padding(vertical = 2.dp)
                  ) {
                    Text("• ", color = JhsTerracotta, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                      text = benefit,
                      fontSize = 12.sp,
                      color = JhsHeadingText,
                      lineHeight = 16.sp
                    )
                  }
                }
              }
            }

            // Expanded Full Details
            AnimatedVisibility(visible = isExpanded) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Divider(color = JhsBorder)

                // 1. Eligibility Criteria
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(
                    text = viewModel.tr("पात्रता की शर्तें (Eligibility):", "Eligibility Criteria:", "Patrata Ki Shartein (Eligibility):"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = JhsTealDark
                  )
                  schemeEligibility.forEach { el ->
                    Row(
                      verticalAlignment = Alignment.Top,
                      modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                      Text("✓ ", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                      Text(
                        text = el,
                        fontSize = 12.sp,
                        color = JhsHeadingText,
                        lineHeight = 16.sp
                      )
                    }
                  }
                }

                // 2. Required Documents
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(
                    text = viewModel.tr("आवश्यक दस्तावेज़ (Required Documents):", "Required Documents:", "Zaroori Documents (Required Documents):"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = JhsTealDark
                  )
                  schemeDocs.forEach { doc ->
                    Row(
                      verticalAlignment = Alignment.Top,
                      modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                      Text("📄 ", fontSize = 12.sp)
                      Text(
                        text = doc,
                        fontSize = 12.sp,
                        color = JhsHeadingText,
                        lineHeight = 16.sp
                      )
                    }
                  }
                }

                // 3. Application Procedure
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(
                    text = viewModel.tr("आवेदन प्रक्रिया (How to Apply):", "Application Procedure (How to Apply):", "Avedan Prakriya (How to Apply):"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = JhsTealDark
                  )
                  Text(
                    text = schemeProcedure,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = JhsHeadingText
                  )
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = "${viewModel.tr("कार्यालय / स्थान:", "Office / Location:", "Office / Location:")} $officeLabel",
                    fontSize = 11.sp,
                    color = JhsSecondaryText,
                    fontWeight = FontWeight.Medium
                  )
                  Text(
                    text = "${viewModel.tr("शिकायत निवारण:", "Grievance Redressal:", "Grievance Redressal:")} $grievanceLabel",
                    fontSize = 11.sp,
                    color = JhsTerracottaDark,
                    fontWeight = FontWeight.Medium
                  )
                  Surface(
                    color = Color(0xFFE8F5E9),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.padding(top = 2.dp)
                  ) {
                    Text(
                      text = viewModel.tr(
                        "सरकारी आवेदन शुल्क: ₹0 (पूर्णतः निःशुल्क - किसी बिचौलिए को पैसे न दें)",
                        "Official Application Fee: ₹0 (100% Free - Do not pay any middlemen)",
                        "Sarkari Application Fee: ₹0 (Bilkul Free - Kisi middleman ko paise na dein)"
                      ),
                      fontSize = 10.sp,
                      color = Color(0xFF2E7D32),
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                  }
                }

                // 4. Action Buttons (Direct Application Builder integration & Official Portal)
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                  verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  // Direct Action: Open Application Builder with template pre-selected!
                  Button(
                    onClick = { viewModel.openApplicationForScheme(scheme) },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("apply_scheme_${scheme.id}")
                  ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      viewModel.tr(
                        "आवेदन पत्र भरें / ड्राफ्ट बनाएं",
                        "Fill Application / Create Draft",
                        "Application Form Bharein / Draft Banayein"
                      ),
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp
                    )
                  }

                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    if (scheme.onlineApplicationLink != null) {
                      FilledTonalButton(
                        onClick = {
                          val intent = Intent(Intent.ACTION_VIEW, Uri.parse(scheme.onlineApplicationLink))
                          context.startActivity(intent)
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                      ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                          viewModel.tr("ऑनलाइन पोर्टल", "Online Portal", "Online Portal"),
                          fontSize = 11.sp
                        )
                      }
                    }

                    OutlinedButton(
                      onClick = { reportingScheme = scheme },
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.weight(1f)
                    ) {
                      Icon(Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(14.dp), tint = JhsTerracotta)
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        viewModel.tr("त्रुटि रिपोर्ट", "Report Issue", "Report Error"),
                        fontSize = 11.sp,
                        color = JhsTerracotta
                      )
                    }
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Expand / Collapse Label
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isExpanded) {
                  viewModel.tr("कम विवरण देखें ▲", "Show Less Details ▲", "Kam Details Dekhein ▲")
                } else {
                  viewModel.tr(
                    "संपूर्ण पात्रता, दस्तावेज़ व प्रक्रिया देखें ▼",
                    "View Full Eligibility, Documents & Procedure ▼",
                    "Poori Eligibility, Documents & Process Dekhein ▼"
                  )
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTeal
              )
            }
          }
        }
      }
    }
  }

  // ----------------------------------------------------
  // Report Error Dialog
  // ----------------------------------------------------
  if (reportingScheme != null) {
    val s = reportingScheme!!
    val sTitle = if (lang == "hi") s.nameHindi else s.nameEnglish
    AlertDialog(
      onDismissRequest = { reportingScheme = null; errorReportSuccessMsg = null },
      title = {
        Text(
          viewModel.tr(
            "योजना जानकारी में त्रुटि रिपोर्ट",
            "Report Scheme Information Update / Issue",
            "Scheme Info Mein Update / Error Report"
          ),
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "${viewModel.tr("योजना:", "Scheme:", "Scheme:")} $sTitle",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = viewModel.tr(
              "यदि पात्रता, दस्तावेज़ या प्रक्रिया में कोई नियम बदल गया है तो विवरण लिखें। JHS सत्यापन टीम इसकी पुष्टि करेगी:",
              "If any eligibility rule, required document, or application process has changed, please describe below. The JHS verification team will review and update it:",
              "Agar eligibility, documents ya process mein koi badlav hua hai toh niche likhein. JHS team verify karegi:"
            ),
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          OutlinedTextField(
            value = errorReportDesc,
            onValueChange = { errorReportDesc = it },
            placeholder = {
              Text(
                viewModel.tr(
                  "बदले हुए नियम या त्रुटि का विवरण लिखें...",
                  "Describe the updated rule or issue...",
                  "Badle hue niyam ya error ki detail likhein..."
                )
              )
            },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
          )
          if (errorReportSuccessMsg != null) {
            Text(text = errorReportSuccessMsg ?: "", color = JhsTealDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (errorReportDesc.isNotBlank()) {
              viewModel.reportSchemeError(s.id, sTitle, errorReportDesc)
              errorReportSuccessMsg = viewModel.tr(
                "✅ धन्यवाद! आपकी रिपोर्ट JHS सत्यापन टीम को भेज दी गई है।",
                "✅ Thank you! Your report has been sent to the JHS verification team.",
                "✅ Dhanyawad! Aapki report JHS verification team ko bhej di gayi hai."
              )
              errorReportDesc = ""
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = JhsTeal)
        ) {
          Text(viewModel.tr("रिपोर्ट भेजें", "Submit Report", "Report Bhejein"))
        }
      },
      dismissButton = {
        TextButton(onClick = { reportingScheme = null; errorReportSuccessMsg = null }) {
          Text(viewModel.tr("बंद करें", "Close", "Close"))
        }
      }
    )
  }

  if (showMasterGuideSheet) {
    PvtgMasterGuideViewerDialog(
      viewModel = viewModel,
      onDismiss = { showMasterGuideSheet = false }
    )
  }
}

private fun translateDepartment(raw: String, isHindi: Boolean): String {
  if (isHindi) return raw
  // If raw contains an English name in parentheses, e.g. "जनजातीय कार्य विभाग, मध्य प्रदेश शासन (Tribal Affairs Dept, MP)", extract or translate
  val parenMatch = Regex("\\(([^)]*[A-Za-z][^)]*)\\)").find(raw)
  if (parenMatch != null && parenMatch.groupValues[1].length > 5) {
    return parenMatch.groupValues[1]
  }
  return raw
    .replace("जनजातीय कार्य विभाग", "Tribal Affairs Department")
    .replace("महिला एवं बाल विकास विभाग", "Women & Child Development Dept.")
    .replace("पशुपालन एवं डेयरी विभाग", "Animal Husbandry & Dairy Dept.")
    .replace("पंचायत एवं ग्रामीण विकास विभाग", "Panchayat & Rural Development Dept.")
    .replace("कृषि एवं किसान कल्याण विभाग", "Agriculture & Farmers Welfare Dept.")
    .replace("किसान कल्याण तथा कृषि विकास विभाग", "Farmers Welfare & Agriculture Development Dept.")
    .replace("राजस्व विभाग", "Revenue Department")
    .replace("सामाजिक न्याय एवं दिव्यांगजन सशक्तिकरण विभाग", "Social Justice & PwD Empowerment Dept.")
    .replace("लोक स्वास्थ्य एवं परिवार कल्याण विभाग", "Public Health & Family Welfare Dept.")
    .replace("लोक स्वास्थ्य यांत्रिकी विभाग", "Public Health Engineering Dept. (PHED)")
    .replace("ऊर्जा विभाग / म.प्र. ऊर्जा विकास निगम", "Energy Dept. / MP Urja Vikas Nigam")
    .replace("सूक्ष्म, लघु और मध्यम उद्यम (MSME) मंत्रालय", "Ministry of MSME")
    .replace("ग्रामीण विकास मंत्रालय", "Ministry of Rural Development")
    .replace("आवासन और शहरी कार्य मंत्रालय", "Ministry of Housing & Urban Affairs")
    .replace("श्रम एवं रोजगार मंत्रालय", "Ministry of Labour & Employment")
    .replace("स्कूल शिक्षा विभाग", "School Education Department")
    .replace("उच्च शिक्षा विभाग", "Higher Education Department")
    .replace("खाद्य, नागरिक आपूर्ति एवं उपभोक्ता संरक्षण विभाग", "Food, Civil Supplies & Consumer Protection Dept.")
    .replace("वन विभाग", "Forest Department")
    .replace("म.प्र. शासन", "Govt. of MP")
    .replace("मध्य प्रदेश शासन", "Govt. of Madhya Pradesh")
    .replace("म.प्र.", "MP")
    .replace("भारत सरकार", "Govt. of India")
}

private fun translateOfficeLocation(raw: String, isHindi: Boolean): String {
  if (isHindi) return raw
  return raw
    .replace("ग्राम पंचायत कार्यालय", "Gram Panchayat Office")
    .replace("ग्राम पंचायत भवन", "Gram Panchayat Bhawan")
    .replace("ग्राम पंचायत", "Gram Panchayat")
    .replace("जनपद पंचायत कार्यालय", "Janpad Panchayat Office")
    .replace("जनपद पंचायत", "Janpad Panchayat")
    .replace("जिला पंचायत", "Zila Panchayat")
    .replace("आंगनवाड़ी केंद्र", "Anganwadi Centre")
    .replace("तहसील कार्यालय", "Tehsil Office")
    .replace("लोक सेवा केंद्र", "Lok Seva Kendra (Public Service Centre)")
    .replace("अनुविभागीय अधिकारी (SDO) कार्यालय", "Sub-Divisional Officer (SDO) Office")
    .replace("सहायक आयुक्त जनजातीय कार्य कार्यालय", "Assistant Commissioner Tribal Affairs Office")
    .replace("पशु चिकित्सालय", "Veterinary Hospital / Dispensary")
    .replace("जिला चिकित्सालय", "District Hospital")
    .replace("सामुदायिक स्वास्थ्य केंद्र", "Community Health Centre (CHC)")
    .replace("कृषि विभाग कार्यालय", "Agriculture Department Office")
    .replace("एमपी ऑनलाइन कियोस्क", "MP Online / CSC Kiosk")
    .replace("सीएससी (CSC) केंद्र", "Common Service Centre (CSC)")
    .replace("बैंक शाखा", "Bank Branch")
    .replace("विद्यालय / महाविद्यालय", "School / College Office")
    .replace("कार्यालय", "Office")
}

private fun translateGrievance(raw: String, isHindi: Boolean): String {
  if (isHindi) return raw
  return raw
    .replace("उपायुक्त जनजातीय कार्य विभाग", "Deputy Commissioner Tribal Affairs")
    .replace("सहायक आयुक्त जनजातीय कार्य विभाग", "Assistant Commissioner Tribal Affairs")
    .replace("जिला जनसुनवाई (प्रत्येक मंगलवार कलेक्टर कार्यालय)", "District Collector Jan Sunwai (Every Tuesday)")
    .replace("जिला कलेक्टर जनसुनवाई", "District Collector Jan Sunwai")
    .replace("जनसुनवाई", "Collectorate Jan Sunwai")
    .replace("सीएम हेल्पलाइन", "CM Helpline")
    .replace("हेल्पलाइन", "Helpline")
    .replace("मुख्य कार्यपालन अधिकारी (CEO)", "Chief Executive Officer (CEO)")
    .replace("जिला पंचायत सीईओ", "CEO Zila Panchayat")
    .replace("जनपद पंचायत सीईओ", "CEO Janpad Panchayat")
    .replace("अथवा", "or")
}

