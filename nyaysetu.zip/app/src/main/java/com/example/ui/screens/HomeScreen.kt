package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.PvtgMasterGuideViewerDialog
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel
import com.example.viewmodel.ScreenTab

@Composable
fun HomeScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  val user by viewModel.currentUser.collectAsState()

  var quickCaseId by remember { mutableStateOf("") }
  var quickPin by remember { mutableStateOf("") }
  var showMasterGuideSheet by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("home_screen"),
    contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Sleek JHS Identity Bar with "About JHS" clickable button
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { viewModel.setTab(ScreenTab.ABOUT_JHS) }
          .testTag("home_about_button_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            Image(
              painter = painterResource(id = R.drawable.jhs_logo),
              contentDescription = "Justice Hub Society Logo",
              contentScale = ContentScale.Fit,
              modifier = Modifier.size(38.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Justice Hub Society",
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = JhsHeadingText
              )
              Text(
                text = viewModel.tr("अधिकार से न्याय तक", "Rights to Justice", "Adhikar Se Nyay"),
                fontSize = 11.sp,
                color = JhsImportantLabel,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          Button(
            onClick = { viewModel.setTab(ScreenTab.ABOUT_JHS) },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = JhsSecondaryButtonBg,
              contentColor = JhsImportantLabel
            ),
            border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.25f)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
            modifier = Modifier.defaultMinSize(minHeight = 32.dp)
          ) {
            Icon(Icons.Default.Info, contentDescription = null, tint = JhsImportantLabel, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = viewModel.tr("संस्था परिचय", "About JHS", "About"),
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }

    // 2. Friendly Greeting Banner (Section 5)
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("greeting_banner"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, JhsBorder.copy(alpha = 0.8f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsLightBeige,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.dp, JhsBorder.copy(alpha = 0.6f))
            ) {
              Text(
                text = viewModel.tr("सहरिया व ग्रामीण साथी मंच", "Community Justice Platform", "Community Platform"),
                color = JhsTeal,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
              // Voice Assistant Launcher
              FilledTonalButton(
                onClick = { viewModel.setTab(ScreenTab.ASSISTANT) },
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = JhsTeal, contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.height(34.dp).testTag("home_hero_voice_button")
              ) {
                Icon(Icons.Default.Mic, contentDescription = "AI Voice Assistant", modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(viewModel.tr("बोलकर पूछें", "Ask by Voice", "Bolkar Poochein"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }

              // Audio Listen Button (Hindi Voice)
              IconButton(
                onClick = {
                  if (isSpeaking) {
                    viewModel.stopSpeech()
                  } else {
                    val speechText = viewModel.tr(
                      hi = "नमस्ते! आपका न्यायसेतु में स्वागत है। आप क्या करना चाहते हैं? नीचे दिए गए विकल्पों में से चुनें। अपनी समस्या बताएं, सरकारी योजनाएं देखें, या अपना आवेदन तैयार करें।",
                      en = "Welcome to NyaySetu! What would you like to do? Choose from the options below to get assistance, view government schemes, or prepare applications.",
                      hinglish = "Namaste! Aapka NyaySetu mein swagat hai. Aap kya karna chahte hain? Niche diye gaye vikalpon mein se chunein."
                    )
                    viewModel.speak(speechText)
                  }
                },
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(JhsTealContainer)
                  .testTag("listen_hero_button")
              ) {
                Icon(
                  imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                  contentDescription = "Read Aloud",
                  tint = JhsTeal,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = viewModel.tr(
              hi = "नमस्ते! आपका NyaySetu में स्वागत है।",
              en = "Namaste! Welcome to NyaySetu.",
              hinglish = "Namaste! Aapka NyaySetu mein swagat hai."
            ),
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.ExtraBold,
              color = JhsCharcoal,
              fontSize = 20.sp,
              lineHeight = 26.sp
            )
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = viewModel.tr(
              hi = "अधिकार, न्याय और सरकारी योजनाओं के लिए आपका साथी।",
              en = "Your trusted partner for rights, justice and public services.",
              hinglish = "Adhikar, nyay aur schemes ke liye aapka sathi."
            ),
            style = MaterialTheme.typography.bodyMedium.copy(
              color = JhsCharcoalLight,
              fontSize = 13.sp
            )
          )
        }
      }
    }

    // Special Banner: PVTG & Tribal Master Guide (Part 1 - 16)
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { showMasterGuideSheet = true }
          .testTag("pvtg_master_guide_banner"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, JhsTeal.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsTerracottaContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = viewModel.tr("विशेष महा-मार्गदर्शिका (भाग 1 से 16)", "Special Master Guide (Parts 1 - 16)", "Special Master Guide (Part 1-16)"),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTerracotta,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
            Surface(
              color = JhsTealContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = viewModel.tr("ऑडियो वाचन", "Audio Reading", "Audio Reading"),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTealDark
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = viewModel.tr("📜 मध्य प्रदेश आदिवासी एवं PVTG महा-मार्गदर्शिका", "📜 MP Tribal & PVTG Master Guide", "📜 MP Tribal & PVTG Master Guide"),
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = JhsHeadingText,
              fontSize = 16.sp
            )
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = viewModel.tr(
              hi = "सहरिया, बैगा, भारिया योजनाएं • 16 अनिवार्य दस्तावेज़ • सरकारी फीस व अवैध वसूली रोकथाम • 32 आधिकारिक पोर्टल • 12 केस स्टडीज",
              en = "Sahariya, Baiga, Bharia Schemes • 16 Essential Documents • Official Fees & Anti-Corruption • 32 Portals • 12 Case Studies",
              hinglish = "Sahariya, Baiga, Bharia Schemes • 16 Zaroori Documents • Govt Fees & Official Portals • 12 Case Studies"
            ),
            fontSize = 12.sp,
            lineHeight = 17.sp,
            color = JhsBodyText
          )

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = { showMasterGuideSheet = true },
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = viewModel.tr("सम्पूर्ण 16 भाग पढ़ें व ऑडियो सुनें", "Read All 16 Chapters & Listen Audio", "Poore 16 Chapters Padhein Aur Sunen"),
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp
            )
          }
        }
      }
    }

    // 3. Clear Question Section Header
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp, start = 2.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(JhsTerracotta)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = viewModel.tr(
            hi = "आप क्या करना चाहते हैं?",
            en = "What would you like to do?",
            hinglish = "Aap kya karna chahte hain?"
          ),
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = JhsCharcoal,
            fontSize = 16.sp
          )
        )
      }
    }

    // 4. Exactly 10 Clean 2-Column Community Cards
    // Row 1: Cards 1 & 2
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        CommunityCard(
          title = viewModel.tr("मेरी समस्या बताएं", "Tell My Problem", "Meri Samasya Batayein"),
          explanation = viewModel.tr("अपनी समस्या बताएं और सहायता मांगें।", "Share your issue and request legal/social help.", "Apni dikkat batayein aur madad lein."),
          icon = Icons.Default.HelpCenter,
          iconTint = JhsTeal,
          containerBg = JhsTealContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_wizard"),
          onClick = { viewModel.openWizard() }
        )

        CommunityCard(
          title = viewModel.tr("सरकारी योजनाएं देखें", "Govt Schemes", "Sarkari Yojanaayein"),
          explanation = viewModel.tr("अपने काम की सरकारी योजनाओं की जानकारी पाएं।", "Explore welfare schemes suited for your family.", "Apne fayde ki schemes dekhein."),
          icon = Icons.Default.AccountBalance,
          iconTint = JhsTerracotta,
          containerBg = JhsTerracottaContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_schemes"),
          onClick = { viewModel.setTab(ScreenTab.SCHEMES) }
        )
      }
    }

    // Row 2: Cards 3 & 4
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        CommunityCard(
          title = viewModel.tr("अपना आवेदन बनाएं", "Create Application", "Apna Avedan Banayein"),
          explanation = viewModel.tr("आसान सवालों के जवाब देकर आवेदन तैयार करें।", "Answer simple questions to draft official PDF.", "Saral sawalon se application banayein."),
          icon = Icons.Default.Description,
          iconTint = JhsGoldDark,
          containerBg = JhsGoldContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_builder"),
          onClick = { viewModel.setTab(ScreenTab.BUILDER) }
        )

        CommunityCard(
          title = viewModel.tr("अपने अधिकार जानें", "Know Your Rights", "Apne Adhikar Janein"),
          explanation = viewModel.tr("अपने अधिकारों और कानूनों को सरल भाषा में समझें।", "Understand laws and land rights in simple Hindi.", "Kanoon aur adhikar asaan bhasha mein."),
          icon = Icons.Default.MenuBook,
          iconTint = JhsTeal,
          containerBg = JhsTealContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_rights"),
          onClick = { viewModel.setTab(ScreenTab.RIGHTS) }
        )
      }
    }

    // Row 3: Cards 5 & 6
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        CommunityCard(
          title = viewModel.tr("गांव की समस्याएं", "Village Issues", "Gaon Ki Samasyaayein"),
          explanation = viewModel.tr("अपने गांव की समस्याएं और विकास की जरूरतें देखें।", "Track village road, water, school priorities.", "Sadak, paani, school ki zarooratein."),
          icon = Icons.Default.HolidayVillage,
          iconTint = JhsTerracotta,
          containerBg = JhsTerracottaContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_priorities"),
          onClick = { viewModel.setTab(ScreenTab.PRIORITIES) }
        )

        CommunityCard(
          title = viewModel.tr("रोजगार और आजीविका", "Livelihood & Work", "Rojgar Aur Aajeevika"),
          explanation = viewModel.tr("रोजगार, खेती और आजीविका के अवसर देखें।", "Farming, MGNREGA wages and skill opportunities.", "Kheti, mazdoori aur kamai ke sadhan."),
          icon = Icons.Default.Agriculture,
          iconTint = JhsGoldDark,
          containerBg = JhsGoldContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_livelihood"),
          onClick = { viewModel.setTab(ScreenTab.LIVELIHOOD) }
        )
      }
    }

    // Row 4: Cards 7 & 8
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        CommunityCard(
          title = viewModel.tr("महिलाओं और बच्चों की सहायता", "Women & Child Care", "Mahila Aur Bachhe"),
          explanation = viewModel.tr("महिलाओं और बच्चों से जुड़ी जानकारी और सहायता पाएं।", "Safe, confidential support and welfare schemes.", "Surakshit sahayata aur poshan yojanaayein."),
          icon = Icons.Default.Shield,
          iconTint = JhsTerracotta,
          containerBg = JhsTerracottaContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_women_child"),
          onClick = { viewModel.setTab(ScreenTab.WOMEN_CHILD) }
        )

        CommunityCard(
          title = viewModel.tr("सीखें और समझें", "Learn & Understand", "Seekhein Aur Samjhein"),
          explanation = viewModel.tr("छोटे पाठ और वीडियो के माध्यम से नई जानकारी पाएं।", "Simple audio-visual lessons and legal glossary.", "Chhote sabak aur kanooni shabdavali."),
          icon = Icons.Default.School,
          iconTint = JhsTeal,
          containerBg = JhsTealContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_learning"),
          onClick = { viewModel.setTab(ScreenTab.LEARNING) }
        )
      }
    }

    // Row 5: Cards 9 & 10
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        CommunityCard(
          title = viewModel.tr("समुदाय की कहानियां", "Community Stories", "Samuday Ki Kahaniyaan"),
          explanation = viewModel.tr("लोगों की कहानियां और पारंपरिक ज्ञान जानें।", "Victories, oral wisdom and inspiring experiences.", "Logon ki prerak kahaniyaan aur gyaan."),
          icon = Icons.Default.AutoStories,
          iconTint = JhsGoldDark,
          containerBg = JhsGoldContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_stories"),
          onClick = { viewModel.setTab(ScreenTab.STORIES) }
        )

        CommunityCard(
          title = viewModel.tr("मदद चाहिए?", "Need Help?", "Madad Chahiye?"),
          explanation = viewModel.tr("ऐप इस्तेमाल करने में सहायता लें।", "Get direct helpline support and guidance.", "App chalane mein seedhi madad lein."),
          icon = Icons.Default.SupportAgent,
          iconTint = JhsTeal,
          containerBg = JhsTealContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .weight(1f)
            .testTag("action_tile_helpline"),
          onClick = { viewModel.setTab(ScreenTab.HELPLINE) }
        )
      }
    }

    // 5. Friendly "मेरे आवेदन की स्थिति देखें" Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("quick_tracker_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, JhsBorder.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(JhsTealContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = JhsTeal,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = viewModel.tr(
                  hi = "मेरे आवेदन की स्थिति देखें",
                  en = "Track My Application Status",
                  hinglish = "Mere Avedan Ki Sthiti Dekhein"
                ),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = JhsCharcoal
              )
              Text(
                text = viewModel.tr(
                  hi = "यदि आपने पहले से कोई शिकायत या आवेदन दिया है, तो उसकी स्थिति यहां देखें।",
                  en = "If you have already submitted a grievance or application, track it here.",
                  hinglish = "Pehle se darj shikayat ya avedan ki sthiti yahan dekhein."
                ),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            val trackerInputColors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = JhsInputBg,
              unfocusedContainerColor = JhsInputBg,
              focusedBorderColor = JhsTeal,
              unfocusedBorderColor = JhsBorder,
              focusedLabelColor = JhsImportantLabel,
              unfocusedLabelColor = JhsSecondaryText,
              focusedTextColor = JhsHeadingText,
              unfocusedTextColor = JhsBodyText,
              focusedPlaceholderColor = JhsPlaceholderText,
              unfocusedPlaceholderColor = JhsPlaceholderText
            )

            OutlinedTextField(
              value = quickCaseId,
              onValueChange = { quickCaseId = it },
              label = { Text(viewModel.tr("केस आईडी", "Case ID", "Case ID"), fontSize = 11.sp) },
              placeholder = { Text("NYAY-2026-0041", fontSize = 11.sp) },
              modifier = Modifier
                .weight(1.3f)
                .testTag("quick_case_id_input"),
              singleLine = true,
              colors = trackerInputColors,
              shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
              value = quickPin,
              onValueChange = { quickPin = it },
              label = { Text(viewModel.tr("सुरक्षा पिन", "PIN Code", "PIN"), fontSize = 11.sp) },
              placeholder = { Text("4192", fontSize = 11.sp) },
              modifier = Modifier
                .weight(0.7f)
                .testTag("quick_pin_input"),
              singleLine = true,
              colors = trackerInputColors,
              shape = RoundedCornerShape(12.dp)
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                val targetId = if (quickCaseId.isNotBlank()) quickCaseId.trim() else "NYAY-2026-0041"
                val targetPin = if (quickPin.isNotBlank()) quickPin.trim() else "4192"
                viewModel.setTrackingTarget(targetId, targetPin)
              },
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("quick_check_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = JhsPrimaryButtonBg,
                contentColor = Color.White
              )
            ) {
              Icon(Icons.Default.Search, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = viewModel.tr("स्थिति जांचें", "Check Status", "Sthiti Jaanchen"),
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
              )
            }

            Button(
              onClick = { viewModel.setTab(ScreenTab.TRACK) },
              modifier = Modifier
                .weight(1f)
                .height(48.dp),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = JhsSecondaryButtonBg,
                contentColor = JhsImportantLabel
              ),
              border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.25f))
            ) {
              Text(
                text = viewModel.tr("पूरी सूची देखें", "View All Cases", "Poori List"),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }
      }
    }
  }

  if (showMasterGuideSheet) {
    PvtgMasterGuideViewerDialog(
      viewModel = viewModel,
      onDismiss = { showMasterGuideSheet = false }
    )
  }
}

@Composable
fun CommunityCard(
  title: String,
  explanation: String,
  icon: ImageVector,
  iconTint: Color,
  containerBg: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .heightIn(min = 145.dp)
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    border = BorderStroke(1.dp, JhsBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(14.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(containerBg),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = iconTint,
          modifier = Modifier.size(26.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column {
        Text(
          text = title,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          lineHeight = 17.sp,
          color = JhsCharcoal
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = explanation,
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          lineHeight = 15.sp,
          maxLines = 2
        )
      }
    }
  }
}
