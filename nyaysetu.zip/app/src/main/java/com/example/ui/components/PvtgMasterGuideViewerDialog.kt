package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PvtgAndTribalMasterGuideData
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PvtgMasterGuideViewerDialog(
  viewModel: NyaySetuViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  var selectedTab by remember { mutableStateOf(0) } // 0=Overview, 1=PVTG Schemes, 2=Housing&Infra, 3=Livelihood, 4=Farmers&FRA, 5=Documents&Fees, 6=Grievance&RTI, 7=12 Case Studies, 8=32 Portals & Checklist

  val tabTitles = listOf(
    "प्रस्तावना व परिचय",
    "भाग 1: PVTG योजनाएँ",
    "भाग 5: आवास, जल, बिजली",
    "भाग 6: रोजगार व आजीविका",
    "भाग 7-8: किसान, FRA व स्वास्थ्य",
    "भाग 11-13: 16 दस्तावेज़ व फीस",
    "भाग 14: शिकायत, 181 व विधिक सहायता",
    "भाग 15: 12 केस अध्ययन",
    "भाग 16: 32 पोर्टल व चेकलिस्ट"
  )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = JhsCream,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
    modifier = Modifier.fillMaxHeight(0.95f)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
        .navigationBarsPadding()
    ) {
      // Top Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(JhsTealContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.MenuBook, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "आदिवासी एवं PVTG महा-मार्गदर्शिका",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
            )
            Text(
              text = "मध्य प्रदेश शासन व भारत सरकार (भाग 1 से 16)",
              fontSize = 11.sp,
              color = JhsSecondaryText
            )
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          IconButton(
            onClick = {
              if (isSpeaking) {
                viewModel.stopSpeech()
              } else {
                val currentText = when (selectedTab) {
                  1 -> "भाग 1: मध्य प्रदेश में 3 PVTG समुदाय हैं: सहरिया, बैगा और भारिया। इनके लिए PM-JANMAN, DAJGUA, आहार अनुदान ₹1,500 प्रतिमाह और दुधारू पशु प्रदाय 90% अनुदान योजनाएं संचालित हैं।"
                  2 -> "भाग 5: आवास, बिजली, पानी और शौचालय। PM-JANMAN आवास, प्रधानमंत्री आवास ग्रामीण ₹1.20 लाख, स्वच्छ भारत मिशन शौचालय ₹12,000 और जल जीवन मिशन हर घर नल।"
                  3 -> "भाग 6: रोजगार व आजीविका। मनरेगा 100 दिन कानूनी रोजगार अधिकार, राष्ट्रीय ग्रामीण आजीविका मिशन, PMJVM वन धन विकास केंद्र और मुख्यमंत्री सीखो-कमाओ योजना।"
                  4 -> "भाग 7 और 8: किसान, वन अधिकार अधिनियम 2006, पेसा कानून 1996, PM-KISAN ₹6,000, फसल बीमा, आयुष्मान भारत ₹5 लाख और राष्ट्रीय सिकल सेल एनीमिया उन्मूलन मिशन।"
                  5 -> "भाग 11 से 13: परिवार के 16 महत्वपूर्ण दस्तावेज। आधार, समग्र, जाति, निवास, आय, वन पट्टा और बैंक DBT। सरकारी शुल्क बनाम कियोस्क शुल्क के नियम।"
                  6 -> "भाग 14: शिकायत और विधिक सहायता। CM हेल्पलाइन 181, सूचना का अधिकार RTI 2005 और DLSA 15100 से मुफ्त सरकारी वकील।"
                  7 -> "भाग 15: आदिवासी परिवारों के वास्तविक जीवन से जुड़े 12 केस उदाहरण।"
                  8 -> "भाग 16: सभी 32 महत्वपूर्ण सरकारी पोर्टल और 15 सवाल चेकलिस्ट।"
                  else -> "न्यायसेतु आदिवासी एवं PVTG महा-मार्गदर्शिका में आपका स्वागत है। यहाँ आप सभी 16 भागों की आधिकारिक जानकारी, योजनाएं, दस्तावेज नियम और पोर्टल देख सकते हैं।"
                }
                viewModel.speak(currentText)
              }
            },
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(JhsTealContainer)
          ) {
            Icon(
              imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
              contentDescription = "Listen",
              tint = JhsTeal
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = JhsHeadingText)
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Tab navigation chips
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(tabTitles.indices.toList()) { index ->
          val isSelected = selectedTab == index
          Surface(
            color = if (isSelected) JhsTeal else Color.White,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, if (isSelected) JhsTeal else JhsBorder),
            modifier = Modifier.clickable { selectedTab = index }
          ) {
            Text(
              text = tabTitles[index],
              fontSize = 12.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) Color.White else JhsHeadingText,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Tab Content
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 30.dp)
      ) {
        when (selectedTab) {
          0 -> {
            // Overview & Summary
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text(
                    text = "मध्य प्रदेश आदिवासी एवं PVTG विस्तृत मार्गदर्शिका (भाग 1 - 16)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = JhsTeal
                  )
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = "स्थिति सत्यापन: 31 अक्टूबर 2026 तक के आधिकारिक आदेशों एवं पोर्टल्स के आधार पर तैयार। इसमें केवल योजनाओं के नाम नहीं, बल्कि पात्रता, मिलने वाले वास्तविक लाभ, आवेदन प्रक्रिया, 16 जरूरी दस्तावेज, सरकारी फीस नियम, 32 सरकारी पोर्टल और 12 केस स्टडीज शामिल हैं।",
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = JhsBodyText
                  )
                  Spacer(modifier = Modifier.height(12.dp))

                  Surface(
                    color = JhsLightBeige,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, JhsBorder.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                      Text(
                        text = "मूल दर्शन (Core Philosophy):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = JhsHeadingText
                      )
                      Spacer(modifier = Modifier.height(4.dp))
                      Text(
                        text = "• तकनीक को लोगों को न्याय, अधिकार और विकास के करीब लाना चाहिए। यह समुदायों और सार्वजनिक संस्थाओं के बीच कोई नई बाधा नहीं बननी चाहिए।\n• किसी भी परिवार को योजना का लाभ दिलाने के लिए पहले उसकी आवश्यकता पहचानें, पात्रता जांचें, दस्तावेज पूरे कराएं और अंतिम स्वीकृति तक स्थिति का पालन करें।",
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = JhsBodyText
                      )
                    }
                  }
                }
              }
            }

            item {
              Text(
                text = "मार्गदर्शिका के मुख्य खंड:",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = JhsHeadingText
              )
            }

            items(tabTitles.drop(1).indices.toList()) { i ->
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder),
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable { selectedTab = i + 1 }
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = tabTitles[i + 1],
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = JhsHeadingText
                  )
                  Icon(Icons.Default.ChevronRight, contentDescription = null, tint = JhsTeal)
                }
              }
            }
          }

          1 -> {
            // Part 1: PVTG Schemes
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text(
                    text = "1. मध्य प्रदेश में 3 PVTG समुदायों की पहचान",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = JhsTeal
                  )
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = "ST और PVTG एक ही श्रेणी नहीं हैं। ST संविधान के अंतर्गत राज्य हेतु अधिसूचित जनजातियां हैं, जबकि PVTG अनुसूचित जनजातियों के भीतर वे 75 समूह हैं जिन्हें अत्यधिक पिछड़ा और विकास कार्यक्रमों का विशेष पात्र माना गया है।",
                    fontSize = 12.5.sp,
                    color = JhsBodyText
                  )
                  Spacer(modifier = Modifier.height(10.dp))

                  val pvtgs = listOf(
                    "सहरिया (Sahariya)" to "ग्वालियर-चंबल क्षेत्र के शिवपुरी, श्योपुर, मुरैना, भिंड, ग्वालियर, गुना, अशोकनगर और दतिया।",
                    "बैगा (Baiga)" to "डिंडोरी, मंडला, बालाघाट, उमरिया, शहडोल, अनूपपुर आदि जिले।",
                    "भारिया (Bharia)" to "विशेष रूप से छिंदवाड़ा जिले का पातालकोट क्षेत्र।"
                  )
                  pvtgs.forEach { (name, area) ->
                    Surface(
                      color = JhsSecondaryBg,
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                    ) {
                      Column(modifier = Modifier.padding(10.dp)) {
                        Text(name, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = JhsTealDark)
                        Text(area, fontSize = 11.5.sp, color = JhsBodyText)
                      }
                    }
                  }
                }
              }
            }

            // PM-JANMAN, DAJGUA, Aahar Anudan, Dudharu Pashu
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text(
                    text = "2. PM-JANMAN (11 प्रमुख हस्तक्षेप)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = JhsHeadingText
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "9 केंद्रीय मंत्रालयों द्वारा संचालित: पक्का आवास, सुरक्षित पेयजल, सड़क संपर्क, बिजली/सोलर, मोबाइल सुविधा, स्वास्थ्य व पोषण, आंगनवाड़ी, शिक्षा व छात्रावास, आजीविका अवसर, बहुउद्देशीय केंद्र, स्वच्छता।\n\nविशेष: PVTG परिवारों हेतु PMAY-G के कुछ कठोर अपात्रता नियमों में केंद्र सरकार द्वारा छूट दी गई है।",
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = JhsBodyText
                  )
                  Spacer(modifier = Modifier.height(10.dp))
                  HorizontalDivider(color = JhsBorderSubtle)
                  Spacer(modifier = Modifier.height(10.dp))

                  Text(
                    text = "3. धरती आबा जनजातीय ग्राम उत्कर्ष अभियान (DAJGUA)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = JhsHeadingText
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "2 अक्टूबर 2024 से 2028-29 तक देश के 63,843 जनजातीय बहुल गाँवों में 17 मंत्रालयों के 25 हस्तक्षेप। म.प्र. के छिंदवाड़ा व पांढुर्णा के 591 गाँव सहित अन्य चयनित जनजातीय ग्राम शामिल हैं।",
                    fontSize = 12.sp,
                    color = JhsBodyText
                  )
                  Spacer(modifier = Modifier.height(10.dp))
                  HorizontalDivider(color = JhsBorderSubtle)
                  Spacer(modifier = Modifier.height(10.dp))

                  Text(
                    text = "4. आहार अनुदान योजना (म.प्र. शासन)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = JhsHeadingText
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "सहरिया, बैगा, भारिया परिवारों की महिला मुखिया को कुपोषण उन्मूलन हेतु ₹1,500 प्रतिमाह DBT पोषण सहायता। अलग से आवेदन की आवश्यकता नहीं, विभागीय डेटा व समग्र आधार मैपिंग से सत्यापन।",
                    fontSize = 12.sp,
                    color = JhsBodyText
                  )
                  Spacer(modifier = Modifier.height(10.dp))
                  HorizontalDivider(color = JhsBorderSubtle)
                  Spacer(modifier = Modifier.height(10.dp))

                  Text(
                    text = "5. मुख्यमंत्री दुधारू पशु प्रदाय कार्यक्रम",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = JhsHeadingText
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "90% सरकारी अनुदान एवं मात्र 10% हितग्राही अंशदान पर 2 देशी दुधारू गाय (7+ ली/दिन) अथवा मुर्रा भैंस (8+ ली/दिन)। ग्राम सभा व पशु चिकित्सालय द्वारा चयन।",
                    fontSize = 12.sp,
                    color = JhsBodyText
                  )
                }
              }
            }
          }

          2 -> {
            // Part 5: Housing, Water, Power, Sanitation
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text("आवास एवं बुनियादी सुविधाएँ (भाग 5)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = JhsTeal)
                  Spacer(modifier = Modifier.height(8.dp))

                  val items = listOf(
                    "PM-JANMAN आवास योजना (ग्रामीण)" to "PVTG परिवारों हेतु विशेष घटक। PMAY-G के सामान्य अपात्रता नियमों में शिथिलता। ग्राम पंचायत व जनपद नोडल अधिकारी से संपर्क करें।",
                    "प्रधानमंत्री आवास योजना – ग्रामीण (PMAY-G)" to "मैदानी क्षेत्रों में ₹1.20 लाख की इकाई सहायता किस्तों में। साथ में शौचालय प्रोत्साहन व मनरेगा मजदूरी अभिसरण का लाभ।",
                    "स्वच्छ भारत मिशन – ग्रामीण (SBM-G)" to "व्यक्तिगत घरेलू शौचालय (IHHL) निर्माण हेतु ₹12,000 की प्रोत्साहन राशि। निर्माण उपरांत जियो-टैग कर सीधे बैंक खाते में भुगतान।",
                    "जल जीवन मिशन (हर घर जल)" to "नल से नियमित व सुरक्षित पेयजल की आपूर्ति। शिकायत में केवल कनेक्शन नहीं, आपूर्ति की निरंतरता व गुणवत्ता भी लिखें।"
                  )

                  items.forEach { (t, d) ->
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                      Text("• $t", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
                      Text(d, fontSize = 12.sp, lineHeight = 17.sp, color = JhsBodyText, modifier = Modifier.padding(start = 12.dp, top = 2.dp))
                    }
                  }
                }
              }
            }
          }

          3 -> {
            // Part 6: Livelihood & Employment
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text("रोजगार, मनरेगा व कौशल विकास (भाग 6)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = JhsTeal)
                  Spacer(modifier = Modifier.height(8.dp))

                  val items = listOf(
                    "महात्मा गांधी नरेगा (MGNREGA)" to "प्रत्येक ग्रामीण परिवार को वित्तीय वर्ष में 100 दिन अकुशल शारीरिक रोजगार का कानूनी अधिकार। काम की लिखित मांग दें व पावती लें। 15 दिन में काम न मिलने पर बेरोजगारी भत्ता देय।",
                    "राष्ट्रीय ग्रामीण आजीविका मिशन (DAY-NRLM)" to "महिला स्वयं सहायता समूह (SHG), नियमित बचत, कम ब्याज पर बैंक ऋण व आजीविका प्रशिक्षण।",
                    "PMJVM व वन धन विकास केंद्र (TRIFED)" to "महुआ, चिरौंजी, तेन्दूपत्ता, शहद, लाख आदि का मूल्य संवर्धन व प्रसंस्करण। 300 सदस्यीय केंद्र हेतु ₹15 लाख अनुदान व न्यूनतम समर्थन मूल्य (MSP) गारंटी।",
                    "मुख्यमंत्री सीखो-कमाओ योजना (MMSKY)" to "18-29 वर्ष के शिक्षित युवाओं को ऑन-द-जॉब ट्रेनिंग के साथ ₹8,000 से ₹10,000 प्रतिमाह स्टाइपेंड।"
                  )

                  items.forEach { (t, d) ->
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                      Text("• $t", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
                      Text(d, fontSize = 12.sp, lineHeight = 17.sp, color = JhsBodyText, modifier = Modifier.padding(start = 12.dp, top = 2.dp))
                    }
                  }
                }
              }
            }
          }

          4 -> {
            // Part 7-8: Farmers, FRA, PESA, Health
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text("किसान, वन अधिकार व स्वास्थ्य (भाग 7 से 8)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = JhsTeal)
                  Spacer(modifier = Modifier.height(8.dp))

                  val items = listOf(
                    "वन अधिकार अधिनियम, 2006 (FRA)" to "13 दिसंबर 2005 से पूर्व काबिज वनभूमि पर अधिकतम 4 हेक्टेयर तक व्यक्तिगत पट्टा (IFR)। पट्टा पति-पत्नी के संयुक्त नाम। धारा 4(5): दावा लंबित रहने तक बेदखली पूरी तरह प्रतिबंधित है।",
                    "पेसा कानून, 1996 (PESA)" to "अनुसूचित क्षेत्रों में ग्राम सभा को सामुदायिक संसाधन, लघु वनोपज, बाजार व विकास योजनाओं के निर्णय की सर्वोच्च शक्ति।",
                    "PM-KISAN व फसल बीमा (PMFBY)" to "पात्र किसानों को ₹6,000 वार्षिक (e-KYC अनिवार्य)। फसल आपदा नुकसान होने पर 72 घंटे में बीमा कंपनी को सूचना दें।",
                    "आयुष्मान भारत (AB-PMJAY)" to "पात्र परिवार को प्रति वर्ष ₹5 लाख का कैशलेस स्वास्थ्य कवर।",
                    "राष्ट्रीय सिकल सेल एनीमिया उन्मूलन मिशन" to "आदिवासी समुदाय में सिकल सेल की निःशुल्क जांच, काउंसलिंग व डिजिटल रंग-कोडित स्वास्थ्य कार्ड।"
                  )

                  items.forEach { (t, d) ->
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                      Text("• $t", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
                      Text(d, fontSize = 12.sp, lineHeight = 17.sp, color = JhsBodyText, modifier = Modifier.padding(start = 12.dp, top = 2.dp))
                    }
                  }
                }
              }
            }
          }

          5 -> {
            // Part 11-13: 16 Essential Documents & Official Fees
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text("16 अनिवार्य दस्तावेज़ एवं फीस नियम (भाग 11 से 13)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = JhsTeal)
                  Spacer(modifier = Modifier.height(8.dp))

                  Text("16 आवश्यक दस्तावेज़ चेकलिस्ट:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = JhsHeadingText)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    "1. आधार कार्ड | 2. समग्र परिवार आईडी | 3. समग्र सदस्य आईडी | 4. जाति (ST/PVTG) प्रमाण पत्र | 5. निवास प्रमाण पत्र | 6. आय प्रमाण पत्र | 7. जन्म प्रमाण पत्र | 8. मृत्यु प्रमाण पत्र | 9. बैंक पासबुक (Aadhaar NPCI मैपर सक्रिय) | 10. राशन कार्ड | 11. जॉब कार्ड | 12. वनाधिकार पट्टा | 13. UDID दिव्यांगता कार्ड | 14. किसान B-1 खसरा | 15. पैन कार्ड | 16. स्कूल अंकसूची।",
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = JhsBodyText
                  )
                  Spacer(modifier = Modifier.height(12.dp))

                  Surface(
                    color = JhsLightBeige,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, JhsBorder.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                      Text("सरकारी फीस के नियम (सावधानी):", fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = JhsHeadingText)
                      Spacer(modifier = Modifier.height(4.dp))
                      Text(
                        "• सरकारी शुल्क: कानूनन निर्धारित दर (सामान्य आधार नामांकन निःशुल्क, जाति/आय सामान्यतः निःशुल्क या ₹10-₹30)।\n• कियोस्क सेवा शुल्क: अधिकृत लोक सेवा केंद्र की निर्धारित कंप्यूटराइज्ड रसीद लें।\n• अवैध वसूली: किसी कर्मचारी या दलाल द्वारा बिना रसीद अतिरिक्त पैसा मांगना गैरकानूनी है। भुगतान न करें, तुरंत CM हेल्पलाइन 181 पर शिकायत दर्ज कराएं।",
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp,
                        color = JhsBodyText
                      )
                    }
                  }
                }
              }
            }
          }

          6 -> {
            // Part 14: Grievance, CM 181, RTI, DLSA 15100 & Sample Letter
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text("शिकायत, आरटीआई एवं कानूनी सहायता (भाग 14)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = JhsTeal)
                  Spacer(modifier = Modifier.height(8.dp))

                  Text("1. मध्य प्रदेश CM हेल्पलाइन 181:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = JhsHeadingText)
                  Text("किसी भी सरकारी विभाग में आवेदन पर कार्यवाही न होने, योजना लाभ रोके जाने पर 181 पर कॉल करें और शिकायत क्रमांक प्राप्त करें।", fontSize = 12.sp, color = JhsBodyText)
                  Spacer(modifier = Modifier.height(8.dp))

                  Text("2. सूचना का अधिकार (RTI 2005):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = JhsHeadingText)
                  Text("पात्रता सूची, मस्टर रोल, कार्य आदेश व आवेदन अस्वीकृति का लिखित कारण प्राप्त करने हेतु ₹10 के शुल्क (बीपीएल हेतु निःशुल्क) पर आवेदन दें।", fontSize = 12.sp, color = JhsBodyText)
                  Spacer(modifier = Modifier.height(8.dp))

                  Text("3. मुफ्त कानूनी सहायता (DLSA / NALSA 15100):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = JhsHeadingText)
                  Text("विधिक सेवा प्राधिकरण अधिनियम की धारा 12 के तहत अनुसूचित जनजाति (ST) के प्रत्येक नागरिक को अदालत व अपील में पूरी तरह मुफ्त वकील का अधिकार है।", fontSize = 12.sp, color = JhsBodyText)
                }
              }
            }

            // Grievance letter sample card with copy button
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text("शिकायत पत्र का कानूनी प्रारूप (नमूना)", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = JhsHeadingText)
                    IconButton(
                      onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("शिकायत प्रारूप", PvtgAndTribalMasterGuideData.sampleGrievanceLetterTemplate))
                        Toast.makeText(context, "शिकायत प्रारूप कॉपी हो गया", Toast.LENGTH_SHORT).show()
                      }
                    ) {
                      Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = JhsTeal)
                    }
                  }
                  Spacer(modifier = Modifier.height(6.dp))
                  Surface(
                    color = JhsSecondaryBg,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(
                      text = PvtgAndTribalMasterGuideData.sampleGrievanceLetterTemplate,
                      fontSize = 11.sp,
                      lineHeight = 15.sp,
                      color = JhsBodyText,
                      modifier = Modifier.padding(10.dp)
                    )
                  }
                }
              }
            }
          }

          7 -> {
            // Part 15: 12 Real Life Case Studies
            item {
              Text(
                text = "आदिवासी परिवारों के वास्तविक जीवन के 12 उदाहरण:",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = JhsHeadingText
              )
            }

            items(PvtgAndTribalMasterGuideData.caseStudies) { cs ->
              Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Text(cs.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsTeal)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text("स्थिति: ${cs.situation}", fontSize = 12.sp, color = JhsBodyText)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text("लागू योजनाएँ:\n${cs.applicableSchemes}", fontSize = 11.5.sp, color = JhsHeadingText)
                  Spacer(modifier = Modifier.height(6.dp))
                  Surface(
                    color = JhsLightBeige,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(
                      text = "सुझाव: ${cs.recommendedAction}",
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.Medium,
                      color = JhsTealDark,
                      modifier = Modifier.padding(8.dp)
                    )
                  }
                }
              }
            }
          }

          8 -> {
            // Part 16: 32 Portals Directory & 15 Questions Checklist
            item {
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text("आवेदन से पहले 15 सवाल चेकलिस्ट", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JhsTeal)
                  Spacer(modifier = Modifier.height(6.dp))
                  PvtgAndTribalMasterGuideData.preApplication15Questions.forEach { q ->
                    Text("• $q", fontSize = 12.sp, lineHeight = 16.sp, color = JhsBodyText, modifier = Modifier.padding(vertical = 2.dp))
                  }
                }
              }
            }

            item {
              Text(
                text = "सभी 32 महत्वपूर्ण सरकारी पोर्टल (Official Portals Directory):",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = JhsHeadingText
              )
            }

            items(PvtgAndTribalMasterGuideData.officialPortalsList) { portal ->
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, JhsBorder),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(portal.subject, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = JhsHeadingText)
                    Text(portal.name, fontSize = 11.sp, color = JhsTeal)
                    Text(portal.url, fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                  }
                  IconButton(
                    onClick = {
                      try {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(portal.url))
                        context.startActivity(browserIntent)
                      } catch (e: Exception) {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Portal URL", portal.url))
                        Toast.makeText(context, "लिंक कॉपी हो गया: ${portal.url}", Toast.LENGTH_SHORT).show()
                      }
                    }
                  ) {
                    Icon(Icons.Default.OpenInNew, contentDescription = "Open", tint = JhsTeal)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
