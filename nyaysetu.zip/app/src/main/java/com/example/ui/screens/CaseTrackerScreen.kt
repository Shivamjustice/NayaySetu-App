package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CaseRecord
import com.example.model.CaseStatus
import com.example.model.PriorityLevel
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun CaseTrackerScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val caseIdInput by viewModel.trackerCaseId.collectAsState()
  val pinInput by viewModel.trackerPin.collectAsState()
  val trackedCase by viewModel.trackedCase.collectAsState()
  val errorMessage by viewModel.trackerErrorMessage.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Search & 2FA PIN Verification Bar
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = if (lang == "hi") "मामले की स्थिति देखें (Two-Factor Secure Tracking)" else "Track Case Status (2-Factor Verification)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (lang == "hi") {
              "नागरिक गोपनीयता सुरक्षा: स्थिति देखने हेतु केस आईडी के साथ 4-अंकों का सत्यापन पिन दर्ज करें।"
            } else {
              "Citizen Privacy Protection: Enter Case ID and the 4-digit Security PIN issued at submission."
            },
            style = MaterialTheme.typography.bodySmall.copy(color = JhsSecondaryText)
          )

          Spacer(modifier = Modifier.height(12.dp))

          val trackerInputColors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = JhsInputBg,
            unfocusedContainerColor = JhsInputBg,
            focusedBorderColor = JhsTeal,
            unfocusedBorderColor = JhsBorder,
            focusedTextColor = JhsHeadingText,
            unfocusedTextColor = JhsHeadingText,
            focusedPlaceholderColor = JhsPlaceholderText,
            unfocusedPlaceholderColor = JhsPlaceholderText
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = caseIdInput,
              onValueChange = { viewModel.trackerCaseId.value = it },
              label = { Text(if (lang == "hi") "केस आईडी" else "Case ID", fontSize = 12.sp) },
              placeholder = { Text("NYAY-2026-0041", fontSize = 11.sp) },
              leadingIcon = { Icon(Icons.Default.Fingerprint, contentDescription = null, tint = JhsTeal) },
              colors = trackerInputColors,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .weight(1.2f)
                .testTag("tracker_screen_case_id_input"),
              singleLine = true
            )

            OutlinedTextField(
              value = pinInput,
              onValueChange = { viewModel.trackerPin.value = it },
              label = { Text(if (lang == "hi") "4-अंक पिन" else "4-Digit PIN", fontSize = 12.sp) },
              placeholder = { Text("4192", fontSize = 11.sp) },
              leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = JhsTerracotta) },
              colors = trackerInputColors,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .weight(0.8f)
                .testTag("tracker_screen_pin_input"),
              singleLine = true
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Button(
            onClick = { viewModel.lookupCase() },
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("verify_and_track_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal, contentColor = Color.White)
          ) {
            Icon(Icons.Default.VerifiedUser, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (lang == "hi") "सत्यापित करें व स्थिति देखें" else "Verify & View Status",
              fontWeight = FontWeight.SemiBold,
              fontSize = 14.sp
            )
          }

          if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
              color = JhsTerracotta.copy(alpha = 0.1f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = errorMessage ?: "",
                color = JhsTerracotta,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }
      }
    }

    // 2. Case Details Card (if found)
    if (trackedCase != null) {
      val c = trackedCase!!

      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("tracked_case_details_card"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Category Badge & Priority
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                color = JhsTealContainer,
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = if (lang == "hi") c.category.labelHi else c.category.labelEn,
                  color = JhsOnTealContainer,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }

              Surface(
                color = when (c.priority) {
                  PriorityLevel.URGENT -> JhsTerracotta.copy(alpha = 0.15f)
                  PriorityLevel.HIGH -> JhsGold.copy(alpha = 0.2f)
                  else -> MaterialTheme.colorScheme.surfaceVariant
                },
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = if (lang == "hi") c.priority.labelHi else c.priority.labelEn,
                  color = when (c.priority) {
                    PriorityLevel.URGENT -> JhsTerracotta
                    PriorityLevel.HIGH -> JhsGoldDark
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                  },
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title & Case ID
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Top
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = c.title,
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "${if (lang == "hi") "केस आईडी" else "Case ID"}: ${c.id}",
                  fontSize = 12.sp,
                  color = JhsTeal,
                  fontWeight = FontWeight.SemiBold
                )
              }

              // Speak Case Status Button
              IconButton(
                onClick = {
                  if (isSpeaking) {
                    viewModel.stopSpeech()
                  } else {
                    val readText = if (lang == "hi") {
                      "केस संख्या ${c.id}। स्थिति: ${c.status.labelHi}। ${c.status.descriptionHi}। आवेदक: ${c.applicantName}। गाँव: ${c.village}, विकासखंड ${c.block}। सहायता आग्रह: ${c.assistanceRequested}"
                    } else {
                      "Case ID ${c.id}. Status: ${c.status.labelEn}. Applicant: ${c.applicantName}. Village: ${c.village}. Assistance: ${c.assistanceRequested}"
                    }
                    viewModel.speak(readText)
                  }
                },
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(JhsTealContainer)
              ) {
                Icon(
                  imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                  contentDescription = "Listen Status",
                  tint = JhsTeal,
                  modifier = Modifier.size(20.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Location & Date
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(vertical = 2.dp)
            ) {
              Icon(Icons.Default.LocationOn, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${c.village}, ${c.gramPanchayat}, ${c.block}, ${c.district}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(vertical = 2.dp)
            ) {
              Icon(Icons.Default.Person, contentDescription = null, tint = JhsTerracotta, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${if (lang == "hi") "आवेदक" else "Applicant"}: ${if (c.isAnonymous) (if (lang == "hi") "गोपनीय" else "Anonymous") else c.applicantName}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Description
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = if (lang == "hi") "समस्या का विवरण:" else "Grievance Description:",
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = c.description, fontSize = 12.sp, lineHeight = 16.sp)
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 13-Stage Visual Workflow Stepper Bar
            Text(
              text = if (lang == "hi") "13-स्तरीय कानूनी प्रक्रिया (Legal Workflow Progress)" else "13-Stage Legal Workflow Progress",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Surface(
              color = JhsTealContainer.copy(alpha = 0.5f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(JhsTeal),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "${c.status.stepIndex}/13",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = if (lang == "hi") c.status.labelHi else c.status.labelEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = JhsTealDark
                  )
                  Text(
                    text = if (lang == "hi") c.status.descriptionHi else c.status.descriptionEn,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Case Team & Assigned Contacts
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(
                  text = if (lang == "hi") "नियुक्त केस मैनेजर:" else "Assigned Manager:",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.outline
                )
                Text(
                  text = c.assignedManagerName.ifBlank { "सुनीता शर्मा (Sunita Sharma)" },
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }

              Column {
                Text(
                  text = if (lang == "hi") "ग्राम वॉलंटियर:" else "Field Volunteer:",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.outline
                )
                Text(
                  text = c.assignedVolunteerName.ifBlank { "रमेश सहरिया (Ramesh Sahariya)" },
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }
        }
      }

      // 3. Document Checklist Section
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(Icons.Default.Checklist, contentDescription = null, tint = JhsTeal)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (lang == "hi") "आवश्यक दस्तावेज़ सत्यापन सूची" else "Document Verification Checklist",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (c.documentChecklist.isEmpty()) {
              Text(
                text = if (lang == "hi") "कोई अतिरिक्त दस्तावेज़ अपेक्षित नहीं है।" else "No additional documents required.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            } else {
              c.documentChecklist.forEach { doc ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = if (doc.isVerified) Icons.Default.CheckCircle else Icons.Outlined.HourglassEmpty,
                    contentDescription = null,
                    tint = if (doc.isVerified) JhsTeal else JhsTerracotta,
                    modifier = Modifier.size(20.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = doc.title,
                      fontSize = 12.sp,
                      fontWeight = if (doc.isVerified) FontWeight.Normal else FontWeight.SemiBold
                    )
                    Text(
                      text = doc.description + (if (doc.notes != null) " (${doc.notes})" else ""),
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                  if (doc.isMandatory) {
                    Surface(
                      color = JhsTerracotta.copy(alpha = 0.15f),
                      shape = RoundedCornerShape(6.dp)
                    ) {
                      Text(
                        text = if (lang == "hi") "अनिवार्य" else "Mandatory",
                        color = JhsTerracotta,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }

      // 4. Institutional Referral (e.g. DLSA)
      if (c.referrals.isNotEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JhsWhite),
            border = BorderStroke(1.dp, JhsBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountBalance, contentDescription = null, tint = JhsTeal)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (lang == "hi") "विधिक सेवा संस्था संदर्भ (Institutional Referral)" else "Statutory / DLSA Referral",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              c.referrals.forEach { ref ->
                Text(
                  text = "• ${ref.expertName} (${ref.agencyName})",
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp
                )
                Text(
                  text = ref.informationSharedSummary,
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (ref.responseNotes != null) {
                  Spacer(modifier = Modifier.height(4.dp))
                  Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text(
                      text = "${if (lang == "hi") "डीएलएसए उत्तर" else "Response"}: ${ref.responseNotes}",
                      fontSize = 11.sp,
                      color = JhsTealDark,
                      modifier = Modifier.padding(6.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }

      // 5. Approved Public Updates Timeline (Confidential Internal Notes are filtered out!)
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, contentDescription = null, tint = JhsTeal)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (lang == "hi") "सार्वजनिक प्रगति समय-सारणी" else "Public Progress Timeline",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
              }

              Surface(
                color = JhsGoldContainer,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = if (lang == "hi") "गोपनीयता सुरक्षित" else "Privacy Protected",
                  color = JhsOnGoldContainer,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val publicNotes = c.notes.filter { !it.isInternal }

            if (publicNotes.isEmpty()) {
              Text(
                text = if (lang == "hi") "अभी तक कोई सार्वजनिक नोट दर्ज नहीं हुआ।" else "No public timeline updates recorded yet.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            } else {
              publicNotes.forEach { note ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .size(8.dp)
                      .clip(CircleShape)
                      .background(JhsTeal)
                      .align(Alignment.Top)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Text(
                        text = note.authorName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                      )
                      Text(
                        text = note.timestamp,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.outline
                      )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = note.content,
                      fontSize = 12.sp,
                      lineHeight = 16.sp
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
