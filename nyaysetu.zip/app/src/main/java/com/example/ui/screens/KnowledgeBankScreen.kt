package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CaseCategory
import com.example.model.KnowledgeArticle
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun KnowledgeBankScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val articles by viewModel.filteredKnowledge.collectAsState()
  val searchQuery by viewModel.knowledgeSearchQuery.collectAsState()
  val selectedCat by viewModel.knowledgeSelectedCategory.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()

  var expandedArticleId by remember { mutableStateOf<String?>("kb-01") }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Header with description & audio button
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (lang == "hi") "वनाधिकार व सरकारी योजना ज्ञानकोष" else "Rights & Schemes Knowledge Bank",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Text(
                text = if (lang == "hi") "सत्यापित विधिक जानकारी, पात्रता व प्रक्रिया" else "Verified legal provisions, eligibility & procedure",
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
            }

            IconButton(
              onClick = {
                if (isSpeaking) {
                  viewModel.stopSpeech()
                } else {
                  val overview = if (lang == "hi") {
                    "ज्ञानकोष में आपका स्वागत है। यहाँ आप वनाधिकार अधिनियम 2006, भू-राजस्व संहिता धारा 170-ख, सहरिया आहार अनुदान योजना और मनरेगा के कानूनी अधिकारों की पूरी जानकारी सुन और पढ़ सकते हैं।"
                  } else {
                    "Welcome to the Rights Knowledge Bank. Access verified guides on Forest Rights Act, Section 170-B, and tribal welfare schemes."
                  }
                  viewModel.speak(overview)
                }
              },
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(JhsTealContainer)
            ) {
              Icon(
                imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                contentDescription = "Listen Overview",
                tint = JhsTeal
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.knowledgeSearchQuery.value = it },
            placeholder = { Text(if (lang == "hi") "खोजें (उदा. वनाधिकार, 170-ख, आहार अनुदान, मनरेगा)..." else "Search rights & laws...", fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = JhsTeal) },
            trailingIcon = {
              if (searchQuery.isNotBlank()) {
                IconButton(onClick = { viewModel.knowledgeSearchQuery.value = "" }) {
                  Icon(Icons.Default.Close, contentDescription = "Clear")
                }
              }
            },
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = JhsInputBg,
              unfocusedContainerColor = JhsInputBg,
              focusedBorderColor = JhsTeal,
              unfocusedBorderColor = JhsBorder,
              focusedTextColor = JhsHeadingText,
              unfocusedTextColor = JhsHeadingText,
              focusedPlaceholderColor = JhsPlaceholderText,
              unfocusedPlaceholderColor = JhsPlaceholderText
            ),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("knowledge_search_input"),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
          )
        }
      }
    }

    // 2. Category Filter Chips
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        item {
          FilterChip(
            selected = selectedCat == null,
            onClick = { viewModel.knowledgeSelectedCategory.value = null },
            label = { Text(if (lang == "hi") "सभी विषय" else "All Topics") },
            shape = RoundedCornerShape(16.dp)
          )
        }

        item {
          FilterChip(
            selected = selectedCat == CaseCategory.FOREST_RIGHTS,
            onClick = { viewModel.knowledgeSelectedCategory.value = CaseCategory.FOREST_RIGHTS },
            label = { Text(if (lang == "hi") "वनाधिकार (FRA)" else "Forest Rights") },
            shape = RoundedCornerShape(16.dp)
          )
        }

        item {
          FilterChip(
            selected = selectedCat == CaseCategory.LAND_RIGHTS,
            onClick = { viewModel.knowledgeSelectedCategory.value = CaseCategory.LAND_RIGHTS },
            label = { Text(if (lang == "hi") "भूमि (170-ख)" else "Land (Sec 170-B)") },
            shape = RoundedCornerShape(16.dp)
          )
        }

        item {
          FilterChip(
            selected = selectedCat == CaseCategory.GOVT_SCHEMES,
            onClick = { viewModel.knowledgeSelectedCategory.value = CaseCategory.GOVT_SCHEMES },
            label = { Text(if (lang == "hi") "आहार अनुदान" else "DBT Schemes") },
            shape = RoundedCornerShape(16.dp)
          )
        }

        item {
          FilterChip(
            selected = selectedCat == CaseCategory.WAGES_LIVELIHOOD,
            onClick = { viewModel.knowledgeSelectedCategory.value = CaseCategory.WAGES_LIVELIHOOD },
            label = { Text(if (lang == "hi") "मनरेगा मजदूरी" else "MGNREGA") },
            shape = RoundedCornerShape(16.dp)
          )
        }
      }
    }

    // 3. Articles List
    if (articles.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = if (lang == "hi") "खोज के अनुरूप कोई लेख नहीं मिला।" else "No matching articles found.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    } else {
      items(articles) { article ->
        val isExpanded = expandedArticleId == article.id

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              expandedArticleId = if (isExpanded) null else article.id
            },
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            // Category & Speaker Row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                color = JhsTealContainer,
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = if (lang == "hi") article.category.labelHi else article.category.labelEn,
                  color = JhsOnTealContainer,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }

              IconButton(
                onClick = {
                  if (isSpeaking) {
                    viewModel.stopSpeech()
                  } else {
                    val textToRead = if (lang == "hi") {
                      "${article.titleHindi}। ${article.summaryHindi}। ${article.contentHindi}"
                    } else {
                      "${article.titleEnglish}. ${article.summaryEnglish}. ${article.contentEnglish}"
                    }
                    viewModel.speak(textToRead)
                  }
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                  contentDescription = "Read Article Aloud",
                  tint = JhsTeal,
                  modifier = Modifier.size(20.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = if (lang == "hi") article.titleHindi else article.titleEnglish,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = if (lang == "hi") article.summaryHindi else article.summaryEnglish,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              lineHeight = 16.sp
            )

            // Expanded Details
            AnimatedVisibility(visible = isExpanded) {
              Column(modifier = Modifier.padding(top = 12.dp)) {
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(10.dp))

                // Full Content
                Text(
                  text = if (lang == "hi") "विधिक प्रावधान व अधिकार:" else "Statutory Provisions:",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = JhsTealDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = if (lang == "hi") article.contentHindi else article.contentEnglish,
                  fontSize = 12.sp,
                  lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Eligibility
                val eligibility = if (lang == "hi") article.eligibilityHindi else article.eligibilityEnglish
                if (eligibility.isNotEmpty()) {
                  Text(
                    text = if (lang == "hi") "पात्रता शर्तें:" else "Eligibility Criteria:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = JhsTerracotta
                  )
                  eligibility.forEach { item ->
                    Text(text = "• $item", fontSize = 12.sp, modifier = Modifier.padding(vertical = 1.dp))
                  }
                  Spacer(modifier = Modifier.height(10.dp))
                }

                // Documents Checklist
                val docs = if (lang == "hi") article.documentChecklistHindi else article.documentChecklistEnglish
                if (docs.isNotEmpty()) {
                  Text(
                    text = if (lang == "hi") "आवश्यक दस्तावेज़:" else "Required Documents:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = JhsTeal
                  )
                  docs.forEach { d ->
                    Text(text = "✓ $d", fontSize = 12.sp, modifier = Modifier.padding(vertical = 1.dp))
                  }
                  Spacer(modifier = Modifier.height(10.dp))
                }

                // Reviewer & Verified Source
                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                      text = "${if (lang == "hi") "सत्यापित स्रोत" else "Official Source"}: ${article.officialSource}",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.SemiBold
                    )
                    Text(
                      text = "${if (lang == "hi") "समीक्षक" else "Reviewer"}: ${article.reviewer} (${article.verificationDate})",
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.outline
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isExpanded) (if (lang == "hi") "संक्षिप्त करें" else "Show Less") else (if (lang == "hi") "विस्तार से पढ़ें" else "Read Details"),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTeal
              )
              Icon(
                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = JhsTeal
              )
            }
          }
        }
      }
    }
  }
}
