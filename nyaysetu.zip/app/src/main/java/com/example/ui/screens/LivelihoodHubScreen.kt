package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LivelihoodOpportunity
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun LivelihoodHubScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val livelihoods by viewModel.livelihoods.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = if (lang == "hi") "सतत आजीविका व वनोपज संवर्धन केंद्र" else "Sustainable Livelihoods & Forest Produce Hub",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (lang == "hi") {
              "बिचौलियों से मुक्ति, वन धन विकास केंद्र, न्यूनतम समर्थन मूल्य (MSP) व पारंपरिक शिल्प संवर्धन।"
            } else {
              "Fair prices for NTFP forest gatherers, Van Dhan Kendras, and artisan crafts support."
            },
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
        }
      }
    }

    items(livelihoods) { item ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = item.sector,
                color = JhsTealDark,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }

            Text(
              text = item.geographicCoverage,
              fontSize = 11.sp,
              color = JhsSecondaryText
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = if (lang == "hi") item.titleHindi else item.titleEnglish,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = if (lang == "hi") item.descriptionHindi else item.descriptionEnglish,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            color = JhsBodyText
          )

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = "${if (lang == "hi") "पात्रता" else "Eligibility"}: ${if (lang == "hi") item.eligibilityHindi else item.eligibilityEnglish}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = JhsHeadingText
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${if (lang == "hi") "भागीदारी प्रक्रिया" else "Process"}: ${if (lang == "hi") item.processHindi else item.processEnglish}",
                fontSize = 11.sp,
                color = JhsSecondaryText
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${if (lang == "hi") "संपर्क" else "Contact"}: ${item.contactInfo}",
                fontSize = 11.sp,
                color = JhsTeal,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }
  }
}
