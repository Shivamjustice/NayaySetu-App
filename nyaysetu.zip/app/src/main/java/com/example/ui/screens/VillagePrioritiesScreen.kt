package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NyaySetuRepository
import com.example.model.VillagePriorityItem
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun VillagePrioritiesScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val priorities by viewModel.villagePriorities.collectAsState()

  var showNewDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Header Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (lang == "hi") "गाँव की जरूरतें और विकास प्राथमिकताएँ" else "Village Priorities & Development",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Text(
                text = if (lang == "hi") "ग्राम सभा प्रस्ताव, महिला समूह व समुदाय द्वारा चिन्हित कार्य" else "Gram Sabha resolutions and collective priorities",
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
              onClick = { showNewDialog = true },
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
              contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
              modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("add_village_priority_button")
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (lang == "hi") "प्रस्ताव जोड़ें" else "Add Priority", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }

    // 2. Priority Items List
    items(priorities) { item ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Theme & Status Badge
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = item.theme,
                color = JhsTeal,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }

            Surface(
              color = when (item.status) {
                "Work In Progress" -> JhsTeal.copy(alpha = 0.15f)
                "Sanctioned" -> JhsGold.copy(alpha = 0.2f)
                "Representation Submitted" -> JhsTerracotta.copy(alpha = 0.15f)
                else -> JhsSecondaryBg
              },
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = item.status,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = when (item.status) {
                  "Work In Progress" -> JhsTeal
                  "Sanctioned" -> JhsHeadingText
                  "Representation Submitted" -> JhsTerracotta
                  else -> JhsSecondaryText
                },
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = item.communityPriority,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LocationOn, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "${item.village}, ${item.gramPanchayat}, ${item.block}, ${item.district}",
              fontSize = 12.sp,
              color = JhsSecondaryText
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "${if (lang == "hi") "प्रस्तावित कार्यवाही" else "Action"}: ${item.proposedAction}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = JhsHeadingText
              )
              Spacer(modifier = Modifier.height(3.dp))
              Text(
                text = "${if (lang == "hi") "उत्तरदायी संस्था" else "Authority"}: ${item.responsibleInstitution}",
                fontSize = 12.sp,
                color = JhsBodyText
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "${if (lang == "hi") "स्रोत" else "Source"}: ${item.sourceOfInfo} (${item.meetingDate})",
                fontSize = 11.sp,
                color = JhsSecondaryText
              )
            }
          }
        }
      }
    }
  }

  // Add Priority Dialog
  if (showNewDialog) {
    var vVillage by remember { mutableStateOf("") }
    var vBlock by remember { mutableStateOf("कराहल (Karahal)") }
    var vTheme by remember { mutableStateOf("पेयजल व स्वच्छता (Drinking Water)") }
    var vPriority by remember { mutableStateOf("") }
    var vAction by remember { mutableStateOf("") }
    var vInst by remember { mutableStateOf("लोक स्वास्थ्य यांत्रिकी विभाग (PHED)") }

    AlertDialog(
      onDismissRequest = { showNewDialog = false },
      title = { Text(if (lang == "hi") "गाँव की नयी प्राथमिकता जोड़ें" else "Add Village Priority", color = JhsHeadingText, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = vVillage,
            onValueChange = { vVillage = it },
            label = { Text(if (lang == "hi") "गाँव का नाम *" else "Village Name *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = vPriority,
            onValueChange = { vPriority = it },
            label = { Text(if (lang == "hi") "प्राथमिकता / मांग *" else "Priority / Demand *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = vAction,
            onValueChange = { vAction = it },
            label = { Text(if (lang == "hi") "प्रस्तावित कार्यवाही" else "Proposed Action") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (vVillage.isNotBlank() && vPriority.isNotBlank()) {
              NyaySetuRepository.addVillagePriority(
                village = vVillage,
                gramPanchayat = vVillage,
                block = vBlock,
                district = "श्योपुर (Sheopur)",
                theme = vTheme,
                priority = vPriority,
                source = "Gram Sabha Resolution",
                proposedAction = vAction.ifBlank { "संबंधित विभाग को मांग पत्र प्रेषण" },
                institution = vInst
              )
              showNewDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(if (lang == "hi") "दर्ज करें" else "Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewDialog = false }) {
          Text(if (lang == "hi") "रद्द करें" else "Cancel", color = JhsSecondaryText)
        }
      }
    )
  }
}
