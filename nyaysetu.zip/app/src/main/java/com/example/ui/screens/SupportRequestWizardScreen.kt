package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CaseCategory
import com.example.ui.components.jhsInputColors
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportRequestWizardScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val step by viewModel.wizardStep.collectAsState()
  val context = LocalContext.current

  val selectedCategory by viewModel.wizardCategory.collectAsState()
  val title by viewModel.wizardTitle.collectAsState()
  val applicantName by viewModel.wizardApplicantName.collectAsState()
  val isAnonymous by viewModel.wizardIsAnonymous.collectAsState()
  val contactPhone by viewModel.wizardContactPhone.collectAsState()
  val district by viewModel.wizardDistrict.collectAsState()
  val block by viewModel.wizardBlock.collectAsState()
  val gramPanchayat by viewModel.wizardGramPanchayat.collectAsState()
  val village by viewModel.wizardVillage.collectAsState()
  val description by viewModel.wizardDescription.collectAsState()
  val assistanceRequested by viewModel.wizardAssistanceRequested.collectAsState()

  val consentPurpose by viewModel.wizardConsentPurpose.collectAsState()
  val consentLimits by viewModel.wizardConsentLimits.collectAsState()
  val consentReferral by viewModel.wizardConsentReferral.collectAsState()

  val receipt by viewModel.wizardCreatedReceipt.collectAsState()

  ModalBottomSheet(
    onDismissRequest = { viewModel.closeWizard() },
    containerColor = JhsCream,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
    modifier = Modifier.testTag("support_request_wizard_sheet")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.92f)
        .padding(horizontal = 16.dp)
        .navigationBarsPadding()
    ) {
      // Header with Step Indicator
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = if (lang == "hi") "सहायता व शिकायत दर्ज करें" else "Submit Grievance / Request",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Text(
            text = when (step) {
              1 -> if (lang == "hi") "चरण 1/4: विषय व श्रेणी चुनें" else "Step 1/4: Select Category"
              2 -> if (lang == "hi") "चरण 2/4: समस्या व स्थान विवरण" else "Step 2/4: Grievance Details"
              3 -> if (lang == "hi") "चरण 3/4: सूचित विधिक सहमति" else "Step 3/4: Informed Consent"
              else -> if (lang == "hi") "चरण 4/4: डिजिटल पावती व पिन" else "Step 4/4: Receipt & PIN"
            },
            style = MaterialTheme.typography.bodySmall.copy(color = JhsTeal, fontWeight = FontWeight.SemiBold)
          )
        }

        IconButton(onClick = { viewModel.closeWizard() }) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = JhsHeadingText)
        }
      }

      // Step Progress Bar
      LinearProgressIndicator(
        progress = { step / 4f },
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 10.dp)
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp)),
        color = JhsTeal,
        trackColor = JhsSecondaryBg
      )

      Spacer(modifier = Modifier.height(6.dp))

      // Step Contents
      when (step) {
        1 -> {
          // STEP 1: CATEGORY SELECTION (14 Categories)
          Text(
            text = if (lang == "hi") "आपकी समस्या किस विषय से संबंधित है?" else "Which category matches your grievance?",
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            color = JhsHeadingText
          )
          Spacer(modifier = Modifier.height(10.dp))

          LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            items(CaseCategory.values()) { cat ->
              val isSelected = cat == selectedCategory
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable { viewModel.wizardCategory.value = cat },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                  containerColor = if (isSelected) JhsSecondaryBg else JhsWhite
                ),
                border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) JhsTeal else JhsBorder)
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  RadioButton(
                    selected = isSelected,
                    onClick = { viewModel.wizardCategory.value = cat },
                    modifier = Modifier.size(24.dp),
                    colors = RadioButtonDefaults.colors(selectedColor = JhsTeal)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (lang == "hi") cat.labelHi else cat.labelEn,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = JhsHeadingText,
                    lineHeight = 16.sp
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Button(
            onClick = { viewModel.wizardStep.value = 2 },
            modifier = Modifier
              .fillMaxWidth()
              .defaultMinSize(minHeight = 48.dp)
              .testTag("wizard_step1_next_button"),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(if (lang == "hi") "आगे बढ़ें (विवरण दर्ज करें)" else "Next: Enter Details", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          }
        }

        2 -> {
          // STEP 2: GRIEVANCE & LOCATION DETAILS
          LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            item {
              // Anonymous Toggle
              Card(
                colors = CardDefaults.cardColors(containerColor = JhsWhite),
                border = BorderStroke(1.dp, JhsBorder),
                shape = RoundedCornerShape(12.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = if (lang == "hi") "गोपनीय रूप से शिकायत दर्ज करें" else "File Anonymously",
                      fontWeight = FontWeight.Bold,
                      fontSize = 14.sp,
                      color = JhsHeadingText
                    )
                    Text(
                      text = if (lang == "hi") "संवेदनशील मामलों में नाम सार्वजनिक नहीं किया जाएगा" else "Name will not be exposed publicly",
                      fontSize = 12.sp,
                      color = JhsSecondaryText
                    )
                  }
                  Switch(
                    checked = isAnonymous,
                    onCheckedChange = { viewModel.wizardIsAnonymous.value = it },
                    colors = SwitchDefaults.colors(
                      checkedThumbColor = JhsWhite,
                      checkedTrackColor = JhsTeal
                    )
                  )
                }
              }
            }

            if (!isAnonymous) {
              item {
                OutlinedTextField(
                  value = applicantName,
                  onValueChange = { viewModel.wizardApplicantName.value = it },
                  label = { Text(if (lang == "hi") "आवेदक का नाम *" else "Applicant Name *") },
                  placeholder = { Text("उदा. रामदयाल सहरिया", color = JhsPlaceholderText) },
                  colors = jhsInputColors(),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.fillMaxWidth(),
                  singleLine = true
                )
              }
            }

            item {
              OutlinedTextField(
                value = contactPhone,
                onValueChange = { viewModel.wizardContactPhone.value = it },
                label = { Text(if (lang == "hi") "संपर्क मोबाइल नंबर (वैकल्पिक)" else "Contact Mobile (Optional)") },
                placeholder = { Text("98261XXXXX", color = JhsPlaceholderText) },
                colors = jhsInputColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
            }

            item {
              Text(
                text = if (lang == "hi") "स्थान विवरण (ग्वालियर-चंबल संभाग):" else "Location (Gwalior-Chambal):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = JhsHeadingText
              )
            }

            item {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedTextField(
                  value = district,
                  onValueChange = { viewModel.wizardDistrict.value = it },
                  label = { Text(if (lang == "hi") "जिला *" else "District *") },
                  colors = jhsInputColors(),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
                OutlinedTextField(
                  value = block,
                  onValueChange = { viewModel.wizardBlock.value = it },
                  label = { Text(if (lang == "hi") "ब्लॉक *" else "Block *") },
                  colors = jhsInputColors(),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
              }
            }

            item {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedTextField(
                  value = gramPanchayat,
                  onValueChange = { viewModel.wizardGramPanchayat.value = it },
                  label = { Text(if (lang == "hi") "ग्राम पंचायत" else "Gram Panchayat") },
                  colors = jhsInputColors(),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
                OutlinedTextField(
                  value = village,
                  onValueChange = { viewModel.wizardVillage.value = it },
                  label = { Text(if (lang == "hi") "गाँव / टोला *" else "Village / Hamlet *") },
                  colors = jhsInputColors(),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
              }
            }

            item {
              OutlinedTextField(
                value = title,
                onValueChange = { viewModel.wizardTitle.value = it },
                label = { Text(if (lang == "hi") "समस्या का शीर्षक" else "Title of Grievance") },
                placeholder = { Text(if (lang == "hi") "उदा. वनाधिकार दावा सत्यापन या मनरेगा भुगतान" else "e.g. FRA verification or wage delay", color = JhsPlaceholderText) },
                colors = jhsInputColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
            }

            item {
              OutlinedTextField(
                value = description,
                onValueChange = { viewModel.wizardDescription.value = it },
                label = { Text(if (lang == "hi") "समस्या का सविस्तार विवरण *" else "Detailed Description *") },
                placeholder = { Text(if (lang == "hi") "कृपया क्या हुआ, कब से समस्या है, व कौन से दस्तावेज़ उपलब्ध हैं, लिखें..." else "Describe facts, timeline, available documents...", color = JhsPlaceholderText) },
                colors = jhsInputColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5
              )
            }

            item {
              OutlinedTextField(
                value = assistanceRequested,
                onValueChange = { viewModel.wizardAssistanceRequested.value = it },
                label = { Text(if (lang == "hi") "आप किस प्रकार की सहायता चाहते हैं? *" else "What assistance do you request? *") },
                placeholder = { Text(if (lang == "hi") "उदा. आवेदन पत्र तैयार करना, ग्राम सभा में विधिक मार्गदर्शन, या कलेक्टर को पत्र" else "e.g. Draft petition, legal advice at Gram Sabha...", color = JhsPlaceholderText) },
                colors = jhsInputColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4
              )
            }

            item {
              val videoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
              ) { uri: Uri? ->
                uri?.let { Toast.makeText(context, "वीडियो सफलतापूर्वक संलग्न किया गया", Toast.LENGTH_SHORT).show() }
              }
              val audioLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
              ) { uri: Uri? ->
                uri?.let { Toast.makeText(context, "ऑडियो रिकॉर्डिंग/फ़ाइल संलग्न की गई", Toast.LENGTH_SHORT).show() }
              }

              Spacer(modifier = Modifier.height(4.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = { videoLauncher.launch("video/*") },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsTeal)
                ) {
                  Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("वीडियो जोड़ें (Video)", fontSize = 11.sp)
                }

                OutlinedButton(
                  onClick = { audioLauncher.launch("audio/*") },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsTeal)
                ) {
                  Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("ऑडियो जोड़ें (Audio)", fontSize = 11.sp)
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = { viewModel.wizardStep.value = 1 },
              modifier = Modifier
                .weight(0.4f)
                .defaultMinSize(minHeight = 48.dp),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, JhsBorder),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsHeadingText)
            ) {
              Text(if (lang == "hi") "पीछे" else "Back", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }

            Button(
              onClick = { viewModel.wizardStep.value = 3 },
              modifier = Modifier
                .weight(0.6f)
                .defaultMinSize(minHeight = 48.dp)
                .testTag("wizard_step2_next_button"),
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
              shape = RoundedCornerShape(12.dp),
              enabled = description.isNotBlank() || village.isNotBlank()
            ) {
              Text(if (lang == "hi") "सहमति की ओर बढ़ें" else "Next: Consent", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }

        3 -> {
          // STEP 3: GRANULAR INFORMED CONSENT
          LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            item {
              Surface(
                color = JhsSecondaryBg,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, JhsBorder)
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.Shield, contentDescription = null, tint = JhsTeal)
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = if (lang == "hi") {
                      "सूचित विधिक सहमति: जेएचएस आपके अधिकारों का पूर्ण सम्मान करता है। कोई भी आधार या बैंक क्रेडेंशियल नहीं लिया जाता।"
                    } else {
                      "Informed Consent: We respect citizen dignity. No Aadhaar or bank credentials harvested."
                    },
                    fontSize = 12.sp,
                    color = JhsBodyText,
                    lineHeight = 17.sp
                  )
                }
              }
            }

            item {
              ConsentCheckboxRow(
                checked = consentPurpose,
                onCheckedChange = { viewModel.wizardConsentPurpose.value = it },
                title = if (lang == "hi") "1. उद्देश्य सहमति (Purpose of Data Collection)" else "1. Purpose of Data Collection",
                description = if (lang == "hi") {
                  "मैं सहमत हूँ कि मेरे द्वारा दी गई जानकारी का उपयोग केवल मेरे मामले में विधिक सहायता, आवेदन तैयार करने व फॉलो-अप हेतु किया जाएगा।"
                } else {
                  "I agree that the facts provided will only be used for legal assistance and petition preparation."
                }
              )
            }

            item {
              ConsentCheckboxRow(
                checked = consentLimits,
                onCheckedChange = { viewModel.wizardConsentLimits.value = it },
                title = if (lang == "hi") "2. पहुँच सीमाएँ (Confidentiality & Access)" else "2. Confidentiality & Access Limits",
                description = if (lang == "hi") {
                  "केवल अधिकृत JHS लीगल टीम और स्थानीय पैरालीगल वॉलंटियर ही इस मामले का विवरण देख सकते हैं। सार्वजनिक रूप से कोई व्यक्तिगत विवरण प्रकट नहीं होगा।"
                } else {
                  "Only designated legal caseworkers and field volunteers have access. Personal info is kept confidential."
                }
              )
            }

            item {
              ConsentCheckboxRow(
                checked = consentReferral,
                onCheckedChange = { viewModel.wizardConsentReferral.value = it },
                title = if (lang == "hi") "3. संस्थागत संदर्भ सहमति (Statutory Referrals)" else "3. Referral to Legal Aid / DLSA",
                description = if (lang == "hi") {
                  "आवश्यकता पड़ने पर जिला विधिक सेवा प्राधिकरण (DLSA), उच्च न्यायालय विधिक क्लिनिक या जनसुनवाई में जानकारी साझा करने की अनुमति है।"
                } else {
                  "Permission to share facts with DLSA or statutory authorities for official legal aid if needed."
                }
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = { viewModel.wizardStep.value = 2 },
              modifier = Modifier
                .weight(0.4f)
                .defaultMinSize(minHeight = 48.dp),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, JhsBorder),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsHeadingText)
            ) {
              Text(if (lang == "hi") "पीछे" else "Back", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }

            Button(
              onClick = { viewModel.submitSupportRequest() },
              modifier = Modifier
                .weight(0.6f)
                .defaultMinSize(minHeight = 48.dp)
                .testTag("wizard_submit_button"),
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
              shape = RoundedCornerShape(12.dp),
              enabled = consentPurpose && consentLimits
            ) {
              Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (lang == "hi") "मामला दर्ज करें" else "Submit Grievance", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }

        4 -> {
          // STEP 4: SUBMISSION RECEIPT & TWO-FACTOR PIN CARD
          val (caseId, pin) = receipt ?: Pair("NYAY-2026-0099", "5421")

          Column(
            modifier = Modifier
              .weight(1f)
              .padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(JhsSecondaryBg),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = JhsTeal,
                modifier = Modifier.size(44.dp)
              )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
              text = if (lang == "hi") "मामला सफलतापूर्वक दर्ज हुआ!" else "Grievance Successfully Registered!",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = JhsHeadingText
              )
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = if (lang == "hi") {
                "आपकी सहायता याचिका सुरक्षित दर्ज हो चुकी है। कृपया नीचे दी गई केस आईडी व पिन को सुरक्षित नोट कर लें।"
              } else {
                "Your request has been filed. Please safely save the Case ID and 4-digit verification PIN below."
              },
              textAlign = androidx.compose.ui.text.style.TextAlign.Center,
              fontSize = 13.sp,
              color = JhsBodyText
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Digital Receipt Card
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = JhsWhite),
              border = BorderStroke(1.dp, JhsBorder),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
              Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = if (lang == "hi") "डिजिटल पावती (Tracking Receipt)" else "Tracking Receipt",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsSecondaryText
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = if (lang == "hi") "केस आईडी" else "Case ID", fontSize = 12.sp, color = JhsSecondaryText)
                    Text(
                      text = caseId,
                      fontWeight = FontWeight.ExtraBold,
                      fontSize = 20.sp,
                      color = JhsTeal
                    )
                  }

                  Box(
                    modifier = Modifier
                      .width(1.dp)
                      .height(40.dp)
                      .background(JhsBorder)
                  )

                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = if (lang == "hi") "सुरक्षा पिन" else "Security PIN", fontSize = 12.sp, color = JhsSecondaryText)
                    Text(
                      text = pin,
                      fontWeight = FontWeight.ExtraBold,
                      fontSize = 20.sp,
                      color = JhsTerracotta
                    )
                  }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                  horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                  OutlinedButton(
                    onClick = {
                      val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                      val clip = ClipData.newPlainText("NyaySetu Case", "Case ID: $caseId | Security PIN: $pin")
                      cm.setPrimaryClip(clip)
                      Toast.makeText(context, if (lang == "hi") "आईडी व पिन कॉपी हो गया" else "Copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, JhsBorder),
                    modifier = Modifier.defaultMinSize(minHeight = 44.dp)
                  ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp), tint = JhsTeal)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (lang == "hi") "कॉपी करें" else "Copy", fontSize = 12.sp, color = JhsHeadingText)
                  }

                  OutlinedButton(
                    onClick = {
                      val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "NyaySetu (न्यायसेतु) Case Record:\nCase ID: $caseId\nSecurity PIN: $pin\nTrack at: NyaySetu App")
                      }
                      context.startActivity(Intent.createChooser(shareIntent, "Share Receipt"))
                    },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, JhsBorder),
                    modifier = Modifier.defaultMinSize(minHeight = 44.dp)
                  ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = JhsTeal)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (lang == "hi") "शेयर करें" else "Share", fontSize = 12.sp, color = JhsHeadingText)
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Button(
            onClick = {
              viewModel.closeWizard()
              val (cId, p) = receipt ?: Pair("NYAY-2026-0041", "4192")
              viewModel.setTrackingTarget(cId, p)
            },
            modifier = Modifier
              .fillMaxWidth()
              .defaultMinSize(minHeight = 48.dp)
              .testTag("wizard_view_case_status_button"),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(if (lang == "hi") "मामले की स्थिति अभी देखें" else "Track This Case Now", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }
  }
}

@Composable
fun ConsentCheckboxRow(
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  title: String,
  description: String
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = JhsWhite),
    border = BorderStroke(1.dp, JhsBorder),
    shape = RoundedCornerShape(12.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clickable { onCheckedChange(!checked) }
        .padding(14.dp),
      verticalAlignment = Alignment.Top
    ) {
      Checkbox(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = CheckboxDefaults.colors(
          checkedColor = JhsTeal,
          checkmarkColor = Color.White
        )
      )
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
        Spacer(modifier = Modifier.height(3.dp))
        Text(
          text = description,
          fontSize = 12.sp,
          color = JhsBodyText,
          lineHeight = 17.sp
        )
      }
    }
  }
}
