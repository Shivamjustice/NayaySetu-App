package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JHS Official Brand Colour System
// Primary Background: #FAF7F0 – Warm Cream
val JhsCream = Color(0xFFFAF7F0)
val JhsBackground = Color(0xFFFAF7F0)

// Card Background: #FFFFFF – White
val JhsWhite = Color(0xFFFFFFFF)
val JhsSurface = Color(0xFFFFFFFF)

// Primary Brand: #176B63 – Deep Teal
val JhsTeal = Color(0xFF176B63)
val JhsTealDark = Color(0xFF12574F)           // Active/Hover State: #12574F
val JhsTealLight = Color(0xFF23877D)

// Secondary Background: #E8F1ED – Soft Mint
val JhsSoftMint = Color(0xFFE8F1ED)
val JhsSecondaryBg = Color(0xFFE8F1ED)
val JhsTealContainer = Color(0xFFE8F1ED)
val JhsOnTealContainer = Color(0xFF104F49)

// Main Text: #263238 – Charcoal
val JhsHeadingText = Color(0xFF263238)
val JhsCharcoal = Color(0xFF263238)

// Body Text: #455A56 – Dark Grey Green
val JhsBodyText = Color(0xFF455A56)
val JhsCharcoalLight = Color(0xFF455A56)

// Secondary Text: #60736F – Muted Green Grey
val JhsSecondaryText = Color(0xFF60736F)
val JhsCharcoalMuted = Color(0xFF60736F)

// Borders: #E8E1D5 – Light Beige
val JhsBorder = Color(0xFFE8E1D5)
val JhsLightBeige = Color(0xFFE8E1D5)
val JhsBorderSubtle = Color(0xFFECE7D9)
val JhsSubtleTealBorder = Color(0xFFCEE4E0)   // Subtle light teal border for premium cards

// Accent: #C56A3D – Terracotta (limited decorative highlights, icons and indicators)
val JhsTerracotta = Color(0xFFC56A3D)
val JhsTerracottaDark = Color(0xFF9E4B22)
val JhsTerracottaLight = Color(0xFFD98357)
val JhsTerracottaContainer = Color(0xFFFAECE6)
val JhsOnTerracottaContainer = Color(0xFF5D2409)

// Highlight: #E3A72F – Muted Gold (limited decorative highlights, icons and indicators)
val JhsGold = Color(0xFFE3A72F)
val JhsGoldDark = Color(0xFFB88015)
val JhsGoldLight = Color(0xFFECC065)
val JhsGoldContainer = Color(0xFFFBF4E4)
val JhsOnGoldContainer = Color(0xFF573B00)

// Form & Interactive Tokens
val JhsImportantLabel = Color(0xFF176B63)     // Deep Teal
val JhsPlaceholderText = Color(0xFF75817E)    // Visible Placeholder Text
val JhsInputBg = Color(0xFFFAF9F6)            // Very light cream / white input background
val JhsPrimaryButtonBg = Color(0xFF176B63)    // Primary Button: #176B63
val JhsSecondaryButtonBg = Color(0xFFE8F1ED)  // Secondary Button: #E8F1ED
val JhsButtonActiveState = Color(0xFF12574F)  // Active State: #12574F

// High Contrast Sunlight Mode (Accessibility)
val JhsHighContrastBg = Color(0xFFFFFFFF)
val JhsHighContrastText = Color(0xFF000000)
val JhsHighContrastBorder = Color(0xFF000000)
