package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.NyaySetuRepository
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun NotificationDialog(
  viewModel: NyaySetuViewModel,
  onDismiss: () -> Unit
) {
  val notifications by viewModel.notifications.collectAsState()
  val lang by viewModel.currentLanguage.collectAsState()

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 16.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = JhsWhite),
      border = BorderStroke(1.dp, JhsBorder),
      elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.NotificationsActive,
              contentDescription = null,
              tint = JhsTeal
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (lang == "hi") "सूचनाएँ व अपडेट" else "Notifications & Updates",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = JhsHeadingText)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (notifications.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = if (lang == "hi") "कोई नयी सूचना नहीं है।" else "No new notifications.",
              color = JhsSecondaryText
            )
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 360.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(notifications) { notif ->
              Card(
                colors = CardDefaults.cardColors(
                  containerColor = if (notif.severity == "urgent") {
                    JhsSecondaryBg
                  } else {
                    JhsWhite
                  }
                ),
                border = BorderStroke(1.dp, JhsBorder),
                shape = RoundedCornerShape(12.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                  verticalAlignment = Alignment.Top
                ) {
                  Box(
                    modifier = Modifier
                      .size(10.dp)
                      .clip(CircleShape)
                      .background(if (notif.severity == "urgent") JhsTerracotta else JhsTeal)
                      .align(Alignment.Top)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = if (lang == "hi") notif.titleHindi else notif.titleEnglish,
                      fontWeight = FontWeight.SemiBold,
                      fontSize = 13.sp,
                      color = JhsHeadingText
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = if (lang == "hi") notif.messageHindi else notif.messageEnglish,
                      fontSize = 12.sp,
                      color = JhsBodyText
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Text(
                        text = notif.timestamp,
                        fontSize = 10.sp,
                        color = JhsSecondaryText
                      )
                      if (notif.caseId != null) {
                        TextButton(
                          onClick = {
                            viewModel.trackerCaseId.value = notif.caseId
                            viewModel.trackerPin.value = "4192" // sample pin for quick link
                            viewModel.lookupCase()
                            onDismiss()
                            viewModel.setTab(com.example.viewmodel.ScreenTab.TRACK)
                          },
                          contentPadding = PaddingValues(0.dp)
                        ) {
                          Text(
                            text = notif.caseId,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = JhsTeal
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = {
            NyaySetuRepository.markAllNotificationsRead()
            onDismiss()
          },
          modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(if (lang == "hi") "सभी पढ़े हुए चिह्नित करें" else "Mark All as Read", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}

