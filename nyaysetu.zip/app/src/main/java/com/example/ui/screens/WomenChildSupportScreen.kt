package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CaseCategory
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun WomenChildSupportScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val resources by viewModel.womenChildResources.collectAsState()
  val context = LocalContext.current
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Confidentiality & Security Banner
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "महिला व बाल संरक्षण कक्ष (Women & Child Support)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Text(
                text = "गोपनीय विधिक सहायता, बाल संरक्षण एवं आपातकालीन सेवाएँ",
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
            }
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Security, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "Strictly Confidential",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTealDark
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Confidentiality Guarantee
          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "🔒 गोपनीयता सुरक्षा: महिला व बाल उत्पीड़न से संबंधित संवेदनशील मामलों का विवरण केवल अधिकृत विधिक केस प्रबंधकों व महिला अधिवक्ताओं द्वारा ही देखा जाता है। यह आम वॉलंटियर्स या सार्वजनिक यूज़र्स के लिए प्रतिबंधित है।",
              fontSize = 11.sp,
              lineHeight = 15.sp,
              color = JhsHeadingText,
              modifier = Modifier.padding(10.dp)
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = {
              viewModel.wizardCategory.value = CaseCategory.WOMENS_RIGHTS
              viewModel.wizardIsSensitive.value = true
              viewModel.openWizard()
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal, contentColor = Color.White)
          ) {
            Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("गोपनीय सहायता आग्रह दर्ज करें", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          }
        }
      }
    }

    // 2. Emergency Helplines Direct Cards
    item {
      Text(text = "🚨 आपातकालीन एवं सुरक्षा हेल्पलाइन (24x7):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = JhsCharcoal)
      Spacer(modifier = Modifier.height(4.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        EmergencyHelplineCard("181", "महिला हेल्पलाइन", "सखी वन स्टॉप सेंटर", JhsTerracotta, Modifier.weight(1f)) {
          context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:181")))
        }
        EmergencyHelplineCard("1098", "चाइल्डलाइन", "बाल आपातकालीन सुरक्षा", JhsTeal, Modifier.weight(1f)) {
          context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:1098")))
        }
        EmergencyHelplineCard("112", "आपातकालीन", "पुलिस / एम्बुलेंस", Color(0xFFD32F2F), Modifier.weight(1f)) {
          context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")))
        }
      }
    }

    // 3. Legal Rights & Protective Resources
    item {
      Text(text = "विधिक अधिकार व सुरक्षा नियम:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }

    items(resources) { res ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsTerracotta.copy(alpha = 0.15f),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = res.category,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTerracottaDark,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
            IconButton(
              onClick = {
                if (isSpeaking) {
                  viewModel.stopSpeech()
                } else {
                  viewModel.speak("${res.titleHindi}. ${res.descriptionHindi}. विधिक प्रावधान: ${res.legalProvisions}")
                }
              },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(
                imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                contentDescription = "Read",
                tint = JhsTerracotta,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = res.titleHindi,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsCharcoal)
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(text = res.descriptionHindi, fontSize = 12.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

          Spacer(modifier = Modifier.height(8.dp))

          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(text = "कानूनी प्रावधान: ${res.legalProvisions}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = JhsTealDark)
              Text(text = "प्रक्रिया: ${res.procedureHindi}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun EmergencyHelplineCard(
  number: String,
  title: String,
  subtitle: String,
  color: Color,
  modifier: Modifier = Modifier,
  onCall: () -> Unit
) {
  Card(
    modifier = modifier.clickable { onCall() },
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = JhsWhite),
    border = BorderStroke(1.dp, JhsBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(text = number, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = color)
      Text(text = title, fontSize = 10.sp, fontWeight = FontWeight.Bold)
      Text(text = subtitle, fontSize = 9.sp, color = MaterialTheme.colorScheme.outline)
      Spacer(modifier = Modifier.height(6.dp))
      FilledIconButton(
        onClick = onCall,
        colors = IconButtonDefaults.filledIconButtonColors(containerColor = color),
        modifier = Modifier.size(30.dp)
      ) {
        Icon(Icons.Default.Phone, contentDescription = "Call $number", tint = Color.White, modifier = Modifier.size(16.dp))
      }
    }
  }
}
