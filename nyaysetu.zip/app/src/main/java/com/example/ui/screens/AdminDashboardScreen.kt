package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NyaySetuRepository
import com.example.model.AppUser
import com.example.model.CaseRecord
import com.example.model.CaseStatus
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun AdminDashboardScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val cases by viewModel.cases.collectAsState()
  val stories by viewModel.stories.collectAsState()
  val allUsers by viewModel.allUsers.collectAsState()
  val auditLogs by viewModel.auditLogs.collectAsState()
  val aiSettings by viewModel.aiAssistantSettings.collectAsState()
  val unansweredGaps by viewModel.unansweredQuestions.collectAsState()
  val aiFeedbacks by viewModel.aiFeedbackRecords.collectAsState()

  var selectedCaseForEdit by remember { mutableStateOf<CaseRecord?>(null) }
  var showUserManagement by remember { mutableStateOf(false) }
  var showAuditLogs by remember { mutableStateOf(false) }
  var showStoryModeration by remember { mutableStateOf(false) }
  var showAiGovernance by remember { mutableStateOf(false) }
  var editingStory by remember { mutableStateOf<com.example.model.StoryItem?>(null) }
  var activeMetricSelection by remember { mutableStateOf<String>("ALL_CASES") }
  var caseToDelete by remember { mutableStateOf<CaseRecord?>(null) }
  var userToDelete by remember { mutableStateOf<AppUser?>(null) }
  var storyToDelete by remember { mutableStateOf<com.example.model.StoryItem?>(null) }

  val totalCount = cases.size
  val activeCount = cases.count { it.status != CaseStatus.CLOSED }
  val highPriorityCount = cases.count { it.priority == com.example.model.PriorityLevel.URGENT || it.priority == com.example.model.PriorityLevel.HIGH }
  val resolvedCount = cases.count { it.status == CaseStatus.RESOLUTION_REPORTED || it.status == CaseStatus.CLOSED }

  val filteredCases = when (activeMetricSelection) {
    "ACTIVE_CASES" -> cases.filter { it.status != CaseStatus.CLOSED }
    else -> cases
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Dashboard Header (Admin Full Power Badge)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "JHS मुख्य एडमिन नियंत्रण कक्ष",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsTerracottaDark)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  color = JhsTerracotta,
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Text(
                    text = "FULL POWER",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 9.sp,
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                  )
                }
              }
              Text(
                text = "प्रशासक: ${currentUser?.name ?: "Director JHS"} | समस्त यूज़र, केस व कहानी प्रबंधन",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              IconButton(
                onClick = {
                  showUserManagement = !showUserManagement
                  showAuditLogs = false
                  showStoryModeration = false
                  showAiGovernance = false
                  activeMetricSelection = if (showUserManagement) "USERS" else "ALL_CASES"
                },
                modifier = Modifier
                  .clip(CircleShape)
                  .background(if (showUserManagement) JhsTealContainer else MaterialTheme.colorScheme.surfaceVariant)
              ) {
                Icon(Icons.Default.People, contentDescription = "Users", tint = JhsTeal)
              }

              IconButton(
                onClick = {
                  showAuditLogs = !showAuditLogs
                  showUserManagement = false
                  showStoryModeration = false
                  showAiGovernance = false
                },
                modifier = Modifier
                  .clip(CircleShape)
                  .background(if (showAuditLogs) JhsGoldContainer else MaterialTheme.colorScheme.surfaceVariant)
              ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = "Audit Trail", tint = JhsGoldDark)
              }

              IconButton(
                onClick = {
                  showStoryModeration = !showStoryModeration
                  showUserManagement = false
                  showAuditLogs = false
                  showAiGovernance = false
                  activeMetricSelection = if (showStoryModeration) "STORIES" else "ALL_CASES"
                },
                modifier = Modifier
                  .clip(CircleShape)
                  .background(if (showStoryModeration) JhsTealContainer else MaterialTheme.colorScheme.surfaceVariant)
              ) {
                Icon(Icons.Default.MenuBook, contentDescription = "Stories", tint = JhsTeal)
              }

              IconButton(
                onClick = {
                  showAiGovernance = !showAiGovernance
                  showUserManagement = false
                  showAuditLogs = false
                  showStoryModeration = false
                },
                modifier = Modifier
                  .clip(CircleShape)
                  .background(if (showAiGovernance) JhsTealContainer else MaterialTheme.colorScheme.surfaceVariant)
              ) {
                Icon(Icons.Default.RecordVoiceOver, contentDescription = "AI Voice Assistant Governance", tint = JhsTeal)
              }
            }
          }
        }
      }
    }

    // 2. Metrics 4-Grid (Clickable to open corresponding data sections)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        MetricTile(
          labelHi = "कुल मामले",
          labelEn = "Total Cases",
          value = "$totalCount",
          accentColor = JhsTeal,
          isSelected = activeMetricSelection == "ALL_CASES" && !showUserManagement && !showStoryModeration && !showAuditLogs && !showAiGovernance,
          onClick = {
            activeMetricSelection = "ALL_CASES"
            showUserManagement = false
            showStoryModeration = false
            showAuditLogs = false
            showAiGovernance = false
          },
          modifier = Modifier.weight(1f)
        )
        MetricTile(
          labelHi = "सक्रिय पैरवी",
          labelEn = "Active Cases",
          value = "$activeCount",
          accentColor = JhsGoldDark,
          isSelected = activeMetricSelection == "ACTIVE_CASES" && !showUserManagement && !showStoryModeration && !showAuditLogs && !showAiGovernance,
          onClick = {
            activeMetricSelection = "ACTIVE_CASES"
            showUserManagement = false
            showStoryModeration = false
            showAuditLogs = false
            showAiGovernance = false
          },
          modifier = Modifier.weight(1f)
        )
        MetricTile(
          labelHi = "सदस्य",
          labelEn = "Users",
          value = "${allUsers.size}",
          accentColor = JhsTerracotta,
          isSelected = showUserManagement,
          onClick = {
            showUserManagement = true
            showStoryModeration = false
            showAuditLogs = false
            showAiGovernance = false
            activeMetricSelection = "USERS"
          },
          modifier = Modifier.weight(1f)
        )
        MetricTile(
          labelHi = "कहानियाँ",
          labelEn = "Stories",
          value = "${stories.size}",
          accentColor = JhsOnTealContainer,
          isSelected = showStoryModeration,
          onClick = {
            showStoryModeration = true
            showUserManagement = false
            showAuditLogs = false
            showAiGovernance = false
            activeMetricSelection = "STORIES"
          },
          modifier = Modifier.weight(1f)
        )
      }
    }

    // AI Voice Assistant Governance & Smart Knowledge Gap Management
    if (showAiGovernance) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "AI वाणी सहायक नियंत्रण व ज्ञानकोश प्रबंधन",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = JhsHeadingText
                  )
                  Text(
                    text = "Multilingual RAG Engine & Gap Analytics",
                    fontSize = 10.sp,
                    color = JhsSecondaryText
                  )
                }
              }
              Switch(
                checked = aiSettings.isEnabled,
                onCheckedChange = { viewModel.updateAiAssistantSettings(aiSettings.copy(isEnabled = it)) },
                colors = SwitchDefaults.colors(checkedThumbColor = JhsTeal, checkedTrackColor = JhsTealContainer)
              )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = JhsBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Settings row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("स्वचालित वाचन (Auto Speak Answers)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = JhsHeadingText)
                Text("उत्तर आने पर स्वतः ध्वनि से पढ़कर सुनाएं", fontSize = 11.sp, color = JhsSecondaryText)
              }
              Switch(
                checked = aiSettings.autoSpeakResponse,
                onCheckedChange = { viewModel.updateAiAssistantSettings(aiSettings.copy(autoSpeakResponse = it)) }
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Smart Database Gaps (Unanswered Questions)
            Text(
              text = "⚠️ ज्ञानकोश अंतराल (Smart Database Gaps - ${unansweredGaps.count { !it.isResolved }} लंबित):",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = JhsTerracotta
            )
            Text(
              text = "नागरिकों द्वारा पूछे गए प्रश्न जिनका उत्तर डेटाबेस में सत्यापित नहीं था:",
              fontSize = 11.sp,
              color = JhsSecondaryText
            )
            Spacer(modifier = Modifier.height(6.dp))

            if (unansweredGaps.isEmpty()) {
              Text("कोई लंबित ज्ञानकोश अंतराल नहीं है। सभी प्रश्न सत्यापित हैं।", fontSize = 11.sp, color = JhsSecondaryText)
            } else {
              unansweredGaps.forEach { gap ->
                Surface(
                  color = if (gap.isResolved) JhsSecondaryBg.copy(alpha = 0.5f) else JhsTerracottaContainer.copy(alpha = 0.4f),
                  shape = RoundedCornerShape(10.dp),
                  border = BorderStroke(1.dp, if (gap.isResolved) JhsBorder else JhsTerracotta.copy(alpha = 0.5f)),
                  modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(text = "प्रश्न: \"${gap.query}\"", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = JhsHeadingText, modifier = Modifier.weight(1f))
                      Surface(
                        color = if (gap.isResolved) JhsTealContainer else JhsTerracotta,
                        shape = RoundedCornerShape(6.dp)
                      ) {
                        Text(
                          text = if (gap.isResolved) "सत्यापित एवं समाहित" else "${gap.frequencyCount} बार पूछा गया",
                          color = if (gap.isResolved) JhsTealDark else Color.White,
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "श्रेणी: ${gap.category} | तारीख: ${gap.timestamp}", fontSize = 10.sp, color = JhsSecondaryText)
                    Text(text = "सुझाव: ${gap.suggestedAction}", fontSize = 11.sp, color = JhsBodyText)

                    if (!gap.isResolved) {
                      Spacer(modifier = Modifier.height(6.dp))
                      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Button(
                          onClick = { viewModel.resolveUnansweredQuestion(gap.id) },
                          colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
                          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                          shape = RoundedCornerShape(8.dp),
                          modifier = Modifier.height(30.dp)
                        ) {
                          Text("ज्ञानकोश में जोड़ें व हल मार्क करें ✓", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                      }
                    }
                  }
                }
              }
            }

            // User Feedback section
            if (aiFeedbacks.isNotEmpty()) {
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "📊 नागरिक प्रतिक्रिया रिपोर्ट (User Feedback - ${aiFeedbacks.size} प्राप्त):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = JhsTealDark
              )
              Spacer(modifier = Modifier.height(6.dp))
              aiFeedbacks.take(5).forEach { fb ->
                Surface(
                  color = JhsSecondaryBg,
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                  Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = fb.aiResponse, fontSize = 11.sp, maxLines = 1, color = JhsHeadingText)
                      Text(text = fb.timestamp, fontSize = 9.sp, color = JhsSecondaryText)
                    }
                    Surface(
                      color = when (fb.feedbackType) {
                        "HELPFUL" -> JhsTealContainer
                        "NOT_HELPFUL" -> JhsTerracottaContainer
                        else -> JhsGoldContainer
                      },
                      shape = RoundedCornerShape(6.dp)
                    ) {
                      Text(
                        text = when (fb.feedbackType) {
                          "HELPFUL" -> "👍 उपयोगी"
                          "NOT_HELPFUL" -> "👎 उपयोगी नहीं"
                          "INCORRECT" -> "⚠️ गलत जानकारी"
                          else -> "📝 अधूरी जानकारी"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = JhsHeadingText,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 3. User Management Section (Admin has power over all registered members)
    if (showUserManagement) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "पंजीकृत सदस्य सूची (User Accounts & Roles):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = JhsTealDark
              )
              Text(
                text = "${allUsers.size} Users",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTerracotta
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            allUsers.forEach { u ->
              Surface(
                color = Color.White,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                border = CardDefaults.outlinedCardBorder()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                      Box(
                        modifier = Modifier
                          .size(32.dp)
                          .clip(CircleShape)
                          .background(Color(u.avatarColorHex)),
                        contentAlignment = Alignment.Center
                      ) {
                        Text(u.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                      }
                      Spacer(modifier = Modifier.width(8.dp))
                      Column {
                        Text(u.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("ID: @${u.username} • Ph: ${u.phone}", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                      }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                      if (!u.isVerifiedByAdmin) {
                        Surface(
                          color = JhsGold.copy(alpha = 0.2f),
                          shape = RoundedCornerShape(6.dp)
                        ) {
                          Text(
                            text = "अनुमोदन लंबित",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = JhsGoldDark,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                          )
                        }
                      }

                      if (u.isSuspended) {
                        Surface(
                          color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                          shape = RoundedCornerShape(6.dp)
                        ) {
                          Text(
                            text = "निलंबित",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                          )
                        }
                      }

                      Surface(
                        color = if (u.role == UserRole.SUPER_ADMIN) JhsTerracotta.copy(alpha = 0.15f) else JhsTealContainer,
                        shape = RoundedCornerShape(6.dp)
                      ) {
                        Text(
                          text = u.role.labelHi.split(" ").first(),
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          color = if (u.role == UserRole.SUPER_ADMIN) JhsTerracottaDark else JhsOnTealContainer,
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                  }

                  Spacer(modifier = Modifier.height(8.dp))

                  // Admin Action Buttons per User
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    if (!u.isVerifiedByAdmin) {
                      FilledTonalButton(
                        onClick = { viewModel.approveUser(u.id) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.defaultMinSize(minHeight = 28.dp)
                      ) {
                        Text("स्वीकृत करें", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                      }
                    }

                    OutlinedButton(
                      onClick = { viewModel.toggleUserSuspension(u.id) },
                      contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                      modifier = Modifier.defaultMinSize(minHeight = 28.dp),
                      colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (u.isSuspended) JhsTeal else MaterialTheme.colorScheme.error
                      )
                    ) {
                      Text(if (u.isSuspended) "सक्रिय करें" else "निलंबित करें", fontSize = 10.sp)
                    }

                    FilledTonalButton(
                      onClick = {
                        val allRoles = listOf(
                          UserRole.COMMUNITY_MEMBER,
                          UserRole.VOLUNTEER,
                          UserRole.CASE_MANAGER,
                          UserRole.DEPT_ADMIN,
                          UserRole.SUPER_ADMIN
                        )
                        val nextIndex = (allRoles.indexOf(u.role) + 1) % allRoles.size
                        viewModel.changeUserRole(u.id, allRoles[nextIndex])
                      },
                      contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                      modifier = Modifier.defaultMinSize(minHeight = 28.dp)
                    ) {
                      Text("रोल बदलें ↻", fontSize = 10.sp)
                    }

                    OutlinedButton(
                      onClick = { userToDelete = u },
                      contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                      modifier = Modifier.defaultMinSize(minHeight = 28.dp),
                      colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                      Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(12.dp))
                      Spacer(modifier = Modifier.width(3.dp))
                      Text("हटाएं", fontSize = 10.sp)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // Story Moderation & Management Section
    if (showStoryModeration) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "समुदाय कहानियाँ व मीडिया मॉडरेशन (Stories Management):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = JhsTealDark
              )
              Text(
                text = "${stories.size} Stories",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTerracotta
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            stories.forEach { story ->
              Surface(
                color = Color.White,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                border = CardDefaults.outlinedCardBorder()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(story.titleHi, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
                  Spacer(modifier = Modifier.height(2.dp))
                  Text("लेखक: ${story.authorName} (${story.village})", fontSize = 11.sp, color = JhsSecondaryText)
                  Spacer(modifier = Modifier.height(6.dp))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    OutlinedButton(
                      onClick = { editingStory = story },
                      contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                      modifier = Modifier.defaultMinSize(minHeight = 28.dp)
                    ) {
                      Text("संपादित करें", fontSize = 10.sp)
                    }
                    OutlinedButton(
                      onClick = { storyToDelete = story },
                      contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                      modifier = Modifier.defaultMinSize(minHeight = 28.dp),
                      colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                      Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(12.dp))
                      Spacer(modifier = Modifier.width(3.dp))
                      Text("हटाएं", fontSize = 10.sp)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 4. Audit Logs View (if toggled)
    if (showAuditLogs) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(
              text = "अपरिवर्तनीय ऑडिट लॉग (Immutable System Audit Trail):",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            auditLogs.take(6).forEach { log ->
              Text(
                text = "• [${log.timestamp}] ${log.userName} (${log.action}): ${log.details}",
                fontSize = 11.sp,
                lineHeight = 15.sp,
                modifier = Modifier.padding(vertical = 2.dp)
              )
            }
          }
        }
      }
    }

    // 5. Case Management List (Full 13-stage Workflow Control & Deletion)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = if (activeMetricSelection == "ACTIVE_CASES") {
              "सक्रिय पैरवी विधिक मामले (Active Advocacy Cases):"
            } else {
              "विधिक मामले एवं चरण प्रबंधन (13-Stage Workflow):"
            },
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = if (activeMetricSelection == "ACTIVE_CASES") JhsGoldDark else JhsHeadingText
          )
          Text(
            text = "${filteredCases.size} मामले उपलब्ध",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.outline
          )
        }

        if (activeMetricSelection == "ACTIVE_CASES") {
          FilledTonalButton(
            onClick = { activeMetricSelection = "ALL_CASES" },
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.defaultMinSize(minHeight = 28.dp)
          ) {
            Text("सभी मामले देखें ➔", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    if (filteredCases.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder)
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = if (activeMetricSelection == "ACTIVE_CASES") "वर्तमान में कोई सक्रिय पैरवी मामला नहीं है" else "कोई मामला उपलब्ध नहीं है",
              fontSize = 12.sp,
              color = JhsSecondaryText
            )
          }
        }
      }
    }

    items(filteredCases) { c ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = c.id, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsTeal)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "• PIN: ${c.verificationPin}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.outline
              )
            }

            Surface(
              color = JhsTealContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "${c.status.stepIndex}/13: ${if (lang == "hi") c.status.labelHi else c.status.labelEn}",
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = JhsOnTealContainer,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = c.title,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )

          Spacer(modifier = Modifier.height(4.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "${c.village}, ${c.block}",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = "अद्यतन: ${c.lastActionDate}",
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.outline
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(color = JhsBorder.copy(alpha = 0.6f))
          Spacer(modifier = Modifier.height(8.dp))

          // Case Actions: Admin Delete Case and Update Workflow
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedButton(
              onClick = { caseToDelete = c },
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
              modifier = Modifier.defaultMinSize(minHeight = 32.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
            ) {
              Icon(Icons.Default.Delete, contentDescription = "Delete Case", modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("मामला हटाएं", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = { selectedCaseForEdit = c },
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
              modifier = Modifier.defaultMinSize(minHeight = 32.dp)
            ) {
              Text("प्रक्रिया अद्यतन करें ➔", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }

  // Edit / Status Change Dialog
  if (selectedCaseForEdit != null) {
    val targetCase = selectedCaseForEdit!!
    var newStatus by remember { mutableStateOf(targetCase.status) }
    var updateReason by remember { mutableStateOf("") }
    var newNoteContent by remember { mutableStateOf("") }
    var isInternalNote by remember { mutableStateOf(true) }

    AlertDialog(
      onDismissRequest = { selectedCaseForEdit = null },
      title = {
        Text(
          text = "${targetCase.id} - प्रशासनिक कार्यवाही",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "वर्तमान स्थिति बदलें (13 चरण):",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = newStatus.labelHi,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = JhsTeal
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FilledTonalButton(
              onClick = {
                val nextIndex = (newStatus.ordinal + 1).coerceAtMost(CaseStatus.values().size - 1)
                newStatus = CaseStatus.values()[nextIndex]
              },
              modifier = Modifier.weight(1f),
              contentPadding = PaddingValues(4.dp)
            ) {
              Text("अगला चरण ➔", fontSize = 11.sp)
            }
          }

          OutlinedTextField(
            value = updateReason,
            onValueChange = { updateReason = it },
            label = { Text("कारण / विधिक टिप्पणी") },
            placeholder = { Text("उदा. FRC प्रस्ताव प्राप्त या जनसुनवाई पत्र") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Divider(modifier = Modifier.padding(vertical = 4.dp))

          Text(
            text = "नया नोट जोड़ें:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )

          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
              checked = isInternalNote,
              onCheckedChange = { isInternalNote = it }
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (isInternalNote) {
                "गोपनीय आंतरिक नोट (नागरिक को नहीं दिखेगा)"
              } else {
                "सार्वजनिक अद्यतन (नागरिक को दिखेगा)"
              },
              fontSize = 11.sp
            )
          }

          OutlinedTextField(
            value = newNoteContent,
            onValueChange = { newNoteContent = it },
            placeholder = { Text("टिप्पणी दर्ज करें...") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(6.dp))

          // Quick Delete from Edit Modal
          OutlinedButton(
            onClick = {
              val target = targetCase
              selectedCaseForEdit = null
              caseToDelete = target
            },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("यह मामला हमेशा के लिए हटाएं (Delete Case)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (newStatus != targetCase.status) {
              NyaySetuRepository.updateCaseStatus(
                caseId = targetCase.id,
                newStatus = newStatus,
                reason = updateReason.ifBlank { "प्रशासक समीक्षा उपरांत अद्यतन" },
                updaterName = currentUser?.name ?: "Director JHS",
                updaterRole = UserRole.ADMIN
              )
            }
            if (newNoteContent.isNotBlank()) {
              NyaySetuRepository.addCaseNote(
                caseId = targetCase.id,
                authorName = currentUser?.name ?: "Director JHS",
                authorRole = UserRole.ADMIN,
                isInternal = isInternalNote,
                content = newNoteContent
              )
            }
            selectedCaseForEdit = null
          }
        ) {
          Text("सुरक्षित करें")
        }
      },
      dismissButton = {
        TextButton(onClick = { selectedCaseForEdit = null }) {
          Text("रद्द करें")
        }
      }
    )
  }

  // Story Edit Dialog
  if (editingStory != null) {
    val s = editingStory!!
    var editTitle by remember { mutableStateOf(s.titleHi) }
    var editContent by remember { mutableStateOf(s.contentHi) }
    var editCategory by remember { mutableStateOf(s.category) }
    var editVideoUrl by remember { mutableStateOf(s.videoUrl ?: "") }

    AlertDialog(
      onDismissRequest = { editingStory = null },
      title = { Text("कहानी संपादित करें (Edit Story)") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = editTitle,
            onValueChange = { editTitle = it },
            label = { Text("शीर्षक (Title)") },
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = editCategory,
            onValueChange = { editCategory = it },
            label = { Text("श्रेणी (Category)") },
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = editContent,
            onValueChange = { editContent = it },
            label = { Text("विवरण (Content)") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 4
          )
          OutlinedTextField(
            value = editVideoUrl,
            onValueChange = { editVideoUrl = it },
            label = { Text("वीडियो लिंक (Video URL optional)") },
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(onClick = {
          viewModel.updateStory(s.id, editTitle, editContent, editCategory, editVideoUrl)
          editingStory = null
        }) {
          Text("सुरक्षित करें")
        }
      },
      dismissButton = {
        TextButton(onClick = { editingStory = null }) {
          Text("रद्द करें")
        }
      }
    )
  }

  // Confirmation Dialog: Case Deletion
  if (caseToDelete != null) {
    val target = caseToDelete!!
    AlertDialog(
      onDismissRequest = { caseToDelete = null },
      icon = {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
      },
      title = {
        Text(
          text = "मामला हटाने की पुष्टि (Confirm Deletion)",
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "क्या आप वाकई मामला '${target.id} - ${target.title}' को हटाना चाहते हैं?",
            fontSize = 13.sp,
            color = JhsHeadingText,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = "स्थान: ${target.village}, ${target.block}",
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
          Surface(
            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "⚠️ यह कार्यवाही स्थायी है। यह मामला सिस्टम और नागरिक ट्रैकिंग से पूरी तरह हटा दिया जाएगा और इसकी सूचना ऑडिट ट्रेल में सुरक्षित होगी।",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.error,
              modifier = Modifier.padding(8.dp)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteCase(target.id)
            caseToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("हाँ, मामला हटाएं", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { caseToDelete = null }) {
          Text("रद्द करें")
        }
      }
    )
  }

  // Confirmation Dialog: User/Member Deletion
  if (userToDelete != null) {
    val targetUser = userToDelete!!
    AlertDialog(
      onDismissRequest = { userToDelete = null },
      icon = {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
      },
      title = {
        Text(
          text = "सदस्य खाता हटाने की पुष्टि",
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "क्या आप वाकई सदस्य '${targetUser.name}' (@${targetUser.username}) को JHS ऐप से हटाना चाहते हैं?",
            fontSize = 13.sp,
            color = JhsHeadingText
          )
          Text(
            text = "भूमिका: ${targetUser.role.labelHi} | स्थान: ${targetUser.village}, ${targetUser.district}",
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
          Surface(
            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "⚠️ यह सदस्य खाता स्थायी रूप से निष्कासित हो जाएगा।",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.error,
              modifier = Modifier.padding(8.dp)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteUser(targetUser.id)
            userToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("हाँ, सदस्य हटाएं", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { userToDelete = null }) {
          Text("रद्द करें")
        }
      }
    )
  }

  // Confirmation Dialog: Story Deletion
  if (storyToDelete != null) {
    val targetStory = storyToDelete!!
    AlertDialog(
      onDismissRequest = { storyToDelete = null },
      icon = {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
      },
      title = {
        Text("कहानी हटाने की पुष्टि", fontWeight = FontWeight.Bold, fontSize = 16.sp)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "क्या आप वाकई कहानी '${targetStory.titleHi}' (लेखक: ${targetStory.authorName}) को हटाना चाहते हैं?",
            fontSize = 13.sp,
            color = JhsHeadingText
          )
          Surface(
            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "⚠️ यह कहानी और इसका मीडिया फ़ीड से स्थायी रूप से हटा दिया जाएगा।",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.error,
              modifier = Modifier.padding(8.dp)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteStory(targetStory.id)
            storyToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("हाँ, हटाएं", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { storyToDelete = null }) {
          Text("रद्द करें")
        }
      }
    )
  }
}

@Composable
fun MetricTile(
  labelHi: String,
  labelEn: String,
  value: String,
  accentColor: Color,
  modifier: Modifier = Modifier,
  isSelected: Boolean = false,
  onClick: (() -> Unit)? = null
) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isSelected) accentColor.copy(alpha = 0.08f) else JhsWhite
    ),
    border = BorderStroke(
      width = if (isSelected) 2.dp else 1.dp,
      color = if (isSelected) accentColor else JhsBorder
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 6.dp, vertical = 10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = value,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 18.sp,
        color = accentColor
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = labelHi,
        fontSize = 10.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
        color = if (isSelected) accentColor else JhsHeadingText,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        maxLines = 1
      )
      if (isSelected) {
        Spacer(modifier = Modifier.height(3.dp))
        Box(
          modifier = Modifier
            .size(16.dp, 3.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(accentColor)
        )
      }
    }
  }
}

