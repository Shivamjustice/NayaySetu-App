package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommunityActionIssue
import com.example.model.CommunityActionStage
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun GramSabhaScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val meetings by viewModel.gramSabhaMeetings.collectAsState()
  val actionIssues by viewModel.communityActionIssues.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()

  var selectedTab by remember { mutableStateOf(0) } // 0 = Community Action Tracker, 1 = Gram Sabha Meetings
  var showNewIssueDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Header Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "ग्राम सभा व समुदाय सहभागिता (Gram Sabha)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Text(
                text = "ग्राम सभा प्रस्ताव, बैठक अभिलेख एवं सामुदायिक मुद्दों की प्रगति ट्रैकिंग",
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
            }
            Button(
              onClick = { showNewIssueDialog = true },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
              modifier = Modifier.defaultMinSize(minHeight = 36.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("मुद्दा जोड़ें", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }

    // 2. Tabs Selector
    item {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = Color.White,
        contentColor = JhsTeal
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("सामुदायिक एक्शन ट्रैकर (${actionIssues.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("ग्राम सभा बैठकें (${meetings.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        )
      }
    }

    // 3. Tab Contents
    if (selectedTab == 0) {
      // Community Action Tracker: 6-stage workflow
      item {
        Surface(
          color = JhsSecondaryBg,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.2f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(
              text = "🔄 6-चरणीय सामुदायिक समाधान प्रक्रिया:",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = JhsTealDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "1. समस्या पहचान ➔ 2. सामुदायिक चर्चा ➔ 3. सामूहिक आवेदन ➔ 4. विभाग संपर्क ➔ 5. फॉलो-अप ➔ 6. समुदाय पुष्टि",
              fontSize = 10.sp,
              lineHeight = 14.sp,
              color = JhsHeadingText
            )
          }
        }
      }

      items(actionIssues) { issue ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                color = JhsTealContainer,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = issue.category,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsOnTealContainer,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
              Surface(
                color = JhsGoldContainer,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = "चरण ${issue.currentStage.step}/6: ${issue.currentStage.labelHi}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsGoldDark,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = issue.title,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsCharcoal)
            )

            Text(
              text = "गाँव: ${issue.village} • विभाग: ${issue.responsibleDept}",
              fontSize = 11.sp,
              color = JhsTeal,
              fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(text = issue.description, fontSize = 12.sp, lineHeight = 16.sp)

            Spacer(modifier = Modifier.height(10.dp))

            // Progress Timeline Notes
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(text = "कार्यवाही व फॉलो-अप विवरण:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = JhsTerracottaDark)
                issue.progressNotes.forEach { note ->
                  Text(text = "• $note", fontSize = 11.sp, modifier = Modifier.padding(vertical = 1.dp))
                }
              }
            }

            // Advance stage action if Case Manager or Admin
            val canManage = currentUser?.role in listOf(UserRole.SUPER_ADMIN, UserRole.DEPT_ADMIN, UserRole.CASE_MANAGER)
            if (canManage && issue.currentStage.step < 6) {
              Spacer(modifier = Modifier.height(10.dp))
              OutlinedButton(
                onClick = {
                  val nextStep = (issue.currentStage.step + 1).coerceAtMost(6)
                  val nextStage = CommunityActionStage.values()[nextStep - 1]
                  viewModel.updateCommunityActionStage(issue.id, nextStage, "चरण '${nextStage.labelHi}' पर अग्रसर")
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.FastForward, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("अगले चरण पर बढ़ाएँ", fontSize = 11.sp)
              }
            }
          }
        }
      }
    } else {
      // Gram Sabha Meetings
      items(meetings) { m ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "ग्राम सभा: ${m.village}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Surface(
                color = JhsSecondaryBg,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = "दिनांक: ${m.meetingDate}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTealDark,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Text(
              text = "उपस्थिति: ${m.attendeesCount} ग्रामीण सदस्य",
              fontSize = 11.sp,
              color = JhsSecondaryText
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(text = "कार्यसूची (Agenda):", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = JhsHeadingText)
            Text(text = m.agenda, fontSize = 11.sp, lineHeight = 15.sp, color = JhsBodyText)

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.2f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(text = "पारित वैधानिक संकल्प (Resolutions):", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = JhsTealDark)
                m.resolutionsPassed.forEach { res ->
                  Text(text = "✓ $res", fontSize = 11.sp, color = JhsHeadingText, modifier = Modifier.padding(vertical = 1.dp))
                }
              }
            }
          }
        }
      }
    }
  }

  // Add Collective Issue Modal
  if (showNewIssueDialog) {
    var titleInput by remember { mutableStateOf("") }
    var villageInput by remember { mutableStateOf("सहरिया डांडा, कराहल") }
    var categoryInput by remember { mutableStateOf("पेयजल व स्वच्छता") }
    var descInput by remember { mutableStateOf("") }
    var deptInput by remember { mutableStateOf("लोक स्वास्थ्य यांत्रिकी (PHED)") }

    val dialogInputColors = OutlinedTextFieldDefaults.colors(
      focusedContainerColor = JhsInputBg,
      unfocusedContainerColor = JhsInputBg,
      focusedBorderColor = JhsTeal,
      unfocusedBorderColor = JhsBorder,
      focusedTextColor = JhsHeadingText,
      unfocusedTextColor = JhsHeadingText,
      focusedPlaceholderColor = JhsPlaceholderText,
      unfocusedPlaceholderColor = JhsPlaceholderText
    )

    AlertDialog(
      onDismissRequest = { showNewIssueDialog = false },
      containerColor = Color.White,
      title = { Text("नया सामुदायिक मुद्दा दर्ज करें", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = JhsHeadingText) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = titleInput,
            onValueChange = { titleInput = it },
            label = { Text("मुद्दे का शीर्षक *", fontSize = 12.sp) },
            singleLine = true,
            colors = dialogInputColors,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = villageInput,
            onValueChange = { villageInput = it },
            label = { Text("गाँव व ब्लॉक *", fontSize = 12.sp) },
            singleLine = true,
            colors = dialogInputColors,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = deptInput,
            onValueChange = { deptInput = it },
            label = { Text("संबंधित शासकीय विभाग *", fontSize = 12.sp) },
            singleLine = true,
            colors = dialogInputColors,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = descInput,
            onValueChange = { descInput = it },
            label = { Text("समस्या का विवरण *", fontSize = 12.sp) },
            minLines = 3,
            colors = dialogInputColors,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (titleInput.isNotBlank() && descInput.isNotBlank()) {
              viewModel.addCommunityActionIssue(titleInput, villageInput, categoryInput, descInput, deptInput)
              showNewIssueDialog = false
            }
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JhsTeal, contentColor = Color.White)
        ) {
          Text("दर्ज करें", fontWeight = FontWeight.SemiBold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewIssueDialog = false }) {
          Text("रद्द करें", color = JhsSecondaryText)
        }
      }
    )
  }
}
