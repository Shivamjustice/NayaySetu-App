package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppUser
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun AuthScreen(viewModel: NyaySetuViewModel) {
  val currentLang by viewModel.currentLanguage.collectAsState()
  val isNewUser by viewModel.authIsNewUser.collectAsState()
  val username by viewModel.authUsername.collectAsState()
  val password by viewModel.authPassword.collectAsState()
  val errorMessage by viewModel.authErrorMessage.collectAsState()
  val successNotice by viewModel.authSuccessNotice.collectAsState()
  val allUsers by viewModel.allUsers.collectAsState()

  val showForgotPass by viewModel.showForgotPassDialog.collectAsState()
  val forgotIdentifier by viewModel.forgotPassIdentifier.collectAsState()
  val forgotNewPass by viewModel.forgotPassNewPass.collectAsState()
  val forgotMsg by viewModel.forgotPassStatusMsg.collectAsState()

  val showContactAdmin by viewModel.showContactAdminDialog.collectAsState()
  val adminName by viewModel.contactAdminName.collectAsState()
  val adminPhone by viewModel.contactAdminPhone.collectAsState()
  val adminMsg by viewModel.contactAdminMsg.collectAsState()
  val contactStatusMsg by viewModel.contactAdminStatusMsg.collectAsState()

  // Registration Fields
  val regName by viewModel.regName.collectAsState()
  val regUsername by viewModel.regUsername.collectAsState()
  val regPassword by viewModel.regPassword.collectAsState()
  val regPhone by viewModel.regPhone.collectAsState()
  val regEmail by viewModel.regEmail.collectAsState()
  val regDistrict by viewModel.regDistrict.collectAsState()
  val regBlock by viewModel.regBlock.collectAsState()
  val regVillage by viewModel.regVillage.collectAsState()
  val regRole by viewModel.regRole.collectAsState()

  var passwordVisible by remember { mutableStateOf(false) }

  val inputColors = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = JhsInputBg,
    unfocusedContainerColor = JhsInputBg,
    focusedBorderColor = JhsTeal,
    unfocusedBorderColor = JhsBorder,
    focusedLabelColor = JhsImportantLabel,
    unfocusedLabelColor = JhsSecondaryText,
    focusedTextColor = JhsHeadingText,
    unfocusedTextColor = JhsBodyText,
    focusedPlaceholderColor = JhsPlaceholderText,
    unfocusedPlaceholderColor = JhsPlaceholderText,
    focusedLeadingIconColor = JhsTeal,
    unfocusedLeadingIconColor = JhsTeal,
    focusedTrailingIconColor = JhsTeal,
    unfocusedTrailingIconColor = JhsSecondaryText
  )

  Surface(
    modifier = Modifier.fillMaxSize(),
    color = JhsCream
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 18.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Official JHS Brand Card & NyaySetu Welcome Header
      item {
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = BorderStroke(1.dp, JhsSubtleTealBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 2.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Image(
              painter = painterResource(id = R.drawable.jhs_logo),
              contentDescription = "Justice Hub Society Official Logo",
              contentScale = ContentScale.Fit,
              modifier = Modifier.size(88.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = viewModel.tr("न्यायसेतु", "NyaySetu", "NyaySetu"),
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = JhsHeadingText,
                fontSize = 22.sp,
                letterSpacing = 0.2.sp
              ),
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = viewModel.tr(
                hi = "समुदायों को न्याय, अधिकार और विकास से जोड़ना",
                en = "Connecting Communities with Justice, Rights and Development",
                hinglish = "Communities ko Nyay, Adhikar aur Vikas se jodna"
              ),
              style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Medium,
                color = JhsTeal,
                lineHeight = 19.sp
              ),
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(horizontal = 6.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = viewModel.tr(
                hi = "जस्टिस हब सोसाइटी (JHS) – आदिवासी एवं ग्रामीण सशक्तिकरण मंच",
                en = "Justice Hub Society (JHS) – Society for Tribal & Rural Empowerment",
                hinglish = "Justice Hub Society (JHS) – Tribal & Rural Empowerment"
              ),
              style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                color = JhsSecondaryText,
                lineHeight = 16.sp
              ),
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(horizontal = 8.dp)
            )
          }
        }
      }


      // 2. Language Selector Row (Equal-Width, High-Contrast 3-Option Segmented Selector)
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          listOf(
            Pair("hi", "हिन्दी"),
            Pair("en", "English"),
            Pair("hinglish", "Hinglish")
          ).forEach { (code, label) ->
            val isSelected = currentLang == code
            Surface(
              onClick = { viewModel.setLanguage(code) },
              modifier = Modifier
                .weight(1f)
                .height(44.dp),
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) JhsTeal else Color.White,
              border = if (isSelected) null else BorderStroke(1.dp, JhsBorder),
              shadowElevation = if (isSelected) 2.dp else 0.dp
            ) {
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
              ) {
                Text(
                  text = label,
                  color = if (isSelected) Color.White else JhsHeadingText,
                  fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                  fontSize = 13.sp
                )
              }
            }
          }
        }
      }

      // 3. Tab Toggle: Existing User Login vs New User Registration
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = JhsSecondaryBg),
          border = BorderStroke(1.dp, JhsBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(4.dp)
          ) {
            Surface(
              onClick = { viewModel.authIsNewUser.value = false },
              shape = RoundedCornerShape(10.dp),
              color = if (!isNewUser) JhsTeal else Color.Transparent,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.padding(vertical = 10.dp)
              ) {
                Text(
                  text = viewModel.tr("लॉगिन", "Sign In", "Login"),
                  fontWeight = if (!isNewUser) FontWeight.SemiBold else FontWeight.Medium,
                  fontSize = 13.sp,
                  color = if (!isNewUser) Color.White else JhsBodyText
                )
              }
            }

            Surface(
              onClick = { viewModel.authIsNewUser.value = true },
              shape = RoundedCornerShape(10.dp),
              color = if (isNewUser) JhsTeal else Color.Transparent,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.padding(vertical = 10.dp)
              ) {
                Text(
                  text = viewModel.tr("नया पंजीकरण", "New Registration", "Naya Registration"),
                  fontWeight = if (isNewUser) FontWeight.SemiBold else FontWeight.Medium,
                  fontSize = 13.sp,
                  color = if (isNewUser) Color.White else JhsBodyText
                )
              }
            }
          }
        }
      }

      // Success notice banner
      if (successNotice != null) {
        item {
          Surface(
            color = JhsSecondaryButtonBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JhsTeal)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = successNotice ?: "",
                color = JhsTealDark,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }

      // Error banner
      if (errorMessage != null) {
        item {
          Surface(
            color = Color(0xFFFDE8E8),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, Color(0xFFF8B4B4)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFF9B1C1C))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = errorMessage ?: "",
                color = Color(0xFF9B1C1C),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }

      // 4. Form: Login or Register
      if (!isNewUser) {
        // --- LOGIN VIEW ---
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, JhsBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(modifier = Modifier.padding(18.dp)) {
              Text(
                text = viewModel.tr("सुरक्षित लॉगिन", "Secure Sign In", "Secure Login"),
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = JhsHeadingText
              )
              Spacer(modifier = Modifier.height(14.dp))

              // Username / Phone / Email Input
              OutlinedTextField(
                value = username,
                onValueChange = { viewModel.authUsername.value = it },
                label = { Text(viewModel.tr("यूज़रनेम / मोबाइल / ईमेल", "Username / Mobile / Email", "Username / Mobile / Email"), fontSize = 12.sp) },
                placeholder = { Text(viewModel.tr("उदा. admin_jhs या 9826194821", "e.g. admin_jhs or 9826194821", "e.g. admin_jhs ya 9826194821"), fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.AccountCircle, contentDescription = null, tint = JhsTeal) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = inputColors,
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("login_username_input")
              )

              Spacer(modifier = Modifier.height(14.dp))

              // Password with Show/Hide Toggle
              OutlinedTextField(
                value = password,
                onValueChange = { viewModel.authPassword.value = it },
                label = { Text(viewModel.tr("पासवर्ड", "Password", "Password"), fontSize = 12.sp) },
                placeholder = { Text("••••••••", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = JhsTeal) },
                trailingIcon = {
                  IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                      imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                      contentDescription = "Toggle Password",
                      tint = JhsTeal
                    )
                  }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = inputColors,
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("login_password_input")
              )

              Spacer(modifier = Modifier.height(10.dp))

              // Forgot Password & Contact Admin Links
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                TextButton(
                  onClick = { viewModel.showForgotPassDialog.value = true },
                  contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = viewModel.tr("पासवर्ड भूल गए?", "Forgot Password?", "Password bhool gaye?"),
                    fontSize = 12.sp,
                    color = JhsImportantLabel,
                    fontWeight = FontWeight.SemiBold
                  )
                }

                TextButton(
                  onClick = { viewModel.showContactAdminDialog.value = true },
                  contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = viewModel.tr("प्रशासक से संपर्क", "Contact Admin", "Admin se Sampark"),
                    fontSize = 12.sp,
                    color = JhsSecondaryText,
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              Button(
                onClick = { viewModel.login() },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("login_submit_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = JhsPrimaryButtonBg,
                  contentColor = Color.White
                )
              ) {
                Icon(Icons.Default.Login, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = viewModel.tr("लॉगिन करें", "Sign In", "Login Karein"),
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 14.sp
                )
              }

              Spacer(modifier = Modifier.height(14.dp))

              // Divider
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
              ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = JhsBorder)
                Text(
                  text = viewModel.tr("अथवा", "OR", "YA"),
                  fontSize = 11.sp,
                  color = JhsSecondaryText,
                  fontWeight = FontWeight.SemiBold,
                  modifier = Modifier.padding(horizontal = 8.dp)
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = JhsBorder)
              }

              Spacer(modifier = Modifier.height(14.dp))

              // Google Sign-In Button (Jetpack CredentialManager)
              val context = androidx.compose.ui.platform.LocalContext.current
              val coroutineScope = rememberCoroutineScope()
              val credentialManager = remember { androidx.credentials.CredentialManager.create(context) }
              var isGoogleSigningIn by remember { mutableStateOf(false) }

              OutlinedButton(
                onClick = {
                  isGoogleSigningIn = true
                  com.example.data.FirestoreSyncManager.onGoogleSignInClicked(
                    context = context,
                    credentialManager = credentialManager,
                    onAuthSuccess = { firebaseUser ->
                      isGoogleSigningIn = false
                      viewModel.onGoogleSignInSuccess(firebaseUser)
                    },
                    onAuthError = { err ->
                      isGoogleSigningIn = false
                      viewModel.authErrorMessage.value = err
                    },
                    scope = coroutineScope,
                    onAuthCancelled = {
                      isGoogleSigningIn = false
                    }
                  )
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("google_sign_in_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                  containerColor = Color.White,
                  contentColor = JhsHeadingText
                ),
                border = BorderStroke(1.2.dp, JhsTeal)
              ) {
                if (isGoogleSigningIn) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = JhsTeal,
                    strokeWidth = 2.dp
                  )
                } else {
                  Text(
                    text = "G",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF4285F4)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = viewModel.tr("Google से साइन इन करें (ऑटो-लॉगिन)", "Sign in with Google", "Google Se Sign In Karein"),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = JhsHeadingText
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = viewModel.tr(
                  hi = "🌐 Google से लॉगिन करने पर आपका डेटा ऑनलाइन क्लाउड (Firebase) में सुरक्षित रहेगा और बार-बार लॉगिन नहीं करना पड़ेगा।",
                  en = "🌐 Signing in with Google keeps your data backed up on cloud with automatic login.",
                  hinglish = "🌐 Google login se data online Firebase me sync rahega aur baar-baar login nahi karna padega."
                ),
                fontSize = 11.sp,
                color = JhsSecondaryText,
                textAlign = TextAlign.Center,
                lineHeight = 15.sp,
                modifier = Modifier.fillMaxWidth()
              )
            }
          }
        }

        // --- ONE-CLICK DEMO TEST LOGIN CARD ---
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, JhsSubtleTealBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Speed, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = viewModel.tr("त्वरित 1-क्लिक टेस्ट प्रवेश (Quick Login)", "Quick 1-Click Access (Demo)", "Quick 1-Click Login"),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = JhsHeadingText
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = viewModel.tr(
                  "बिना पासवर्ड टाइप किए तुरंत ऐप के सभी फ़ीचर्स देखने हेतु एक क्लिक में प्रवेश करें:",
                  "Instant access without typing passwords to test all app features:",
                  "Bina password daale turant app check karne ke liye login karein:"
                ),
                fontSize = 11.sp,
                color = JhsSecondaryText
              )
              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                // Admin Button
                Surface(
                  onClick = {
                    val adminUser = allUsers.find { it.role == UserRole.SUPER_ADMIN } ?: allUsers.first()
                    viewModel.quickLoginAs(adminUser)
                  },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp),
                  color = JhsTealContainer,
                  border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.4f))
                ) {
                  Column(
                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text("👑", fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = viewModel.tr("JHS एडमिन", "Super Admin", "JHS Admin"),
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = JhsTealDark
                    )
                    Text("पूर्ण प्रबंधन", fontSize = 9.sp, color = JhsSecondaryText)
                  }
                }

                // Villager/Citizen Button
                Surface(
                  onClick = {
                    val citizen = allUsers.find { it.role == UserRole.COMMUNITY_MEMBER } ?: allUsers.first()
                    viewModel.quickLoginAs(citizen)
                  },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFFFF4EC),
                  border = BorderStroke(1.dp, JhsTerracotta.copy(alpha = 0.4f))
                ) {
                  Column(
                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text("👤", fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = viewModel.tr("ग्रामीण नागरिक", "Citizen", "Nagrik"),
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = JhsTerracotta
                    )
                    Text("रामदयाल (आवेदक)", fontSize = 9.sp, color = JhsSecondaryText)
                  }
                }
              }
            }
          }
        }


      } else {
        // --- NEW USER REGISTRATION VIEW ---
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, JhsBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(modifier = Modifier.padding(18.dp)) {
              Text(
                text = viewModel.tr("नया नागरिक / कार्यकर्ता पंजीकरण", "New Member Registration", "Naya Member Registration"),
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = JhsHeadingText
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = viewModel.tr(
                  hi = "सुरक्षा नियम: नया पंजीकरण JHS प्रशासन द्वारा सत्यापन उपरांत ही सक्रिय होगा।",
                  en = "Security Notice: New registrations are activated after verification by JHS Administration.",
                  hinglish = "Security Rule: Naya registration JHS administration ke verification ke baad activate hoga."
                ),
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
              Spacer(modifier = Modifier.height(14.dp))

              OutlinedTextField(
                value = regName,
                onValueChange = { viewModel.regName.value = it },
                label = { Text(viewModel.tr("पूरा नाम *", "Full Name *", "Poora Naam *"), fontSize = 12.sp) },
                placeholder = { Text(viewModel.tr("उदा. रामस्वरूप सहरिया", "e.g. Ramswaroop Sahariya", "e.g. Ramswaroop Sahariya"), fontSize = 12.sp) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = inputColors,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = regUsername,
                onValueChange = { viewModel.regUsername.value = it },
                label = { Text(viewModel.tr("यूज़र आईडी चुनें *", "Choose User ID *", "User ID Banayein *"), fontSize = 12.sp) },
                placeholder = { Text("ramswaroop12", fontSize = 12.sp) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = inputColors,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = regPassword,
                onValueChange = { viewModel.regPassword.value = it },
                label = { Text(viewModel.tr("पासवर्ड सेट करें *", "Set Password *", "Password Set Karein *"), fontSize = 12.sp) },
                placeholder = { Text("••••••••", fontSize = 12.sp) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = inputColors,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(10.dp))

              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                  value = regPhone,
                  onValueChange = { viewModel.regPhone.value = it },
                  label = { Text(viewModel.tr("मोबाइल", "Mobile", "Mobile"), fontSize = 12.sp) },
                  placeholder = { Text("9826XXXXXX", fontSize = 12.sp) },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                  singleLine = true,
                  shape = RoundedCornerShape(12.dp),
                  colors = inputColors,
                  modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                  value = regEmail,
                  onValueChange = { viewModel.regEmail.value = it },
                  label = { Text(viewModel.tr("ईमेल", "Email", "Email"), fontSize = 12.sp) },
                  placeholder = { Text("user@gmail.com", fontSize = 12.sp) },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                  singleLine = true,
                  shape = RoundedCornerShape(12.dp),
                  colors = inputColors,
                  modifier = Modifier.weight(1f)
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                  value = regDistrict,
                  onValueChange = { viewModel.regDistrict.value = it },
                  label = { Text(viewModel.tr("जिला", "District", "District"), fontSize = 12.sp) },
                  singleLine = true,
                  shape = RoundedCornerShape(12.dp),
                  colors = inputColors,
                  modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                  value = regVillage,
                  onValueChange = { viewModel.regVillage.value = it },
                  label = { Text(viewModel.tr("गाँव", "Village", "Village"), fontSize = 12.sp) },
                  singleLine = true,
                  shape = RoundedCornerShape(12.dp),
                  colors = inputColors,
                  modifier = Modifier.weight(1f)
                )
              }

              Spacer(modifier = Modifier.height(14.dp))

              Text(
                text = viewModel.tr("आवेदित भूमिका:", "Requested Role:", "Role Chunein:"),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = JhsHeadingText
              )
              Spacer(modifier = Modifier.height(6.dp))

              val currentLang = viewModel.currentLanguage.collectAsState().value
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                UserRole.values().forEach { r ->
                  val isSel = r == regRole
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                      .fillMaxWidth()
                      .clickable { viewModel.regRole.value = r }
                  ) {
                    RadioButton(
                      selected = isSel,
                      onClick = { viewModel.regRole.value = r },
                      colors = RadioButtonDefaults.colors(
                        selectedColor = JhsTeal,
                        unselectedColor = JhsSecondaryText
                      )
                    )
                    Text(
                      text = r.labelFor(currentLang),
                      fontSize = 12.sp,
                      color = if (isSel) JhsHeadingText else JhsBodyText,
                      fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Normal
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              Button(
                onClick = { viewModel.register() },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("register_submit_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = JhsPrimaryButtonBg,
                  contentColor = Color.White
                )
              ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = viewModel.tr("पंजीकरण प्रस्तुत करें", "Submit Registration", "Registration Submit Karein"),
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 14.sp
                )
              }
            }
          }
        }
      }

      // 5. JHS Official Contact Bar with Admin Phone Number
      item {
        val context = androidx.compose.ui.platform.LocalContext.current
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = viewModel.tr("Justice Hub Society (JHS) — अधिकार से न्याय तक", "Justice Hub Society (JHS) — From Rights to Justice", "Justice Hub Society (JHS) — Adhikar Se Nyay"),
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp,
              color = JhsImportantLabel
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text = viewModel.tr("केंद्रीय विधिक सहायता एवं अधिकार मंच • मध्य प्रदेश", "Central Legal Aid & Empowerment Platform • MP", "Central Legal Aid & Rights Platform • MP"),
              fontSize = 11.sp,
              color = JhsSecondaryText
            )
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
              onClick = {
                val dialIntent = android.content.Intent(android.content.Intent.ACTION_DIAL).apply {
                  data = android.net.Uri.parse("tel:7440323972")
                }
                context.startActivity(dialIntent)
              },
              shape = RoundedCornerShape(8.dp),
              color = JhsTealContainer,
              border = BorderStroke(1.dp, JhsSubtleTealBorder)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Phone, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = viewModel.tr("JHS मुख्य एडमिन संपर्क: 7440323972 (कॉल करें)", "JHS Head Admin Contact: 7440323972 (Call Now)", "JHS Main Admin Contact: 7440323972 (Call)"),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTealDark
                )
              }
            }
          }
        }
      }
    }
  }

  // ----------------------------------------------------
  // Forgot Password Dialog
  // ----------------------------------------------------
  if (showForgotPass) {
    AlertDialog(
      onDismissRequest = { viewModel.showForgotPassDialog.value = false },
      containerColor = Color.White,
      shape = RoundedCornerShape(16.dp),
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.LockReset, contentDescription = null, tint = JhsTeal)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = viewModel.tr("पासवर्ड पुनर्प्राप्ति", "Forgot Password", "Password Reset"),
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = JhsHeadingText
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = viewModel.tr(
              hi = "अपना पंजीकृत यूज़रनेम, मोबाइल नंबर या ईमेल दर्ज करें और नया पासवर्ड सेट करें:",
              en = "Enter your registered username, mobile number or email and set a new password:",
              hinglish = "Apna registered username, mobile number ya email darj karein aur naya password set karein:"
            ),
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
          OutlinedTextField(
            value = forgotIdentifier,
            onValueChange = { viewModel.forgotPassIdentifier.value = it },
            label = { Text(viewModel.tr("यूज़रनेम / मोबाइल / ईमेल", "Username / Mobile / Email", "Username / Mobile / Email"), fontSize = 12.sp) },
            singleLine = true,
            colors = inputColors,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = forgotNewPass,
            onValueChange = { viewModel.forgotPassNewPass.value = it },
            label = { Text(viewModel.tr("नया पासवर्ड", "New Password", "Naya Password"), fontSize = 12.sp) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            colors = inputColors,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )
          if (forgotMsg != null) {
            Text(
              text = forgotMsg ?: "",
              fontSize = 12.sp,
              color = if (forgotMsg?.startsWith("✅") == true) JhsTeal else Color(0xFFC56A3D),
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = { viewModel.resetPassword() },
          colors = ButtonDefaults.buttonColors(containerColor = JhsPrimaryButtonBg, contentColor = Color.White),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(viewModel.tr("पासवर्ड रीसेट करें", "Reset Password", "Password Reset Karein"), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
      },
      dismissButton = {
        Button(
          onClick = { viewModel.showForgotPassDialog.value = false },
          colors = ButtonDefaults.buttonColors(containerColor = JhsSecondaryButtonBg, contentColor = JhsImportantLabel),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(viewModel.tr("बंद करें", "Close", "Band Karein"), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
      }
    )
  }

  // ----------------------------------------------------
  // Contact Administrator Dialog
  // ----------------------------------------------------
  if (showContactAdmin) {
    AlertDialog(
      onDismissRequest = { viewModel.showContactAdminDialog.value = false },
      containerColor = Color.White,
      shape = RoundedCornerShape(16.dp),
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.SupportAgent, contentDescription = null, tint = JhsTeal)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = viewModel.tr("प्रशासक से संपर्क", "Contact Administrator", "Admin Help & Support"),
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = JhsHeadingText
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = viewModel.tr(
              hi = "खाता अनलॉक, नया पासवर्ड अथवा सत्यापन हेतु JHS केंद्रीय एडमिन सेल को संदेश प्रेषित करें:",
              en = "Send a direct support message to the JHS Central Admin Desk for account unlock, password reset, or verification:",
              hinglish = "Khata unlock, naya password ya verification ke liye JHS Admin Desk ko message bhejein:"
            ),
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
          val ctx = androidx.compose.ui.platform.LocalContext.current
          Surface(
            onClick = {
              val dialIntent = android.content.Intent(android.content.Intent.ACTION_DIAL).apply {
                data = android.net.Uri.parse("tel:7440323972")
              }
              ctx.startActivity(dialIntent)
            },
            shape = RoundedCornerShape(8.dp),
            color = JhsTealContainer,
            border = BorderStroke(1.dp, JhsSubtleTealBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Call, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = viewModel.tr("मुख्य एडमिन सीधा फोन: 7440323972", "Head Admin Helpline: 7440323972", "Main Admin Helpline: 7440323972"),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTealDark
                )
                Text(
                  text = viewModel.tr("तत्काल बात करने हेतु यहाँ टैप करें", "Tap here to dial directly", "Seedhi baat ke liye tap karein"),
                  fontSize = 10.sp,
                  color = JhsSecondaryText
                )
              }
            }
          }
          OutlinedTextField(
            value = adminName,
            onValueChange = { viewModel.contactAdminName.value = it },
            label = { Text(viewModel.tr("आपका नाम", "Your Full Name", "Aapka Naam"), fontSize = 12.sp) },
            singleLine = true,
            colors = inputColors,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = adminPhone,
            onValueChange = { viewModel.contactAdminPhone.value = it },
            label = { Text(viewModel.tr("संपर्क मोबाइल नंबर", "Contact Mobile Number", "Mobile Number"), fontSize = 12.sp) },
            singleLine = true,
            colors = inputColors,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = adminMsg,
            onValueChange = { viewModel.contactAdminMsg.value = it },
            label = { Text(viewModel.tr("समस्या या अनुरोध", "Issue or Request Details", "Samasya ya Request"), fontSize = 12.sp) },
            minLines = 2,
            colors = inputColors,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )
          if (contactStatusMsg != null) {
            Text(
              text = contactStatusMsg ?: "",
              fontSize = 12.sp,
              color = JhsTeal,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = { viewModel.submitContactAdmin() },
          colors = ButtonDefaults.buttonColors(containerColor = JhsPrimaryButtonBg, contentColor = Color.White),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(viewModel.tr("अनुरोध भेजें", "Send Request", "Request Bhejein"), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
      },
      dismissButton = {
        Button(
          onClick = { viewModel.showContactAdminDialog.value = false },
          colors = ButtonDefaults.buttonColors(containerColor = JhsSecondaryButtonBg, contentColor = JhsImportantLabel),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(viewModel.tr("बंद करें", "Close", "Band Karein"), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
      }
    )
  }
}
