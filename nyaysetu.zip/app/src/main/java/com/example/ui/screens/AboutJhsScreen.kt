package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

data class CoreWorkArea(
  val number: Int,
  val icon: ImageVector,
  val titleHi: String,
  val titleEn: String,
  val titleHinglish: String,
  val pointsHi: List<String>,
  val pointsEn: List<String>,
  val pointsHinglish: List<String>
)

data class ApproachPrinciple(
  val number: Int,
  val icon: ImageVector,
  val titleHi: String,
  val titleEn: String,
  val titleHinglish: String,
  val descHi: String,
  val descEn: String,
  val descHinglish: String
)

@Composable
fun AboutJhsScreen(viewModel: NyaySetuViewModel) {
  val context = LocalContext.current
  val lang by viewModel.currentLanguage.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()

  val coreAreas = remember {
    listOf(
      CoreWorkArea(
        number = 1,
        icon = Icons.Default.Gavel,
        titleHi = "1. अधिकार और न्याय तक पहुँच (Rights & Access to Justice)",
        titleEn = "1. Rights & Access to Justice",
        titleHinglish = "1. Rights & Access to Justice (Adhikar aur Nyay)",
        pointsHi = listOf(
          "आदिवासी एवं ग्रामीण समुदायों में संवैधानिक व कानूनी अधिकारों के प्रति जागरूकता सृजन।",
          "वनाधिकार अधिनियम (FRA 2006), पेसा (PESA 1996) और अन्य प्रासंगिक कानूनों का सघन प्रचार-प्रसार।",
          "सरकारी योजनाओं, आवश्यक दस्तावेजों एवं विधिक प्रक्रियाओं तक पहुँच में समुदायों का मार्गदर्शन।",
          "जमीन के अधिकार, सामाजिक न्याय और अन्य कानूनी मुद्दों पर व्यावहारिक सहायता।",
          "आवश्यकता पड़ने पर नागरिकों को विधिक विशेषज्ञों एवं अधिकृत न्यायिक संस्थाओं (DLSA) से जोड़ना।"
        ),
        pointsEn = listOf(
          "Creating awareness about constitutional and legal rights among tribal and rural communities.",
          "Promoting awareness of the Forest Rights Act (FRA), PESA, and other relevant laws.",
          "Supporting communities in accessing government schemes, essential documents, and legal processes.",
          "Providing support on land rights, social justice, and other legal issues.",
          "Connecting individuals and communities with legal experts and relevant institutions whenever required."
        ),
        pointsHinglish = listOf(
          "Tribal aur rural communities mein constitutional aur legal rights ki awareness failana.",
          "Forest Rights Act (FRA), PESA aur doosre kanoono ka prachar-prasar karna.",
          "Government schemes, zaroori documents aur legal processes mein madad karna.",
          "Zameen ke adhikar, social justice aur legal issues par practical support dena.",
          "Zaroorat padne par citizens ko legal experts aur DLSA institutions se jodna."
        )
      ),
      CoreWorkArea(
        number = 2,
        icon = Icons.Default.Work,
        titleHi = "2. आजीविका और आर्थिक सशक्तिकरण (Livelihood & Economic Empowerment)",
        titleEn = "2. Livelihood & Economic Empowerment",
        titleHinglish = "2. Livelihood & Economic Empowerment (Aajeevika)",
        pointsHi = listOf(
          "समुदायों की पारंपरिक आजीविका पद्धतियों को समझना और उन्हें मजबूत बनाना।",
          "स्थानीय प्राकृतिक संसाधनों पर आधारित टिकाऊ रोजगार अवसरों का विकास करना।",
          "महिलाओं और युवाओं के लिए नए आय-सृजन के साधन विकसित करना।",
          "कौशल विकास (Skill Training) और स्थानीय उद्यमिता को बढ़ावा देना।",
          "दीर्घकालिक आर्थिक आत्मनिर्भरता हेतु समुदाय-आधारित आर्थिक मॉडल तैयार करना।"
        ),
        pointsEn = listOf(
          "Understanding and strengthening traditional livelihood practices within communities.",
          "Developing employment opportunities based on local resources.",
          "Creating new income-generation opportunities for women and young people.",
          "Promoting skill development and entrepreneurship.",
          "Developing community-based models for long-term economic self-reliance."
        ),
        pointsHinglish = listOf(
          "Traditional livelihood practices ko samajhna aur unhe majboot banana.",
          "Local resources par based employment opportunities create karna.",
          "Women aur youth ke liye naye income generation avenues develop karna.",
          "Skill development aur local entrepreneurship ko promote karna.",
          "Long-term economic self-reliance ke liye community-based models taiyar karna."
        )
      ),
      CoreWorkArea(
        number = 3,
        icon = Icons.Default.School,
        titleHi = "3. शिक्षा और बाल अधिकार (Education & Child Rights)",
        titleEn = "3. Education & Child Rights",
        titleHinglish = "3. Education & Child Rights (Shiksha aur Baal Adhikar)",
        pointsHi = listOf(
          "बच्चों की गुणवत्तापूर्ण शिक्षा तक सुलभ पहुँच सुनिश्चित करने हेतु निरंतर प्रयास।",
          "स्कूल छोड़ चुके (Drop-out) बच्चों की पहचान कर उन्हें पुनः मुख्यधारा शिक्षा से जोड़ना।",
          "बाल अधिकारों (Child Rights) और बाल संरक्षण कानूनों के प्रति सामुदायिक जागरूकता।",
          "किशोर-किशोरियों के लिए शैक्षिक एवं नेतृत्व विकास के अवसर उपलब्ध कराना।",
          "सरकारी शिक्षा योजनाओं, छात्रवृत्तियों व छात्रावास सुविधाओं का लाभ दिलाना।"
        ),
        pointsEn = listOf(
          "Working to improve children's access to education.",
          "Identifying and supporting children who have dropped out of school.",
          "Creating awareness about child rights.",
          "Promoting educational and leadership opportunities for adolescents.",
          "Supporting access to government educational schemes and facilities."
        ),
        pointsHinglish = listOf(
          "Bachhon ki quality education tak pahunch behtar banana.",
          "Drop-out bachhon ko identify karke dobara school se connect karna.",
          "Child rights aur protection ke prati awareness failana.",
          "Adolescents ke liye educational aur leadership opportunities provide karna.",
          "Government educational schemes aur hostel facilities ka laabh dilana."
        )
      ),
      CoreWorkArea(
        number = 4,
        icon = Icons.Default.Shield,
        titleHi = "4. महिला सशक्तिकरण (Women Empowerment)",
        titleEn = "4. Women Empowerment",
        titleHinglish = "4. Women Empowerment (Mahila Sashaktikaran)",
        pointsHi = listOf(
          "महिलाओं के कानूनी अधिकारों और विधिक संरक्षण तंत्र के प्रति चेतना जाग्रत करना।",
          "महिलाओं की सामुदायिक नेतृत्व क्षमता और निर्णय लेने की शक्ति को सुदृढ़ बनाना।",
          "आर्थिक गतिविधियों और आजीविका के अवसरों में महिलाओं की सक्रिय भागीदारी सुनिश्चित करना।",
          "किशोरी बालिकाओं की शिक्षा, स्वास्थ्य और सुरक्षा से जुड़ी पहलों का संचालन।"
        ),
        pointsEn = listOf(
          "Creating awareness about women's rights and legal protection.",
          "Strengthening women's leadership and decision-making abilities.",
          "Promoting women's participation in economic activities and livelihood opportunities.",
          "Supporting awareness initiatives related to adolescent girls' education, safety, and health."
        ),
        pointsHinglish = listOf(
          "Women's rights aur legal protection ke prati jagrukta badhana.",
          "Mahilaon ki leadership aur decision-making abilities ko majboot karna.",
          "Economic activities aur livelihood mein women's participation ensure karna.",
          "Adolescent girls ki education, safety aur health initiatives ko support karna."
        )
      ),
      CoreWorkArea(
        number = 5,
        icon = Icons.Default.LocalHospital,
        titleHi = "5. स्वास्थ्य और सामाजिक सुरक्षा (Health & Social Protection)",
        titleEn = "5. Health & Social Protection",
        titleHinglish = "5. Health & Social Protection (Swasthya aur Suraksha)",
        pointsHi = listOf(
          "स्वास्थ्य सेवाओं और सरकारी स्वास्थ्य योजनाओं (सिकल सेल, मातृत्व लाभ) तक पहुँच सुधारना।",
          "स्वास्थ्य अधिकारों और उपलब्ध चिकित्सा सुविधाओं की सटीक जानकारी प्रदान करना।",
          "सामाजिक सुरक्षा पेंशन (वृद्धावस्था, विधवा, दिव्यांग) व कल्याणकारी योजनाओं से जोड़ना।",
          "सामुदायिक स्वास्थ्य समस्याओं को संबंधित प्रशासनिक विभागों व अधिकारियों के समक्ष उठाना।"
        ),
        pointsEn = listOf(
          "Improving access to healthcare services and government health schemes.",
          "Creating awareness about health rights and available healthcare facilities.",
          "Supporting access to social security pensions and other welfare schemes.",
          "Bringing community health concerns to the attention of relevant institutions and government authorities."
        ),
        pointsHinglish = listOf(
          "Healthcare services aur government schemes tak pahunch improve karna.",
          "Health rights aur medical facilities ki accurate jankari dena.",
          "Social security pensions aur welfare schemes ka laabh dilana.",
          "Community health concerns ko authorities aur departments tak pahunchana."
        )
      ),
      CoreWorkArea(
        number = 6,
        icon = Icons.Default.Eco,
        titleHi = "6. पर्यावरण, जैव विविधता और पारंपरिक ज्ञान (Environment & Traditional Knowledge)",
        titleEn = "6. Environment, Biodiversity & Traditional Knowledge",
        titleHinglish = "6. Environment & Traditional Knowledge (Paryavaran)",
        pointsHi = listOf(
          "स्थानीय पारिस्थितिकी तंत्र (Ecosystems) और जैव विविधता के संरक्षण को बढ़ावा देना।",
          "आदिवासी समुदायों के पारंपरिक ज्ञान, प्राकृतिक औषधीय पद्धतियों और अनुभवों का दस्तावेजीकरण।",
          "प्राकृतिक संसाधनों के न्यायसंगत व टिकाऊ उपयोग एवं प्रबंधन को प्रोत्साहित करना।",
          "संरक्षण व पर्यावरण संरक्षण पहलों में स्थानीय ग्राम सभाओं और समुदायों को भागीदार बनाना।"
        ),
        pointsEn = listOf(
          "Promoting the conservation of local ecosystems and biodiversity.",
          "Documenting traditional knowledge, experiences, and practices of communities.",
          "Encouraging the sustainable use and management of natural resources.",
          "Involving local communities in conservation and environmental protection initiatives."
        ),
        pointsHinglish = listOf(
          "Local ecosystems aur biodiversity ke conservation ko promote karna.",
          "Traditional knowledge aur practices ka systematic documentation karna.",
          "Natural resources ke sustainable use aur management ko encourage karna.",
          "Gram Sabhas aur communities ko environmental conservation mein engage karna."
        )
      ),
      CoreWorkArea(
        number = 7,
        icon = Icons.Default.Groups,
        titleHi = "7. युवा नेतृत्व और सामुदायिक भागीदारी (Youth Leadership & Community Participation)",
        titleEn = "7. Youth Leadership & Community Participation",
        titleHinglish = "7. Youth Leadership & Community Participation (Yuva Netritva)",
        pointsHi = listOf(
          "आदिवासी और ग्रामीण युवाओं के लिए नेतृत्व और सामाजिक सेवा के नए अवसर सृजित करना।",
          "स्थानीय युवाओं को सामुदायिक विकास और नागरिक मुद्दों के समाधान में सक्रिय रूप से जोड़ना।",
          "युवा स्वयंसेवकों और जमीनी कार्यकर्ताओं का एक सशक्त व सक्रिय नेटवर्क स्थापित करना।",
          "स्थानीय समस्याओं की पहचान और समाधान में संपूर्ण समुदाय की भागीदारी को सशक्त बनाना।"
        ),
        pointsEn = listOf(
          "Creating leadership opportunities for tribal and rural youth.",
          "Engaging local young people in community development and social issues.",
          "Building networks of youth volunteers and community leaders.",
          "Strengthening community participation in identifying local challenges and developing solutions."
        ),
        pointsHinglish = listOf(
          "Tribal aur rural youth ke liye leadership opportunities create karna.",
          "Local youth ko community development aur social issues mein engage karna.",
          "Youth volunteers aur community leaders ka network banana.",
          "Local challenges identify karne aur solutions banane mein public participation badhana."
        )
      ),
      CoreWorkArea(
        number = 8,
        icon = Icons.Default.FindInPage,
        titleHi = "8. अनुसंधान, दस्तावेजीकरण और नीतिगत पैरवी (Research, Documentation & Advocacy)",
        titleEn = "8. Research, Documentation & Advocacy",
        titleHinglish = "8. Research, Documentation & Advocacy (Shodh aur Pairvi)",
        pointsHi = listOf(
          "समुदायों की जमीनी वास्तविकताओं को समझने के लिए प्रामाणिक मैदानी अनुसंधान संचालित करना।",
          "जनता के वास्तविक अनुभवों, संघर्षों, सफलताओं और लोक-कहानियों का अभिलेखीकरण।",
          "सरकारी योजनाओं और विकास कार्यक्रमों के क्रियान्वयन व प्रभाव का वैज्ञानिक अध्ययन।",
          "साक्ष्यों व तथ्यों के आधार पर जनहितैषी मुद्दों को संबंधित प्रशासनिक संस्थाओं के समक्ष रखना।",
          "मैदानी अनुभवों और अनुसंधान के आधार पर नीतियों और विकास कार्यक्रमों में सुधार की पैरवी।"
        ),
        pointsEn = listOf(
          "Conducting field research to understand the ground realities of communities.",
          "Documenting people's experiences, perspectives, and stories.",
          "Studying the implementation and impact of government schemes and development programmes.",
          "Presenting community issues to relevant institutions with evidence and facts.",
          "Advocating for improved policies and development programmes based on research and field experiences."
        ),
        pointsHinglish = listOf(
          "Ground realities samajhne ke liye authentic field research conduct karna.",
          "Logon ke experiences, perspectives aur stories ko document karna.",
          "Government schemes aur programmes ke impact ki study karna.",
          "Evidence aur facts ke sath public issues ko authorities ke samne rakhna.",
          "Policy improvements aur better development programmes ke liye advocacy karna."
        )
      )
    )
  }

  val approachPrinciples = remember {
    listOf(
      ApproachPrinciple(
        number = 1,
        icon = Icons.Default.Favorite,
        titleHi = "1. समुदाय सर्वोपरि (Community First)",
        titleEn = "1. Community First",
        titleHinglish = "1. Community First (Samuday Sabse Pehle)",
        descHi = "हम प्रत्येक पहल की शुरुआत समुदाय की वास्तविक परिस्थितियों, प्राथमिकताओं और आवश्यकताओं को गहराई से समझकर करते हैं। परियोजना की योजना से लेकर उसके क्रियान्वयन तक प्रत्येक चरण में जनभागीदारी सुनिश्चित की जाती है।",
        descEn = "We begin every initiative by understanding the actual circumstances, needs, and priorities of the community. We aim to ensure active community participation at every stage, from project planning to implementation.",
        descHinglish = "Hum har initiative ki shuruat community ki actual conditions aur zarooraton ko samajhkar karte hain. Planning se implementation tak har stage par active participation rehta hai."
      ),
      ApproachPrinciple(
        number = 2,
        icon = Icons.Default.Balance,
        titleHi = "2. अधिकार-आधारित दृष्टिकोण (Rights-Based Approach)",
        titleEn = "2. Rights-Based Approach",
        titleHinglish = "2. Rights-Based Approach (Adhikar Aadharit)",
        descHi = "हम नागरिकों को केवल सरकारी योजनाओं का आश्रित लाभार्थी नहीं, बल्कि गरिमा और संवैधानिक अधिकारों से युक्त नागरिक मानते हैं। हमारा प्रयास लोगों में अपने अधिकार समझने और उन्हें आत्मविश्वास से प्राप्त करने की क्षमता विकसित करना है।",
        descEn = "We see people not merely as beneficiaries of government schemes but as citizens with rights and entitlements. Our efforts focus on helping people understand their rights and build the confidence and capacity to claim them.",
        descHinglish = "Hum logon ko sirf beneficiaries nahi balki rights-bearing citizens maante hain. Hamara uddeshya logon mein apne haq samajhne aur unhe claim karne ka confidence develop karna hai."
      ),
      ApproachPrinciple(
        number = 3,
        icon = Icons.Default.Groups,
        titleHi = "3. समुदाय-नेतृत्व विकास (Community-Led Development)",
        titleEn = "3. Community-Led Development",
        titleHinglish = "3. Community-Led Development (Samuday Netritva)",
        descHi = "हम स्थानीय युवाओं, महिलाओं और ग्राम सभा नेतृत्व को सशक्त बनाते हैं। हमारा दृष्टिकोण समुदाय को स्वयं अपनी चुनौतियों की पहचान करने, प्राथमिकताएं तय करने और समाधान का नेतृत्व करने के लिए प्रेरित करता है।",
        descEn = "We aim to strengthen local youth, women, and community leadership. Our approach encourages communities to identify their own challenges, set priorities, and take the lead in developing solutions.",
        descHinglish = "Hum local youth, women aur community leadership ko majboot karte hain, taaki log apni problems khud identify karein aur solutions lead karein."
      ),
      ApproachPrinciple(
        number = 4,
        icon = Icons.Default.Assessment,
        titleHi = "4. साक्ष्य-आधारित कार्यपद्धति (Evidence-Based Approach)",
        titleEn = "4. Evidence-Based Approach",
        titleHinglish = "4. Evidence-Based Approach (Tathya Aadharit)",
        descHi = "हम जमीनी शोध, बैठकों, सर्वेक्षणों, आधिकारिक अभिलेखों और लोगों के प्रत्यक्ष अनुभवों का उपयोग करते हैं। हम यह सुनिश्चित करते हैं कि हमारी हर पहल वास्तविक जरूरतों, प्रमाणों और जमीनी तथ्यों पर टिकी हो।",
        descEn = "We use field research, community meetings, surveys, official documents, and people's experiences to understand local challenges. We strive to ensure that our initiatives are based on actual needs, evidence, and ground realities.",
        descHinglish = "Hum field research, surveys aur ground facts ka use karte hain taaki hamari har initiative real evidence aur genuine needs par based ho."
      ),
      ApproachPrinciple(
        number = 5,
        icon = Icons.Default.Handshake,
        titleHi = "5. सहयोग और संस्थागत समन्वय (Collaboration & Institutional Support)",
        titleEn = "5. Collaboration & Institutional Support",
        titleHinglish = "5. Collaboration & Institutional Support (Sahyog)",
        descHi = "हम समुदायों, प्रशासनिक अधिकारियों, विधिक विशेषज्ञों, नागरिक समाज संगठनों और शैक्षणिक संस्थानों के बीच सकारात्मक व सार्थक साझेदारी का निर्माण करते हैं ताकि न्याय की राह सुगम हो सके।",
        descEn = "We seek to build meaningful partnerships among communities, government authorities, legal experts, civil society organisations, academic institutions, and other relevant stakeholders.",
        descHinglish = "Hum communities, government authorities, legal experts aur civil society ke beech meaningful partnerships build karte hain."
      ),
      ApproachPrinciple(
        number = 6,
        icon = Icons.Default.Devices,
        titleHi = "6. तकनीकी-सक्षम समाधान (Technology-Enabled Solutions)",
        titleEn = "6. Technology-Enabled Solutions",
        titleHinglish = "6. Technology-Enabled Solutions (Digital Suvidha)",
        descHi = "हम तकनीक (जैसे न्यायसेतु डिजिटल प्लेटफॉर्म, एआई वाणी सहायक, स्थानीय भाषाओं में जानकारी, और शिकायत ट्रैकिंग प्रणाली) के माध्यम से अधिकारों व सरकारी योजनाओं की जानकारी को हर व्यक्ति के लिए सुलभ बनाते हैं।",
        descEn = "We aim to use technology to make information, rights, government schemes, and support services more accessible to communities. Our initiatives may include digital platforms, voice-based assistants, information in local languages, community data management systems, and grievance-tracking mechanisms.",
        descHinglish = "Hum technology ka use karke digital platforms, voice-based AI assistants aur grievance tracking ke zariye information ko easily accessible banate hain."
      )
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp)
      .testTag("about_jhs_screen"),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Official JHS Hero Header Card with Logo and Tagline
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsSubtleTealBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Image(
            painter = painterResource(id = R.drawable.jhs_logo),
            contentDescription = "Justice Hub Society Official Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(92.dp)
          )
          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "Justice Hub Society (JHS)",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = JhsHeadingText,
              fontSize = 22.sp
            ),
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(4.dp))

          Surface(
            color = JhsTealContainer,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, JhsSubtleTealBorder)
          ) {
            Text(
              text = viewModel.tr(
                hi = "आदिवासी एवं ग्रामीण सशक्तिकरण हेतु",
                en = "For Tribal And Rural Empowerment",
                hinglish = "For Tribal And Rural Empowerment"
              ),
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = JhsTealDark,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Tagline Strip
          Surface(
            color = JhsGoldContainer.copy(alpha = 0.5f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsGold.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = viewModel.tr(
                hi = "ध्येय वाक्य: अधिकार से न्याय तक। समुदाय से बदलाव तक।",
                en = "Tagline: From Rights to Justice. From Community to Change.",
                hinglish = "Tagline: From Rights to Justice. From Community to Change."
              ),
              style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = JhsOnGoldContainer
              ),
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
          }
        }
      }
    }

    // 2. Official Introduction Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Info, contentDescription = null, tint = JhsTeal)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = viewModel.tr("संस्था परिचय", "About Organization", "About Organization"),
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = JhsHeadingText
                )
              )
            }

            IconButton(
              onClick = {
                if (isSpeaking) {
                  viewModel.stopSpeech()
                } else {
                  val introSpeech = viewModel.tr(
                    hi = "जस्टिस हब सोसाइटी (JHS) एक जमीनी स्तर का सामाजिक संगठन है, जो आदिवासी और ग्रामीण समुदायों, विशेष रूप से महिलाओं, बच्चों और युवाओं को उनके अधिकारों, अवसरों और विकास प्रक्रियाओं से जोड़ने का कार्य करता है।",
                    en = "Justice Hub Society (JHS) is a grassroots-level social organisation working to connect tribal and rural communities, particularly women, children, and young people, with their rights, opportunities, and development processes.",
                    hinglish = "Justice Hub Society ek grassroots-level social organisation hai jo tribal aur rural communities ko unke rights aur development se jodti hai."
                  )
                  viewModel.speak(introSpeech)
                }
              },
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(JhsSecondaryBg)
            ) {
              Icon(
                imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                contentDescription = "Read Aloud",
                tint = JhsTeal,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = viewModel.tr(
              hi = "Justice Hub Society (JHS) एक जमीनी स्तर का सामाजिक संगठन है, जो आदिवासी और ग्रामीण समुदायों, विशेष रूप से महिलाओं, बच्चों और युवाओं को उनके अधिकारों, अवसरों और विकास प्रक्रियाओं से जोड़ने का कार्य करता है।\n\nहमारा यह दृढ़ विश्वास है कि किसी समुदाय का वास्तविक विकास तभी संभव है जब लोग अपने अधिकारों के प्रति जागरूक हों, अपने निर्णय स्वयं लेने में सक्षम हों और अपनी विकास यात्रा में सक्रिय भागीदारी निभाएं।\n\nहमारा कार्य केवल समस्याओं की पहचान करने तक सीमित नहीं है, बल्कि हम समुदायों के साथ मिलकर उनकी चुनौतियों का व्यावहारिक, टिकाऊ और दीर्घकालिक समाधान तलाशने के लिए निरंतर प्रयासरत हैं।",
              en = "Justice Hub Society (JHS) is a grassroots-level social organisation working to connect tribal and rural communities, particularly women, children, and young people, with their rights, opportunities, and development processes.\n\nWe believe that the true development of a community is possible only when people are aware of their rights, have the ability to make their own decisions, and actively participate in shaping their development.\n\nOur work goes beyond identifying problems. We aim to work alongside communities to develop practical, sustainable, and long-term solutions to the challenges they face.",
              hinglish = "Justice Hub Society (JHS) ek grassroots-level social organisation hai jo tribal aur rural communities, khas taur par women, children aur youth ko unke rights, opportunities aur development processes se connect karti hai.\n\nHum maante hain ki kisi community ka real development tabhi possible hai jab log apne rights ke prati aware hon, apne decisions khud lene mein saksham hon aur development mein actively participate karein.\n\nHamara kaam sirf problems identify karna nahi hai, balki communities ke sath milkar practical, sustainable aur long-term solutions develop karna hai."
            ),
            fontSize = 13.sp,
            lineHeight = 20.sp,
            color = JhsBodyText
          )
        }
      }
    }

    // 3. Our Mission Card (Highlighted Hero Container)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsTealContainer.copy(alpha = 0.5f)),
        border = BorderStroke(1.dp, JhsSubtleTealBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Stars, contentDescription = null, tint = JhsTeal)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = viewModel.tr("3. हमारा मिशन (Our Mission)", "3. Our Mission", "3. Our Mission (Hamara Mission)"),
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = JhsTealDark
              )
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = viewModel.tr(
              hi = "“हमारा मिशन आदिवासी और ग्रामीण समुदायों, विशेष रूप से महिलाओं और युवाओं को ज्ञान, अधिकारों के प्रति जागरूकता, आवश्यक सहायता प्रणालियों और विकास के अवसरों से जोड़कर सशक्त बनाना है।\n\nहम समुदायों के साथ मिलकर एक ऐसा सक्षम और न्यायपूर्ण वातावरण बनाने का प्रयास करते हैं, जहाँ प्रत्येक नागरिक गरिमा, समानता और सामाजिक न्याय के साथ जीवन यापन कर सके।”",
              en = "“Our mission is to empower tribal and rural communities, particularly women and young people, by connecting them with knowledge, awareness of their rights, essential support systems, and opportunities for development.\n\nWe strive to work alongside communities to create an enabling environment where every individual can live with dignity, equality, and justice.”",
              hinglish = "“Hamara mission tribal aur rural communities, khas taur par mahilaon aur yuvaon ko knowledge, rights awareness, essential support systems aur development opportunities se connect karke empower karna hai.\n\nHum communities ke sath milkar ek aisa enabling environment banane ka prayas karte hain jahan har nagrik dignity, equality aur justice ke sath jee sake.”"
            ),
            fontSize = 13.5.sp,
            lineHeight = 21.sp,
            fontWeight = FontWeight.Medium,
            color = JhsHeadingText
          )
        }
      }
    }

    // 4. Section 1: Core Areas of Work (Header & 8 Detailed Cards)
    item {
      Column(modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)) {
        Text(
          text = viewModel.tr(
            hi = "1. प्रमुख कार्य क्षेत्र (Core Areas of Work)",
            en = "1. Core Areas of Work",
            hinglish = "1. Core Areas of Work (Pramukh Karya Kshetra)"
          ),
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.ExtraBold,
            color = JhsHeadingText,
            fontSize = 17.sp
          )
        )
        Text(
          text = viewModel.tr(
            hi = "हमारा कार्य मुख्यतः आठ प्रमुख स्तंभों पर केंद्रित है:",
            en = "Our work is primarily focused on eight key areas:",
            hinglish = "Hamara kaam mukhya roop se 8 key areas par focused hai:"
          ),
          fontSize = 12.sp,
          color = JhsSecondaryText
        )
      }
    }

    // 8 Core Work Area Items
    items(coreAreas) { area ->
      var isExpanded by remember { mutableStateOf(true) }

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { isExpanded = !isExpanded },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(JhsSecondaryBg),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = area.icon,
                  contentDescription = null,
                  tint = JhsTeal,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Text(
                text = when (lang) {
                  "en" -> area.titleEn
                  "hinglish" -> area.titleHinglish
                  else -> area.titleHi
                },
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = JhsHeadingText,
                  fontSize = 14.sp
                )
              )
            }

            IconButton(
              onClick = { isExpanded = !isExpanded },
              modifier = Modifier.size(30.dp)
            ) {
              Icon(
                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = "Toggle Details",
                tint = JhsSecondaryText
              )
            }
          }

          AnimatedVisibility(visible = isExpanded) {
            Column(
              modifier = Modifier.padding(top = 10.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              val points = when (lang) {
                "en" -> area.pointsEn
                "hinglish" -> area.pointsHinglish
                else -> area.pointsHi
              }

              points.forEach { point ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.Top
                ) {
                  Text(
                    text = "• ",
                    color = JhsTeal,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 1.dp)
                  )
                  Text(
                    text = point,
                    fontSize = 12.5.sp,
                    lineHeight = 18.sp,
                    color = JhsBodyText
                  )
                }
              }
            }
          }
        }
      }
    }

    // 5. Section 2: Our Approach (Header & 6 Principles)
    item {
      Column(modifier = Modifier.padding(top = 12.dp, bottom = 2.dp)) {
        Text(
          text = viewModel.tr(
            hi = "2. हमारी कार्यपद्धति व दृष्टिकोण (Our Approach)",
            en = "2. Our Approach",
            hinglish = "2. Our Approach (Karyapaddhati)"
          ),
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.ExtraBold,
            color = JhsHeadingText,
            fontSize = 17.sp
          )
        )
        Text(
          text = viewModel.tr(
            hi = "JHS की कार्यप्रणाली समुदाय-केंद्रित और अधिकार-आधारित दृष्टिकोण (Community-Centred & Rights-Based Approach) के 6 सिद्धांतों पर आधारित है:",
            en = "JHS is committed to a Community-Centred and Rights-Based Approach built around six key principles:",
            hinglish = "JHS ki working methodology 6 core principles par based hai:"
          ),
          fontSize = 12.sp,
          color = JhsSecondaryText
        )
      }
    }

    // 6 Principles
    items(approachPrinciples) { principle ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.Top
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(JhsTealContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = principle.icon,
              contentDescription = null,
              tint = JhsTeal,
              modifier = Modifier.size(20.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = when (lang) {
                "en" -> principle.titleEn
                "hinglish" -> principle.titleHinglish
                else -> principle.titleHi
              },
              fontWeight = FontWeight.Bold,
              fontSize = 13.5.sp,
              color = JhsHeadingText
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = when (lang) {
                "en" -> principle.descEn
                "hinglish" -> principle.descHinglish
                else -> principle.descHi
              },
              fontSize = 12.sp,
              lineHeight = 18.sp,
              color = JhsBodyText
            )
          }
        }
      }
    }

    // 6. Official Team Helpline Numbers Banner (Interactive Call Buttons)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsSecondaryBg),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SupportAgent, contentDescription = null, tint = JhsTeal)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = viewModel.tr(
                hi = "JHS आधिकारिक सहायता व संपर्क डेस्क",
                en = "JHS Official Support & Helpline Desk",
                hinglish = "JHS Official Support & Helpline Desk"
              ),
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = JhsHeadingText
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Number 1: 7440323972
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = JhsWhite),
            border = BorderStroke(1.dp, JhsBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "7440323972",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = JhsTeal
                  )
                )
                Text(
                  text = viewModel.tr(
                    hi = "केंद्रीय विधिक सहायता सेल व मुख्य एडमिन (Central Legal Desk)",
                    en = "Central Legal Aid Cell & Head Admin Desk",
                    hinglish = "Central Legal Aid Cell & Main Admin Desk"
                  ),
                  fontSize = 12.sp,
                  color = JhsBodyText
                )
              }
              FilledIconButton(
                onClick = {
                  val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:7440323972"))
                  context.startActivity(intent)
                },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = JhsTeal),
                modifier = Modifier.size(46.dp)
              ) {
                Icon(Icons.Default.Phone, contentDescription = "Call 7440323972", tint = Color.White)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Number 2: 8103056522
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = JhsWhite),
            border = BorderStroke(1.dp, JhsBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "8103056522",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = JhsTerracotta
                  )
                )
                Text(
                  text = viewModel.tr(
                    hi = "मैदानी समन्वय व ग्राम स्तर आपातकालीन सहायता (Field Coordinator)",
                    en = "Field Coordination & Community Emergency Desk",
                    hinglish = "Field Coordination & Gram Emergency Desk"
                  ),
                  fontSize = 12.sp,
                  color = JhsBodyText
                )
              }
              FilledIconButton(
                onClick = {
                  val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:8103056522"))
                  context.startActivity(intent)
                },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = JhsTerracotta),
                modifier = Modifier.size(46.dp)
              ) {
                Icon(Icons.Default.Phone, contentDescription = "Call 8103056522", tint = Color.White)
              }
            }
          }
        }
      }
    }
  }
}
