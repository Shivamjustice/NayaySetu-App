package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HelplineItem
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun HelplineScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val helplines by viewModel.helplines.collectAsState()
  val context = LocalContext.current

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = if (lang == "hi") "आपातकालीन व सरकारी सहायता हेल्पलाइन" else "Emergency & Government Helplines",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (lang == "hi") {
              "मुफ्त कॉल एवं 24 घंटे विधिक, प्रशासनिक व आपातकालीन सहायता नंबर।"
            } else {
              "Toll-free 24x7 emergency, legal aid, and citizen grievance hotlines."
            },
            fontSize = 13.sp,
            color = JhsSecondaryText
          )
        }
      }
    }

    items(helplines) { item ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = item.number,
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.ExtraBold,
                  color = JhsTeal
                )
              )
              Spacer(modifier = Modifier.width(8.dp))
              Surface(
                color = JhsGold.copy(alpha = 0.15f),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = item.timing,
                  color = JhsHeadingText,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = if (lang == "hi") item.nameHindi else item.nameEnglish,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = JhsHeadingText
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
              text = if (lang == "hi") item.descriptionHindi else item.descriptionEnglish,
              fontSize = 12.sp,
              color = JhsBodyText,
              lineHeight = 17.sp
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          FilledIconButton(
            onClick = {
              val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${item.number}"))
              context.startActivity(intent)
            },
            colors = IconButtonDefaults.filledIconButtonColors(
              containerColor = JhsTeal,
              contentColor = Color.White
            ),
            modifier = Modifier.size(48.dp)
          ) {
            Icon(Icons.Default.Phone, contentDescription = "Call ${item.number}", modifier = Modifier.size(22.dp))
          }
        }
      }
    }
  }
}

