package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExpertListing
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun ExpertDirectoryScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val experts by viewModel.experts.collectAsState()
  val context = LocalContext.current

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = if (lang == "hi") "विधिक विशेषज्ञ व सहायता संस्था निर्देशिका" else "Legal Aid & Expert Directory",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (lang == "hi") {
              "जिला विधिक सेवा प्राधिकरण (DLSA), उच्च न्यायालय विधिक क्लिनिक व निःशुल्क कानूनी सहायता।"
            } else {
              "District Legal Services Authority (DLSA), paralegal networks, and free legal aid."
            },
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
        }
      }
    }

    items(experts) { exp ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = exp.category,
                color = JhsTeal,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }

            Text(
              text = exp.geographicCoverage,
              fontSize = 12.sp,
              color = JhsSecondaryText
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = exp.name,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Text(
            text = exp.organization,
            fontSize = 12.sp,
            color = JhsSecondaryText
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = if (lang == "hi") exp.descriptionHindi else exp.descriptionEnglish,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            color = JhsBodyText
          )

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "${if (lang == "hi") "सहायता प्रक्रिया" else "Procedure"}: ${exp.referralProcess}",
                fontSize = 12.sp,
                color = JhsBodyText
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${if (lang == "hi") "संपर्क विवरण" else "Contact"}: ${exp.publicContact}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTeal
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = {
              val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:15100"))
              context.startActivity(intent)
            },
            modifier = Modifier
              .fillMaxWidth()
              .defaultMinSize(minHeight = 48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (lang == "hi") "विधिक सहायता से संपर्क करें" else "Contact Legal Aid", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }
  }
}
