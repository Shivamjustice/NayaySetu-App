package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun RtiCentreScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val authorities by viewModel.rtiAuthorities.collectAsState()
  val selectedAuth by viewModel.rtiSelectedAuthority.collectAsState()
  val applicantName by viewModel.rtiApplicantName.collectAsState()
  val address by viewModel.rtiAddress.collectAsState()
  val phone by viewModel.rtiPhone.collectAsState()
  val subject by viewModel.rtiSubject.collectAsState()
  val details by viewModel.rtiInformationDetails.collectAsState()
  val period by viewModel.rtiPeriod.collectAsState()
  val isBpl by viewModel.rtiIsBpl.collectAsState()
  val generatedDraft by viewModel.generatedRtiDraft.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  val context = LocalContext.current

  // Select first authority by default
  LaunchedEffect(authorities) {
    if (selectedAuth == null && authorities.isNotEmpty()) {
      viewModel.rtiSelectedAuthority.value = authorities.first()
    }
  }

  fun printOrSavePdf(title: String, textContent: String) {
    val html = """
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: sans-serif; font-size: 13pt; line-height: 1.5; padding: 25px; margin: 0; color: #111; }
          .header { text-align: center; border-bottom: 2px solid #176B63; padding-bottom: 8px; margin-bottom: 20px; }
          .title { font-size: 16pt; font-weight: bold; color: #176B63; }
          .subtitle { font-size: 11pt; color: #555; }
          .content { white-space: pre-wrap; font-family: monospace; font-size: 11pt; border: 1px solid #ddd; padding: 15px; border-radius: 6px; }
          .footer { margin-top: 30px; border-top: 1px solid #ccc; padding-top: 10px; font-size: 9pt; color: #777; text-align: center; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="title">जस्टिस हब सोसाइटी (JHS) — न्यायसेतु विधिक मंच</div>
          <div class="subtitle">सूचना का अधिकार अधिनियम, 2005 (Right to Information Act)</div>
        </div>
        <div class="content">$textContent</div>
        <div class="footer">यह औपचारिक ड्राफ्ट NyaySetu लीगल प्लेटफॉर्म द्वारा तैयार किया गया है।</div>
      </body>
      </html>
    """.trimIndent()

    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
      override fun onPageFinished(view: WebView?, url: String?) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val printAdapter = webView.createPrintDocumentAdapter(title)
        val printAttributes = PrintAttributes.Builder()
          .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
          .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
          .build()
        printManager.print(title, printAdapter, printAttributes)
      }
    }
    webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. RTI Overview Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "सूचना का अधिकार सहायता केंद्र (RTI Centre)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
              )
              Text(
                text = "पारदर्शिता व जवाबदेही: सरकारी योजनाओं व अभिलेखों की प्रमाणित प्रति प्राप्त करें",
                fontSize = 12.sp,
                color = JhsSecondaryText
              )
            }
            IconButton(
              onClick = {
                if (isSpeaking) {
                  viewModel.stopSpeech()
                } else {
                  viewModel.speak("सूचना का अधिकार अधिनियम 2005 के तहत हर नागरिक को सरकारी फाइलों, मस्टर रोल, खर्च और आदेशों की प्रमाणित प्रति पाने का विधिक अधिकार है। बीपीएल कार्डधारकों को यह पूर्णतः निःशुल्क मिलता है।")
                }
              },
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(JhsTealContainer)
            ) {
              Icon(
                imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                contentDescription = "Read RTI Overview",
                tint = JhsTeal,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // RTI Quick Rules Strip
          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsTeal.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(text = "विधिक नियम व समय-सीमा:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = JhsTealDark)
              Text("• धारा 6(1): आवेदन प्रस्तुत करने के 30 दिवस के भीतर जानकारी देना अनिवार्य है।", fontSize = 10.sp, color = JhsHeadingText)
              Text("• धारा 7(5): गरीबी रेखा से नीचे (BPL) परिवारों हेतु सम्पूर्ण जानकारी पूर्णतः निःशुल्क है।", fontSize = 10.sp, color = JhsHeadingText)
              Text("• धारा 19(1): 30 दिन में उत्तर न मिलने पर प्रथम अपीलीय अधिकारी को अपील प्रस्तुत की जा सकती है।", fontSize = 10.sp, color = JhsHeadingText)
            }
          }
        }
      }
    }

    // 2. Select Public Authority Carousel
    item {
      Text(text = "संबंधित शासकीय विभाग / लोक प्राधिकारी चुनें:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
      Spacer(modifier = Modifier.height(6.dp))
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(authorities) { auth ->
          val isSel = auth.id == selectedAuth?.id
          Card(
            modifier = Modifier
              .width(220.dp)
              .clickable { viewModel.rtiSelectedAuthority.value = auth },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSel) JhsSecondaryBg else Color.White
            ),
            border = BorderStroke(1.dp, if (isSel) JhsTeal else JhsBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = auth.departmentNameHindi,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = JhsHeadingText,
                maxLines = 2
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = auth.designationHindi,
                fontSize = 10.sp,
                color = JhsSecondaryText,
                maxLines = 1
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "शुल्क: ${auth.feeDetails}",
                fontSize = 10.sp,
                color = JhsTeal
              )
            }
          }
        }
      }
    }

    // 3. RTI Input Form
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(text = "आरटीआई आवेदन विवरण भरें:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JhsHeadingText)
          Spacer(modifier = Modifier.height(10.dp))

          val rtiInputColors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = JhsInputBg,
            unfocusedContainerColor = JhsInputBg,
            focusedBorderColor = JhsTeal,
            unfocusedBorderColor = JhsBorder,
            focusedTextColor = JhsHeadingText,
            unfocusedTextColor = JhsHeadingText,
            focusedPlaceholderColor = JhsPlaceholderText,
            unfocusedPlaceholderColor = JhsPlaceholderText
          )

          OutlinedTextField(
            value = applicantName,
            onValueChange = { viewModel.rtiApplicantName.value = it },
            label = { Text("आवेदक का नाम *", fontSize = 12.sp) },
            placeholder = { Text("उदा. रामदयाल सहरिया", fontSize = 11.sp) },
            colors = rtiInputColors,
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(8.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = address,
              onValueChange = { viewModel.rtiAddress.value = it },
              label = { Text("पता (गाँव/ब्लॉक/जिला) *", fontSize = 12.sp) },
              placeholder = { Text("सहरिया डांडा, कराहल", fontSize = 11.sp) },
              colors = rtiInputColors,
              shape = RoundedCornerShape(12.dp),
              singleLine = true,
              modifier = Modifier.weight(1.2f)
            )
            OutlinedTextField(
              value = phone,
              onValueChange = { viewModel.rtiPhone.value = it },
              label = { Text("मोबाइल नंबर", fontSize = 12.sp) },
              placeholder = { Text("9826XXXXXX", fontSize = 11.sp) },
              colors = rtiInputColors,
              shape = RoundedCornerShape(12.dp),
              singleLine = true,
              modifier = Modifier.weight(0.8f)
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          OutlinedTextField(
            value = subject,
            onValueChange = { viewModel.rtiSubject.value = it },
            label = { Text("आवेदन का विषय *", fontSize = 12.sp) },
            placeholder = { Text("उदा. मनरेगा मस्टर रोल व मजदूरी भुगतान की जानकारी", fontSize = 11.sp) },
            colors = rtiInputColors,
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(8.dp))

          OutlinedTextField(
            value = details,
            onValueChange = { viewModel.rtiInformationDetails.value = it },
            label = { Text("चाही गई जानकारी के विशिष्ट बिंदु *", fontSize = 12.sp) },
            placeholder = { Text("1. वर्ष 2025-26 के तालाब निर्माण का स्वीकृत प्राक्कलन व मस्टर रोल की प्रमाणित प्रति।\n2. मजदूरी भुगतान के बैंक ट्रांजैक्शन की तारीखवार सूची।", fontSize = 11.sp) },
            colors = rtiInputColors,
            shape = RoundedCornerShape(12.dp),
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "बीपीएल (गरीबी रेखा से नीचे) छूट:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = JhsHeadingText)
              Text(text = "बीपीएल कार्ड होने पर आवेदन व प्रतिलिपि शुल्क शून्य है", fontSize = 11.sp, color = JhsSecondaryText)
            }
            Switch(
              checked = isBpl,
              onCheckedChange = { viewModel.rtiIsBpl.value = it }
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { viewModel.generateRtiDraft(isFirstAppeal = false) },
              modifier = Modifier.weight(1f).height(48.dp),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal, contentColor = Color.White)
            ) {
              Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("धारा 6(1) आवेदन", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }

            OutlinedButton(
              onClick = { viewModel.generateRtiDraft(isFirstAppeal = true) },
              modifier = Modifier.weight(1f).height(48.dp),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, JhsBorder),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsHeadingText)
            ) {
              Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(16.dp), tint = JhsTeal)
              Spacer(modifier = Modifier.width(4.dp))
              Text("धारा 19(1) प्रथम अपील", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }

    // 4. Generated Official RTI Draft Card & Print / PDF Actions
    if (generatedDraft != null) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = JhsTeal)
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "तैयार विधिक आरटीआई ड्राफ्ट", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JhsHeadingText)
              }
              Surface(
                color = JhsSecondaryBg,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = "Official RTI Draft",
                  color = JhsTealDark,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
              color = JhsInputBg,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.dp, JhsBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = generatedDraft ?: "",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = JhsHeadingText,
                modifier = Modifier.padding(12.dp)
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: Print / PDF, Copy, Share
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Button(
                onClick = { printOrSavePdf("RTI_Application", generatedDraft ?: "") },
                modifier = Modifier.weight(1.1f).height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JhsTeal, contentColor = Color.White)
              ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("प्रिंट / PDF", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              }

              OutlinedButton(
                onClick = {
                  val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  val clip = ClipData.newPlainText("RTI Application", generatedDraft ?: "")
                  cm.setPrimaryClip(clip)
                  Toast.makeText(context, "ड्राफ्ट क्लिपबोर्ड पर कॉपी हो गया", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(0.9f).height(48.dp),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, JhsBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsHeadingText)
              ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp), tint = JhsTeal)
                Spacer(modifier = Modifier.width(3.dp))
                Text("कॉपी", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              }

              OutlinedButton(
                onClick = {
                  val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, generatedDraft ?: "")
                  }
                  context.startActivity(Intent.createChooser(shareIntent, "Share RTI Draft"))
                },
                modifier = Modifier.weight(0.9f).height(48.dp),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, JhsBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsHeadingText)
              ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp), tint = JhsTeal)
                Spacer(modifier = Modifier.width(3.dp))
                Text("शेयर", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              }
            }
          }
        }
      }
    }
  }
}
