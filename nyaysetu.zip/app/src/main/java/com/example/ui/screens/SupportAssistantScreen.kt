package com.example.ui.screens

import androidx.compose.runtime.Composable
import com.example.viewmodel.NyaySetuViewModel

/**
 * SupportAssistantScreen forwards to the full AI Voice Assistant implementation
 */
@Composable
fun SupportAssistantScreen(viewModel: NyaySetuViewModel) {
  AiVoiceAssistantScreen(viewModel = viewModel)
}
