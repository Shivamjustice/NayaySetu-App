package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LearningGuide
import com.example.ui.components.PvtgMasterGuideViewerDialog
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel

@Composable
fun LearningCentreScreen(viewModel: NyaySetuViewModel) {
  val lang by viewModel.currentLanguage.collectAsState()
  val guides by viewModel.learningGuides.collectAsState()
  val isSpeaking by viewModel.ttsHelper.isSpeaking.collectAsState()
  var expandedGuideId by remember { mutableStateOf<String?>("lg-fra") }
  var showMasterGuideSheet by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Header Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "प्रशिक्षण व जागरूकता केंद्र (Learning Centre)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "कानूनी प्रावधानों के सरल मार्गदर्शक, मुख्य नियम एवं प्रशासनिक शब्दावली का अर्थ",
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
        }
      }
    }

    // Special Banner: PVTG & Tribal Master Guide (Part 1 - 16)
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { showMasterGuideSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.5.dp, JhsTeal.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsTerracottaContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = "📜 महा-मार्गदर्शिका (16 भाग)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTerracotta,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
            Surface(
              color = JhsTealContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "ऑडियो सुनें",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTealDark
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "मध्य प्रदेश आदिवासी एवं PVTG महा-मार्गदर्शिका",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = JhsHeadingText
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "सहरिया, बैगा, भारिया योजनाएं • 16 अनिवार्य दस्तावेज़ • सरकारी फीस व अवैध वसूली रोकथाम • 32 आधिकारिक पोर्टल • 12 केस स्टडीज • शिकायत पत्र प्रारूप",
            fontSize = 12.sp,
            color = JhsBodyText,
            lineHeight = 16.sp
          )
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = { showMasterGuideSheet = true },
            modifier = Modifier
              .fillMaxWidth()
              .height(42.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("सम्पूर्ण 16 भाग पढ़ें व ऑडियो सुनें", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
          }
        }
      }
    }

    // 2. Guides List
    items(guides) { guide ->
      val isExpanded = expandedGuideId == guide.id
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { expandedGuideId = if (isExpanded) null else guide.id },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = JhsSecondaryBg,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = guide.category,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = JhsTeal,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
            IconButton(
              onClick = {
                if (isSpeaking) {
                  viewModel.stopSpeech()
                } else {
                  viewModel.speak("${guide.titleHindi}. ${guide.summaryHindi}. ${guide.fullContentHindi}")
                }
              },
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(JhsSecondaryBg)
            ) {
              Icon(
                imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                contentDescription = "Read Aloud",
                tint = JhsTeal,
                modifier = Modifier.size(20.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = guide.titleHindi,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = JhsHeadingText)
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(text = guide.summaryHindi, fontSize = 13.sp, lineHeight = 18.sp, color = JhsBodyText)

          // Key Takeaways Strip
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            color = JhsSecondaryBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, JhsBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(text = "मुख्य विधिक बिंदु:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = JhsHeadingText)
              Spacer(modifier = Modifier.height(4.dp))
              guide.keyTakeaways.forEach { kt ->
                Text(text = "• $kt", fontSize = 12.sp, lineHeight = 16.sp, color = JhsBodyText, modifier = Modifier.padding(vertical = 1.dp))
              }
            }
          }

          // Full content and simplified glossary
          AnimatedVisibility(visible = isExpanded) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              HorizontalDivider(color = JhsBorder)

              Text(text = "विस्तृत विवरण व कानूनी व्याख्या:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JhsHeadingText)
              Text(text = guide.fullContentHindi, fontSize = 12.sp, lineHeight = 18.sp, color = JhsBodyText)

              // Simplified Glossary
              if (guide.simplifiedGlossary.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                  color = JhsSecondaryBg.copy(alpha = 0.5f),
                  shape = RoundedCornerShape(10.dp),
                  border = BorderStroke(1.dp, JhsBorder),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "📖 कानूनी व प्रशासनिक शब्दावली का सरल अर्थ:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = JhsTerracotta)
                    Spacer(modifier = Modifier.height(6.dp))
                    guide.simplifiedGlossary.forEach { (term, meaning) ->
                      Text(text = "• $term: $meaning", fontSize = 12.sp, lineHeight = 16.sp, color = JhsBodyText, modifier = Modifier.padding(vertical = 2.dp))
                    }
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            Text(
              text = if (isExpanded) "कम विवरण देखें ▲" else "विस्तार से पढ़ें व समझें ▼",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = JhsTeal
            )
          }
        }
      }
    }
  }

  if (showMasterGuideSheet) {
    PvtgMasterGuideViewerDialog(
      viewModel = viewModel,
      onDismiss = { showMasterGuideSheet = false }
    )
  }
}
