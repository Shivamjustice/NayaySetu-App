package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CaseRecord
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel
import com.example.viewmodel.ScreenTab

@Composable
fun ProfileScreen(viewModel: NyaySetuViewModel) {
  val user by viewModel.currentUser.collectAsState()
  val lang by viewModel.currentLanguage.collectAsState()
  val highContrast by viewModel.highContrastMode.collectAsState()
  val visibleCases by viewModel.userVisibleCases.collectAsState()
  val context = LocalContext.current

  var isEditingProfile by remember { mutableStateOf(false) }
  var editName by remember(user) { mutableStateOf(user?.name ?: "") }
  var editPhone by remember(user) { mutableStateOf(user?.phone ?: "") }
  var editVillage by remember(user) { mutableStateOf(user?.village ?: "") }
  var editBlock by remember(user) { mutableStateOf(user?.block ?: "") }
  var editDistrict by remember(user) { mutableStateOf(user?.district ?: "") }
  var editBio by remember(user) { mutableStateOf(user?.bio ?: "") }
  var selectedAvatarIndex by remember(user) { mutableStateOf(user?.avatarIndex ?: 0) }

  // Avatar Icons to choose from
  val avatarIcons = listOf(
    Icons.Default.AccountCircle,
    Icons.Default.Face,
    Icons.Default.Person,
    Icons.Default.Engineering,
    Icons.Default.Psychology,
    Icons.Default.Shield
  )

  val avatarBgColors = listOf(
    0xFF176B63, // JhsTeal
    0xFF0B443E, // JhsTealDark
    0xFFC56A3D, // JhsTerracotta
    0xFF8E3B1B, // JhsTerracottaDark
    0xFFE3A72F, // JhsGold
    0xFF3D5A80  // Navy slate
  )

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Prominent Member Picture & Profile Header
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          val galleryLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
            contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
          ) { uri: Uri? ->
            uri?.let { viewModel.updateProfilePhoto(it.toString()) }
          }

          // Member Picture / Avatar Container
          Box(
            modifier = Modifier
              .size(90.dp)
              .clip(CircleShape)
              .background(Color(avatarBgColors[selectedAvatarIndex.coerceIn(0, avatarBgColors.size - 1)]))
              .border(3.dp, JhsGold, CircleShape)
              .clickable { galleryLauncher.launch("image/*") },
            contentAlignment = Alignment.Center
          ) {
            if (!user?.profilePhotoUri.isNullOrBlank()) {
              coil.compose.AsyncImage(
                model = user?.profilePhotoUri,
                contentDescription = "Profile Photo",
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            } else {
              Icon(
                imageVector = avatarIcons[selectedAvatarIndex.coerceIn(0, avatarIcons.size - 1)],
                contentDescription = "Profile Picture",
                tint = Color.White,
                modifier = Modifier.size(54.dp)
              )
            }

            // Edit badge on picture
            Box(
              modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(26.dp)
                .clip(CircleShape)
                .background(JhsTerracotta),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.PhotoCamera, contentDescription = "Upload Photo", tint = Color.White, modifier = Modifier.size(14.dp))
            }
          }

          Spacer(modifier = Modifier.height(4.dp))
          TextButton(onClick = { galleryLauncher.launch("image/*") }) {
            Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp), tint = JhsTeal)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              viewModel.tr("गैलरी से फोटो लगाएं", "Choose Photo from Gallery", "Gallery se photo lagayein"),
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = JhsTeal
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Member Name
          Text(
            text = user?.name ?: viewModel.tr("नागरिक सदस्य", "Citizen Member", "Citizen Member"),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = JhsCharcoal)
          )

          Spacer(modifier = Modifier.height(2.dp))

          Text(
            text = "@${user?.username ?: "user"} • 📞 ${user?.phone?.ifBlank { viewModel.tr("नंबर दर्ज नहीं", "No Phone", "No Phone") } ?: ""}",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.outline
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = if (user?.role == UserRole.ADMIN) JhsTerracotta.copy(alpha = 0.15f) else JhsTealContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = user?.role?.labelFor(lang) ?: viewModel.tr("समुदाय नागरिक", "Community Member", "Community Member"),
                color = if (user?.role == UserRole.ADMIN) JhsTerracottaDark else JhsOnTealContainer,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }

            Surface(
              color = if (user?.isVerifiedByAdmin == true) Color(0xFFE8F5E9) else JhsGoldContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = if (user?.isVerifiedByAdmin == true) Icons.Default.CheckCircle else Icons.Default.HourglassTop,
                  contentDescription = null,
                  tint = if (user?.isVerifiedByAdmin == true) Color(0xFF2E7D32) else JhsGoldDark,
                  modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (user?.isVerifiedByAdmin == true) {
                    viewModel.tr("सत्यापित सदस्य", "Verified Member", "Verified Member")
                  } else {
                    viewModel.tr("सत्यापन प्रतीक्षित", "Verification Pending", "Verification Pending")
                  },
                  color = if (user?.isVerifiedByAdmin == true) Color(0xFF2E7D32) else JhsGoldDark,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Member Residence & Bio
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = JhsTeal, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "${user?.village ?: viewModel.tr("गाँव", "Village", "Village")}, ${user?.block ?: viewModel.tr("ब्लॉक", "Block", "Block")}, ${user?.district ?: viewModel.tr("जिला", "District", "District")}",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
              if (!user?.bio.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "${viewModel.tr("परिचय:", "Bio:", "Bio:")} ${user?.bio}",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Edit Profile Action Button
          Button(
            onClick = {
              editName = user?.name ?: ""
              editPhone = user?.phone ?: ""
              editVillage = user?.village ?: ""
              editBlock = user?.block ?: ""
              editDistrict = user?.district ?: ""
              editBio = user?.bio ?: ""
              selectedAvatarIndex = user?.avatarIndex ?: 0
              isEditingProfile = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
            modifier = Modifier
              .defaultMinSize(minHeight = 48.dp)
              .testTag("edit_profile_button")
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = viewModel.tr("प्रोफ़ाइल एडिट करें", "Edit Profile", "Profile Edit Karein"),
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }

    // 2. Member's Registered Cases (Person sees ONLY their cases)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = if (user?.role == UserRole.ADMIN) {
              viewModel.tr("संगठन के सभी मामले (All Cases):", "All Organization Cases:", "Sabhi Cases (All Cases):")
            } else {
              viewModel.tr("मेरे पंजीकृत मामले (My Cases):", "My Registered Cases:", "Mere Registered Cases:")
            },
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = JhsHeadingText
          )
          Text(
            text = if (user?.role == UserRole.ADMIN) {
              viewModel.tr("एडमिन मोड: समस्त नागरिक मामले दृश्यमान", "Admin Mode: All citizen cases visible", "Admin Mode: Sabhi citizen cases")
            } else {
              viewModel.tr("आपके द्वारा दर्ज या आपके नाम से संबद्ध विधिक मामले", "Legal cases submitted by or associated with you", "Aapke dwara darj legal cases")
            },
            fontSize = 12.sp,
            color = JhsSecondaryText
          )
        }

        Surface(
          color = JhsSecondaryBg,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            text = "${visibleCases.size} ${viewModel.tr("मामले", "Cases", "Cases")}",
            color = JhsTeal,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }
    }

    if (visibleCases.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(Icons.Default.FolderOpen, contentDescription = null, tint = JhsSecondaryText, modifier = Modifier.size(40.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = viewModel.tr(
                "आपके नाम पर अभी कोई मामला दर्ज नहीं है।",
                "No cases are currently registered under your profile.",
                "Aapke naam par abhi koi case darj nahi hai."
              ),
              fontSize = 13.sp,
              color = JhsBodyText
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
              onClick = { viewModel.openWizard() },
              colors = ButtonDefaults.buttonColors(containerColor = JhsTeal),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.defaultMinSize(minHeight = 48.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                viewModel.tr("नया मामला दर्ज करें", "Submit New Case", "Naya Case Darj Karein"),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }
      }
    } else {
      items(visibleCases) { c ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JhsWhite),
          border = BorderStroke(1.dp, JhsBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = c.id,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = JhsTeal
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                  color = JhsGold.copy(alpha = 0.15f),
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Text(
                    text = "PIN: ${c.verificationPin}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = JhsHeadingText,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }

              Surface(
                color = JhsSecondaryBg,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = "${c.status.stepIndex}/13: ${c.status.labelFor(lang)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = JhsTeal,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = c.title,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = JhsHeadingText
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = "${viewModel.tr("आवेदक:", "Applicant:", "Applicant:")} ${c.applicantName} • ${c.village}, ${c.district}",
              fontSize = 12.sp,
              color = JhsBodyText
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${viewModel.tr("प्राप्त दिनांक:", "Date Received:", "Date Received:")} ${c.dateReceived}",
                fontSize = 11.sp,
                color = JhsSecondaryText
              )

              FilledTonalButton(
                onClick = { viewModel.setTrackingTarget(c.id, c.verificationPin) },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                  containerColor = JhsSecondaryBg,
                  contentColor = JhsTeal
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.defaultMinSize(minHeight = 40.dp)
              ) {
                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = viewModel.tr("स्थिति देखें ➔", "Track Status ➔", "Status Dekhein ➔"),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }
        }
      }
    }

    // 3. Settings & Language Switcher
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JhsWhite),
        border = BorderStroke(1.dp, JhsBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = viewModel.tr("ऐप भाषा व सेटिंग्स", "App Language & Settings", "App Settings"),
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = JhsHeadingText
          )
          Spacer(modifier = Modifier.height(12.dp))

          // Language Switcher Options
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            listOf(
              Pair("hi", "हिन्दी"),
              Pair("hinglish", "Hinglish"),
              Pair("en", "English")
            ).forEach { (code, label) ->
              val isSelected = lang == code
              Surface(
                onClick = { viewModel.setLanguage(code) },
                modifier = Modifier
                  .weight(1f)
                  .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) JhsTeal else JhsWhite,
                border = if (isSelected) null else BorderStroke(1.dp, JhsBorder)
              ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                  Text(
                    text = label,
                    color = if (isSelected) Color.White else JhsHeadingText,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                    fontSize = 13.sp
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Sunlight Mode Switch
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.WbSunny, contentDescription = null, tint = JhsGold)
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = viewModel.tr("तेज धूप / आउटडोर मोड", "High-Contrast Sunlight Mode", "Sunlight Mode"),
                fontSize = 13.sp,
                color = JhsBodyText
              )
            }
            Switch(
              checked = highContrast,
              onCheckedChange = { viewModel.toggleHighContrast() },
              colors = SwitchDefaults.colors(
                checkedThumbColor = JhsWhite,
                checkedTrackColor = JhsTeal
              )
            )
          }
        }
      }
    }

    // 4. Logout Button
    item {
      OutlinedButton(
        onClick = { viewModel.logout() },
        modifier = Modifier
          .fillMaxWidth()
          .defaultMinSize(minHeight = 48.dp)
          .testTag("logout_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = JhsTerracotta),
        border = BorderStroke(1.dp, JhsTerracotta.copy(alpha = 0.5f))
      ) {
        Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = viewModel.tr("खाते से लॉगआउट करें", "Log Out of Account", "Logout Karein"),
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        )
      }
    }
  }

  // Edit Profile Dialog
  if (isEditingProfile) {
    AlertDialog(
      onDismissRequest = { isEditingProfile = false },
      title = {
        Text(
          text = "प्रोफ़ाइल विवरण एडिट करें (Edit Profile)",
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = JhsTealDark
        )
      },
      text = {
        LazyColumn(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          item {
            Text("अवतार चित्र चुनें (Select Avatar):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              items(avatarIcons.size) { idx ->
                val isSel = idx == selectedAvatarIndex
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(avatarBgColors[idx]))
                    .border(if (isSel) 3.dp else 1.dp, if (isSel) JhsGold else Color.Transparent, CircleShape)
                    .clickable { selectedAvatarIndex = idx },
                  contentAlignment = Alignment.Center
                ) {
                  Icon(avatarIcons[idx], contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                }
              }
            }
          }

          item {
            OutlinedTextField(
              value = editName,
              onValueChange = { editName = it },
              label = { Text("पूरा नाम (Full Name)") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
          }

          item {
            OutlinedTextField(
              value = editPhone,
              onValueChange = { editPhone = it },
              label = { Text("मोबाइल नंबर (Phone)") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
          }

          item {
            OutlinedTextField(
              value = editVillage,
              onValueChange = { editVillage = it },
              label = { Text("गाँव / टोला (Village)") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              OutlinedTextField(
                value = editBlock,
                onValueChange = { editBlock = it },
                label = { Text("ब्लॉक (Block)") },
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
              OutlinedTextField(
                value = editDistrict,
                onValueChange = { editDistrict = it },
                label = { Text("जिला (District)") },
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            OutlinedTextField(
              value = editBio,
              onValueChange = { editBio = it },
              label = { Text("संक्षिप्त परिचय (Bio)") },
              maxLines = 3,
              modifier = Modifier.fillMaxWidth()
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.updateProfile(
              name = editName,
              phone = editPhone,
              village = editVillage,
              block = editBlock,
              district = editDistrict,
              bio = editBio,
              avatarIndex = selectedAvatarIndex
            )
            isEditingProfile = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = JhsTeal)
        ) {
          Text("सहेजें (Save Changes)")
        }
      },
      dismissButton = {
        TextButton(onClick = { isEditingProfile = false }) {
          Text("रद्द करें (Cancel)")
        }
      }
    )
  }
}
