package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.NyaySetuViewModel
import com.example.viewmodel.ScreenTab

@Composable
fun BottomNavBar(
  viewModel: NyaySetuViewModel,
  onOpenMoreMenu: () -> Unit
) {
  val activeTab by viewModel.activeTab.collectAsState()
  val lang by viewModel.currentLanguage.collectAsState()

  val itemColors = NavigationBarItemDefaults.colors(
    selectedIconColor = JhsTeal,
    selectedTextColor = JhsTeal,
    indicatorColor = JhsSecondaryBg,
    unselectedIconColor = JhsSecondaryText,
    unselectedTextColor = JhsSecondaryText
  )

  NavigationBar(
    modifier = Modifier
      .windowInsetsPadding(WindowInsets.navigationBars)
      .testTag("bottom_nav_bar"),
    containerColor = JhsWhite,
    tonalElevation = 2.dp
  ) {
    NavigationBarItem(
      selected = activeTab == ScreenTab.HOME,
      onClick = { viewModel.setTab(ScreenTab.HOME) },
      icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
      label = { Text(viewModel.tr("होम", "Home", "Home"), fontSize = 10.sp, fontWeight = if (activeTab == ScreenTab.HOME) FontWeight.Bold else FontWeight.Normal) },
      colors = itemColors,
      modifier = Modifier.testTag("nav_home")
    )

    NavigationBarItem(
      selected = activeTab == ScreenTab.SCHEMES,
      onClick = { viewModel.setTab(ScreenTab.SCHEMES) },
      icon = { Icon(Icons.Default.AccountBalance, contentDescription = "Schemes") },
      label = { Text(viewModel.tr("योजनाएं", "Schemes", "Schemes"), fontSize = 10.sp, fontWeight = if (activeTab == ScreenTab.SCHEMES) FontWeight.Bold else FontWeight.Normal) },
      colors = itemColors,
      modifier = Modifier.testTag("nav_schemes")
    )

    NavigationBarItem(
      selected = activeTab == ScreenTab.BUILDER,
      onClick = { viewModel.setTab(ScreenTab.BUILDER) },
      icon = { Icon(Icons.Default.Description, contentDescription = "Application Builder") },
      label = { Text(viewModel.tr("आवेदन", "Apply", "Application"), fontSize = 10.sp) },
      colors = itemColors,
      modifier = Modifier.testTag("nav_builder")
    )

    NavigationBarItem(
      selected = activeTab == ScreenTab.PROFILE || activeTab == ScreenTab.TRACK,
      onClick = { viewModel.setTab(ScreenTab.PROFILE) },
      icon = { Icon(Icons.Default.Person, contentDescription = "My Info") },
      label = { Text(viewModel.tr("मेरी जानकारी", "My Info", "My Info"), fontSize = 10.sp, fontWeight = if (activeTab == ScreenTab.PROFILE || activeTab == ScreenTab.TRACK) FontWeight.Bold else FontWeight.Normal) },
      colors = itemColors,
      modifier = Modifier.testTag("nav_profile")
    )

    NavigationBarItem(
      selected = activeTab == ScreenTab.HELPLINE,
      onClick = { viewModel.setTab(ScreenTab.HELPLINE) },
      icon = { Icon(Icons.Default.SupportAgent, contentDescription = "Help") },
      label = { Text(viewModel.tr("मदद", "Help", "Madad"), fontSize = 10.sp, fontWeight = if (activeTab == ScreenTab.HELPLINE) FontWeight.Bold else FontWeight.Normal) },
      colors = itemColors,
      modifier = Modifier.testTag("nav_help")
    )
  }
}
